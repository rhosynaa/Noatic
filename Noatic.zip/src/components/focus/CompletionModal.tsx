"use client";

import { AlarmClockCheck, BellOff, Play, SkipForward, TimerReset } from "lucide-react";
import { Modal } from "@/components/ui";
import { useFocus } from "@/lib/focus-context";
import { TIMER_KIND_META } from "@/lib/types";

export default function CompletionModal() {
  const { completeInfo, dismissComplete, snooze, startNextNow, chainRun, transition } =
    useFocus();

  if (!completeInfo) return null;
  const meta = TIMER_KIND_META[completeInfo.kind] ?? TIMER_KIND_META.focus;
  const nextLabel = transition?.next?.label || transition?.next?.kind;
  const nextMins = transition?.next?.minutes;

  return (
    <Modal open onClose={dismissComplete}>
      <div className="flex flex-col items-center gap-5 px-6 py-8 text-center">
        <span
          className="animate-pop flex h-16 w-16 items-center justify-center rounded-full"
          style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
        >
          <AlarmClockCheck size={28} />
        </span>

        <div>
          <h2 className="font-display text-[26px] font-semibold" style={{ color: "var(--ink)" }}>
            Session Complete!
          </h2>
          <p className="mt-1 text-[13px]" style={{ color: "var(--ink-soft)" }}>
            {meta.label}
            {completeInfo.label ? ` · ${completeInfo.label}` : ""} ·{" "}
            {completeInfo.minutes} min
            {completeInfo.subject ? ` · ${completeInfo.subject}` : ""} — logged to analytics.
          </p>
        </div>

        {transition && nextLabel ? (
          <p
            className="rounded-full px-4 py-1.5 text-[12px] font-bold tabular-nums"
            style={{ background: "var(--surface-2)", color: "var(--accent)" }}
          >
            Next: {nextLabel}
            {nextMins ? ` (${nextMins}m)` : ""} in {transition.count}s…
          </p>
        ) : (
          <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
            The alarm silences itself after one minute.
          </p>
        )}

        <button
          onClick={dismissComplete}
          className="btn-accent w-full justify-center px-5 py-3.5 text-[14px] font-bold"
          autoFocus
        >
          <BellOff size={17} /> Stop Alarm
        </button>

        <div className="flex w-full gap-2">
          <button
            onClick={snooze}
            className="btn-ghost flex-1 justify-center px-4 py-2.5 text-[12.5px] font-semibold"
          >
            <TimerReset size={14} /> Snooze for 5 min
          </button>
          {completeInfo.hasNext && chainRun && (
            <button
              onClick={startNextNow}
              className="btn-ghost flex-1 justify-center px-4 py-2.5 text-[12.5px] font-semibold"
              style={{ borderColor: "var(--accent)", color: "var(--accent)" }}
            >
              {transition ? <SkipForward size={14} /> : <Play size={14} />} Start Next Session
            </button>
          )}
        </div>

        {chainRun && (
          <p className="text-[11px] font-semibold tracking-[0.08em] uppercase" style={{ color: "var(--ink-faint)" }}>
            {chainRun.name} · step {chainRun.index + 1} of {chainRun.steps.length}
          </p>
        )}
      </div>
    </Modal>
  );
}
