"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ChevronDown,
  Coffee,
  Pause,
  Play,
  RotateCcw,
  SkipForward,
  Square,
  Settings2,
  Timer,
  Workflow,
  X,
} from "lucide-react";
import { useFocus } from "@/lib/focus-context";
import {
  DEADLINE_COLORS,
  TIMER_KIND_META,
  type Note,
  type ProgressData,
  type TargetProgress,
} from "@/lib/types";
import { useDashboard } from "@/lib/dashboard-context";
import { useSections } from "@/lib/sections-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";

function fmt(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = (sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function NoteFocusWidget({ note }: { note: Note }) {
  const { subjects } = useDashboard();
  const { openSection } = useSections();
  const { push } = useToast();
  const focus = useFocus();
  const [expanded, setExpanded] = useState(false);

  const subjectName = note.subject.trim();
  const subjectColor = useMemo(
    () =>
      subjects.find((s) => s.name.toLowerCase() === subjectName.toLowerCase())?.color ?? "rose",
    [subjects, subjectName]
  );
  const dot = DEADLINE_COLORS[subjectColor] ?? "var(--accent)";

  /* closing the note stops any timer that was started from this note */
  const { stopSessionFromNote } = focus;
  useEffect(() => {
    return () => stopSessionFromNote(note.id);
  }, [note.id, stopSessionFromNote]);

  const matchesSubject =
    subjectName !== "" && focus.subject.trim().toLowerCase() === subjectName.toLowerCase();
  const mine = focus.sessionActive && (focus.activeNoteId === note.id || matchesSubject);
  const busyElsewhere = focus.sessionActive && !mine;

  /* chains that belong to this note's subject (or are general) */
  const relevantChains = useMemo(
    () =>
      focus.chains.filter(
        (c) =>
          !c.subject ||
          (subjectName && c.subject.trim().toLowerCase() === subjectName.toLowerCase())
      ),
    [focus.chains, subjectName]
  );

  // custom presets for this subject + the "Any Subject" ones
  const notePresets = useMemo(
    () => focus.presetsFor(subjectName),
    [focus, subjectName]
  );

  const quickStart = () =>
    focus.startSession({ kind: "focus", minutes: 25, subject: subjectName, label: "" }, note.id);

  /** jump to the full Focus Timer sidebar */
  const openFullTimer = () => {
    setExpanded(false);
    openSection("timer");
  };

  /* ---- per-note target hours ---- */
  const [noteTarget, setNoteTarget] = useState<TargetProgress | null>(null);
  const [targetDraft, setTargetDraft] = useState(5);

  const loadTarget = useCallback(async () => {
    try {
      const data = await api<ProgressData>("/api/progress");
      setNoteTarget(
        data.targets.find((t) => t.scope === "note" && t.ref === note.id) ?? null
      );
    } catch {
      /* quiet — targets are optional */
    }
  }, [note.id]);

  // refresh when the panel opens and whenever a session finishes
  useEffect(() => {
    if (!expanded) return;
    void loadTarget();
  }, [expanded, loadTarget, focus.sessionActive]);

  const saveNoteTarget = async () => {
    if (targetDraft <= 0) {
      push("error", "Target hours must be greater than zero");
      return;
    }
    try {
      await api("/api/study-targets", {
        method: "POST",
        body: { scope: "note", ref: note.id, targetHours: targetDraft },
      });
      push("success", "Target set — this note's time counts toward it");
      await loadTarget();
    } catch (e) {
      push("error", e instanceof Error ? e.message : "Couldn't set that target");
    }
  };

  const pct = focus.totalSec ? 1 - focus.leftSec / focus.totalSec : 0;
  const kindMeta = TIMER_KIND_META[focus.kind] ?? TIMER_KIND_META.focus;

  return (
    <div className="relative shrink-0 select-none">
      <div
        className="flex items-center gap-1 rounded-full py-1 pr-1 pl-2.5 text-[12px] font-bold"
        style={{
          background: mine ? "var(--accent-soft)" : "var(--surface-2)",
          border: `1px solid ${mine ? "var(--accent)" : "var(--line)"}`,
          color: "var(--ink)",
        }}
      >
        {mine ? (
          <>
            <button
              onClick={openFullTimer}
              title="Open the full Focus Timer"
              aria-label="Open the full Focus Timer"
              className="flex items-center gap-1.5 rounded-full px-0.5 transition-opacity hover:opacity-75"
            >
              <span
                className={`h-2 w-2 rounded-full ${focus.running ? "animate-pulse" : ""}`}
                style={{ background: focus.running ? "#6d9e7d" : "#cf9c44" }}
              />
              <span className="tabular-nums">{fmt(focus.leftSec)}</span>
              {subjectName && (
                <span className="max-w-[80px] truncate font-semibold" style={{ color: "var(--ink-soft)" }}>
                  {subjectName}
                </span>
              )}
            </button>
            <button
              onClick={focus.toggle}
              aria-label={focus.running ? "Pause" : "Resume"}
              className="flex h-6 w-6 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-3)]"
              style={{ color: "var(--accent)" }}
            >
              {focus.running ? <Pause size={12} /> : <Play size={12} className="ml-px" />}
            </button>
            <button
              onClick={focus.cancelSession}
              aria-label="Cancel and close timer"
              title="Cancel timer"
              className="flex h-6 w-6 items-center justify-center rounded-full transition-colors hover:bg-red-500/10 hover:text-red-500"
              style={{ color: "var(--ink-faint)" }}
            >
              <X size={12} />
            </button>
          </>
        ) : busyElsewhere ? (
          <button
            onClick={openFullTimer}
            title="Open the full Focus Timer"
            aria-label="Open the full Focus Timer"
            className="flex items-center gap-1.5 rounded-full px-0.5 transition-opacity hover:opacity-75"
          >
            <Coffee size={13} style={{ color: "var(--ink-faint)" }} />
            <span style={{ color: "var(--ink-faint)" }}>No active timer</span>
          </button>
        ) : (
          <>
            <button
              onClick={openFullTimer}
              title="Open the full Focus Timer"
              aria-label="Open the full Focus Timer"
              className="flex items-center gap-1.5 rounded-full px-0.5 transition-opacity hover:opacity-75"
            >
              <Timer size={13} style={{ color: "var(--accent)" }} />
              <span style={{ color: "var(--ink-soft)" }}>Focus timer</span>
            </button>
            <button
              onClick={quickStart}
              aria-label="Start focus session for this note"
              title="Start 25 min focus for this note"
              className="flex h-6 w-6 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-3)]"
              style={{ color: "var(--accent)" }}
            >
              <Play size={12} className="ml-px" />
            </button>
          </>
        )}
        <button
          onClick={() => setExpanded((v) => !v)}
          aria-label={expanded ? "Collapse timer" : "Expand timer controls"}
          className="flex h-6 w-6 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-3)]"
          style={{ color: "var(--ink-faint)" }}
        >
          <ChevronDown
            size={13}
            style={{ transform: expanded ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}
          />
        </button>
      </div>

      {expanded && (
        <div
          className="animate-pop absolute right-0 z-30 mt-2 w-[262px] rounded-2xl p-4"
          style={{
            background: "var(--surface)",
            border: "1px solid var(--line)",
            boxShadow: "var(--card-shadow-hover)",
          }}
        >
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
              <span className="h-2 w-2 rounded-full" style={{ background: dot }} />
              {subjectName || "General"}
            </p>
            {mine && (
              <span className="text-[10px] font-bold uppercase" style={{ color: "var(--accent)" }}>
                {kindMeta.label}
              </span>
            )}
          </div>

          {mine ? (
            <>
              <div className="mt-3 flex items-center justify-center">
                <div className="relative flex h-24 w-24 items-center justify-center">
                  <svg viewBox="0 0 96 96" className="absolute inset-0 h-full w-full -rotate-90">
                    <circle cx="48" cy="48" r="42" fill="none" stroke="var(--line)" strokeWidth="6" />
                    <circle
                      cx="48" cy="48" r="42" fill="none"
                      stroke="var(--accent)" strokeWidth="6" strokeLinecap="round"
                      strokeDasharray={`${pct * 264} 264`}
                      style={{ transition: "stroke-dasharray 0.9s linear" }}
                    />
                  </svg>
                  <div className="text-center">
                    <p className="font-display text-[22px] leading-none font-semibold tabular-nums" style={{ color: "var(--ink)" }}>
                      {fmt(focus.leftSec)}
                    </p>
                    <p className="mt-0.5 text-[9.5px] font-bold tracking-[0.1em] uppercase" style={{ color: focus.running ? "var(--accent)" : "var(--ink-faint)" }}>
                      {focus.running ? "active" : "paused"}
                    </p>
                  </div>
                </div>
              </div>

              {focus.label && (
                <p className="mt-2 truncate text-center text-[11px]" style={{ color: "var(--ink-soft)" }}>
                  {focus.label}
                </p>
              )}

              {focus.chainRun && (
                <div className="mt-2">
                  <div className="flex items-center justify-between text-[10px] font-bold" style={{ color: "var(--ink-faint)" }}>
                    <span className="truncate">{focus.chainRun.name}</span>
                    <span className="tabular-nums">
                      Session {focus.chainRun.index + 1} of {focus.chainRun.steps.length}
                    </span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${(((focus.chainRun.index + pct) / focus.chainRun.steps.length) * 100).toFixed(1)}%`,
                        background: "var(--accent)",
                      }}
                    />
                  </div>
                </div>
              )}

              {focus.transition && (
                <p className="mt-2 text-center text-[11px] font-bold tabular-nums" style={{ color: "var(--accent)" }}>
                  Next: {focus.transition.next?.label || focus.transition.next?.kind} in{" "}
                  {focus.transition.count}s…
                </p>
              )}

              {/* read-only: pause/resume, reset the clock, skip, cancel — no duration editing */}
              <div className="mt-3 flex items-center justify-center gap-1.5">
                <button onClick={focus.toggle} className="btn-accent h-9 w-9 !rounded-full !p-0" aria-label={focus.running ? "Pause" : "Resume"}>
                  {focus.running ? <Pause size={15} /> : <Play size={15} className="ml-0.5" />}
                </button>
                <button onClick={focus.resetClock} className="btn-ghost h-9 w-9 !p-0" aria-label="Reset time" title="Reset time">
                  <RotateCcw size={14} />
                </button>
                {focus.chainRun && (
                  <>
                    <button onClick={focus.skipToNext} className="btn-ghost h-9 w-9 !p-0" aria-label="Skip to next session" title="Skip to next">
                      <SkipForward size={14} />
                    </button>
                    <button onClick={focus.restartChain} className="btn-ghost h-9 w-9 !p-0" aria-label="Restart chain" title="Restart chain">
                      <Workflow size={14} />
                    </button>
                  </>
                )}
                <button
                  onClick={focus.cancelSession}
                  className="btn-ghost h-9 w-9 !p-0 hover:!text-red-500"
                  aria-label="Cancel timer"
                  title="Cancel timer"
                >
                  <X size={14} />
                </button>
              </div>
              <p className="mt-2 text-center text-[10px]" style={{ color: "var(--ink-faint)" }}>
                Read-only here — edit durations in the Timer section.
              </p>
            </>
          ) : (
            <div className="mt-3">
              <p className="text-center text-[12px]" style={{ color: "var(--ink-faint)" }}>
                {busyElsewhere
                  ? `No active timer for ${subjectName || "this note"} — a session is running elsewhere.`
                  : "No active timer — start a study session for this note."}
              </p>
              <button onClick={quickStart} className="btn-accent mt-3 w-full justify-center px-3 py-2 text-[12px] font-bold">
                <Play size={13} /> Start Session · 25m
              </button>
              <div className="mt-2 flex justify-center gap-1.5">
                {[15, 45, 60].map((m) => (
                  <button
                    key={m}
                    onClick={() =>
                      focus.startSession(
                        { kind: "focus", minutes: m, subject: subjectName, label: "" },
                        note.id
                      )
                    }
                    className="rounded-full px-3 py-1 text-[11px] font-bold transition-colors hover:bg-[var(--surface-3)]"
                    style={{ background: "var(--surface-2)", color: "var(--ink-soft)", border: "1px solid var(--line)" }}
                  >
                    {m}m
                  </button>
                ))}
              </div>

              {/* target hours for this note */}
              <div className="mt-3 border-t pt-3" style={{ borderColor: "var(--line-soft)" }}>
                <div className="mb-1.5 flex items-center justify-between">
                  <p className="text-[10px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                    Target hours
                  </p>
                  {noteTarget && (
                    <span className="text-[10px] font-bold tabular-nums" style={{ color: "var(--accent)" }}>
                      {noteTarget.percent}%
                    </span>
                  )}
                </div>
                {noteTarget ? (
                  <>
                    <div className="h-2 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${noteTarget.percent}%`, background: dot }}
                      />
                    </div>
                    <p className="mt-1 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                      {Math.round(noteTarget.loggedMinutes)} min logged of {noteTarget.targetHours}h
                    </p>
                  </>
                ) : (
                  <form
                    className="flex items-center gap-1.5"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      await saveNoteTarget();
                    }}
                  >
                    <input
                      type="number"
                      min={0.25}
                      step={0.25}
                      className="input-box !w-[68px] !px-2 !py-1 text-center !text-[11.5px]"
                      value={targetDraft}
                      onChange={(e) => setTargetDraft(Number(e.target.value) || 0)}
                      aria-label="Target hours for this note"
                    />
                    <span className="text-[10.5px]" style={{ color: "var(--ink-faint)" }}>hours</span>
                    <button type="submit" className="btn-ghost ml-auto px-2.5 py-1 text-[11px] font-semibold">
                      Set target
                    </button>
                  </form>
                )}
              </div>

              {/* saved custom times for this subject (plus any-subject ones) */}
              <div className="mt-3 border-t pt-3" style={{ borderColor: "var(--line-soft)" }}>
                <div className="mb-1.5 flex items-center justify-between">
                  <p className="text-[10px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                    Custom times
                  </p>
                  <button
                    onClick={openFullTimer}
                    className="flex items-center gap-1 text-[10px] font-bold transition-colors hover:text-[var(--accent)]"
                    style={{ color: "var(--ink-faint)" }}
                    title="Manage custom times in the Focus Timer"
                  >
                    <Settings2 size={10.5} /> Manage
                  </button>
                </div>
                {notePresets.length > 0 ? (
                  <select
                    className="input-box w-full !px-2 !py-1.5 !text-[11.5px]"
                    value=""
                    aria-label="Start a saved custom time"
                    onChange={(e) => {
                      const preset = notePresets.find((x) => x.id === e.target.value);
                      if (!preset) return;
                      focus.startSession(
                        {
                          kind: preset.kind,
                          minutes: preset.minutes,
                          subject: preset.subject || subjectName,
                          label: preset.label,
                        },
                        note.id
                      );
                    }}
                  >
                    <option value="">Start a custom time…</option>
                    {notePresets.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.label} · {p.minutes}m
                        {p.subject ? ` · ${p.subject}` : " · Any Subject"}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                    No custom times for {subjectName || "this note"} yet — create one in the
                    Focus Timer.
                  </p>
                )}
              </div>

              {relevantChains.length > 0 && (
                <div className="mt-3 border-t pt-3" style={{ borderColor: "var(--line-soft)" }}>
                  <p className="mb-1.5 text-[10px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                    Sequences
                  </p>
                  <div className="flex flex-col gap-1">
                    {relevantChains.slice(0, 4).map((c) => (
                      <button
                        key={c.id}
                        onClick={() => focus.startChain(c, note.id)}
                        className="flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-left transition-colors hover:bg-[var(--surface-2)]"
                        style={{ border: "1px solid var(--line-soft)" }}
                      >
                        <Workflow size={12} style={{ color: "var(--accent)" }} />
                        <span className="min-w-0 flex-1 truncate text-[11.5px] font-semibold" style={{ color: "var(--ink)" }}>
                          {c.name}
                        </span>
                        <span className="text-[10px] tabular-nums" style={{ color: "var(--ink-faint)" }}>
                          {c.steps.length} · {c.steps.reduce((a, s) => a + s.minutes, 0)}m
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {busyElsewhere && (
                <button onClick={focus.cancelSession} className="btn-ghost mt-2 w-full justify-center px-3 py-1.5 text-[11.5px] font-semibold hover:!text-red-500">
                  <Square size={12} /> Stop the other session
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
