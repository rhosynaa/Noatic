"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { createPortal } from "react-dom";
import {
  Check,
  Disc3,
  Flame,
  ImagePlus,
  Library,
  Link2,
  ListMusic,
  ListPlus,
  Music2,
  Pause,
  Play,
  Pencil,
  Plus,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { useMusic } from "@/lib/music-context";
import { fileToDataUrl } from "@/lib/api";
import LibraryPickButton from "@/components/media/LibraryPickButton";
import CoverShuffleButton from "@/components/media/CoverShuffleButton";
import { useToast } from "@/lib/toast";
import {
  DEFAULT_COVER_LIST,
  coverFor,
  type CoverOption,
  type Track,
} from "@/lib/types";
import { Modal, ModalHeader } from "@/components/ui";
import PlayerBar from "@/components/music/PlayerBar";

function detectKind(url: string): "youtube" | "spotify" | "audio" {
  if (/(?:youtube\.com|youtu\.be)\//.test(url)) return "youtube";
  if (/open\.spotify\.com\//.test(url)) return "spotify";
  return "audio";
}

function Eq({ playing }: { playing: boolean }) {
  return (
    <span className="flex h-3.5 items-end gap-[2.5px]" aria-hidden>
      {[0.9, 0.55, 1, 0.7].map((d, i) => (
        <span
          key={i}
          className={playing ? "eq-bar" : ""}
          style={{
            width: 3,
            height: 14 * d,
            borderRadius: 2,
            background: "currentColor",
            transform: playing ? undefined : "scaleY(0.3)",
            animationDelay: `${i * 0.13}s`,
            display: "block",
            transition: "transform 0.3s ease",
            transformOrigin: "bottom",
          }}
        />
      ))}
    </span>
  );
}

function MusicIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.5 17.3c-.22.36-.67.47-1.03.25-2.82-1.72-6.37-2.11-10.55-1.16-.4.09-.8-.16-.89-.56-.09-.4.16-.8.56-.89 4.54-1.04 8.41-.59 11.54 1.33.36.21.47.67.25 1.03zm1.47-3.27c-.27.45-.85.6-1.29.32-3.23-1.99-8.16-2.56-11.98-1.4-.5.15-1.03-.13-1.18-.63-.15-.5.13-1.03.63-1.18 4.36-1.32 9.78-.68 13.5 1.6.44.28.59.86.32 1.29zm.13-3.41c-3.87-2.3-10.26-2.51-13.96-1.39-.6.18-1.23-.16-1.41-.75-.18-.6.16-1.23.75-1.41 4.24-1.29 11.29-1.04 15.74 1.61.54.32.72 1.01.4 1.55-.32.55-1.02.72-1.55.39h.03z" />
    </svg>
  );
}

function YoutubeIcon({ size = 13 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <rect x="2" y="5" width="20" height="14" rx="4" stroke="currentColor" strokeWidth="2" />
      <path d="M10 9.5v5l4.5-2.5L10 9.5z" fill="currentColor" />
    </svg>
  );
}

/** Modal to pick one of the 5 default cover images or upload a custom image for a song */
function CoverPickerModal({
  track,
  onClose,
}: {
  track: Track;
  onClose: () => void;
}) {
  const m = useMusic();
  const { push } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [updating, setUpdating] = useState(false);
  const currentCover = coverFor(track.id, track.coverUrl);

  const setCover = async (url: string, label: string) => {
    setUpdating(true);
    await m.updateTrackCover(track.id, url);
    setUpdating(false);
    push("success", `Cover changed to ${label}`);
    onClose();
  };

  const uploadCustom = async (file: File) => {
    try {
      setUpdating(true);
      const url = await fileToDataUrl(file, 512);
      await m.updateTrackCover(track.id, url);
      push("success", "Custom cover art updated");
      onClose();
    } catch (err) {
      push("error", err instanceof Error ? err.message : "Couldn't use that image");
    } finally {
      setUpdating(false);
    }
  };

  return (
    <Modal open onClose={onClose}>
      <ModalHeader
        title="Choose Cover Art"
        subtitle={`Select a cover for "${track.title}"`}
        onClose={onClose}
      />
      <div className="flex flex-col gap-5 p-6" style={{ background: "var(--surface)" }}>
        <div>
          <p className="text-[11px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
            5 Default Theme Covers
          </p>
          <div className="mt-3 grid grid-cols-5 gap-2.5">
            {DEFAULT_COVER_LIST.map((c) => {
              const isSelected = currentCover === c.url;
              return (
                <button
                  key={c.id}
                  onClick={() => setCover(c.url, c.label)}
                  disabled={updating}
                  className="group relative flex flex-col items-center gap-1.5 rounded-2xl p-1.5 text-center transition-all hover:scale-105"
                  style={{
                    background: isSelected ? "var(--accent-soft)" : "var(--surface-2)",
                    border: isSelected ? "2px solid var(--accent)" : "1px solid var(--line)",
                  }}
                >
                  <span className="relative block aspect-square w-full overflow-hidden rounded-xl">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={c.url} alt={c.label} className="h-full w-full object-cover" />
                    {isSelected && (
                      <span className="absolute inset-0 flex items-center justify-center bg-black/35 text-white">
                        <Check size={16} strokeWidth={3} />
                      </span>
                    )}
                  </span>
                  <span className="truncate text-[10.5px] font-bold" style={{ color: isSelected ? "var(--accent)" : "var(--ink)" }}>
                    {c.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="border-t pt-4" style={{ borderColor: "var(--line-soft)" }}>
          <p className="text-[11px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
            Or Upload Custom Photo
          </p>
          <div className="mt-3 flex items-center gap-3">
            <button
              onClick={() => fileRef.current?.click()}
              disabled={updating}
              className="btn-accent flex-1 justify-center px-4 py-2.5 text-[12.5px] font-semibold"
            >
              <Upload size={14} /> Upload photo from device
            </button>
            <CoverShuffleButton
              target="track"
              refId={track.id}
              label="Shuffle"
              className="btn-ghost flex-1 justify-center px-4 py-2.5 text-[12.5px] font-semibold"
              iconSize={14}
            />
            <LibraryPickButton
              label="My library"
              iconSize={14}
              className="btn-ghost flex-1 justify-center px-4 py-2.5 text-[12.5px] font-semibold"
              onPick={(u) => void setCover(u, "your library")}
            />
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = "";
                if (f) void uploadCustom(f);
              }}
            />
          </div>
        </div>
      </div>
    </Modal>
  );
}

function TrackRow({
  track,
  onOpenCoverPicker,
}: {
  track: Track;
  onOpenCoverPicker: (t: Track) => void;
}) {
  const m = useMusic();
  const [pickOpen, setPickOpen] = useState(false);
  const isCurrent = m.current?.id === track.id;
  const isBroken = m.broken.has(track.id);
  const coverUrl = coverFor(track.id, track.coverUrl);

  return (
    <div
      className="group flex items-center gap-3 rounded-2xl px-3 py-2.5 transition-colors"
      style={{
        background: isCurrent ? "var(--accent-soft)" : "transparent",
      }}
    >
      {/* Cover art thumbnail: clicking opens Cover Art Picker */}
      <button
        onClick={() => onOpenCoverPicker(track)}
        title="Change cover art (pick from 5 defaults or upload)"
        className="relative h-11 w-11 shrink-0 overflow-hidden rounded-xl transition-transform hover:scale-105"
        style={{ background: "var(--surface-3)", boxShadow: "0 2px 6px rgba(0,0,0,0.12)" }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={coverUrl} alt="" className="h-full w-full object-cover" />
        <span className="absolute inset-0 flex items-center justify-center bg-black/45 opacity-0 transition-opacity group-hover:opacity-100">
          <ImagePlus size={14} className="text-white" />
        </span>
      </button>

      {/* Song details: clicking plays the track */}
      <button onClick={() => m.play(track)} className="min-w-0 flex-1 text-left">
        <span className="flex items-center gap-2">
          <span className="font-display truncate text-[14.5px] leading-tight font-semibold" style={{ color: "var(--ink)" }}>
            {track.title}
          </span>
          {isCurrent && m.playing && (
            <span style={{ color: "var(--accent)" }}>
              <Eq playing />
            </span>
          )}
        </span>
        <span className="mt-0.5 flex items-center gap-1.5 text-[11px]" style={{ color: isBroken ? "#d06054" : "var(--ink-faint)" }}>
          {track.sourceType === "youtube" && (
            <span className="inline-flex items-center gap-1 text-red-500 font-semibold">
              <YoutubeIcon size={11} /> YouTube
            </span>
          )}
          {track.sourceType === "spotify" && (
            <span className="inline-flex items-center gap-1 text-green-600 font-semibold">
              <MusicIcon /> Spotify
            </span>
          )}
          {track.sourceType === "audio" && (
            <span className="inline-flex items-center gap-1 font-semibold">
              <Music2 size={11} /> {track.url.startsWith("/api/uploads") ? "Uploaded audio" : "Audio stream"}
            </span>
          )}
          <span>·</span>
          <span className="truncate">{track.artist || "Dreamy Study"}</span>
        </span>
      </button>

      {/* Play / Pause button */}
      <button
        onClick={() => (isCurrent ? m.toggle() : m.play(track))}
        aria-label={isCurrent && m.playing ? "Pause" : "Play"}
        className="btn-accent h-8 w-8 !rounded-full !p-0 shrink-0"
        style={{
          opacity: isCurrent ? 1 : 0.85,
        }}
      >
        {isCurrent && m.playing ? <Pause size={13} /> : <Play size={13} className="ml-0.5" />}
      </button>

      {/* Playlist controls: remove from playlist or add to playlist */}
      {m.activePlaylistId ? (
        <button
          onClick={() => m.removeFromPlaylist(m.activePlaylistId!, track.id)}
          aria-label="Remove from playlist"
          title="Remove from this playlist (keeps the song in library)"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-all hover:bg-black/10 hover:text-red-500"
          style={{ color: "var(--ink-faint)" }}
        >
          <X size={14} />
        </button>
      ) : (
        <div className="flex items-center gap-0.5 shrink-0">
          {m.playlists.length > 0 && (
            <div className="relative">
              <button
                onClick={() => setPickOpen((v) => !v)}
                aria-label="Add to playlist"
                title="Add to a playlist"
                className="flex h-8 w-8 items-center justify-center rounded-full transition-all hover:bg-[var(--surface-3)]"
                style={{ color: pickOpen ? "var(--accent)" : "var(--ink-faint)" }}
              >
                <ListPlus size={14} />
              </button>
              {pickOpen && (
                <>
                  <div className="fixed inset-0 z-[110]" onClick={() => setPickOpen(false)} />
                  <div
                    className="animate-pop absolute right-0 z-[111] mt-1 w-56 overflow-hidden rounded-2xl p-1.5"
                    style={{ background: "var(--surface)", border: "1px solid var(--line)", boxShadow: "var(--card-shadow-hover)" }}
                  >
                    <p className="px-3 py-1.5 text-[10px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
                      Add to playlist
                    </p>
                    {m.playlists.map((pl) => {
                      const inList = pl.trackIds.includes(track.id);
                      return (
                        <button
                          key={pl.id}
                          onClick={() => {
                            if (inList) m.removeFromPlaylist(pl.id, track.id);
                            else m.addToPlaylist(pl.id, track.id);
                            setPickOpen(false);
                          }}
                          className="flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-left text-[12px] font-medium transition-colors hover:bg-[var(--surface-2)]"
                          style={{ color: "var(--ink)" }}
                        >
                          <ListMusic size={13} style={{ color: "var(--accent)" }} />
                          <span className="min-w-0 flex-1 truncate">{pl.name}</span>
                          {inList && <Check size={13} style={{ color: "var(--accent)" }} strokeWidth={3} />}
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          )}
          <button
            onClick={() => m.removeTrack(track.id)}
            aria-label="Delete track"
            title="Delete from library"
            className="flex h-8 w-8 items-center justify-center rounded-full transition-all hover:bg-red-500/10 hover:text-red-500"
            style={{ color: "var(--ink-faint)" }}
          >
            <Trash2 size={13.5} />
          </button>
        </div>
      )}
    </div>
  );
}

function AddTrackForm({ onDone }: { onDone: () => void }) {
  const m = useMusic();
  const { push } = useToast();
  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [url, setUrl] = useState("");
  const [chosenCover, setChosenCover] = useState<string>(DEFAULT_COVER_LIST[0].url);
  const [customCover, setCustomCover] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const audioFileInputRef = useRef<HTMLInputElement>(null);
  const kind = url ? detectKind(url) : null;
  const activeList = m.playlists.find((p) => p.id === m.activePlaylistId);

  const onPickDeviceAudio = async (file: File) => {
    setBusy(true);
    const coverUrlToUse = customCover || chosenCover;
    const ok = await m.uploadTrack(file, {
      title: title.trim(),
      artist: artist.trim(),
      coverUrl: coverUrlToUse,
      playlistId: m.activePlaylistId,
    });
    setBusy(false);
    if (ok) {
      setTitle("");
      setArtist("");
      setUrl("");
      setCustomCover("");
      onDone();
    }
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !url.trim()) {
      push("error", "Please provide a track title and music link or upload an audio file");
      return;
    }
    setBusy(true);
    const coverUrlToUse = customCover || chosenCover;
    const ok = await m.addTrack({
      title: title.trim(),
      artist: artist.trim(),
      url: url.trim(),
      coverUrl: coverUrlToUse,
      playlistId: m.activePlaylistId,
    });
    setBusy(false);
    if (ok) {
      setTitle("");
      setArtist("");
      setUrl("");
      setCustomCover("");
      onDone();
    }
  };

  return (
    <form onSubmit={submit} className="flex flex-col gap-4 rounded-3xl p-5" style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
      <div className="flex items-center justify-between">
        <div>
          <p className="font-display text-[15px] font-semibold" style={{ color: "var(--ink)" }}>
            Add Music
          </p>
          <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
            {activeList ? `Will be added to: ${activeList.name}` : "Will be added to: All Music"}
          </p>
        </div>
        <button
          type="button"
          onClick={onDone}
          className="btn-ghost h-7 w-7 !p-0"
          aria-label="Cancel add track"
        >
          <X size={14} />
        </button>
      </div>

      {/* Upload button */}
      <div>
        <button
          type="button"
          onClick={() => audioFileInputRef.current?.click()}
          disabled={busy}
          className="flex w-full items-center justify-center gap-2 rounded-2xl py-3 px-4 text-[13px] font-bold transition-transform hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
          style={{ background: "var(--accent)", color: "var(--accent-ink)", boxShadow: "0 4px 14px -4px var(--accent)" }}
        >
          <Upload size={16} />
          {busy ? "Uploading audio…" : "Upload MP3 / Audio from Phone or Laptop"}
        </button>
        <input
          ref={audioFileInputRef}
          type="file"
          accept="audio/*,.mp3,.m4a,.aac,.wav,.ogg,.flac,.opus"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) void onPickDeviceAudio(f);
          }}
        />
      </div>

      <div className="flex items-center gap-3">
        <span className="h-px flex-1" style={{ background: "var(--line)" }} />
        <span className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
          or paste music link
        </span>
        <span className="h-px flex-1" style={{ background: "var(--line)" }} />
      </div>

      {/* Link inputs */}
      <div className="flex flex-col gap-2.5">
        <div className="relative">
          <Link2 size={15} className="absolute top-1/2 left-3.5 -translate-y-1/2" style={{ color: "var(--ink-faint)" }} />
          <input
            className="input-box w-full !pl-10 !text-[12.5px]"
            placeholder="Paste Spotify, YouTube or MP3 direct link *"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
        </div>

        {kind && (
          <div className="flex items-center gap-2 rounded-xl px-3 py-1.5 text-[11.5px] font-medium" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
            {kind === "youtube" ? <YoutubeIcon size={14} /> : kind === "spotify" ? <MusicIcon /> : <Link2 size={14} />}
            {kind === "youtube" && "YouTube video detected — plays embedded"}
            {kind === "spotify" && "Spotify song/playlist detected — plays embedded"}
            {kind === "audio" && "Audio stream detected — plays in-app"}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input
            className="input-box w-full !text-[12.5px]"
            placeholder="Track title *"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <input
            className="input-box w-full !text-[12.5px]"
            placeholder="Artist (optional)"
            value={artist}
            onChange={(e) => setArtist(e.target.value)}
          />
        </div>
      </div>

      {/* 5 Default Cover Images Picker */}
      <div className="border-t pt-3" style={{ borderColor: "var(--line-soft)" }}>
        <div className="flex items-center justify-between">
          <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
            Choose Cover Artwork
          </p>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="text-[11px] font-bold transition-colors hover:text-[var(--accent)]"
            style={{ color: customCover ? "var(--accent)" : "var(--ink-soft)" }}
          >
            {customCover ? "Custom image uploaded ✓" : "+ Upload custom"}
          </button>
        </div>

        {/* 5 Default theme covers */}
        <div className="mt-2.5 grid grid-cols-5 gap-2">
          {DEFAULT_COVER_LIST.map((c) => {
            const isSelected = !customCover && chosenCover === c.url;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  setCustomCover("");
                  setChosenCover(c.url);
                }}
                className="group relative flex flex-col items-center gap-1 rounded-xl p-1 transition-all hover:scale-105"
                style={{
                  background: isSelected ? "var(--accent-soft)" : "var(--surface)",
                  border: isSelected ? "2px solid var(--accent)" : "1px solid var(--line)",
                }}
              >
                <span className="relative block aspect-square w-full overflow-hidden rounded-lg">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={c.url} alt={c.label} className="h-full w-full object-cover" />
                  {isSelected && (
                    <span className="absolute inset-0 flex items-center justify-center bg-black/35 text-white">
                      <Check size={13} strokeWidth={3} />
                    </span>
                  )}
                </span>
                <span className="truncate text-[9.5px] font-bold" style={{ color: isSelected ? "var(--accent)" : "var(--ink)" }}>
                  {c.label}
                </span>
              </button>
            );
          })}
        </div>

        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (!f) return;
            try {
              const u = await fileToDataUrl(f, 512);
              setCustomCover(u);
            } catch (err) {
              push("error", err instanceof Error ? err.message : "Couldn't read that image");
            }
          }}
        />
      </div>

      <div className="flex items-center justify-end gap-2 pt-1">
        <button
          type="button"
          onClick={onDone}
          className="btn-ghost px-3.5 py-2 text-[12px] font-semibold"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={busy || !title.trim() || !url.trim()}
          className="btn-accent px-5 py-2 text-[12.5px] font-semibold disabled:opacity-40"
        >
          <Plus size={14} />
          {busy ? "Saving…" : "Save to Music Room"}
        </button>
      </div>
    </form>
  );
}

export default function MusicDrawer() {
  const m = useMusic();
  const [showAdd, setShowAdd] = useState(false);
  const [makingList, setMakingList] = useState(false);
  const [listName, setListName] = useState("");
  const [coverPickerTrack, setCoverPickerTrack] = useState<Track | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const activeList = m.playlists.find((p) => p.id === m.activePlaylistId) ?? null;

  useEffect(() => {
    if (!m.drawerOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && m.setDrawerOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [m]);

  if (typeof document === "undefined") return null;


  return createPortal(
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-[105] transition-opacity duration-300 ${
          m.drawerOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        style={{ background: "rgba(24,18,10,0.45)", backdropFilter: "blur(4px)" }}
        onClick={() => m.setDrawerOpen(false)}
      />

      {/* Right Drawer: uses flex-col with fully scrollable flex-1 body */}
      <aside
        ref={panelRef}
        aria-hidden={!m.drawerOpen}
        className="fixed top-0 right-0 bottom-0 z-[106] flex w-full max-w-xl flex-col transition-transform duration-500"
        style={{
          transform: m.drawerOpen ? "translateX(0)" : "translateX(102%)",
          transitionTimingFunction: "cubic-bezier(0.22,1,0.36,1)",
          background: "var(--bg)",
          borderLeft: "1px solid var(--line)",
          boxShadow: "-24px 0 60px -24px rgba(20,14,6,0.45)",
        }}
      >
        {/* Fixed Header */}
        <div
          className="flex shrink-0 items-center justify-between border-b px-6 py-4 sm:py-5"
          style={{ borderColor: "var(--line-soft)", background: "var(--surface)" }}
        >
          <div className="flex items-center gap-3">
            <span
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
              style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
            >
              <Disc3 size={20} className={m.playing ? "animate-spin [animation-duration:4s]" : ""} />
            </span>
            <div>
              <h2 className="font-display text-xl font-semibold" style={{ color: "var(--ink)" }}>
                Music Room
              </h2>
              <p className="mt-0.5 text-[12px]" style={{ color: "var(--ink-soft)" }}>
                {activeList
                  ? `${activeList.name} (${m.queue.length} track${m.queue.length === 1 ? "" : "s"})`
                  : `All Music (${m.tracks.length} track${m.tracks.length === 1 ? "" : "s"})`}
              </p>
            </div>
          </div>
          <button
            onClick={() => m.setDrawerOpen(false)}
            aria-label="Close music room"
            className="btn-ghost h-8 w-8 !p-0"
            style={{ border: "none" }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Entire Drawer Body: ONE Smooth Scrollable Container */}
        <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6 flex flex-col gap-6">
          {/* 1. NOW PLAYING PLAYER CARD */}
          <div
            className="shrink-0 rounded-3xl p-5"
            style={{
              background: "var(--surface)",
              border: "1px solid var(--line)",
              boxShadow: "var(--card-shadow)",
            }}
          >
            <PlayerBar variant="full" onCoverClick={(t) => setCoverPickerTrack(t)} />
          </div>

          {/* 2. PLAYLISTS SECTION */}
          <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--accent)" }}>
                  Playlists
                </p>
                <p className="text-[12px]" style={{ color: "var(--ink-soft)" }}>
                  Organize your focus soundscapes
                </p>
              </div>
              <button
                onClick={() => setMakingList((v) => !v)}
                className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
              >
                <ListPlus size={13} /> New playlist
              </button>
            </div>

            {makingList && (
              <form
                className="animate-pop mt-3 flex items-center gap-2"
                onSubmit={async (e) => {
                  e.preventDefault();
                  const name = listName.trim();
                  if (!name) return;
                  const row = await m.createPlaylist(name);
                  setListName("");
                  setMakingList(false);
                  if (row) m.setActivePlaylist(row.id);
                }}
              >
                <input
                  className="input-box flex-1 !py-1.5 !text-[12px]"
                  placeholder="Playlist name — e.g. Late Night Study"
                  value={listName}
                  maxLength={60}
                  onChange={(e) => setListName(e.target.value)}
                  autoFocus
                />
                <button type="submit" disabled={!listName.trim()} className="btn-accent px-3 py-1.5 text-[11.5px] font-semibold disabled:opacity-40">
                  <Check size={13} /> Create
                </button>
                <button type="button" onClick={() => setMakingList(false)} className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold">
                  Cancel
                </button>
              </form>
            )}

            {/* Playlist chips */}
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => m.setActivePlaylist(null)}
                className="flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[11.5px] font-bold transition-all"
                style={{
                  background: m.activePlaylistId === null ? "var(--accent)" : "var(--surface-2)",
                  color: m.activePlaylistId === null ? "var(--accent-ink)" : "var(--ink-soft)",
                  border: "1px solid var(--line)",
                }}
              >
                <Library size={12} /> All Music · {m.tracks.length}
              </button>

              {m.playlists.map((pl) => {
                const on = m.activePlaylistId === pl.id;
                return (
                  <span
                    key={pl.id}
                    className="group/pl flex items-center overflow-hidden rounded-full transition-all"
                    style={{
                      background: on ? "var(--accent)" : "var(--surface-2)",
                      border: "1px solid var(--line)",
                    }}
                  >
                    <button
                      onClick={() => m.setActivePlaylist(on ? null : pl.id)}
                      className="flex items-center gap-1.5 py-2 pr-1.5 pl-3.5 text-[11.5px] font-bold"
                      style={{ color: on ? "var(--accent-ink)" : "var(--ink-soft)" }}
                    >
                      <ListMusic size={12} />
                      {pl.name} · {pl.trackIds.length}
                    </button>
                    <button
                      onClick={() => {
                        const name = window.prompt("Rename playlist", pl.name);
                        if (name && name.trim()) void m.renamePlaylist(pl.id, name.trim());
                      }}
                      aria-label={`Rename ${pl.name}`}
                      title="Rename playlist"
                      className="px-1 py-2 opacity-60 transition-opacity hover:opacity-100"
                      style={{ color: on ? "var(--accent-ink)" : "var(--ink-faint)" }}
                    >
                      <Pencil size={11} />
                    </button>
                    <button
                      onClick={() => void m.deletePlaylist(pl.id)}
                      aria-label={`Delete ${pl.name}`}
                      title="Delete playlist (songs stay in library)"
                      className="pr-2.5 pl-1 py-2 opacity-60 transition-opacity hover:opacity-100 hover:text-red-500"
                      style={{ color: on ? "var(--accent-ink)" : "var(--ink-faint)" }}
                    >
                      <Trash2 size={11} />
                    </button>
                  </span>
                );
              })}
            </div>
          </section>

          {/* 3. ADD MUSIC / UPLOAD FORM TOGGLE */}
          {!showAdd ? (
            <button
              onClick={() => setShowAdd(true)}
              className="flex w-full items-center justify-center gap-2 rounded-2xl py-3 px-4 text-[13px] font-bold transition-all hover:bg-[var(--surface-2)]"
              style={{
                background: "var(--surface)",
                border: "1px dashed var(--accent)",
                color: "var(--accent)",
              }}
            >
              <Plus size={15} /> Add Songs / Upload Music
            </button>
          ) : (
            <AddTrackForm onDone={() => setShowAdd(false)} />
          )}

          {/* 4. TRACK LIST / CURRENT QUEUE */}
          <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--accent)" }}>
                  {activeList ? activeList.name : "All Music"}
                </p>
                <p className="text-[12px]" style={{ color: "var(--ink-soft)" }}>
                  {m.queue.length} track{m.queue.length === 1 ? "" : "s"} in this queue
                </p>
              </div>
              <button
                onClick={() => setShowAdd((v) => !v)}
                className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
              >
                <Plus size={13} className={showAdd ? "rotate-45 transition-transform" : ""} />
                Add music
              </button>
            </div>

            <div className="mt-3 flex flex-col gap-1">
              {m.queue.map((t, i) => (
                <TrackRow
                  key={t.id}
                  track={t}
                  onOpenCoverPicker={(trackToEdit) => setCoverPickerTrack(trackToEdit)}
                />
              ))}

              {m.queue.length === 0 && (
                <div className="flex flex-col items-center gap-2 py-8 text-center" style={{ color: "var(--ink-faint)" }}>
                  <Music2 size={24} />
                  <p className="text-[13px] font-semibold" style={{ color: "var(--ink)" }}>
                    {activeList ? `"${activeList.name}" is empty` : "Your music library is empty"}
                  </p>
                  <p className="max-w-xs text-[11.5px]">
                    {activeList
                      ? "Use '+ Add Music' above to upload a song or add a Spotify/YouTube link directly into this playlist."
                      : "Upload audio files from your device or paste YouTube / Spotify links above."}
                  </p>
                </div>
              )}
            </div>
          </section>
        </div>
      </aside>

      {/* Cover Art Picker Modal */}
      {coverPickerTrack && (
        <CoverPickerModal
          track={coverPickerTrack}
          onClose={() => setCoverPickerTrack(null)}
        />
      )}
    </>,
    document.body
  );
}
