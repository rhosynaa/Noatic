"use client";

import {
  Disc3,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from "lucide-react";
import { useMusic } from "@/lib/music-context";
import { coverFor, type Track } from "@/lib/types";

function formatTime(sec: number) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function Eq({ playing }: { playing: boolean }) {
  return (
    <span className="flex h-3.5 items-end gap-[2.5px]" aria-hidden>
      {[0.9, 0.55, 1, 0.7].map((d, i) => (
        <span
          key={i}
          className={playing ? "eq-bar" : ""}
          style={{
            width: 3,
            height: 14 * d,
            borderRadius: 2,
            background: "currentColor",
            transform: playing ? undefined : "scaleY(0.3)",
            animationDelay: `${i * 0.13}s`,
            display: "block",
            transition: "transform 0.3s ease",
            transformOrigin: "bottom",
          }}
        />
      ))}
    </span>
  );
}

function SourceBadge({ track }: { track: Track }) {
  if (track.sourceType === "youtube")
    return (
      <span className="inline-flex items-center gap-1 font-bold text-[#d0603f]">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" aria-hidden>
          <rect x="2" y="5" width="20" height="14" rx="4" stroke="currentColor" strokeWidth="2" />
          <path d="M10 9.5v5l4.5-2.5L10 9.5z" fill="currentColor" />
        </svg>
        YouTube
      </span>
    );
  if (track.sourceType === "spotify")
    return (
      <span className="inline-flex items-center gap-1 font-bold text-[#3f9c63]">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
          <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.5 17.3c-.22.36-.67.47-1.03.25-2.82-1.72-6.37-2.11-10.55-1.16-.4.09-.8-.16-.89-.56-.09-.4.16-.8.56-.89 4.54-1.04 8.41-.59 11.54 1.33.36.21.47.67.25 1.03zm1.47-3.27c-.27.45-.85.6-1.29.32-3.23-1.99-8.16-2.56-11.98-1.4-.5.15-1.03-.13-1.18-.63-.15-.5.13-1.03.63-1.18 4.36-1.32 9.78-.68 13.5 1.6.44.28.59.86.32 1.29zm.13-3.41c-3.87-2.3-10.26-2.51-13.96-1.39-.6.18-1.23-.16-1.41-.75-.18-.6.16-1.23.75-1.41 4.24-1.29 11.29-1.04 15.74 1.61.54.32.72 1.01.4 1.55-.32.55-1.02.72-1.55.39h.03z" />
        </svg>
        Spotify
      </span>
    );
  return (
    <span className="inline-flex items-center gap-1 font-bold" style={{ color: "var(--ink-faint)" }}>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
        <path d="M12 3v10.55A4 4 0 1014 17V7h4V3h-6z" />
      </svg>
      {track.url.startsWith("/api/uploads") ? "Uploaded" : "Audio"}
    </span>
  );
}

/**
 * The one true player. Used by both the dashboard widget and the Music Room
 * drawer so they can never drift apart or degrade to a blank state.
 *
 * Every control always renders — they simply disable when there is nothing to
 * act on, so the bar is never an empty pill.
 */
export default function PlayerBar({
  variant = "full",
  onCoverClick,
}: {
  variant?: "full" | "compact";
  onCoverClick?: (track: Track) => void;
}) {
  const m = useMusic();
  const cur = m.current;
  const full = variant === "full";

  const isEmbed = cur ? cur.sourceType !== "audio" : false;
  const seekable = !!cur && !isEmbed;
  // duration is 0 until metadata loads (or for streams) — show a placeholder
  const knownDuration = m.duration > 0;
  const pct = knownDuration ? (m.progress / m.duration) * 100 : 0;
  const isMuted = m.volume === 0;
  const hasQueue = m.queue.length > 0;

  const repeatIcon = m.repeat === "one" ? <Repeat1 size={15} /> : <Repeat size={15} />;

  const ctrl = (active: boolean) => ({
    color: active ? "var(--accent)" : "var(--ink-faint)",
    background: active ? "var(--accent-soft)" : "transparent",
  });

  return (
    <div className="flex w-full flex-col gap-3.5">
      {/* ---------- track info ---------- */}
      <div className="flex items-center gap-3.5">
        {full && (
          <button
            onClick={() => cur && onCoverClick?.(cur)}
            disabled={!cur}
            title={cur ? "Change cover art" : undefined}
            aria-label="Change cover art"
            className="group relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl transition-transform hover:scale-[1.03] disabled:cursor-default disabled:opacity-60"
            style={{ boxShadow: "var(--card-shadow)", background: "var(--surface-3)" }}
          >
            {cur ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={coverFor(cur.id, cur.coverUrl)} alt="" className="h-full w-full object-cover" />
            ) : (
              <span
                className="flex h-full w-full items-center justify-center"
                style={{ color: "var(--ink-faint)" }}
              >
                <Disc3 size={26} />
              </span>
            )}
            {m.playing && cur && (
              <span className="absolute inset-0 flex items-center justify-center bg-black/35 text-white">
                <Eq playing />
              </span>
            )}
          </button>
        )}

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p
              className="text-[10.5px] font-bold tracking-[0.14em] uppercase"
              style={{ color: "var(--accent)" }}
            >
              {m.playing ? "Now playing" : cur ? "Paused" : "Nothing playing"}
            </p>
            {m.playing && <Eq playing />}
          </div>
          <p
            className={`font-display truncate font-semibold ${full ? "mt-1 text-[18px] leading-tight" : "text-[19px] leading-tight"}`}
            style={{ color: "var(--ink)" }}
            title={cur?.title}
          >
            {cur ? cur.title : hasQueue ? "Tap play to start your queue" : "Add a song to begin"}
          </p>
          <p className="mt-0.5 flex items-center gap-1.5 truncate text-[12.5px]" style={{ color: "var(--ink-soft)" }}>
            {cur ? (
              <>
                <SourceBadge track={cur} />
                <span aria-hidden>·</span>
                <span className="truncate">{cur.artist || "Unknown artist"}</span>
              </>
            ) : (
              <span>Upload a file or paste a link in the Music Room</span>
            )}
          </p>
        </div>
      </div>

      {/* ---------- Spotify / YouTube embed (Music Room only) ---------- */}
      {full && cur && isEmbed && (
        <div className="shrink-0 overflow-hidden rounded-2xl" style={{ border: "1px solid var(--line)" }}>
          {m.playing ? (
            <iframe
              key={cur.id}
              src={
                cur.sourceType === "youtube"
                  ? `https://www.youtube.com/embed/${cur.url}?autoplay=1&rel=0`
                  : `${cur.url}?utm_source=generator`
              }
              width="100%"
              height={cur.sourceType === "youtube" ? 200 : 152}
              frameBorder="0"
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              loading="lazy"
              title={cur.title}
            />
          ) : (
            <button
              onClick={() => m.toggle()}
              className="flex h-[104px] w-full flex-col items-center justify-center gap-2 text-[12.5px] font-semibold transition-colors hover:bg-[var(--surface-3)]"
              style={{ background: "var(--surface-2)", color: "var(--ink-soft)" }}
            >
              <Play size={20} style={{ color: "var(--accent)" }} />
              Press play to load the {cur.sourceType === "youtube" ? "YouTube" : "Spotify"} player
            </button>
          )}
        </div>
      )}

      {/* ---------- progress + times ---------- */}
      <div className="shrink-0">
        <input
          type="range"
          min={0}
          max={Math.max(1, m.duration)}
          step={0.1}
          value={Math.min(m.progress, m.duration || 1)}
          onChange={(e) => m.seek(Number(e.target.value))}
          aria-label="Seek"
          className="music-range w-full"
          disabled={!seekable}
          style={{
            background: `linear-gradient(to right, var(--accent) ${pct}%, var(--line) ${pct}%)`,
            opacity: seekable ? 1 : 0.45,
            cursor: seekable ? "pointer" : "not-allowed",
          }}
        />
        <div
          className="mt-1 flex justify-between text-[10.5px] font-semibold tabular-nums"
          style={{ color: "var(--ink-faint)" }}
        >
          <span>{cur ? formatTime(m.progress) : "0:00"}</span>
          <span>
            {cur
              ? knownDuration
                ? formatTime(m.duration)
                : isEmbed
                  ? "streaming"
                  : "loading…"
              : "0:00"}
          </span>
        </div>
      </div>

      {/* ---------- transport: shuffle · prev · play · next · repeat ---------- */}
      <div className="flex shrink-0 flex-wrap items-center justify-center gap-1.5">
        <button
          onClick={m.toggleShuffle}
          aria-label="Shuffle"
          aria-pressed={m.shuffle}
          title={m.shuffle ? "Shuffle on" : "Shuffle off"}
          disabled={!hasQueue}
          className="flex h-9 w-9 items-center justify-center rounded-full transition-all disabled:opacity-40"
          style={ctrl(m.shuffle)}
        >
          <Shuffle size={15} />
        </button>

        <button
          onClick={m.prev}
          aria-label="Previous track"
          title="Previous track"
          disabled={!hasQueue}
          className="flex h-10 w-10 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-2)] disabled:opacity-40"
          style={{ color: "var(--ink)" }}
        >
          <SkipBack size={17} fill="currentColor" />
        </button>

        <button
          onClick={m.toggle}
          aria-label={m.playing ? "Pause" : "Play"}
          title={m.playing ? "Pause" : "Play"}
          disabled={!hasQueue}
          className="btn-accent mx-0.5 h-12 w-12 !rounded-full !p-0 disabled:opacity-40"
        >
          {m.playing ? <Pause size={19} /> : <Play size={19} className="ml-0.5" />}
        </button>

        <button
          onClick={m.next}
          aria-label="Next track"
          title="Next track"
          disabled={!hasQueue}
          className="flex h-10 w-10 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-2)] disabled:opacity-40"
          style={{ color: "var(--ink)" }}
        >
          <SkipForward size={17} fill="currentColor" />
        </button>

        <button
          onClick={m.toggleRepeat}
          aria-label={`Repeat: ${m.repeat}`}
          aria-pressed={m.repeat !== "off"}
          title={
            m.repeat === "off"
              ? "Repeat off"
              : m.repeat === "all"
                ? "Repeat queue"
                : "Repeat this song"
          }
          disabled={!hasQueue}
          className="flex h-9 w-9 items-center justify-center rounded-full transition-all disabled:opacity-40"
          style={ctrl(m.repeat !== "off")}
        >
          {repeatIcon}
        </button>
      </div>

      {/* ---------- volume ---------- */}
      <div className="flex shrink-0 items-center justify-center gap-2" style={{ color: "var(--ink-faint)" }}>
        <button
          onClick={() => m.setVolume(isMuted ? 0.85 : 0)}
          aria-label={isMuted ? "Unmute" : "Mute"}
          title={isMuted ? "Unmute" : "Mute"}
          className="transition-colors hover:text-[var(--ink)]"
        >
          {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
        </button>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={m.volume}
          onChange={(e) => m.setVolume(Number(e.target.value))}
          aria-label="Volume"
          className="music-range w-24"
          style={{
            background: `linear-gradient(to right, var(--accent) ${m.volume * 100}%, var(--line) ${m.volume * 100}%)`,
          }}
        />
        <span className="w-8 text-right text-[10.5px] font-semibold tabular-nums">
          {Math.round(m.volume * 100)}%
        </span>
      </div>
    </div>
  );
}
