"use client";

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import { createPortal } from "react-dom";
import {
  BarChart3,
  BookMarked,
  BookOpen,
  Check,
  ChevronDown,
  ChevronLeft,
  ImagePlus,
  LayoutGrid,
  Link2,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { api, fileToDataUrl } from "@/lib/api";
import { useToast } from "@/lib/toast";
import { DEADLINE_COLORS, type AnalyticsData, type StudyTarget, type Subject } from "@/lib/types";
import { dueLabel } from "@/components/widgets/DeadlinesWidget";
import LibraryPickButton from "@/components/media/LibraryPickButton";
import CoverShuffleButton from "@/components/media/CoverShuffleButton";

const fmt = (m: number) => (m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`);
const tomorrow = () => new Date(Date.now() + 86400000).toISOString().slice(0, 10);

/* ------------------------------------------------------------------ */
/* card-specific helpers                                               */
/* ------------------------------------------------------------------ */

type DueRow = { id: string; title: string; dueDate: string };

/**
 * Popover for swapping a card's cover art.
 * Rendered in a portal with fixed positioning so the card's `overflow-hidden`
 * can never clip it, and clamped so it always stays fully on screen.
 */
function CoverEditor({
  subject,
  anchorRef,
  onClose,
}: {
  subject: Subject;
  anchorRef: React.RefObject<HTMLButtonElement | null>;
  onClose: () => void;
}) {
  const { updateSubject } = useDashboard();
  const { push } = useToast();
  const [url, setUrl] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  /* place the panel next to its button, flipping/clamping to stay on screen */
  useLayoutEffect(() => {
    const place = () => {
      const anchor = anchorRef.current?.getBoundingClientRect();
      if (!anchor) return;
      const panel = panelRef.current;
      const w = panel?.offsetWidth ?? 224;
      const h = panel?.offsetHeight ?? 170;
      const M = 8; // viewport margin
      const vw = document.documentElement.clientWidth;
      const vh = document.documentElement.clientHeight;

      // prefer below-right of the button, flip above when short on room
      let top = anchor.bottom + 8;
      if (top + h > vh - M) {
        const above = anchor.top - 8 - h;
        top = above >= M ? above : Math.max(M, vh - M - h);
      }
      let left = anchor.right - w;
      left = Math.min(Math.max(M, left), Math.max(M, vw - M - w));
      setPos({ top, left });
    };

    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [anchorRef]);

  /* dismiss on Escape or an outside click */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    const onDown = (e: PointerEvent) => {
      if (
        !panelRef.current?.contains(e.target as Node) &&
        !anchorRef.current?.contains(e.target as Node)
      )
        onClose();
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onDown);
    };
  }, [onClose, anchorRef]);

  const upload = async (file: File | undefined) => {
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file, 900);
      if (await updateSubject(subject.id, { coverUrl: dataUrl })) {
        push("success", "Cover updated");
        onClose();
      }
    } catch (e) {
      push("error", e instanceof Error ? e.message : "Couldn't use that image");
    }
  };

  const setLink = async (e: FormEvent) => {
    e.preventDefault();
    const clean = url.trim();
    if (!clean) return;
    if (await updateSubject(subject.id, { coverUrl: clean })) {
      push("success", "Cover updated");
      onClose();
    }
  };

  if (typeof document === "undefined") return null;

  return createPortal(
    <div
      ref={panelRef}
      role="dialog"
      aria-label={`Cover image for ${subject.name}`}
      className="animate-pop fixed z-[130] w-56 rounded-2xl p-3"
      style={{
        top: pos?.top ?? -9999,
        left: pos?.left ?? -9999,
        visibility: pos ? "visible" : "hidden",
        // never taller than the viewport — both actions stay reachable
        maxHeight: "calc(100dvh - 16px)",
        overflowY: "auto",
        background: "var(--surface)",
        border: "1px solid var(--line)",
        boxShadow: "var(--card-shadow-hover)",
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[11px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-soft)" }}>
          Cover image
        </p>
        <button onClick={onClose} aria-label="Close cover editor" className="btn-ghost h-6 w-6 !p-0" style={{ border: "none" }}>
          <X size={12} />
        </button>
      </div>
      <button onClick={() => fileRef.current?.click()} className="btn-accent w-full gap-1.5 px-3 py-2 text-[12px] font-semibold">
        <ImagePlus size={13} />
        Upload from device
      </button>
      <CoverShuffleButton
        target="subject"
        refId={subject.id}
        label="Shuffle a category"
        className="btn-ghost w-full justify-center gap-1.5 px-3 py-2 text-[12px] font-semibold"
        iconSize={13}
      />
      <LibraryPickButton
        label="Pick from my library"
        className="btn-ghost w-full justify-center gap-1.5 px-3 py-2 text-[12px] font-semibold"
        iconSize={13}
        onPick={async (u) => {
          if (await updateSubject(subject.id, { coverUrl: u })) {
            push("success", "Cover updated");
            onClose();
          }
        }}
      />
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          void upload(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
      <form onSubmit={setLink} className="mt-2 flex items-center gap-1.5">
        <div className="flex flex-1 items-center gap-1 rounded-xl px-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
          <Link2 size={11.5} style={{ color: "var(--ink-faint)" }} />
          <input
            className="w-full bg-transparent py-2 text-[12px] outline-none placeholder:text-[var(--ink-faint)]"
            placeholder="Paste image link"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
        </div>
        <button type="submit" disabled={!url.trim()} className="btn-ghost h-8 w-8 shrink-0 !p-0 disabled:opacity-40" aria-label="Set cover from link">
          <Check size={13} />
        </button>
      </form>
    </div>,
    document.body
  );
}

/* ------------------------------------------------------------------ */
/* one subject card                                                    */
/* ------------------------------------------------------------------ */

function SubjectCard({
  subject: s,
  deadlines,
  notes,
  study,
  targets,
  onOpenProgress,
}: {
  subject: Subject;
  deadlines: { id: string; title: string; subject: string; dueDate: string; done: boolean }[];
  notes: { id: string; subject: string }[];
  study: AnalyticsData["studyBySubject"];
  targets: StudyTarget[];
  onOpenProgress: () => void;
}) {
  const { addDeadline, deleteSubject } = useDashboard();
  const { openLibrary } = useSections();
  const openThisLibrary = () => openLibrary({ id: s.id, name: s.name });
  const [coverEditing, setCoverEditing] = useState(false);
  const coverBtnRef = useRef<HTMLButtonElement>(null);
  const [quickAdd, setQuickAdd] = useState(false);
  const [qaTitle, setQaTitle] = useState("");
  const [qaDate, setQaDate] = useState(tomorrow());
  const [showAll, setShowAll] = useState(false);

  const same = (a: string, b: string) => a.trim().toLowerCase() === b.trim().toLowerCase();
  const tone = DEADLINE_COLORS[s.color] ?? "var(--accent)";

  /* assignments = this subject's deadlines */
  const assignments = deadlines.filter((d) => same(d.subject, s.name));
  const doneCount = assignments.filter((d) => d.done).length;
  const totalCount = assignments.length;
  const assignmentPct = totalCount > 0 ? (doneCount / totalCount) * 100 : 0;

  /* study hours vs target */
  const loggedMin = study.find((x) => same(x.subject, s.name))?.totalMinutes ?? 0;
  const target = targets.find((t) => t.scope === "subject" && same(t.ref, s.name));
  const timePct =
    target && target.targetHours > 0
      ? Math.min(100, (loggedMin / 60 / target.targetHours) * 100)
      : 0;

  /* hybrid progress: 60% assignments + 40% study time */
  const pct = Math.round(assignmentPct * 0.6 + timePct * 0.4);

  /* every stored assignment — open ones first (soonest first), then done */
  const ordered = [...assignments].sort(
    (a, b) =>
      Number(a.done) - Number(b.done) ||
      new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
  );

  /* next up to 3 upcoming assignments */
  const upcoming: DueRow[] = ordered.filter((d) => !d.done).slice(0, 3);

  /* how many assignments sit in storage beyond the preview */
  const hiddenCount = ordered.length - upcoming.length;

  const noteCount = notes.filter((n) => same(n.subject ?? "", s.name)).length;

  const submitQuickAdd = async (e: FormEvent) => {
    e.preventDefault();
    if (!qaTitle.trim() || !qaDate) return;
    await addDeadline({ title: qaTitle.trim(), subject: s.name, color: s.color, dueDate: qaDate });
    setQaTitle("");
    setQaDate(tomorrow());
    setQuickAdd(false);
  };

  return (
    <article className="card card-hover group relative flex flex-col overflow-hidden">
      {/* ---------- cover ---------- */}
      <div className="relative h-36 w-full overflow-hidden" style={{ background: "var(--surface-3)" }}>
        {s.coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={s.coverUrl} alt={`${s.name} cover`} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center" style={{ color: tone }}>
            <BookMarked size={28} />
          </div>
        )}
        <div
          className="absolute inset-x-0 bottom-0 h-14"
          style={{ background: "linear-gradient(to top, rgba(24,18,10,0.28), transparent)" }}
        />
        {/* the cover itself opens this subject's note library */}
        <button
          onClick={openThisLibrary}
          aria-label={`Open ${s.name} library`}
          title={`Open ${s.name} library`}
          className="absolute inset-0 z-[1] cursor-pointer focus-visible:outline-2 focus-visible:-outline-offset-4 focus-visible:outline-white"
        >
          <span
            className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1.5 py-2 text-[11px] font-bold tracking-[0.08em] text-white uppercase opacity-0 transition-opacity duration-200 group-hover:opacity-100"
            style={{ textShadow: "0 1px 6px rgba(0,0,0,0.5)" }}
          >
            <BookOpen size={12} /> Open library
          </span>
        </button>
        <button
          ref={coverBtnRef}
          onClick={() => setCoverEditing((v) => !v)}
          aria-label={`Change cover for ${s.name}`}
          aria-expanded={coverEditing}
          className={`absolute top-2.5 right-2.5 z-[2] flex h-8 w-8 items-center justify-center rounded-full transition-all group-hover:opacity-100 ${
            coverEditing ? "opacity-100" : "opacity-0"
          }`}
          style={{ background: "rgba(24,18,10,0.55)", color: "#fff6f1", backdropFilter: "blur(4px)" }}
        >
          <ImagePlus size={13.5} />
        </button>
        {coverEditing && (
          <CoverEditor subject={s} anchorRef={coverBtnRef} onClose={() => setCoverEditing(false)} />
        )}
      </div>

      {/* ---------- body ---------- */}
      <div className="flex flex-1 flex-col gap-3 p-5 pt-4">
        <div className="flex items-start gap-3">
          <div className="min-w-0 flex-1">
            <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: tone }}>
              {s.code || "—"}
            </p>
            <button
              onClick={openThisLibrary}
              title={`Open ${s.name} library`}
              className="font-display mt-0.5 block max-w-full truncate text-left text-[18px] font-semibold transition-colors hover:underline"
              style={{ color: "var(--ink)" }}
            >
              {s.name}
            </button>
            {s.semester && (
              <p className="mt-0.5 truncate text-[11.5px] font-medium" style={{ color: "var(--ink-faint)" }}>
                {s.semester}
              </p>
            )}
          </div>
          <button
            onClick={() => deleteSubject(s.id)}
            aria-label={`Delete ${s.name}`}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
            style={{ color: "var(--ink-faint)" }}
          >
            <Trash2 size={13.5} />
          </button>
        </div>

        {/* ---------- mini due list ---------- */}
        <div className="rounded-2xl px-3.5 py-2.5" style={{ background: "var(--surface-2)" }}>
          <p className="mb-1.5 text-[9.5px] font-bold tracking-[0.13em] uppercase" style={{ color: "var(--ink-faint)" }}>
            Due next
          </p>
          {upcoming.length > 0 ? (
            <div className="flex flex-col gap-1.5">
              {upcoming.map((d) => {
                const chip = dueLabel(d.dueDate);
                return (
                  <div key={d.id} className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: tone }} />
                    <span className="min-w-0 flex-1 truncate text-[12px] font-medium" style={{ color: "var(--ink)" }}>
                      {d.title}
                    </span>
                    <span
                      className="shrink-0 rounded-full px-2 py-0.5 text-[9.5px] font-bold"
                      style={{
                        background:
                          chip.tone === "over"
                            ? "#d060541e"
                            : chip.tone === "soon"
                              ? "var(--accent-soft)"
                              : "var(--surface-3)",
                        color:
                          chip.tone === "over"
                            ? "#c5503f"
                            : chip.tone === "soon"
                              ? "var(--accent)"
                              : "var(--ink-soft)",
                      }}
                    >
                      {chip.text}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
              Nothing due — tap + to add an assignment.
            </p>
          )}

          {/* ---------- where added assignments live: the full stored list ---------- */}
          {hiddenCount > 0 && (
            <button
              onClick={() => setShowAll((v) => !v)}
              aria-expanded={showAll}
              className="mt-1.5 flex w-full items-center justify-center gap-1 rounded-xl py-1.5 text-[10.5px] font-semibold transition-colors hover:bg-[var(--surface-3)]"
              style={{ color: "var(--ink-soft)" }}
            >
              {showAll ? "Show fewer" : `All ${totalCount} assignments · +${hiddenCount} more`}
              <ChevronDown
                size={11.5}
                className={`transition-transform duration-300 ${showAll ? "rotate-180" : ""}`}
              />
            </button>
          )}
          {showAll && hiddenCount > 0 && (
            <div className="animate-pop mt-1.5 flex max-h-[168px] flex-col gap-1.5 overflow-y-auto pr-0.5">
              {ordered.map((d) => {
                const chip = d.done ? null : dueLabel(d.dueDate);
                return (
                  <div key={d.id} className="flex items-center gap-2">
                    <span
                      className="h-1.5 w-1.5 shrink-0 rounded-full"
                      style={{ background: d.done ? "var(--ink-faint)" : tone }}
                    />
                    <span
                      className={`min-w-0 flex-1 truncate text-[12px] font-medium ${d.done ? "line-through" : ""}`}
                      style={{ color: d.done ? "var(--ink-faint)" : "var(--ink)" }}
                    >
                      {d.title}
                    </span>
                    {d.done ? (
                      <span
                        className="shrink-0 rounded-full px-2 py-0.5 text-[9.5px] font-bold"
                        style={{ background: "var(--surface-3)", color: "var(--ink-soft)" }}
                      >
                        Done
                      </span>
                    ) : (
                      chip && (
                        <span
                          className="shrink-0 rounded-full px-2 py-0.5 text-[9.5px] font-bold"
                          style={{
                            background:
                              chip.tone === "over"
                                ? "#d060541e"
                                : chip.tone === "soon"
                                  ? "var(--accent-soft)"
                                  : "var(--surface-3)",
                            color:
                              chip.tone === "over"
                                ? "#c5503f"
                                : chip.tone === "soon"
                                  ? "var(--accent)"
                                  : "var(--ink-soft)",
                          }}
                        >
                          {chip.text}
                        </span>
                      )
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ---------- hybrid progress ---------- */}
        <div>
          <div className="mb-1 flex items-baseline justify-between">
            <p className="text-[10px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
              Progress
            </p>
            <p className="text-[11px] font-bold" style={{ color: tone }}>
              {pct}%
            </p>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${pct}%`, background: tone, transitionTimingFunction: "cubic-bezier(0.22,1,0.36,1)" }}
            />
          </div>
          <p className="mt-1 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
            {doneCount}/{totalCount} assignments done
            {" · "}
            {target ? `${fmt(loggedMin)} of ${target.targetHours}h studied` : "no study target set"}
          </p>
        </div>

        {/* ---------- quick add assignment ---------- */}
        {quickAdd && (
          <form onSubmit={submitQuickAdd} className="animate-pop flex flex-col gap-2 rounded-2xl p-2.5" style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}>
            <input
              autoFocus
              className="input-line !py-1.5 text-[12.5px]"
              placeholder="Assignment title — e.g. Lab report 3"
              value={qaTitle}
              onChange={(e) => setQaTitle(e.target.value)}
              maxLength={120}
            />
            <div className="flex items-center gap-2">
              <input
                type="date"
                className="input-line flex-1 !py-1.5 text-[12px]"
                value={qaDate}
                onChange={(e) => setQaDate(e.target.value)}
              />
              <button type="submit" disabled={!qaTitle.trim()} className="btn-accent h-8 w-8 shrink-0 !p-0 disabled:opacity-40" aria-label="Add assignment">
                <Check size={13} />
              </button>
              <button
                type="button"
                onClick={() => {
                  setQuickAdd(false);
                  setQaTitle("");
                  setQaDate(tomorrow());
                }}
                className="btn-ghost h-8 w-8 shrink-0 !p-0"
                aria-label="Cancel"
              >
                <X size={13} />
              </button>
            </div>
          </form>
        )}

        {/* ---------- action row ---------- */}
        <div className="mt-auto flex items-center border-t pt-3" style={{ borderColor: "var(--line-soft)" }}>
          <button
            onClick={openThisLibrary}
            className="flex items-center gap-1.5 rounded-full px-2 py-1 text-[12px] font-semibold transition-colors hover:bg-[var(--surface-2)]"
            style={{ color: "var(--ink-soft)" }}
            title={`Open ${s.name} library — ${noteCount} note${noteCount === 1 ? "" : "s"}`}
            aria-label={`Open ${s.name} library, ${noteCount} notes`}
          >
            <BookOpen size={14} style={{ color: tone }} />
            {noteCount} note{noteCount === 1 ? "" : "s"}
          </button>
          <span className="flex-1" />
          <button
            onClick={() => setQuickAdd((v) => !v)}
            aria-label={`Quick add assignment for ${s.name}`}
            aria-expanded={quickAdd}
            className="flex h-8 w-8 items-center justify-center rounded-full transition-all hover:-translate-y-0.5"
            style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
          >
            <Plus size={14} />
          </button>
          <button
            onClick={onOpenProgress}
            aria-label={`View ${s.name} progress`}
            className="ml-1.5 flex h-8 w-8 items-center justify-center rounded-full transition-all hover:-translate-y-0.5"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)", color: "var(--ink-soft)" }}
          >
            <BarChart3 size={14} />
          </button>
        </div>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* the Subject Dashboard for one workspace (full main-content page)    */
/* ------------------------------------------------------------------ */

export default function SubjectDashboard() {
  const { workspace, openSection, exitWorkspace } = useSections();
  const { subjects, addSubject, deadlines, notes } = useDashboard();
  const { push } = useToast();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [semester, setSemester] = useState("");
  const [color, setColor] = useState("rose");
  const [study, setStudy] = useState<AnalyticsData["studyBySubject"]>([]);
  const [targets, setTargets] = useState<StudyTarget[]>([]);

  const loadStats = useCallback(async () => {
    try {
      const data = await api<AnalyticsData>("/api/analytics");
      setStudy(data.studyBySubject);
    } catch {
      /* quiet — stats feed progress bars */
    }
    try {
      setTargets(await api<StudyTarget[]>("/api/study-targets"));
    } catch {
      /* quiet */
    }
  }, []);

  useEffect(() => {
    if (!workspace) return;
    const id = setTimeout(() => void loadStats(), 0);
    return () => clearTimeout(id);
  }, [workspace, loadStats]);

  if (!workspace) return null;

  // only this workspace's subjects
  const wsSubjects = subjects.filter((s) => s.workspaceId === workspace.id);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    await addSubject(name.trim(), color, workspace.id, code.trim(), semester.trim());
    setName("");
    setCode("");
    setSemester("");
  };

  const countFor = (subName: string) =>
    deadlines.filter((d) => !d.done && d.subject.trim().toLowerCase() === subName.toLowerCase())
      .length;

  const notesFor = (subName: string) =>
    notes.filter((n) => (n.subject ?? "").trim().toLowerCase() === subName.toLowerCase()).length;

  const totalOpen = wsSubjects.reduce((a, s) => a + countFor(s.name), 0);
  const totalNotes = wsSubjects.reduce((a, s) => a + notesFor(s.name), 0);
  const totalWeek = wsSubjects.reduce(
    (a, s) =>
      a +
      (study.find((x) => x.subject.toLowerCase() === s.name.toLowerCase())?.weekMinutes ?? 0),
    0
  );

  return (
    <div className="flex flex-col gap-4 @container @3xl:gap-5">
      {/* ---------- page header ---------- */}
      <div className="animate-fade-up flex flex-wrap items-center gap-2.5">
        <button
          onClick={() => openSection("workspaces")}
          className="btn-ghost px-3.5 py-2 text-[12.5px] font-semibold"
          style={{ background: "var(--surface)" }}
        >
          <ChevronLeft size={13} />
          All workspaces
        </button>
        <button
          onClick={exitWorkspace}
          className="btn-ghost px-3.5 py-2 text-[12.5px] font-semibold"
          style={{ background: "var(--surface)" }}
        >
          <LayoutGrid size={13} />
          Dashboard
        </button>
      </div>

      <header
        className="animate-fade-up card flex flex-wrap items-center gap-4 p-5 sm:p-6"
        style={{ animationDelay: "0.04s" }}
      >
        <span
          className="flex h-14 w-14 shrink-0 items-center justify-center rounded-3xl"
          style={{
            background: "var(--accent)",
            color: "var(--accent-ink)",
            boxShadow: "0 12px 26px -10px var(--accent)",
          }}
        >
          <BookMarked size={22} />
        </span>
        <div className="min-w-0 flex-1">
          <p
            className="text-[10.5px] font-bold tracking-[0.15em] uppercase"
            style={{ color: "var(--accent)" }}
          >
            Subject dashboard
          </p>
          <h1
            className="font-display truncate text-[26px] leading-tight font-semibold sm:text-[30px]"
            style={{ color: "var(--ink)" }}
          >
            {workspace.name}
          </h1>
          <p className="mt-0.5 text-[12.5px]" style={{ color: "var(--ink-soft)" }}>
            {wsSubjects.length} subject{wsSubjects.length === 1 ? "" : "s"} in this workspace
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {[
            { label: "Open assignments", value: String(totalOpen) },
            { label: "Notes", value: String(totalNotes) },
            { label: "This week", value: fmt(totalWeek) },
          ].map((st) => (
            <div
              key={st.label}
              className="rounded-2xl px-4 py-2.5 text-center"
              style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
            >
              <p className="font-display text-[19px] font-semibold" style={{ color: "var(--ink)" }}>
                {st.value}
              </p>
              <p
                className="text-[10px] font-semibold tracking-[0.1em] uppercase"
                style={{ color: "var(--ink-faint)" }}
              >
                {st.label}
              </p>
            </div>
          ))}
        </div>
      </header>

      {/* ---------- add a subject ---------- */}
      <form
        onSubmit={submit}
        className="animate-fade-up card flex flex-col gap-3 p-4 sm:p-5"
        style={{ animationDelay: "0.08s" }}
      >
        <div className="flex flex-wrap items-center gap-2.5">
          <span
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
            style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
          >
            <Plus size={14} />
          </span>
          <input
            className="input-line min-w-40 flex-1"
            placeholder={`New subject in ${workspace.name} — e.g. Physics`}
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={40}
          />
          <input
            className="input-line w-24"
            placeholder="Code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            maxLength={16}
            aria-label="Subject code"
          />
          <input
            className="input-line w-32"
            placeholder="Semester"
            value={semester}
            onChange={(e) => setSemester(e.target.value)}
            maxLength={32}
            aria-label="Semester or term"
          />
          <button
            type="submit"
            disabled={!name.trim()}
            className="btn-accent h-9 px-4 text-[12.5px] font-semibold disabled:opacity-40"
          >
            <Check size={14} />
            Add
          </button>
        </div>
        <div className="flex items-center gap-1.5 pl-11">
          {Object.entries(DEADLINE_COLORS).map(([key, c]) => (
            <button
              key={key}
              type="button"
              onClick={() => setColor(key)}
              aria-label={key}
              className="h-6 w-6 rounded-full transition-transform hover:scale-110"
              style={{
                background: c,
                boxShadow: color === key ? `0 0 0 2px var(--surface), 0 0 0 4px ${c}` : "none",
              }}
            />
          ))}
        </div>
      </form>

      {/* ---------- subject cards ---------- */}
      <div
        className="animate-fade-up grid grid-cols-1 gap-4 @2xl:grid-cols-2 @5xl:grid-cols-3"
        style={{ animationDelay: "0.12s" }}
      >
        {wsSubjects.map((s) => (
          <SubjectCard
            key={s.id}
            subject={s}
            deadlines={deadlines}
            notes={notes}
            study={study}
            targets={targets}
            onOpenProgress={() => {
              openSection("analytics");
              push("info", `Progress for ${s.name} lives in the analytics view`);
            }}
          />
        ))}
      </div>

      {wsSubjects.length === 0 && (
        <div
          className="animate-fade-up card flex flex-col items-center gap-2 px-6 py-16 text-center"
          style={{ animationDelay: "0.12s" }}
        >
          <BookMarked size={24} style={{ color: "var(--ink-faint)" }} />
          <p className="font-display text-[17px] font-semibold" style={{ color: "var(--ink)" }}>
            No subjects in {workspace.name} yet
          </p>
          <p className="max-w-sm text-[13px]" style={{ color: "var(--ink-faint)" }}>
            Add your first subject above, then use it to label deadlines, notes and flashcards.
          </p>
        </div>
      )}

      <p
        className="rounded-2xl px-4 py-3 text-[11.5px] leading-relaxed"
        style={{ background: "var(--accent-soft)", color: "var(--ink-soft)" }}
      >
        Each card's progress blends assignment completion (60%) with focus hours against your
        study target (40%). Set targets in the Analytics drawer to tune a subject's bar.
      </p>
    </div>
  );
}
