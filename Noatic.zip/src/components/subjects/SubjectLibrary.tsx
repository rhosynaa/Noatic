"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  BookOpen,
  ChevronLeft,
  LayoutGrid,
  Network,
  Pin,
  Plus,
  Search,
  SlidersHorizontal,
} from "lucide-react";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { findLinkedMap, useMindmapsList } from "@/lib/mindmap-nav";
import { NoteEditor } from "@/components/widgets/NotesWidget";
import LibraryTagFilter from "@/components/subjects/LibraryTagFilter";
import { DEADLINE_COLORS, NOTE_COLORS, type Note, type Subject } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

/** loose name compare so "Biology" and " biology " land in the same library */
export const sameSubject = (a: string, b: string) =>
  a.trim().toLowerCase() === b.trim().toLowerCase();

/** grid density — how many book covers sit on one row */
export type Density = 2 | 3 | 4 | 5;
const DENSITIES: Density[] = [2, 3, 4, 5];
const DENSITY_KEY = "dreamy.library.density";

const DENSITY_CLASS: Record<Density, string> = {
  2: "grid-cols-2",
  3: "grid-cols-2 sm:grid-cols-3",
  4: "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4",
  5: "grid-cols-2 sm:grid-cols-3 lg:grid-cols-5",
};

/** how many libraries the rail shows before it starts scrolling */
const RAIL_VISIBLE = 10;
/** the `gap-1.5` between rail rows, in px — used to measure the cut-off */
const RAIL_GAP = 6;

/** deterministic spine colour for a note that has no image of its own */
const SPINE_TONES = ["#b05c4a", "#cf9c44", "#8b7bc4", "#6d9e7d", "#4f7fa8", "#c2708f"];
export function autoTone(seed: string): string {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return SPINE_TONES[h % SPINE_TONES.length];
}

const wordCount = (s: string) => s.split(/\s+/).filter(Boolean).length;

/* ------------------------------------------------------------------ */
/* one note rendered as a vertical book cover                          */
/* ------------------------------------------------------------------ */

function BookCover({
  note,
  onOpen,
  activeTags = [],
}: {
  note: Note;
  onOpen: () => void;
  /** tags currently filtering the shelf — highlighted on the cover */
  activeTags?: string[];
}) {
  // the note's own image wins; otherwise a colour generated from the note
  const paper = NOTE_COLORS[note.color]?.bg;
  const tone = paper ? autoTone(note.color + note.id) : autoTone(note.id);

  return (
    <button
      onClick={onOpen}
      aria-label={`Open note ${note.title || "Untitled"}`}
      title={note.title || "Untitled note"}
      className="group/book flex flex-col text-left transition-transform duration-200 hover:-translate-y-1.5 focus-visible:-translate-y-1.5 focus-visible:outline-none"
    >
      {/* the cover — a tall 2:3 "book" standing on the shelf */}
      <div
        className="relative w-full overflow-hidden rounded-r-xl rounded-l-md shadow-md transition-shadow duration-200 group-hover/book:shadow-xl"
        style={{
          aspectRatio: "2 / 3",
          background: note.imageUrl ? "var(--surface-3)" : paper || tone,
          border: "1px solid var(--line)",
        }}
      >
        {note.imageUrl ? (
          <img
            src={note.imageUrl}
            alt=""
            className="h-full w-full object-cover"
            onError={(e) => ((e.currentTarget.style.display = "none"))}
          />
        ) : (
          <div className="absolute inset-0" style={{ background: `linear-gradient(150deg, ${tone}26, ${tone}05)` }} />
        )}

        {/* the spine strip down the left edge */}
        <div
          className="absolute inset-y-0 left-0 w-[9px]"
          style={{ background: tone, boxShadow: "inset -1px 0 2px rgba(0,0,0,0.18)" }}
        />
        <div
          className="absolute inset-y-0 left-[9px] w-[3px]"
          style={{ background: "linear-gradient(to right, rgba(0,0,0,0.13), transparent)" }}
        />

        {/* title block printed on the cover */}
        {!note.imageUrl && (
          <div className="absolute inset-0 flex flex-col p-3 pl-5">
            <p
              className="font-display line-clamp-4 text-[13.5px] leading-snug font-semibold"
              style={{ color: "var(--ink)" }}
            >
              {note.title || "Untitled"}
            </p>
            <p className="mt-1.5 line-clamp-3 text-[10px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>
              {note.content}
            </p>
            <span className="flex-1" />
            <span
              className="self-start rounded-full px-2 py-0.5 text-[8.5px] font-bold tracking-[0.08em] uppercase"
              style={{ background: "rgba(255,255,255,0.55)", color: tone }}
            >
              {wordCount(note.content)} words
            </span>
          </div>
        )}

        {/* image covers get a readable caption bar instead */}
        {note.imageUrl && (
          <div
            className="absolute inset-x-0 bottom-0 p-2.5 pl-4"
            style={{ background: "linear-gradient(to top, rgba(24,18,10,0.82), transparent)" }}
          >
            <p className="font-display line-clamp-2 text-[12.5px] leading-snug font-semibold text-white">
              {note.title || "Untitled"}
            </p>
          </div>
        )}

        {note.pinned && (
          <span
            className="absolute top-2 right-2 flex h-6 w-6 items-center justify-center rounded-full"
            style={{ background: "rgba(255,255,255,0.85)", color: tone }}
          >
            <Pin size={11} />
          </span>
        )}
      </div>

      {/* shelf label under the book */}
      <p className="mt-2 line-clamp-2 px-0.5 text-[11.5px] leading-snug font-semibold" style={{ color: "var(--ink)" }}>
        {note.title || "Untitled"}
      </p>
      <p className="px-0.5 text-[10px]" style={{ color: "var(--ink-faint)" }}>
        {new Date(note.updatedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
      </p>
      {/* the note's hashtags, so it's clear what the filter matches on */}
      {(note.tags ?? []).length > 0 && (
        <span className="mt-1 flex flex-wrap gap-1 px-0.5">
          {(note.tags ?? []).slice(0, 3).map((t) => (
            <span
              key={t}
              className="rounded-full px-1.5 py-0.5 text-[8.5px] font-bold"
              style={{
                background: activeTags.some((a) => a.toLowerCase() === t.toLowerCase())
                  ? "var(--accent)"
                  : "var(--surface-2)",
                color: activeTags.some((a) => a.toLowerCase() === t.toLowerCase())
                  ? "var(--accent-ink)"
                  : "var(--ink-faint)",
              }}
            >
              #{t}
            </span>
          ))}
        </span>
      )}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* the library page for one subject                                    */
/* ------------------------------------------------------------------ */

export default function SubjectLibrary({ subject }: { subject: Subject }) {
  const { closeLibrary, openLibrary, openMindmap } = useSections();
  const { notes, subjects, addNote } = useDashboard();
  const { maps: mindmaps } = useMindmapsList();
  /** the mind map linked to this subject, if any */
  const linkedMap = findLinkedMap(mindmaps, "subject", subject.id);
  const [editing, setEditing] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [densityOpen, setDensityOpen] = useState(false);
  const [activeTags, setActiveTags] = useState<string[]>([]);

  /* grid density is a preference, so it survives reloads */
  const [density, setDensity] = useState<Density>(() => {
    if (typeof window === "undefined") return 4;
    const raw = Number(window.localStorage.getItem(DENSITY_KEY));
    return (DENSITIES as number[]).includes(raw) ? (raw as Density) : 4;
  });
  useEffect(() => {
    try {
      window.localStorage.setItem(DENSITY_KEY, String(density));
    } catch {
      /* preference is best-effort */
    }
  }, [density]);

  /* only the subjects of the workspace we're browsing, for the rail */
  const siblings = useMemo(
    () => subjects.filter((s) => s.workspaceId === subject.workspaceId),
    [subjects, subject.workspaceId]
  );

  /* the rail shows ten libraries at a time — the rest are a scroll away.
     the cap is measured off the real rows so it lands on an exact boundary. */
  const railRef = useRef<HTMLDivElement | null>(null);
  const [railMax, setRailMax] = useState<number | null>(null);
  useLayoutEffect(() => {
    if (siblings.length <= RAIL_VISIBLE) {
      setRailMax(null);
      return;
    }
    const measure = () => {
      const rows = railRef.current?.children;
      if (!rows || rows.length <= RAIL_VISIBLE) return;
      const first = rows[0] as HTMLElement;
      const cutoff = rows[RAIL_VISIBLE] as HTMLElement;
      // distance from the top of row 1 to the top of row 11, minus the gap
      const h = cutoff.offsetTop - first.offsetTop - RAIL_GAP;
      if (h > 0) setRailMax(h);
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [siblings.length]);

  /* every note filed under this subject */
  const mine = useMemo(
    () => notes.filter((n) => sameSubject(n.subject ?? "", subject.name)),
    [notes, subject.name]
  );

  /* every unique hashtag on this shelf, with how many notes carry each */
  const { tagList, tagCounts } = useMemo(() => {
    const counts: Record<string, number> = {};
    const canon = new Map<string, string>(); // lowercase → first spelling seen
    for (const n of mine)
      for (const raw of n.tags ?? []) {
        const t = raw.trim();
        if (!t) continue;
        const key = t.toLowerCase();
        if (!canon.has(key)) canon.set(key, t);
        const name = canon.get(key)!;
        counts[name] = (counts[name] ?? 0) + 1;
      }
    return {
      tagList: [...canon.values()].sort((a, b) => a.localeCompare(b)),
      tagCounts: counts,
    };
  }, [mine]);

  /* a tag that disappears (last note untagged) shouldn't stay in the filter */
  useEffect(() => {
    setActiveTags((prev) => {
      const keep = prev.filter((t) => tagList.some((x) => x.toLowerCase() === t.toLowerCase()));
      return keep.length === prev.length ? prev : keep;
    });
  }, [tagList]);

  /* apply the tag filter, then the text search — pinned first, then newest */
  const shelf = useMemo(() => {
    // a note must carry every selected tag
    const tagged = activeTags.length
      ? mine.filter((n) => {
          const has = (n.tags ?? []).map((t) => t.toLowerCase());
          return activeTags.every((t) => has.includes(t.toLowerCase()));
        })
      : mine;
    const q = query.trim().toLowerCase();
    const found = q
      ? tagged.filter(
          (n) =>
            n.title.toLowerCase().includes(q) ||
            n.content.toLowerCase().includes(q) ||
            (n.tags ?? []).some((t) => t.toLowerCase().includes(q))
        )
      : tagged;
    return [...found].sort(
      (a, b) =>
        Number(b.pinned) - Number(a.pinned) ||
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }, [mine, query, activeTags]);

  const toggleTag = (tag: string) =>
    setActiveTags((prev) =>
      prev.some((t) => t.toLowerCase() === tag.toLowerCase())
        ? prev.filter((t) => t.toLowerCase() !== tag.toLowerCase())
        : [...prev, tag]
    );

  /* the live note object, so edits show through immediately */
  const editingNote = editing ? (notes.find((n) => n.id === editing) ?? null) : null;

  const tone = DEADLINE_COLORS[subject.color] ?? "var(--accent)";

  /** new notes made here are pre-filed under this subject */
  const createNote = async () => {
    const row = await addNote({
      title: "",
      content: "",
      subject: subject.name,
      color: subject.color in NOTE_COLORS ? subject.color : "cream",
    });
    if (row) setEditing(row.id);
  };

  return (
    <div className="animate-fade-up flex flex-col gap-4 sm:flex-row sm:items-start">
      {/* ---------- left rail: jump between subject libraries ---------- */}
      <aside
        className="shrink-0 rounded-3xl p-3 sm:w-[194px]"
        style={{ background: "var(--surface)", border: "1px solid var(--line)", boxShadow: "var(--card-shadow)" }}
      >
        <p className="flex items-center gap-1.5 px-1.5 pb-2 text-[9.5px] font-bold tracking-[0.13em] uppercase" style={{ color: "var(--ink-faint)" }}>
          Libraries
          <span className="normal-case opacity-80">· {siblings.length}</span>
        </p>
        <div
          ref={railRef}
          className="rail-scroll flex gap-1.5 overflow-x-auto sm:flex-col sm:overflow-x-visible sm:overflow-y-auto"
          // past ten subjects the rail keeps its height and scrolls instead
          style={railMax ? { maxHeight: railMax } : undefined}
        >
          {siblings.map((s) => {
            const active = s.id === subject.id;
            const count = notes.filter((n) => sameSubject(n.subject ?? "", s.name)).length;
            const sTone = DEADLINE_COLORS[s.color] ?? "var(--accent)";
            return (
              <button
                key={s.id}
                onClick={() => openLibrary({ id: s.id, name: s.name })}
                aria-current={active ? "page" : undefined}
                className="flex shrink-0 items-center gap-2 rounded-2xl px-2.5 py-2 text-left transition-colors sm:w-full"
                style={{
                  background: active ? "var(--accent-soft)" : "transparent",
                  color: active ? "var(--ink)" : "var(--ink-soft)",
                }}
              >
                <span className="h-6 w-1.5 shrink-0 rounded-full" style={{ background: sTone }} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] font-semibold">{s.name}</span>
                  <span className="block text-[10px]" style={{ color: "var(--ink-faint)" }}>
                    {count} note{count === 1 ? "" : "s"}
                  </span>
                </span>
              </button>
            );
          })}
          {siblings.length === 0 && (
            <p className="px-1.5 py-2 text-[11px]" style={{ color: "var(--ink-faint)" }}>
              No subjects yet.
            </p>
          )}
        </div>
        {railMax && (
          <p
            className="hidden px-1.5 pt-1.5 text-[9.5px] font-semibold sm:block"
            style={{ color: "var(--ink-faint)", borderTop: "1px solid var(--line-soft)" }}
          >
            Showing {RAIL_VISIBLE} of {siblings.length} — scroll for more
          </p>
        )}
      </aside>

      {/* ---------- the shelf ---------- */}
      <section className="min-w-0 flex-1">
        {/* header */}
        <div
          className="mb-4 rounded-3xl p-4 sm:p-5"
          style={{ background: "var(--surface)", border: "1px solid var(--line)", boxShadow: "var(--card-shadow)" }}
        >
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={closeLibrary}
              className="btn-ghost h-8 gap-1 px-2.5 text-[11.5px] font-semibold"
              aria-label="Back to subjects"
            >
              <ChevronLeft size={13} /> Subjects
            </button>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase" style={{ color: tone }}>
                {subject.code || "Library"}
              </p>
              <h2 className="font-display truncate text-[21px] leading-tight font-semibold" style={{ color: "var(--ink)" }}>
                {subject.name}
              </h2>
            </div>

            {/* density control — 2, 3, 4 or 5 covers per row */}
            <div className="relative">
              <button
                onClick={() => setDensityOpen((v) => !v)}
                aria-expanded={densityOpen}
                aria-label="Grid density settings"
                title="Books per row"
                className="btn-ghost h-8 gap-1.5 px-2.5 text-[11.5px] font-semibold"
              >
                <SlidersHorizontal size={13} /> {density} per row
              </button>
              {densityOpen && (
                <>
                  <div className="fixed inset-0 z-[60]" onClick={() => setDensityOpen(false)} />
                  <div
                    className="animate-pop absolute right-0 z-[61] mt-1.5 w-[188px] rounded-2xl p-2.5"
                    style={{
                      background: "var(--surface)",
                      border: "1px solid var(--line)",
                      boxShadow: "0 18px 40px rgba(24,18,10,0.18)",
                    }}
                  >
                    <p
                      className="mb-1.5 flex items-center gap-1.5 px-0.5 text-[9.5px] font-bold tracking-[0.12em] uppercase"
                      style={{ color: "var(--ink-faint)" }}
                    >
                      <LayoutGrid size={11} /> Books per row
                    </p>
                    <div className="grid grid-cols-4 gap-1.5">
                      {DENSITIES.map((d) => (
                        <button
                          key={d}
                          onClick={() => {
                            setDensity(d);
                            setDensityOpen(false);
                          }}
                          aria-pressed={density === d}
                          className="rounded-xl py-2 text-[13px] font-bold transition-all hover:-translate-y-0.5"
                          style={{
                            background: density === d ? "var(--accent)" : "var(--surface-2)",
                            color: density === d ? "var(--accent-ink)" : "var(--ink-soft)",
                            border: `1px solid ${density === d ? "var(--accent)" : "var(--line-soft)"}`,
                          }}
                        >
                          {d}
                        </button>
                      ))}
                    </div>
                    <p className="mt-2 px-0.5 text-[10px] leading-relaxed" style={{ color: "var(--ink-faint)" }}>
                      Your choice is remembered for every library.
                    </p>
                  </div>
                </>
              )}
            </div>

            <button onClick={createNote} className="btn-accent h-8 gap-1.5 px-3 text-[11.5px] font-semibold">
              <Plus size={13} /> New note
            </button>
          </div>

          {/* search within this library */}
          <div className="mt-3 flex items-center gap-2 rounded-2xl px-3 py-1.5" style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}>
            <Search size={13} style={{ color: "var(--ink-faint)" }} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={`Search ${subject.name} notes…`}
              aria-label={`Search notes in ${subject.name}`}
              className="min-w-0 flex-1 bg-transparent py-1 text-[12.5px] outline-none"
              style={{ color: "var(--ink)" }}
            />
            <span className="shrink-0 text-[10.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
              {shelf.length} book{shelf.length === 1 ? "" : "s"}
            </span>
          </div>

          {/* dynamic hashtag filter — click to browse, or type to autocomplete */}
          <LibraryTagFilter
            tags={tagList}
            counts={tagCounts}
            active={activeTags}
            onToggle={toggleTag}
            onClear={() => setActiveTags([])}
          />
        </div>

        {/* the grid of book covers */}
        {shelf.length > 0 ? (
          <div className={`grid gap-x-4 gap-y-5 ${DENSITY_CLASS[density]}`}>
            {shelf.map((n) => (
              <BookCover
                key={n.id}
                note={n}
                activeTags={activeTags}
                onOpen={() => setEditing(n.id)}
              />
            ))}
          </div>
        ) : (
          <div
            className="flex flex-col items-center gap-2 rounded-3xl px-6 py-14 text-center"
            style={{ background: "var(--surface)", border: "1px dashed var(--line)" }}
          >
            <BookOpen size={26} style={{ color: "var(--ink-faint)" }} />
            <p className="text-[13.5px] font-semibold" style={{ color: "var(--ink)" }}>
              {activeTags.length
                ? `No notes tagged ${activeTags.map((t) => `#${t}`).join(" + ")}`
                : query
                  ? "No notes match that search"
                  : `No notes in ${subject.name} yet`}
            </p>
            <p className="max-w-[330px] text-[11.5px] leading-relaxed" style={{ color: "var(--ink-faint)" }}>
              {activeTags.length
                ? "Try removing a tag — notes must carry every tag you pick."
                : query
                  ? "Try a different word, or clear the search."
                  : `Make one here, or set a note's subject to "${subject.name}" from the dashboard and it lands on this shelf.`}
            </p>
            {activeTags.length > 0 && (
              <button
                onClick={() => setActiveTags([])}
                className="btn-ghost mt-1.5 px-3.5 py-2 text-[12px] font-semibold"
              >
                Clear tag filter
              </button>
            )}
            {!query && activeTags.length === 0 && (
              <button onClick={createNote} className="btn-accent mt-1.5 gap-1.5 px-3.5 py-2 text-[12px] font-semibold">
                <Plus size={13} /> Write the first note
              </button>
            )}
          </div>
        )}
      </section>

      {/* clicking a cover opens the real note editor */}
      {editingNote && <NoteEditor note={editingNote} onClose={() => setEditing(null)} />}
    </div>
  );
}
