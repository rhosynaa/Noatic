"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  Check,
  ChevronDown,
  Flame,
  GraduationCap,
  ListChecks,
  MessageSquareQuote,
  PanelLeftOpen,
  PanelRightClose,
  Pencil,
  Plus,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import { useSections } from "@/lib/sections-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import {
  GRADE_POINTS,
  type FocusSession,
  type GpaCourse,
  type SelfAssessment,
  type Task,
} from "@/lib/types";

/** remembers whether the overview panel is collapsed */
const SIDEBAR_KEY = "dreamy.workspaceRail.collapsed";

const STUDY_KINDS = new Set(["focus", "custom"]);

/**
 * Re-renders once each midnight so date-derived labels and ranges never go
 * stale on a tab that's been left open overnight.
 */
function useMidnightTick(): number {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const schedule = () => {
      const next = new Date();
      next.setHours(24, 0, 0, 30); // a hair past midnight
      timer = setTimeout(() => {
        setTick((n) => n + 1);
        schedule();
      }, next.getTime() - Date.now());
    };
    schedule();
    return () => clearTimeout(timer);
  }, []);
  return tick;
}
const dayKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const fmtShort = (d: Date) =>
  d.toLocaleDateString(undefined, { month: "short", day: "numeric" });

function Panel({
  icon,
  title,
  action,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="card p-4">
      <div className="mb-3 flex items-center gap-2">
        <span
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl"
          style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
        >
          {icon}
        </span>
        <h3
          className="flex-1 text-[11px] font-bold tracking-[0.12em] uppercase"
          style={{ color: "var(--ink-soft)" }}
        >
          {title}
        </h3>
        {action}
      </div>
      {children}
    </section>
  );
}

/* shared filter pill — mirrors the Canvas-style dropdowns in the reference */
function FilterSelect({
  value,
  onChange,
  label,
  wide = false,
  children,
}: {
  value: string;
  onChange: (v: string) => void;
  label: string;
  wide?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={`relative ${wide ? "w-full" : ""}`}>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-label={label}
        className={`cursor-pointer appearance-none rounded-full pr-6 pl-2.5 text-[11px] font-semibold outline-none ${
          wide ? "w-full py-1.5" : "py-1"
        }`}
        style={{
          background: "var(--surface-2)",
          border: "1px solid var(--line)",
          color: "var(--ink-soft)",
        }}
      >
        {children}
      </select>
      <ChevronDown
        size={11}
        className="pointer-events-none absolute top-1/2 right-2 -translate-y-1/2"
        style={{ color: "var(--ink-faint)" }}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 1 — study streak (pinned to the very top)                           */
/* ------------------------------------------------------------------ */

function StudyStreak({ sessions }: { sessions: FocusSession[] }) {
  const { days, weekMap } = useMemo(() => {
    const studyDays = new Set(
      sessions
        .filter((s) => STUDY_KINDS.has(s.kind ?? "focus"))
        .map((s) => dayKey(new Date(s.completedAt)))
    );
    let streak = 0;
    const cursor = new Date();
    if (!studyDays.has(dayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
    while (studyDays.has(dayKey(cursor))) {
      streak++;
      cursor.setDate(cursor.getDate() - 1);
    }
    // last 7 days, oldest → newest
    const map: { label: string; hit: boolean }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      map.push({
        label: d.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 1),
        hit: studyDays.has(dayKey(d)),
      });
    }
    return { days: streak, weekMap: map };
  }, [sessions]);

  return (
    <Panel icon={<Flame size={14} />} title="Study streak">
      <div className="flex items-end gap-2.5">
        <p
          className="font-display text-[34px] leading-none font-semibold"
          style={{ color: "var(--accent)" }}
        >
          {days}
        </p>
        <p className="pb-1 text-[12.5px] font-medium" style={{ color: "var(--ink-soft)" }}>
          day{days === 1 ? "" : "s"} in a row
        </p>
      </div>
      <div className="mt-3 flex items-center justify-between gap-1">
        {weekMap.map((d, i) => (
          <div key={i} className="flex flex-1 flex-col items-center gap-1">
            <span
              className="flex h-7 w-full items-center justify-center rounded-lg text-[10px] font-bold transition-colors"
              style={{
                background: d.hit ? "var(--accent)" : "var(--surface-2)",
                color: d.hit ? "var(--accent-ink)" : "var(--ink-faint)",
                border: d.hit ? "none" : "1px solid var(--line-soft)",
              }}
            >
              {d.hit ? "✓" : ""}
            </span>
            <span className="text-[9.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
              {d.label}
            </span>
          </div>
        ))}
      </div>
      <p className="mt-2.5 text-[11px]" style={{ color: "var(--ink-faint)" }}>
        {days > 0
          ? "Log a focus session today to extend your streak."
          : "Start a focus session to begin a streak."}
      </p>
    </Panel>
  );
}

/* ------------------------------------------------------------------ */
/* 2 — tasks overview + big completion donut (Canvas reference layout) */
/* ------------------------------------------------------------------ */

type RangeKey = "week" | "today" | "nodate" | "all";

function inRange(t: Task, range: RangeKey): boolean {
  if (range === "all") return true;
  if (!t.dueDate) return range === "nodate";
  if (range === "nodate") return false;
  const due = new Date(t.dueDate);
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  if (range === "today") {
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    // due today, or overdue and still open
    return (due >= start && due < end) || (!t.done && due < start);
  }
  // "week" → rolling 7-day window (matches the "Oct 13 to Oct 20" range)
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  return due >= new Date(start.getTime() - 86400000) && due < end;
}

function TasksOverview() {
  const { tasks, subjects } = useDashboard();
  const { workspace } = useSections();
  const tick = useMidnightTick();
  const [range, setRange] = useState<RangeKey>("week");
  const [filter, setFilter] = useState("all");

  /* only the subjects belonging to the workspace being viewed */
  const subjectNames = useMemo(
    () =>
      [
        ...new Set(
          subjects.filter((s) => !workspace || s.workspaceId === workspace.id).map((s) => s.name)
        ),
      ].sort((a, b) => a.localeCompare(b)),
    [subjects, workspace]
  );

  /* fast lookup for "does this task belong to one of our subjects?" */
  const inWorkspace = useMemo(
    () => new Set(subjectNames.map((n) => n.trim().toLowerCase())),
    [subjectNames]
  );

  /* switching workspace can strip the picked subject — fall back to the total */
  useEffect(() => {
    if (filter !== "all" && filter !== "__none" && !inWorkspace.has(filter.trim().toLowerCase()))
      setFilter("all");
  }, [inWorkspace, filter]);

  /* the rolling week window, labelled like the reference ("Oct 13 to Oct 20") */
  const weekLabel = useMemo(() => {
    const start = new Date();
    const end = new Date();
    end.setDate(end.getDate() + 7);
    return `${fmtShort(start)} to ${fmtShort(end)}`;
    // `tick` rolls the window over at midnight instead of freezing at mount
  }, [tick]);

  const scoped = useMemo(() => {
    const ranged = tasks.filter((t) => inRange(t, range));
    if (filter === "__none") return ranged.filter((t) => !t.subject?.trim());
    // "All subjects" = the cumulative of this workspace's subjects, nothing else
    if (filter === "all")
      return ranged.filter((t) => inWorkspace.has((t.subject ?? "").trim().toLowerCase()));
    return ranged.filter(
      (t) => (t.subject ?? "").trim().toLowerCase() === filter.toLowerCase()
    );
    // `tick` keeps the counts in step with the label when the day rolls over
  }, [tasks, range, filter, inWorkspace, tick]);

  const done = scoped.filter((t) => t.done).length;
  const total = scoped.length;
  const pending = total - done;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;

  return (
    <Panel
      icon={<ListChecks size={14} />}
      title="Tasks"
      action={
        <FilterSelect value={range} onChange={(v) => setRange(v as RangeKey)} label="Filter tasks by range">
          <option value="week">{weekLabel}</option>
          <option value="today">Due today</option>
          <option value="nodate">No date</option>
          <option value="all">All tasks</option>
        </FilterSelect>
      }
    >
      {/* course filter — full width, like "All Courses" in the reference */}
      <FilterSelect
        value={filter}
        onChange={setFilter}
        label="Filter tasks by subject"
        wide
      >
        <option value="all">All subjects</option>
        {subjectNames.map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
        <option value="__none">No subject</option>
      </FilterSelect>

      {/* the big donut — CSS conic-gradient, animated via the --p property */}
      <div className="mt-4 flex justify-center">
        <div
          className="relative h-36 w-36 shrink-0 rounded-full"
          style={
            {
              "--p": `${pct}%`,
              background:
                "conic-gradient(var(--accent) 0% var(--p), var(--surface-3) var(--p) 100%)",
              transition: "--p 0.8s cubic-bezier(0.22,1,0.36,1)",
            } as React.CSSProperties
          }
          role="img"
          aria-label={`${pct}% of tasks complete — ${done} of ${total}`}
        >
          <div
            className="absolute inset-[13px] flex flex-col items-center justify-center rounded-full"
            style={{ background: "var(--surface)" }}
          >
            <span
              className="font-display text-[28px] leading-none font-semibold"
              style={{ color: "var(--accent)" }}
            >
              {total > 0 ? `${pct}%` : "—"}
            </span>
            <span
              className="mt-1 text-[10.5px] font-semibold"
              style={{ color: "var(--ink-faint)" }}
            >
              {total > 0 ? `${done}/${total} Complete` : "No tasks"}
            </span>
          </div>
        </div>
      </div>

      {/* counts — auto-update from completed vs pending */}
      <div className="mt-4 space-y-2">
        {[
          { label: "Completed", value: done, tone: "var(--accent)", hollow: false },
          { label: "Pending", value: pending, tone: "var(--ink-faint)", hollow: true },
        ].map((r) => (
          <div key={r.label} className="flex items-center gap-2">
            <span
              className="h-2.5 w-2.5 shrink-0 rounded-full"
              style={
                r.hollow
                  ? { border: "2px solid var(--surface-3)" }
                  : { background: r.tone }
              }
            />
            <span className="flex-1 truncate text-[12px]" style={{ color: "var(--ink-soft)" }}>
              {r.label}
            </span>
            <span className="text-[13px] font-bold" style={{ color: "var(--ink)" }}>
              {r.value}
            </span>
          </div>
        ))}
        <p
          className="border-t pt-1.5 text-[11px]"
          style={{ borderColor: "var(--line-soft)", color: "var(--ink-faint)" }}
        >
          {total} task{total === 1 ? "" : "s"} tracked
          {workspace ? ` · ${workspace.name}` : ""}
        </p>
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------------ */
/* 3 — self assessment (recent self-graded work + my commentary)       */
/* ------------------------------------------------------------------ */

function SelfAssessmentPanel() {
  const { push } = useToast();
  const { subjects } = useDashboard();
  const { openSection, workspace } = useSections();

  /* suggest only the subjects that live in the workspace being viewed */
  const wsSubjects = useMemo(
    () => subjects.filter((s) => !workspace || s.workspaceId === workspace.id),
    [subjects, workspace]
  );
  const [rows, setRows] = useState<SelfAssessment[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [adding, setAdding] = useState(false);
  const [nTitle, setNTitle] = useState("");
  const [nSubject, setNSubject] = useState("");
  const [nScore, setNScore] = useState("");
  const [nMax, setNMax] = useState("100");
  const [nComment, setNComment] = useState("");

  const load = useCallback(async () => {
    try {
      setRows(await api<SelfAssessment[]>("/api/self-assessments"));
    } catch {
      /* quiet */
    }
  }, []);

  useEffect(() => {
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [load]);

  const resetNew = () => {
    setNTitle("");
    setNSubject("");
    setNScore("");
    setNMax("100");
    setNComment("");
  };

  const submitNew = async (e: FormEvent) => {
    e.preventDefault();
    const title = nTitle.trim();
    if (!title) return;
    try {
      const row = await api<SelfAssessment>("/api/self-assessments", {
        method: "POST",
        body: {
          title,
          subject: nSubject.trim(),
          score: nScore === "" ? 0 : Number(nScore),
          maxScore: nMax === "" ? 100 : Number(nMax),
          comment: nComment.trim(),
        },
      });
      setRows((r) => [row, ...r]);
      push("success", "Self-assessment logged");
      resetNew();
      setAdding(false);
    } catch {
      push("error", "Couldn't add that self-assessment");
    }
  };

  const saveComment = async (row: SelfAssessment) => {
    const comment = draft.trim();
    setEditingId(null);
    setRows((r) => r.map((x) => (x.id === row.id ? { ...x, comment } : x)));
    try {
      await api(`/api/self-assessments/${row.id}`, { method: "PATCH", body: { comment } });
      push("success", "Comment saved");
    } catch {
      push("error", "Couldn't save that comment");
      void load();
    }
  };

  const toneFor = (p: number) => (p >= 85 ? "#6d9e7d" : p >= 70 ? "#cf9c44" : "#d4705c");

  return (
    <Panel
      icon={<MessageSquareQuote size={14} />}
      title="Self-assessment"
      action={
        <button
          onClick={() => {
            setAdding((v) => !v);
            setEditingId(null);
          }}
          aria-expanded={adding}
          className="btn-ghost px-2.5 py-1 text-[10.5px] font-bold"
          style={{ background: "var(--surface-2)" }}
        >
          <Plus size={10.5} />
          {adding ? "Close" : "Add"}
        </button>
      }
    >
      {/* ---------- make a new self-assessment ---------- */}
      {adding && (
        <form
          onSubmit={submitNew}
          className="animate-pop mb-3 flex flex-col gap-2 rounded-2xl p-2.5"
          style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
        >
          <input
            autoFocus
            className="input-line !py-1.5 text-[12px]"
            placeholder="What did you finish? — e.g. Lab report 3"
            value={nTitle}
            onChange={(e) => setNTitle(e.target.value)}
            maxLength={120}
            aria-label="Title of the work you are grading"
          />
          <div className="flex items-center gap-1.5">
            <input
              className="input-line min-w-0 flex-1 !py-1.5 text-[11.5px]"
              placeholder="Subject"
              value={nSubject}
              onChange={(e) => setNSubject(e.target.value)}
              list="sa-subject-options"
              maxLength={40}
              aria-label="Subject"
            />
            <datalist id="sa-subject-options">
              {wsSubjects.map((s) => (
                <option key={s.id} value={s.name} />
              ))}
            </datalist>
            <input
              type="number"
              min={0}
              max={1000}
              className="input-box w-14 shrink-0 !px-1.5 !py-1 text-center text-[11.5px]"
              placeholder="Score"
              value={nScore}
              onChange={(e) => setNScore(e.target.value)}
              aria-label="Your score"
            />
            <span className="text-[11px] font-bold" style={{ color: "var(--ink-faint)" }}>
              /
            </span>
            <input
              type="number"
              min={1}
              max={1000}
              className="input-box w-14 shrink-0 !px-1.5 !py-1 text-center text-[11.5px]"
              value={nMax}
              onChange={(e) => setNMax(e.target.value)}
              aria-label="Maximum score"
            />
          </div>
          <textarea
            rows={2}
            className="input-box resize-none !py-1.5 text-[11.5px]"
            placeholder="How did it go? (optional)"
            value={nComment}
            onChange={(e) => setNComment(e.target.value)}
            maxLength={280}
            aria-label="Your commentary"
          />
          <div className="flex items-center justify-end gap-1.5">
            <button
              type="button"
              onClick={() => {
                setAdding(false);
                resetNew();
              }}
              className="btn-ghost h-7 w-7 !p-0"
              aria-label="Cancel"
            >
              <X size={12} />
            </button>
            <button
              type="submit"
              disabled={!nTitle.trim()}
              className="btn-accent h-7 px-2.5 text-[11px] font-semibold disabled:opacity-40"
            >
              <Check size={12} />
              Save
            </button>
          </div>
        </form>
      )}

      {rows.length === 0 ? (
        <p
          className="rounded-xl px-3 py-6 text-center text-[12px]"
          style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}
        >
          No self-graded work yet — tap Add to grade one.
        </p>
      ) : (
        <div className="flex flex-col gap-2.5">
          {rows.slice(0, 4).map((r) => {
            const pctScore = Math.round((r.score / r.maxScore) * 100);
            const tone = toneFor(pctScore);
            const editing = editingId === r.id;
            return (
              <div
                key={r.id}
                className="rounded-2xl p-3"
                style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
              >
                <div className="flex items-start gap-2.5">
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[12px] font-bold"
                    style={{ background: `${tone}22`, color: tone }}
                  >
                    {pctScore}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-semibold" style={{ color: "var(--ink)" }}>
                      {r.title}
                    </p>
                    <p className="text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                      {r.subject && `${r.subject} · `}
                      {new Date(r.assessedAt).toLocaleDateString(undefined, {
                        month: "short",
                        day: "numeric",
                      })}
                      {" · "}
                      {r.score}/{r.maxScore}
                    </p>
                  </div>
                  {!editing && (
                    <button
                      onClick={() => {
                        setEditingId(r.id);
                        setDraft(r.comment);
                      }}
                      aria-label={`Edit comment on ${r.title}`}
                      className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-[var(--accent-soft)]"
                      style={{ color: "var(--ink-faint)" }}
                    >
                      <Pencil size={11.5} />
                    </button>
                  )}
                </div>

                {editing ? (
                  <div className="mt-2 flex items-end gap-1.5">
                    <textarea
                      autoFocus
                      rows={2}
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      maxLength={280}
                      placeholder="How did it go?"
                      className="input-box flex-1 resize-none !py-1.5 text-[11.5px]"
                    />
                    <button
                      onClick={() => void saveComment(r)}
                      aria-label="Save comment"
                      className="btn-accent h-7 w-7 shrink-0 !p-0"
                    >
                      <Check size={12} />
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      aria-label="Cancel comment"
                      className="btn-ghost h-7 w-7 shrink-0 !p-0"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ) : (
                  r.comment && (
                    <p
                      className="mt-1.5 text-[11.5px] leading-relaxed italic"
                      style={{ color: "var(--ink-soft)" }}
                    >
                      “{r.comment}”
                    </p>
                  )
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ---------- view every assessment on the full page ---------- */}
      {rows.length > 0 && (
        <button
          onClick={() => openSection("selfassessments")}
          className="btn-ghost mt-3 w-full justify-center py-1.5 text-[11.5px] font-semibold"
          style={{ borderStyle: "dashed" }}
        >
          <MessageSquareQuote size={12} />
          View all {rows.length} assessment{rows.length === 1 ? "" : "s"}
        </button>
      )}
    </Panel>
  );
}

/* ------------------------------------------------------------------ */
/* 4 — GPA calculator                                                  */
/* ------------------------------------------------------------------ */

function GpaCalculator() {
  const { openSection } = useSections();
  const [rows, setRows] = useState<GpaCourse[]>([]);

  const load = useCallback(async () => {
    try {
      setRows(await api<GpaCourse[]>("/api/gpa-courses"));
    } catch {
      /* quiet */
    }
  }, []);

  useEffect(() => {
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [load]);

  const { current, weighted, credits } = useMemo(() => {
    const cr = rows.reduce((a, r) => a + r.credits, 0);
    if (cr === 0) return { current: 0, weighted: 0, credits: 0 };
    const base = rows.reduce((a, r) => a + (GRADE_POINTS[r.grade] ?? 0) * r.credits, 0);
    const wt = rows.reduce(
      (a, r) => a + ((GRADE_POINTS[r.grade] ?? 0) + r.weight) * r.credits,
      0
    );
    return { current: base / cr, weighted: wt / cr, credits: cr };
  }, [rows]);

  return (
    <Panel
      icon={<GraduationCap size={14} />}
      title="GPA calculator"
      action={
        <button
          onClick={() => openSection("gpatracker")}
          aria-label="Edit calculator — open the GPA tracker page"
          className="btn-ghost px-2.5 py-1 text-[10.5px] font-bold"
          style={{ background: "var(--surface-2)" }}
        >
          <SlidersHorizontal size={10.5} />
          Edit calculator
        </button>
      }
    >
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: "Current GPA", value: current, accent: false },
          { label: "Weighted GPA", value: weighted, accent: true },
        ].map((g) => (
          <div
            key={g.label}
            className="rounded-2xl px-3 py-2.5 text-center"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
          >
            <p
              className="font-display text-[22px] leading-none font-semibold"
              style={{ color: g.accent ? "var(--accent)" : "var(--ink)" }}
            >
              {g.value.toFixed(2)}
            </p>
            <p
              className="mt-1 text-[9.5px] font-bold tracking-[0.1em] uppercase"
              style={{ color: "var(--ink-faint)" }}
            >
              {g.label}
            </p>
          </div>
        ))}
      </div>
      <p className="mt-2 text-[11px]" style={{ color: "var(--ink-faint)" }}>
        {rows.length} course{rows.length === 1 ? "" : "s"} · {credits} credit hours
      </p>

      <p className="mt-2 border-t pt-2 text-[10.5px] leading-relaxed" style={{ borderColor: "var(--line-soft)", color: "var(--ink-faint)" }}>
        Tap Edit calculator to open the full GPA tracker — course tables, goals and every semester live there.
      </p>
    </Panel>
  );
}

/* ------------------------------------------------------------------ */
/* the sidebar                                                         */
/* ------------------------------------------------------------------ */

/**
 * Big-picture workspace sidebar. Everything here is intentionally
 * workspace-wide — it must stay visible and unchanged while drilling into
 * any individual subject, so it never reads a "selected subject".
 */
export default function WorkspaceSidebar() {
  const [sessions, setSessions] = useState<FocusSession[]>([]);

  /* collapsed state is a preference, so the extra room survives reloads */
  const [collapsed, setCollapsed] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem(SIDEBAR_KEY) === "1";
  });
  useEffect(() => {
    try {
      window.localStorage.setItem(SIDEBAR_KEY, collapsed ? "1" : "0");
    } catch {
      /* preference is best-effort */
    }
  }, [collapsed]);

  useEffect(() => {
    const id = setTimeout(() => {
      api<FocusSession[]>("/api/focus-sessions")
        .then(setSessions)
        .catch(() => {});
    }, 0);
    return () => clearTimeout(id);
  }, []);

  return (
    <div
      className={`workspace-rail ${collapsed ? "is-collapsed" : ""} w-full shrink-0 sm:sticky sm:top-6`}
    >
      {/* the toggle rides the panel's top-left corner, and stays put when
          the panel slides away so it can always bring it back */}
      <button
        onClick={() => setCollapsed((v) => !v)}
        aria-expanded={!collapsed}
        aria-controls="workspace-overview"
        aria-label={collapsed ? "Show workspace overview" : "Hide workspace overview"}
        title={collapsed ? "Show overview panel" : "Hide overview panel for more room"}
        className="workspace-rail-toggle group/rail flex items-center gap-1.5 rounded-full transition-all hover:-translate-y-0.5"
        style={{
          background: "var(--surface)",
          border: "1px solid var(--line)",
          color: "var(--ink-soft)",
          boxShadow: "var(--card-shadow)",
        }}
      >
        {collapsed ? <PanelLeftOpen size={14} /> : <PanelRightClose size={14} />}
        <span className="hidden text-[11px] font-bold sm:inline">
          {collapsed ? "Overview" : "Hide"}
        </span>
      </button>

      {/* clips the panel as it slides, so it can never widen the page */}
      <div className="workspace-rail-clip">
        <aside
          id="workspace-overview"
          aria-label="Workspace overview"
          aria-hidden={collapsed}
          // once off-screen it must not be tabbable
          {...(collapsed ? { inert: "" as unknown as boolean } : {})}
          className="animate-fade-up workspace-rail-panel flex flex-col gap-4"
          style={{ animationDelay: "0.1s" }}
        >
          <StudyStreak sessions={sessions} />
          <TasksOverview />
          <SelfAssessmentPanel />
          <GpaCalculator />
        </aside>
      </div>
    </div>
  );
}
