"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Hash, Tag, X } from "lucide-react";

/**
 * Filter bar for a subject library.
 *
 * Clicking it opens every unique hashtag used across that subject's notes;
 * typing narrows the list down as an autocomplete. Picking a tag — by click,
 * Enter or arrow keys — filters the shelf instantly.
 */
export default function LibraryTagFilter({
  tags,
  counts,
  active,
  onToggle,
  onClear,
}: {
  /** every unique tag in this subject's notes, already sorted */
  tags: string[];
  /** how many notes carry each tag */
  counts: Record<string, number>;
  /** currently selected tags */
  active: string[];
  onToggle: (tag: string) => void;
  onClear: () => void;
}) {
  const [draft, setDraft] = useState("");
  const [open, setOpen] = useState(false);
  const [cursor, setCursor] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  /* typing narrows the tag list — a leading "#" is ignored while matching */
  const query = draft.replace(/^#+/, "").trim().toLowerCase();
  const matches = useMemo(() => {
    const pool = query ? tags.filter((t) => t.toLowerCase().includes(query)) : tags;
    // exact-prefix matches feel more relevant, so float them up
    return query
      ? [...pool].sort((a, b) => {
          const ap = a.toLowerCase().startsWith(query) ? 0 : 1;
          const bp = b.toLowerCase().startsWith(query) ? 0 : 1;
          return ap - bp || a.localeCompare(b);
        })
      : pool;
  }, [tags, query]);

  /* keep the highlighted row in range whenever the list changes */
  useEffect(() => setCursor(0), [query, open]);

  /* close on outside click or Escape */
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [open]);

  /* keep the highlighted option scrolled into view */
  useEffect(() => {
    if (!open) return;
    const el = listRef.current?.querySelectorAll("[data-opt]")[cursor] as HTMLElement | undefined;
    el?.scrollIntoView({ block: "nearest" });
  }, [cursor, open]);

  const choose = (tag: string) => {
    onToggle(tag);
    setDraft("");
    setOpen(false);
    inputRef.current?.focus();
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Escape") {
      setOpen(false);
      setDraft("");
      return;
    }
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (!open) setOpen(true);
      setCursor((c) => {
        const n = matches.length;
        if (n === 0) return 0;
        return e.key === "ArrowDown" ? (c + 1) % n : (c - 1 + n) % n;
      });
      return;
    }
    if (e.key === "Enter") {
      e.preventDefault();
      const pick = matches[cursor];
      if (pick) choose(pick);
      return;
    }
    // backspace on an empty box removes the last selected tag
    if (e.key === "Backspace" && draft === "" && active.length > 0) {
      onToggle(active[active.length - 1]);
    }
  };

  return (
    <div ref={wrapRef} className="relative mt-3">
      {/* ---------- the bar itself ---------- */}
      <div
        onClick={() => {
          setOpen(true);
          inputRef.current?.focus();
        }}
        className="flex flex-wrap items-center gap-1.5 rounded-2xl px-2.5 py-1.5"
        style={{
          background: "var(--surface-2)",
          border: `1px solid ${open ? "var(--accent)" : "var(--line-soft)"}`,
          boxShadow: open ? "0 0 0 3px var(--accent-soft)" : "none",
          transition: "border-color 0.15s, box-shadow 0.15s",
        }}
      >
        <Tag size={13} className="shrink-0" style={{ color: "var(--ink-faint)" }} />

        {/* selected tags sit inside the bar as removable chips */}
        {active.map((t) => (
          <span
            key={t}
            className="flex shrink-0 items-center gap-1 rounded-full py-0.5 pr-1 pl-2 text-[10.5px] font-bold"
            style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
          >
            #{t}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggle(t);
              }}
              aria-label={`Remove #${t} filter`}
              className="flex h-4 w-4 items-center justify-center rounded-full transition-colors hover:bg-black/20"
            >
              <X size={9} />
            </button>
          </span>
        ))}

        <input
          ref={inputRef}
          value={draft}
          onChange={(e) => {
            setDraft(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={onKeyDown}
          placeholder={active.length ? "Add another #tag…" : "Filter by #tag — click or type…"}
          aria-label="Filter notes by hashtag"
          aria-expanded={open}
          aria-autocomplete="list"
          role="combobox"
          aria-controls="library-tag-listbox"
          className="min-w-[130px] flex-1 bg-transparent py-1 text-[12px] outline-none"
          style={{ color: "var(--ink)" }}
        />

        {active.length > 0 && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClear();
              setDraft("");
            }}
            className="shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold transition-colors hover:bg-[var(--surface-3)]"
            style={{ color: "var(--ink-faint)" }}
          >
            Clear
          </button>
        )}
      </div>

      {/* ---------- the dropdown ---------- */}
      {open && (
        <div
          ref={listRef}
          id="library-tag-listbox"
          role="listbox"
          className="animate-pop rail-scroll absolute z-[70] mt-1.5 max-h-[240px] w-full overflow-y-auto rounded-2xl p-1.5"
          style={{
            background: "var(--surface)",
            border: "1px solid var(--line)",
            boxShadow: "0 18px 40px rgba(24,18,10,0.18)",
          }}
        >
          <p
            className="px-2 py-1 text-[9px] font-bold tracking-[0.12em] uppercase"
            style={{ color: "var(--ink-faint)" }}
          >
            {query ? `Matching “${query}”` : `All tags in this library · ${tags.length}`}
          </p>

          {matches.map((t, i) => {
            const on = active.includes(t);
            return (
              <button
                key={t}
                data-opt
                role="option"
                aria-selected={on}
                onMouseEnter={() => setCursor(i)}
                onClick={() => choose(t)}
                className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left transition-colors"
                style={{
                  background:
                    i === cursor ? "var(--accent-soft)" : on ? "var(--surface-2)" : "transparent",
                }}
              >
                <Hash size={11} className="shrink-0" style={{ color: "var(--accent)" }} />
                <span
                  className="min-w-0 flex-1 truncate text-[12px] font-semibold"
                  style={{ color: "var(--ink)" }}
                >
                  {t}
                </span>
                <span className="shrink-0 text-[10px]" style={{ color: "var(--ink-faint)" }}>
                  {counts[t] ?? 0}
                </span>
                {on && (
                  <span
                    className="shrink-0 rounded-full px-1.5 text-[8.5px] font-bold"
                    style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
                  >
                    ON
                  </span>
                )}
              </button>
            );
          })}

          {matches.length === 0 && (
            <p className="px-2 py-3 text-center text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
              {tags.length === 0
                ? "No tags on this shelf yet — add some in a note."
                : `No tag matches “${query}”.`}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
