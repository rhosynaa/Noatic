"use client";

import { useCallback, type ReactNode } from "react";
import { ToastProvider } from "@/lib/toast";
import { SettingsProvider, useSettings } from "@/lib/settings-context";
import { ProfileProvider } from "@/lib/profile-context";
import { MusicProvider } from "@/lib/music-context";
import SettingsModal from "@/components/modals/SettingsModal";
import HelpModal from "@/components/modals/HelpModal";
import type { Profile, Settings } from "@/lib/types";

function MusicBridge({ children }: { children: ReactNode }) {
  const { musicShuffle, setMusicShuffle } = useSettings();
  const persist = useCallback((v: boolean) => setMusicShuffle(v), [setMusicShuffle]);
  return (
    <MusicProvider initialShuffle={musicShuffle} onShufflePersist={persist}>
      {children}
    </MusicProvider>
  );
}

export function AppProviders({
  children,
  initialSettings,
  initialProfile,
}: {
  children: ReactNode;
  initialSettings?: Settings;
  initialProfile?: Profile | null;
}) {
  return (
    <ToastProvider>
      <SettingsProvider initial={initialSettings}>
        <ProfileProvider initial={initialProfile}>
          <MusicBridge>
            {children}
            <SettingsModal />
            <HelpModal />
          </MusicBridge>
        </ProfileProvider>
      </SettingsProvider>
    </ToastProvider>
  );
}
