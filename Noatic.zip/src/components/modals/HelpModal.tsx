"use client";

import {
  Moon,
  GripVertical,
  LifeBuoy,
  Link2,
  Music4,
  NotebookPen,
  Quote,
  RefreshCcw,
  Sparkles,
  UserRound,
  Image as ImageIcon,
} from "lucide-react";
import { Modal, ModalHeader, SectionLabel } from "@/components/ui";
import { useSettings } from "@/lib/settings-context";

const SECTIONS = [
  {
    icon: LifeBuoy,
    title: "Tour of the sidebar sections",
    steps: [
      "Tasks — the full task manager behind the dashboard widget: add, edit inline, tick, filter All / To do / Done.",
      "Calendar — a month view with colored dots for every deadline; click a day to see (and tick off) what's due.",
      "Flashcards — create cards per subject, then hit Study for a flip-card mode with shuffle and a Got-it counter.",
      "Subjects — color-coded labels reused by deadlines and flashcards; shows how many open deadlines each has.",
      "Mind map — an infinite-feeling idea canvas: drag nodes, double-click to rename, add child ideas in one tap.",
      "Analytics — your 7-day completion bars, focus minutes, streak flame and deadlines-per-subject breakdown.",
      "Timer — the full pomodoro room; every finished session is logged and feeds Analytics.",
      "Quotes — the Quote of the day & Daily motivation collections (add / edit / delete). Music, Templates and Images live there too.",
      "Trash — deleted tasks, notes, deadlines and flashcards rest here; restore them or erase forever with one tap.",
    ],
  },
  {
    icon: NotebookPen,
    title: "Adding a new note template",
    steps: [
      "Open the sidebar and press Templates in the menu.",
      "Hit New template, give it a title and fill the content — use ALL-CAPS labels and bullet dashes, they become your skeleton.",
      "Save it. Now, from the Recent Notes widget, press Template and pick yours — a fresh note is created with that structure.",
    ],
  },
  {
    icon: UserRound,
    title: "Logging in with your Google account",
    steps: [
      "Click your name in the top-right to open your profile page.",
      "Find the Google integration card and type your Gmail address, then press Connect account.",
      "Flip Auto-sync on — your notes and widgets re-sync to the database every 15 minutes, and you can press Sync now anytime. Disconnect whenever you like.",
      "Self-hosting? For true OAuth, add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as environment variables and swap the connect button for the Google sign-in flow.",
    ],
  },
  {
    icon: Music4,
    title: "Music: Spotify, YouTube & MP3 links",
    steps: [
      "Open the Music Room (the widget, then View playlist, or via the sidebar).",
      "Press Add track and paste a YouTube link (watch, share or shorts), a Spotify link (track, album or playlist) or any direct MP3 URL.",
      "YouTube and Spotify tracks play right inside the player through their official embeds. MP3 links stream directly.",
      "Use the shuffle button to stop studying to the same three songs on repeat.",
    ],
  },
  {
    icon: GripVertical,
    title: "Rearranging your dashboard",
    steps: [
      "Every widget has a small grip handle in its top-right corner.",
      "Drag it by the handle and the other widgets will shuffle aside to show you where it will land.",
      "Your layout saves automatically — hide widgets entirely in Settings → Dashboard widgets.",
    ],
  },
  {
    icon: Quote,
    title: "Quotes & daily motivation",
    steps: [
      "The sidebar holds your Quote of the day and Daily motivation collections — add, edit or delete lines anytime.",
      "Each day at midnight, a random quote and a random motivation are drawn from your lists onto the dashboard.",
      "Keeping at least one of each means the widget always has something to say.",
    ],
  },
  {
    icon: ImageIcon,
    title: "Changing any image",
    steps: [
      "Banner, daydream gallery image, avatar, note covers and music artwork are all changeable.",
      "Dashboard images: sidebar → Images. Avatar: your profile page. Music covers: hover a track in the playlist. Note images: open the note.",
      "Upload from your device (auto-compressed) or paste any image link.",
    ],
  },
  {
    icon: Moon,
    title: "Dark mode, desktop mode & more",
    steps: [
      "The settings gear in the header opens appearance controls: dark mode and four accent colours.",
      "On mobile, enable Desktop mode to see the full multi-column dashboard (scaled to fit — nothing microscopic).",
      "Everything you change is saved to the database instantly and survives refreshes and devices.",
    ],
  },
  {
    icon: RefreshCcw,
    title: "Good to know",
    steps: [
      "Your plan checkbox ticks instantly and syncs in the background — no more page reloads.",
      "The bell in the header lists overdue and upcoming deadlines; the red badge counts urgent ones.",
      "All data lives in PostgreSQL, so clearing your browser won't lose anything.",
    ],
  },
];

export default function HelpModal() {
  const { helpOpen, closeHelp } = useSettings();

  return (
    <Modal open={helpOpen} onClose={closeHelp} wide>
      <ModalHeader
        title="Help & how-tos"
        subtitle="Everything the dashboard can do, in plain steps"
        onClose={closeHelp}
      />
      <div className="overflow-y-auto px-6 py-6">
        <div className="mb-6 flex items-start gap-3 rounded-2xl p-4" style={{ background: "var(--accent-soft)" }}>
          <Sparkles size={18} className="mt-0.5 shrink-0" style={{ color: "var(--accent)" }} />
          <p className="text-[13.5px] leading-relaxed" style={{ color: "var(--ink)" }}>
            Welcome back. This is your soft space to get things done — everything is
            editable, everything syncs, and everything below answers the questions we hear
            most often.
          </p>
        </div>

        <div className="flex flex-col gap-7">
          {SECTIONS.map((sec) => (
            <section key={sec.title} className="flex gap-3.5">
              <span
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                style={{ background: "var(--surface-2)", color: "var(--accent)" }}
              >
                <sec.icon size={17} />
              </span>
              <div>
                <SectionLabel>{sec.title}</SectionLabel>
                <ol className="mt-2 flex flex-col gap-1.5">
                  {sec.steps.map((step, i) => (
                    <li
                      key={i}
                      className="flex gap-2.5 text-[13px] leading-relaxed"
                      style={{ color: "var(--ink-soft)" }}
                    >
                      <span
                        className="mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold"
                        style={{ background: "var(--surface-3)", color: "var(--ink-soft)", height: 18, width: 18 }}
                      >
                        {i + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </section>
          ))}
        </div>

        <div
          className="mt-8 flex flex-wrap items-center justify-between gap-3 rounded-2xl px-5 py-4"
          style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}
        >
          <div className="flex items-center gap-2.5 text-[13px] font-semibold" style={{ color: "var(--ink)" }}>
            <LifeBuoy size={16} style={{ color: "var(--accent)" }} />
            Still stuck?
          </div>
          <div className="flex items-center gap-2 text-[12px]" style={{ color: "var(--ink-soft)" }}>
            <Link2 size={13} />
            dashboard.support@dreamy.app
          </div>
        </div>
      </div>
    </Modal>
  );
}
