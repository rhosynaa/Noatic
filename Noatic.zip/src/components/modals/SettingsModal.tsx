"use client";

import { MonitorSmartphone, Moon, RotateCcw, Eye, EyeOff } from "lucide-react";
import { Modal, ModalHeader, SectionLabel, Toggle } from "@/components/ui";
import { useSettings } from "@/lib/settings-context";
import { ACCENTS, WIDGET_META, DEFAULT_WIDGET_ORDER } from "@/lib/types";

export default function SettingsModal() {
  const s = useSettings();

  return (
    <Modal open={s.settingsOpen} onClose={s.closeSettings}>
      <ModalHeader
        title="Settings"
        subtitle="Make the space yours — it remembers everything"
        onClose={s.closeSettings}
      />
      <div className="flex flex-col gap-6 overflow-y-auto px-6 py-6">
        <section className="flex flex-col gap-2">
          <SectionLabel>Appearance</SectionLabel>
          <Toggle
            checked={s.dark}
            onChange={s.setDark}
            label="Dark mode"
            hint="A candlelit version of your desk"
          />
          <div
            className="flex items-center justify-between gap-4 rounded-2xl px-4 py-3"
            style={{ background: "var(--surface-2)" }}
          >
            <span>
              <span className="block text-[13.5px] font-semibold" style={{ color: "var(--ink)" }}>
                Accent colour
              </span>
              <span className="mt-0.5 block text-[12px]" style={{ color: "var(--ink-soft)" }}>
                {ACCENTS[s.accent]?.name ?? "Rosewood"}
              </span>
            </span>
            <span className="flex items-center gap-2">
              {Object.entries(ACCENTS).map(([key, a]) => (
                <button
                  key={key}
                  aria-label={a.name}
                  title={a.name}
                  onClick={() => s.setAccent(key)}
                  className="h-7 w-7 rounded-full transition-transform hover:scale-110"
                  style={{
                    background: a.accent,
                    boxShadow:
                      s.accent === key
                        ? `0 0 0 2px var(--surface), 0 0 0 4px ${a.accent}`
                        : "none",
                  }}
                />
              ))}
            </span>
          </div>
        </section>

        <section className="flex flex-col gap-2">
          <SectionLabel>Display</SectionLabel>
          <div className="flex items-start gap-3 rounded-2xl px-1">
            <MonitorSmartphone
              size={16}
              className="mt-0.5 shrink-0"
              style={{ color: "var(--ink-faint)" }}
            />
            <p className="text-[12.5px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>
              On mobile the dashboard stacks into one clean column. Turn on{" "}
              <strong style={{ color: "var(--ink)" }}>desktop mode</strong> to zoom out and
              see the full multi-column desk — like a browser&apos;s desktop site, but tuned
              so nothing gets too tiny.
            </p>
          </div>
          <Toggle
            checked={s.desktopMode}
            onChange={s.setDesktopMode}
            label="Desktop mode on mobile"
            hint="Wider dashboard view, fits the screen"
          />
        </section>

        <section className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <SectionLabel>Dashboard widgets</SectionLabel>
            <button
              onClick={s.resetLayout}
              className="btn-ghost px-2.5 py-1 text-[11.5px] font-semibold"
              style={{ border: "none" }}
            >
              <RotateCcw size={12} />
              Reset layout
            </button>
          </div>
          <div className="flex flex-col gap-1.5">
            {DEFAULT_WIDGET_ORDER.map((key) => {
              const meta = WIDGET_META[key];
              const hidden = s.hidden.includes(key);
              return (
                <div
                  key={key}
                  className="flex items-center justify-between gap-3 rounded-2xl px-4 py-2.5"
                  style={{ background: "var(--surface-2)", opacity: hidden ? 0.55 : 1 }}
                >
                  <span>
                    <span
                      className="block text-[13.5px] font-semibold"
                      style={{ color: "var(--ink)" }}
                    >
                      {meta.title}
                    </span>
                    <span
                      className="mt-0.5 block text-[11.5px]"
                      style={{ color: "var(--ink-faint)" }}
                    >
                      {meta.description}
                    </span>
                  </span>
                  <button
                    onClick={() => s.toggleHidden(key)}
                    aria-label={hidden ? `Show ${meta.title}` : `Hide ${meta.title}`}
                    className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-3)]"
                    style={{ color: hidden ? "var(--ink-faint)" : "var(--accent)" }}
                  >
                    {hidden ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              );
            })}
          </div>
          <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
            Tip: long-press / drag the grip handle on any widget to rearrange the dashboard.
          </p>
        </section>

        <section className="flex items-center gap-2 pb-2 text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
          <Moon size={13} />
          Everything saves instantly to your account — no apply button needed.
        </section>
      </div>
    </Modal>
  );
}
