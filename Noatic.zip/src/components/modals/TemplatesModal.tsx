"use client";

import { useState, type FormEvent } from "react";
import { Check, LayoutTemplate, NotebookPen, Plus, Trash2 } from "lucide-react";
import { Modal, ModalHeader } from "@/components/ui";
import { useDashboard } from "@/lib/dashboard-context";
import { useToast } from "@/lib/toast";
import type { Note } from "@/lib/types";

const ACCENT_OPTIONS = ["sun", "violet", "blush"] as const;

export default function TemplatesModal({
  open,
  onClose,
  onUseTemplate,
}: {
  open: boolean;
  onClose: () => void;
  onUseTemplate: (note: Note) => void;
}) {
  const { templates, addTemplate, deleteTemplate, addNote } = useDashboard();
  const { push } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [accent, setAccent] = useState<(typeof ACCENT_OPTIONS)[number]>("sun");
  const [content, setContent] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    await addTemplate({ title: title.trim(), accent, content });
    setTitle("");
    setContent("");
    setShowForm(false);
  };

  return (
    <Modal open={open} onClose={onClose} wide>
      <ModalHeader
        title="Note templates"
        subtitle="Reusable skeletons for faster note-taking"
        onClose={onClose}
      />
      <div className="flex flex-col gap-3 overflow-y-auto px-6 py-5">
        <div className="flex items-center justify-between">
          <p className="text-[12.5px]" style={{ color: "var(--ink-soft)" }}>
            {templates.length} template{templates.length === 1 ? "" : "s"} — press{" "}
            <strong style={{ color: "var(--ink)" }}>Use</strong> to start a note from one.
          </p>
          <button onClick={() => setShowForm((v) => !v)} className="btn-accent px-3.5 py-2 text-[12px] font-semibold">
            <Plus size={13.5} className={showForm ? "rotate-45 transition-transform" : "transition-transform"} />
            New template
          </button>
        </div>

        {showForm && (
          <form
            onSubmit={submit}
            className="animate-pop flex flex-col gap-3 rounded-2xl p-4"
            style={{ background: "var(--accent-soft)", border: "1px dashed var(--accent)" }}
          >
            <input
              className="input-line !text-[15px] font-semibold"
              placeholder="Template title — e.g. Seminar prep *"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              autoFocus
            />
            <textarea
              className="min-h-[110px] w-full resize-y rounded-xl p-3 text-[13px] leading-relaxed outline-none"
              style={{ background: "var(--surface)", border: "1px solid var(--line)", color: "var(--ink)" }}
              placeholder={"Write the skeleton — e.g.\nTOPIC:\nKEY IDEAS\n1. \n2. \nQUESTIONS:\n"}
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
            <div className="flex items-center justify-between">
              <div className="flex gap-1.5">
                {ACCENT_OPTIONS.map((a) => (
                  <button
                    key={a}
                    type="button"
                    onClick={() => setAccent(a)}
                    className="h-5 w-5 rounded-full transition-transform hover:scale-110"
                    style={{
                      background: a === "sun" ? "#cf9c44" : a === "violet" ? "#8b7bc4" : "#d4705c",
                      boxShadow: accent === a ? "0 0 0 2px var(--surface), 0 0 0 4px var(--accent)" : "none",
                    }}
                    aria-label={a}
                  />
                ))}
              </div>
              <button type="submit" disabled={!title.trim()} className="btn-accent px-4 py-2 text-[12px] font-semibold disabled:opacity-50">
                <Check size={13} /> Save template
              </button>
            </div>
          </form>
        )}

        <div className="flex flex-col gap-2.5">
          {templates.map((t) => (
            <article
              key={t.id}
              className="rounded-2xl p-4"
              style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <span
                    className="flex h-8 w-8 items-center justify-center rounded-xl"
                    style={{
                      background: t.accent === "violet" ? "#8b7bc41f" : t.accent === "blush" ? "#d4705c1f" : "#cf9c441f",
                      color: t.accent === "violet" ? "#8b7bc4" : t.accent === "blush" ? "#d4705c" : "#cf9c44",
                    }}
                  >
                    <LayoutTemplate size={15} />
                  </span>
                  <h3 className="font-display text-[16px] font-semibold" style={{ color: "var(--ink)" }}>
                    {t.title}
                  </h3>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={async () => {
                      const note = await addNote({ title: t.title, content: t.content });
                      if (note) {
                        push("success", `Note started from “${t.title}”`);
                        onClose();
                        onUseTemplate(note);
                      }
                    }}
                    className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
                  >
                    <NotebookPen size={12.5} /> Use
                  </button>
                  <button
                    onClick={() => deleteTemplate(t.id)}
                    aria-label={`Delete ${t.title}`}
                    className="btn-ghost px-2 py-1.5 text-[11.5px] hover:!text-red-500"
                  >
                    <Trash2 size={12.5} />
                  </button>
                </div>
              </div>
              <pre className="mt-3 max-h-32 overflow-y-auto font-mono text-[12px] leading-relaxed whitespace-pre-wrap" style={{ color: "var(--ink-soft)" }}>
                {t.content || "(empty template)"}
              </pre>
            </article>
          ))}
          {templates.length === 0 && !showForm && (
            <p className="py-8 text-center text-[13px]" style={{ color: "var(--ink-faint)" }}>
              No templates yet — create your first one above. See Help → Templates for the step-by-step.
            </p>
          )}
        </div>
      </div>
    </Modal>
  );
}
