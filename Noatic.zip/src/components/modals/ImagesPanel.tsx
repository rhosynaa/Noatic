"use client";

import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { HERO_IMG, GALLERY_IMG, AVATAR_IMG } from "@/lib/assets";
import {
  Check,
  ChevronDown,
  ChevronUp,
  FolderOpen,
  Image as ImageIcon,
  ImagePlus,
  Library,
  Link2,
  Pencil,
  RefreshCcw,
  Search,
  Shuffle,
  Trash2,
  X,
} from "lucide-react";
import { Modal, ModalHeader } from "@/components/ui";
import { useDashboard } from "@/lib/dashboard-context";
import { useProfile } from "@/lib/profile-context";
import { fileToDataUrl } from "@/lib/api";
import { useToast } from "@/lib/toast";
import Link from "@/lib/router";
import { DEFAULT_ROTATE_SECONDS, ROTATE_INTERVALS, type MediaItem } from "@/lib/types";

const DEFAULTS: Record<string, string> = {
  hero: HERO_IMG,
  gallery: GALLERY_IMG,
  avatar: AVATAR_IMG,
};

const UNFILED = "Unfiled";
/** the category label a picture is shown under */
const catOf = (m: MediaItem) => m.category.trim() || UNFILED;

/* ------------------------------------------------------------------ */
/* picking a picture (or a whole category) for one slot                */
/* ------------------------------------------------------------------ */

function LibraryPicker({
  onPick,
  onRotate,
  activeCategory,
  activeSeconds,
}: {
  onPick: (url: string) => void;
  onRotate: (category: string | null, seconds: number) => void;
  activeCategory?: string;
  activeSeconds?: number;
}) {
  const { media } = useDashboard();
  const [seconds, setSeconds] = useState(activeSeconds ?? DEFAULT_ROTATE_SECONDS);

  const groups = useMemo(() => {
    const m = new Map<string, MediaItem[]>();
    for (const item of media) {
      const c = catOf(item);
      if (!m.has(c)) m.set(c, []);
      m.get(c)!.push(item);
    }
    return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [media]);

  if (media.length === 0)
    return (
      <p className="px-1 py-3 text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
        Your library is empty — add pictures below and they'll show up here.
      </p>
    );

  return (
    <div className="mt-2 flex flex-col gap-3">
      {groups.map(([cat, items]) => {
        const rotating = activeCategory?.trim().toLowerCase() === cat.trim().toLowerCase();
        return (
          <div key={cat}>
            <div className="mb-1.5 flex flex-wrap items-center gap-1.5">
              <FolderOpen size={11} style={{ color: "var(--accent)" }} />
              <span className="text-[10.5px] font-bold" style={{ color: "var(--ink-soft)" }}>
                {cat}
              </span>
              <span className="text-[10px]" style={{ color: "var(--ink-faint)" }}>
                {items.length}
              </span>
              <span className="flex-1" />
              {/* the whole-category option: shuffle at random on a timer */}
              <button
                onClick={() => onRotate(rotating ? null : cat, seconds)}
                className="flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold transition-colors"
                style={{
                  background: rotating ? "var(--accent)" : "var(--surface-3)",
                  color: rotating ? "var(--accent-ink)" : "var(--ink-soft)",
                }}
                title={
                  rotating
                    ? "Stop shuffling this category"
                    : `Shuffle a random picture from “${cat}”`
                }
              >
                <Shuffle size={9.5} />
                {rotating ? "Shuffling" : "Shuffle"}
              </button>
            </div>

            {rotating && (
              <div className="mb-2 flex items-center gap-1.5">
                <span className="text-[10px]" style={{ color: "var(--ink-faint)" }}>
                  Change
                </span>
                <select
                  value={seconds}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    setSeconds(v);
                    onRotate(cat, v);
                  }}
                  aria-label="How often the picture changes"
                  className="cursor-pointer rounded-full px-2 py-1 text-[10.5px] font-semibold outline-none"
                  style={{
                    background: "var(--surface-3)",
                    border: "1px solid var(--line)",
                    color: "var(--ink-soft)",
                  }}
                >
                  {ROTATE_INTERVALS.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex flex-wrap gap-1.5">
              {items.map((m) => (
                <button
                  key={m.id}
                  onClick={() => onPick(m.url)}
                  title={`Use “${m.name}”`}
                  className="h-12 w-16 overflow-hidden rounded-lg transition-transform hover:-translate-y-0.5"
                  style={{ border: "1px solid var(--line)" }}
                >
                  <img src={m.url} alt={m.name} className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* one changeable picture on the site                                  */
/* ------------------------------------------------------------------ */

function ImageSlot({
  slotKey,
  label,
  url,
  hint,
}: {
  slotKey: string;
  label: string;
  url: string;
  hint: string;
}) {
  const { setImage, setImageRotation, images } = useDashboard();
  const { profile, update } = useProfile();
  const { push } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [urlDraft, setUrlDraft] = useState("");
  const [showUrl, setShowUrl] = useState(false);
  const [showLib, setShowLib] = useState(false);
  const [busy, setBusy] = useState(false);

  const isAvatar = slotKey === "avatar";
  const current = isAvatar ? (profile?.avatarUrl ?? DEFAULTS.avatar) : url;
  const slot = images.find((i) => i.key === slotKey);
  const rotateCategory = slot?.rotateCategory;
  const rotateSeconds = slot?.rotateSeconds ?? DEFAULT_ROTATE_SECONDS;
  const rotateLabel = ROTATE_INTERVALS.find((o) => o.value === rotateSeconds)?.label ?? "";

  const save = async (value: string) => {
    setBusy(true);
    if (isAvatar) {
      await update({ avatarUrl: value });
    } else {
      await setImage(slotKey, value, label);
    }
    setBusy(false);
    setShowUrl(false);
    setUrlDraft("");
  };

  return (
    <div
      className="flex flex-col gap-3 rounded-2xl p-4"
      style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
    >
      <div className="flex items-center gap-4">
        <div
          className="relative h-20 w-32 shrink-0 overflow-hidden rounded-xl"
          style={{ border: "1px solid var(--line)" }}
        >
          <img
            src={current}
            alt={label}
            className={`h-full w-full ${isAvatar ? "object-contain p-1" : "object-cover"}`}
            onError={(e) => {
              (e.target as HTMLImageElement).src = DEFAULTS[slotKey];
            }}
          />
          {busy && (
            <span className="absolute inset-0 flex items-center justify-center bg-black/40 text-[11px] font-bold text-white">
              Saving…
            </span>
          )}
          {rotateCategory && (
            <span
              className="absolute bottom-1 left-1 flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[8.5px] font-bold"
              style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
            >
              <Shuffle size={8} /> Auto
            </span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[13.5px] font-semibold" style={{ color: "var(--ink)" }}>
            {label}
          </p>
          <p className="mt-0.5 text-[11.5px] leading-relaxed" style={{ color: "var(--ink-faint)" }}>
            {hint}
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            <button
              onClick={() => fileRef.current?.click()}
              className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
            >
              <ImagePlus size={12} /> Upload
            </button>
            <button
              onClick={() => setShowLib((v) => !v)}
              aria-expanded={showLib}
              className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
            >
              <Library size={12} /> From library
            </button>
            <button
              onClick={() => setShowUrl((v) => !v)}
              className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
            >
              <Link2 size={12} /> Link
            </button>
            <button
              onClick={() => save(DEFAULTS[slotKey])}
              className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
            >
              <RefreshCcw size={12} /> Reset
            </button>
          </div>
        </div>
      </div>

      {/* the auto-shuffle banner, when this slot is following a category */}
      {rotateCategory && !isAvatar && (
        <div
          className="flex flex-wrap items-center gap-2 rounded-xl px-3 py-2 text-[11px]"
          style={{ background: "var(--accent-soft)", color: "var(--ink-soft)" }}
        >
          <Shuffle size={12} style={{ color: "var(--accent)" }} />
          <span>
            Shuffling <strong>{rotateCategory}</strong> · {rotateLabel.toLowerCase()}
          </span>
          <span className="flex-1" />
          <button
            onClick={() => setImageRotation(slotKey, null, rotateSeconds, label)}
            className="rounded-full px-2 py-0.5 text-[10px] font-bold"
            style={{ background: "var(--surface)", color: "var(--ink-soft)" }}
          >
            Stop
          </button>
        </div>
      )}

      {showLib && !isAvatar && (
        <LibraryPicker
          activeCategory={rotateCategory}
          activeSeconds={rotateSeconds}
          onPick={(u) => {
            void save(u);
            setShowLib(false);
          }}
          onRotate={(cat, secs) => void setImageRotation(slotKey, cat, secs, label)}
        />
      )}
      {showLib && isAvatar && (
        <LibraryPicker
          onPick={(u) => {
            void save(u);
            setShowLib(false);
          }}
          onRotate={() => push("info", "Avatars don't shuffle — pick a picture instead")}
        />
      )}

      {showUrl && (
        <div className="flex items-center gap-1.5">
          <input
            autoFocus
            className="input-line min-w-0 flex-1 !py-1.5 text-[12px]"
            placeholder="https://…"
            value={urlDraft}
            onChange={(e) => setUrlDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && urlDraft.trim() && save(urlDraft.trim())}
          />
          <button
            onClick={() => urlDraft.trim() && save(urlDraft.trim())}
            disabled={!urlDraft.trim()}
            className="btn-accent h-8 w-8 shrink-0 !p-0 disabled:opacity-40"
            aria-label="Use this link"
          >
            <Check size={13} />
          </button>
        </div>
      )}

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          try {
            const dataUrl = await fileToDataUrl(f, slotKey === "hero" ? 1200 : 1024);
            await save(dataUrl);
          } catch (err) {
            push("error", err instanceof Error ? err.message : "Couldn't read that image");
          }
        }}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the library itself — upload, name, categorise, delete               */
/* ------------------------------------------------------------------ */

function MediaLibrary() {
  const { media, addMedia, updateMedia, deleteMedia } = useDashboard();
  const { push } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [category, setCategory] = useState("");
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [draftName, setDraftName] = useState("");
  const [draftCat, setDraftCat] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [query, setQuery] = useState("");
  /* category chips clamp to two lines — anything past that hides behind
     a "Show more" toggle until "Show less" collapses it again */
  const [catsExpanded, setCatsExpanded] = useState(false);
  const [catsOverflow, setCatsOverflow] = useState(false);
  const [twoLineH, setTwoLineH] = useState(0);
  const chipRowRef = useRef<HTMLDivElement>(null);

  const categories = useMemo(
    () => [...new Set(media.map(catOf))].sort((a, b) => a.localeCompare(b)),
    [media]
  );

  const shown = useMemo(() => {
    /* a search looks everywhere, by picture name (or category name), so a
       picture pops up even while another category chip is selected */
    const q = query.trim().toLowerCase();
    if (q)
      return media.filter(
        (m) => m.name.toLowerCase().includes(q) || catOf(m).toLowerCase().includes(q)
      );
    return filter === "all" ? media : media.filter((m) => catOf(m) === filter);
  }, [media, filter, query]);

  /* measure one chip and allow exactly two rows of chips; scrollHeight always
     reports the unclamped content height, so it also tells us when the extra
     rows are gone (e.g. after deleting a category) and the toggle can hide */
  useLayoutEffect(() => {
    const el = chipRowRef.current;
    if (!el) return;
    const measure = () => {
      const first = el.querySelector<HTMLElement>("[data-cat-chip]");
      const chipH = first?.offsetHeight || 26;
      const two = chipH * 2 + 6; // two rows of chips + the gap-1.5 between them
      setTwoLineH(two);
      setCatsOverflow(el.scrollHeight > two + 1);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [categories, media.length, catsExpanded]);

  /* GIFs must not be downscaled through a canvas — it would kill the animation */
  const readFile = (file: File): Promise<string> =>
    file.type === "image/gif"
      ? new Promise((res, rej) => {
          // a GIF can't go through a canvas or it loses its animation, so it's
          // stored as-is — which means it has to be small enough to store
          if (file.size > 1_800_000)
            return rej(new Error(`“${file.name}” is too big — GIFs must be under ~1.8MB`));
          const r = new FileReader();
          r.onload = () => res(String(r.result));
          r.onerror = () => rej(new Error("Couldn't read that GIF"));
          r.readAsDataURL(file);
        })
      : fileToDataUrl(file, 1100);

  const upload = async (picked: File[]) => {
    if (picked.length === 0) return;
    setBusy(true);
    for (const file of picked.slice(0, 12)) {
      try {
        const url = await readFile(file);
        await addMedia({
          url,
          name: file.name.replace(/\.[^.]+$/, "").slice(0, 60) || "Untitled",
          category: category.trim(),
        });
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't add that file");
      }
    }
    setBusy(false);
  };

  return (
    <div
      className="flex flex-col gap-3 rounded-2xl p-4"
      style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
    >
      <div className="flex flex-wrap items-center gap-2">
        <Library size={14} style={{ color: "var(--accent)" }} />
        <p className="text-[13.5px] font-semibold" style={{ color: "var(--ink)" }}>
          My picture library
        </p>
        <span className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
          {media.length} item{media.length === 1 ? "" : "s"}
        </span>
      </div>
      <p className="-mt-1.5 text-[11.5px] leading-relaxed" style={{ color: "var(--ink-faint)" }}>
        Upload images or GIFs, file them into a category, then use them for any picture above —
        or let a whole category shuffle itself.
      </p>

      {/* upload row: a category to file into, then the picker */}
      <div className="flex flex-wrap items-center gap-1.5">
        <input
          className="input-line min-w-0 flex-1 !py-1.5 text-[12px]"
          placeholder="Category for new uploads — e.g. Wallpapers"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          list="media-category-options"
          maxLength={40}
          aria-label="Category for new uploads"
        />
        <datalist id="media-category-options">
          {categories.map((c) => (
            <option key={c} value={c} />
          ))}
        </datalist>
        <button
          onClick={() => fileRef.current?.click()}
          disabled={busy}
          className="btn-accent px-3 py-1.5 text-[11.5px] font-semibold disabled:opacity-50"
        >
          <ImagePlus size={12} /> {busy ? "Adding…" : "Add images / GIFs"}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*,image/gif"
          multiple
          className="hidden"
          onChange={(e) => {
            // copy the FileList into a real array *before* resetting the input —
            // a FileList is live, so clearing the input would empty it first
            const picked = Array.from(e.target.files ?? []);
            e.target.value = "";
            void upload(picked);
          }}
        />
      </div>

      {/* category filter — chips fill the first line, wrap onto a second,
          and anything that would push onto a third line stays hidden behind
          "Show more"; the little search bar sits at the opposite end */}
      {categories.length > 0 && (
        <div className="flex flex-wrap items-start gap-1.5">
          <div
            ref={chipRowRef}
            className="flex min-w-0 flex-1 basis-52 flex-wrap content-start gap-1.5 overflow-hidden"
            style={!catsExpanded && twoLineH ? { maxHeight: twoLineH } : undefined}
          >
            {["all", ...categories].map((c) => (
              <button
                key={c}
                data-cat-chip
                onClick={() => setFilter(c)}
                className="rounded-full px-2.5 py-1 text-[10.5px] font-bold whitespace-nowrap transition-colors"
                style={{
                  background: filter === c ? "var(--accent)" : "var(--surface-3)",
                  color: filter === c ? "var(--accent-ink)" : "var(--ink-soft)",
                }}
              >
                {c === "all" ? `All ${media.length}` : c}
              </button>
            ))}
          </div>

          {/* opposite end: show more/less (only when there are hidden rows) + search */}
          <div className="ml-auto flex shrink-0 items-start gap-1.5">
            {catsOverflow && (
              <button
                onClick={() => setCatsExpanded((v) => !v)}
                aria-expanded={catsExpanded}
                title={
                  catsExpanded ? "Collapse back to two lines" : "Show every category"
                }
                className="flex items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-bold whitespace-nowrap transition-colors"
                style={{ background: "var(--surface-3)", color: "var(--ink-soft)" }}
              >
                {catsExpanded ? (
                  <>
                    Show less <ChevronUp size={11} />
                  </>
                ) : (
                  <>
                    Show more <ChevronDown size={11} />
                  </>
                )}
              </button>
            )}
            <div
              className="flex items-center gap-1 rounded-full px-2 py-1"
              style={{ background: "var(--surface-3)", border: "1px solid var(--line)" }}
            >
              <Search size={11} className="shrink-0" style={{ color: "var(--ink-faint)" }} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by name…"
                aria-label="Search your picture library by name"
                className="w-24 min-w-0 bg-transparent py-px text-[10.5px] font-semibold outline-none sm:w-32"
                style={{ color: "var(--ink)" }}
              />
              {query && (
                <button
                  onClick={() => setQuery("")}
                  aria-label="Clear the search"
                  title="Clear"
                  className="shrink-0 transition-colors hover:text-[var(--ink)]"
                  style={{ color: "var(--ink-faint)" }}
                >
                  <X size={10.5} />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* the grid */}
      {shown.length > 0 ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {shown.map((m) => (
            <div
              key={m.id}
              className="group/media overflow-hidden rounded-xl"
              style={{ background: "var(--surface)", border: "1px solid var(--line-soft)" }}
            >
              <div className="relative h-24 w-full" style={{ background: "var(--surface-3)" }}>
                <img src={m.url} alt={m.name} className="h-full w-full object-cover" />
                <button
                  onClick={() => deleteMedia(m.id)}
                  aria-label={`Delete ${m.name}`}
                  title="Delete"
                  className="absolute top-1 right-1 flex h-6 w-6 items-center justify-center rounded-full opacity-0 transition-opacity group-hover/media:opacity-100 focus-visible:opacity-100"
                  style={{ background: "rgba(24,18,10,0.6)", color: "#fff" }}
                >
                  <Trash2 size={11} />
                </button>
              </div>

              {editing === m.id ? (
                <div className="flex flex-col gap-1 p-2">
                  <input
                    autoFocus
                    className="input-line !py-1 text-[11px]"
                    value={draftName}
                    onChange={(e) => setDraftName(e.target.value)}
                    placeholder="Name"
                    maxLength={60}
                    aria-label="Picture name"
                  />
                  <input
                    className="input-line !py-1 text-[11px]"
                    value={draftCat}
                    onChange={(e) => setDraftCat(e.target.value)}
                    placeholder="Category"
                    list="media-category-options"
                    maxLength={40}
                    aria-label="Picture category"
                  />
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        void updateMedia(m.id, {
                          name: draftName.trim() || "Untitled",
                          category: draftCat.trim(),
                        });
                        setEditing(null);
                      }}
                      className="btn-accent flex-1 justify-center py-1 text-[10.5px] font-bold"
                    >
                      <Check size={10} /> Save
                    </button>
                    <button
                      onClick={() => setEditing(null)}
                      className="btn-ghost px-2 py-1 text-[10.5px]"
                      aria-label="Cancel"
                    >
                      <X size={10} />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-1 p-2">
                  <span className="min-w-0 flex-1">
                    <span
                      className="block truncate text-[11px] font-semibold"
                      style={{ color: "var(--ink)" }}
                    >
                      {m.name}
                    </span>
                    <span className="block truncate text-[9.5px]" style={{ color: "var(--ink-faint)" }}>
                      {catOf(m)}
                    </span>
                  </span>
                  <button
                    onClick={() => {
                      setEditing(m.id);
                      setDraftName(m.name);
                      setDraftCat(m.category);
                    }}
                    aria-label={`Rename or recategorise ${m.name}`}
                    title="Rename / change category"
                    className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-2)]"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Pencil size={10.5} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="px-1 py-4 text-center text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
          {query.trim()
            ? `No pictures match “${query.trim()}” — try another name.`
            : "Nothing here yet — add your first picture above."}
        </p>
      )}
    </div>
  );
}

export default function ImagesPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { images } = useDashboard();
  const hero = images.find((i) => i.key === "hero")?.url ?? DEFAULTS.hero;
  const gallery = images.find((i) => i.key === "gallery")?.url ?? DEFAULTS.gallery;

  return (
    <Modal open={open} onClose={onClose} wide>
      <ModalHeader
        title="Site images"
        subtitle="Every picture here is yours to change"
        onClose={onClose}
      />
      <div className="flex flex-col gap-3 overflow-y-auto px-6 py-5">
        <ImageSlot
          slotKey="hero"
          label="Dashboard banner"
          url={hero}
          hint="The big warm welcome at the top of your dashboard."
        />
        <ImageSlot
          slotKey="gallery"
          label="Daydream gallery"
          url={gallery}
          hint="The postcard image in the Daydream corner widget."
        />
        <ImageSlot
          slotKey="avatar"
          label="Your avatar"
          url={DEFAULTS.avatar}
          hint="Shown in the header and on your profile page."
        />

        <MediaLibrary />

        <div
          className="mt-1 flex items-start gap-2.5 rounded-2xl px-4 py-3.5 text-[12px] leading-relaxed"
          style={{ background: "var(--accent-soft)", color: "var(--ink-soft)" }}
        >
          <ImageIcon size={15} className="mt-0.5 shrink-0" style={{ color: "var(--accent)" }} />
          <p>
            More images can be changed in place: open any note to change its image, and hover a
            track in the Music Room playlist to swap its cover art. Profile details live on your{" "}
            <Link
              href="/profile"
              onClick={onClose}
              className="font-semibold underline underline-offset-2"
              style={{ color: "var(--accent)" }}
            >
              profile page
            </Link>
            .
          </p>
        </div>
      </div>
    </Modal>
  );
}
