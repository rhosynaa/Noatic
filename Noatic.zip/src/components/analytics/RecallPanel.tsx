"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Brain, Layers, Trash2, Undo2 } from "lucide-react";
import { SectionLabel } from "@/components/ui";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import {
  DEADLINE_COLORS,
  RATING_META,
  type ReviewBucket,
  type ReviewRating,
  type ReviewStats,
} from "@/lib/types";

type View = "daily" | "weekly" | "monthly";
const VIEW_LABEL: Record<View, string> = {
  daily: "Daily",
  weekly: "Weekly",
  monthly: "Monthly",
};
const ORDER: ReviewRating[] = ["easy", "good", "hard"];

const pct = (n: number, total: number) => (total > 0 ? Math.round((n / total) * 100) : 0);

/** stacked easy/good/hard column per period */
function StackedChart({ buckets }: { buckets: ReviewBucket[] }) {
  const max = Math.max(1, ...buckets.map((b) => b.total));
  return (
    <div className="mt-4 flex h-32 items-end gap-1.5">
      {buckets.map((b) => (
        <div key={b.key} className="group flex flex-1 flex-col items-center gap-1.5">
          <span
            className="text-[10px] font-bold tabular-nums opacity-0 transition-opacity group-hover:opacity-100"
            style={{ color: "var(--ink-soft)" }}
          >
            {b.total || ""}
          </span>
          <div
            className="flex w-full flex-col-reverse overflow-hidden"
            style={{
              height: `${(b.total / max) * 84}px`,
              minHeight: b.total ? 8 : 4,
              background: b.total ? "transparent" : "var(--surface-3)",
              borderRadius: "6px 6px 3px 3px",
            }}
            title={
              b.total
                ? `${b.label}: ${b.easy} easy · ${b.good} good · ${b.hard} hard`
                : `${b.label}: no reviews`
            }
          >
            {ORDER.map((r) =>
              b[r] > 0 ? (
                <div
                  key={r}
                  style={{
                    height: `${(b[r] / b.total) * 100}%`,
                    background: RATING_META[r].color,
                  }}
                />
              ) : null
            )}
          </div>
          <span className="truncate text-[9.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
            {b.label}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function RecallPanel() {
  const { push } = useToast();
  const [data, setData] = useState<ReviewStats | null>(null);
  const [view, setView] = useState<View>("daily");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setData(await api<ReviewStats>("/api/flashcard-reviews"));
    } catch {
      push("error", "Couldn't load recall stats");
    }
  }, [push]);

  useEffect(() => {
    void load();
  }, [load]);

  const buckets = useMemo(() => {
    if (!data) return [];
    return view === "daily" ? data.daily : view === "weekly" ? data.weekly : data.monthly;
  }, [data, view]);

  const viewTotals = useMemo(
    () =>
      buckets.reduce(
        (a, b) => ({
          easy: a.easy + b.easy,
          good: a.good + b.good,
          hard: a.hard + b.hard,
          total: a.total + b.total,
        }),
        { easy: 0, good: 0, hard: 0, total: 0 }
      ),
    [buckets]
  );

  const deleteLast = async (n: number) => {
    setBusy(true);
    try {
      const res = await api<{ deleted: number }>(`/api/flashcard-reviews?last=${n}`, {
        method: "DELETE",
      });
      push("success", `Removed ${res.deleted} entr${res.deleted === 1 ? "y" : "ies"}`);
      await load();
    } catch {
      push("error", "Couldn't delete those entries");
    } finally {
      setBusy(false);
    }
  };

  const deleteOne = async (id: string) => {
    setData((d) => (d ? { ...d, recent: d.recent.filter((r) => r.id !== id) } : d));
    try {
      await api(`/api/flashcard-reviews/${id}`, { method: "DELETE" });
    } catch {
      push("error", "Couldn't delete that entry");
    }
    await load();
  };

  if (!data) {
    return (
      <p className="py-8 text-center text-[13px]" style={{ color: "var(--ink-faint)" }}>
        Loading recall stats…
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      {/* ---------- rates ---------- */}
      <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <SectionLabel>Flashcard recall · {VIEW_LABEL[view].toLowerCase()}</SectionLabel>
          <div className="flex gap-1 rounded-full p-1" style={{ background: "var(--surface-2)" }}>
            {(["daily", "weekly", "monthly"] as View[]).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className="rounded-full px-3 py-1 text-[11px] font-bold transition-all"
                style={{
                  background: view === v ? "var(--accent)" : "transparent",
                  color: view === v ? "var(--accent-ink)" : "var(--ink-soft)",
                }}
              >
                {VIEW_LABEL[v]}
              </button>
            ))}
          </div>
        </div>

        <StackedChart buckets={buckets} />

        {/* rate summary for the selected range */}
        <div className="mt-4 grid grid-cols-3 gap-2">
          {ORDER.map((r) => (
            <div
              key={r}
              className="rounded-2xl px-3 py-2.5 text-center"
              style={{ background: `${RATING_META[r].color}14`, border: `1px solid ${RATING_META[r].color}40` }}
            >
              <p className="font-display text-[20px] leading-none font-semibold" style={{ color: RATING_META[r].color }}>
                {pct(viewTotals[r], viewTotals.total)}%
              </p>
              <p className="mt-1 text-[10.5px] font-bold" style={{ color: "var(--ink-soft)" }}>
                {RATING_META[r].label}
              </p>
              <p className="text-[10px] tabular-nums" style={{ color: "var(--ink-faint)" }}>
                {viewTotals[r]} card{viewTotals[r] === 1 ? "" : "s"}
              </p>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
          {viewTotals.total > 0 ? (
            <>
              <span className="font-bold" style={{ color: "var(--accent)" }}>
                {pct(viewTotals.easy + viewTotals.good, viewTotals.total)}% recall
              </span>{" "}
              across {viewTotals.total} review{viewTotals.total === 1 ? "" : "s"} ·{" "}
              {view === "daily" ? "last 14 days" : view === "weekly" ? "last 8 weeks" : "last 6 months"}
            </>
          ) : (
            "No reviews in this range yet — rate some cards in the Flashcards section."
          )}
        </p>
      </section>

      {/* ---------- per subject ---------- */}
      {data.bySubject.length > 0 && (
        <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
          <SectionLabel>Recall by subject · all time</SectionLabel>
          <div className="mt-4 flex flex-col gap-3">
            {data.bySubject.map((s) => (
              <div key={s.subject}>
                <div className="flex items-center justify-between text-[12px]">
                  <span className="flex items-center gap-1.5 font-semibold" style={{ color: "var(--ink)" }}>
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ background: DEADLINE_COLORS[s.color] ?? "var(--accent)" }}
                    />
                    {s.subject}
                  </span>
                  <span className="font-bold tabular-nums" style={{ color: "var(--ink-soft)" }}>
                    {pct(s.easy + s.good, s.total)}% recall · {s.total} review{s.total === 1 ? "" : "s"}
                  </span>
                </div>
                <div className="mt-1.5 flex h-3 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
                  {ORDER.map((r) =>
                    s[r] > 0 ? (
                      <div
                        key={r}
                        style={{ width: `${(s[r] / s.total) * 100}%`, background: RATING_META[r].color }}
                        title={`${s[r]} ${RATING_META[r].label}`}
                      />
                    ) : null
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ---------- entries ---------- */}
      <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <SectionLabel>Review entries</SectionLabel>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => deleteLast(1)}
              disabled={busy || data.recent.length === 0}
              className="btn-ghost px-3 py-1.5 text-[11px] font-semibold disabled:opacity-40"
              title="Delete the most recent entry"
            >
              <Undo2 size={12} /> Undo last
            </button>
            <button
              onClick={() => deleteLast(5)}
              disabled={busy || data.recent.length === 0}
              className="btn-ghost px-3 py-1.5 text-[11px] font-semibold disabled:opacity-40 hover:!text-red-500"
              title="Delete the 5 most recent entries"
            >
              <Trash2 size={12} /> Last 5
            </button>
          </div>
        </div>

        <div className="mt-3 flex max-h-[320px] flex-col gap-1.5 overflow-y-auto pr-1">
          {data.recent.map((r) => (
            <div
              key={r.id}
              className="group flex items-center gap-2.5 rounded-xl px-3 py-2"
              style={{ background: "var(--surface-2)" }}
            >
              <span
                className="shrink-0 rounded-full px-2 py-0.5 text-[9.5px] font-bold uppercase"
                style={{ background: `${RATING_META[r.rating].color}22`, color: RATING_META[r.rating].color }}
              >
                {RATING_META[r.rating].label}
              </span>
              <span className="min-w-0 flex-1 truncate text-[12px]" style={{ color: "var(--ink)" }}>
                {r.front ?? "Deleted card"}
              </span>
              {r.subject && (
                <span className="hidden shrink-0 text-[10.5px] sm:inline" style={{ color: "var(--ink-faint)" }}>
                  {r.subject}
                </span>
              )}
              <span className="shrink-0 text-[10.5px] tabular-nums" style={{ color: "var(--ink-faint)" }}>
                {new Date(r.reviewedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}{" "}
                {new Date(r.reviewedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
              </span>
              <button
                onClick={() => deleteOne(r.id)}
                aria-label="Delete entry"
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                style={{ color: "var(--ink-faint)" }}
              >
                <Trash2 size={11} />
              </button>
            </div>
          ))}
          {data.recent.length === 0 && (
            <p className="flex flex-col items-center gap-2 py-6 text-center text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
              <Layers size={18} />
              No reviews logged yet — study a deck and tap Easy, Good or Hard.
            </p>
          )}
        </div>
      </section>

      <p className="flex items-center gap-1.5 px-1 text-[11px]" style={{ color: "var(--ink-faint)" }}>
        <Brain size={12} />
        Ratings feed the Hard pile in Flashcards — cards you last marked Hard show up there.
      </p>
    </div>
  );
}
