"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  Check,
  Clock3,
  NotebookPen,
  Pencil,
  Plus,
  Target,
  Trash2,
  X,
} from "lucide-react";
import { SectionLabel } from "@/components/ui";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import { useDashboard } from "@/lib/dashboard-context";
import {
  DEADLINE_COLORS,
  TIMER_KIND_META,
  type ProgressBucket,
  type ProgressData,
  type TimerKind,
} from "@/lib/types";

type View = "daily" | "weekly" | "monthly";

const VIEW_LABEL: Record<View, string> = {
  daily: "Daily",
  weekly: "Weekly",
  monthly: "Monthly",
};

export function fmtMins(m: number): string {
  const h = Math.floor(m / 60);
  const r = Math.round(m % 60);
  if (h && r) return `${h}h ${r}m`;
  if (h) return `${h}h`;
  return `${r}m`;
}

function BarChart({ buckets }: { buckets: ProgressBucket[] }) {
  const max = Math.max(1, ...buckets.map((b) => b.minutes));
  return (
    <div className="mt-4 flex h-32 items-end gap-1.5">
      {buckets.map((b) => (
        <div key={b.key} className="group flex flex-1 flex-col items-center gap-1.5">
          <span
            className="text-[10px] font-bold tabular-nums opacity-0 transition-opacity group-hover:opacity-100"
            style={{ color: "var(--accent)" }}
          >
            {b.minutes ? fmtMins(b.minutes) : ""}
          </span>
          <div
            className="w-full transition-all duration-700"
            style={{
              height: `${(b.minutes / max) * 84}px`,
              minHeight: b.minutes ? 8 : 4,
              background: b.minutes ? "var(--accent)" : "var(--surface-3)",
              opacity: b.minutes ? 0.55 + (0.45 * b.minutes) / max : 1,
              borderRadius: "6px 6px 3px 3px",
            }}
            title={`${b.label} · ${fmtMins(b.minutes)}`}
          />
          <span className="truncate text-[9.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
            {b.label}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function ProgressPanel() {
  const { push } = useToast();
  const { subjects, notes } = useDashboard();
  const [data, setData] = useState<ProgressData | null>(null);
  const [view, setView] = useState<View>("daily");
  const [busy, setBusy] = useState(false);

  /* target form */
  const [showTargetForm, setShowTargetForm] = useState(false);
  const [scope, setScope] = useState<"subject" | "note">("subject");
  const [ref, setRef] = useState("");
  const [hours, setHours] = useState(10);
  const [editingTargetId, setEditingTargetId] = useState<string | null>(null);

  /* entry editing */
  const [editEntryId, setEditEntryId] = useState<string | null>(null);
  const [entryMinutes, setEntryMinutes] = useState(25);
  const [entrySubject, setEntrySubject] = useState("");
  const [entryLabel, setEntryLabel] = useState("");
  const [entryDate, setEntryDate] = useState("");

  const load = useCallback(async () => {
    try {
      setData(await api<ProgressData>("/api/progress"));
    } catch {
      push("error", "Couldn't load progress");
    }
  }, [push]);

  useEffect(() => {
    void load();
  }, [load]);

  const buckets = useMemo(() => {
    if (!data) return [];
    return view === "daily" ? data.daily : view === "weekly" ? data.weekly : data.monthly;
  }, [data, view]);

  const viewTotal = buckets.reduce((a, b) => a + b.minutes, 0);

  /* ---------- targets ---------- */
  const submitTarget = async (e: FormEvent) => {
    e.preventDefault();
    if (!ref.trim()) {
      push("error", "Pick a subject or note first");
      return;
    }
    if (hours <= 0) {
      push("error", "Target hours must be greater than zero");
      return;
    }
    setBusy(true);
    try {
      if (editingTargetId) {
        await api(`/api/study-targets/${editingTargetId}`, {
          method: "PATCH",
          body: { targetHours: hours },
        });
        push("success", "Target updated");
      } else {
        await api("/api/study-targets", {
          method: "POST",
          body: { scope, ref: ref.trim(), targetHours: hours },
        });
        push("success", "Target set — the timer now counts toward it");
      }
      setShowTargetForm(false);
      setEditingTargetId(null);
      setRef("");
      setHours(10);
      await load();
    } catch (err) {
      push("error", err instanceof Error ? err.message : "Couldn't save that target");
    } finally {
      setBusy(false);
    }
  };

  const deleteTarget = async (id: string) => {
    setData((d) => (d ? { ...d, targets: d.targets.filter((t) => t.id !== id) } : d));
    try {
      await api(`/api/study-targets/${id}`, { method: "DELETE" });
      push("success", "Target removed");
    } catch {
      push("error", "Couldn't remove that target");
    }
    await load();
  };

  /* ---------- entries ---------- */
  const beginEditEntry = (e: ProgressData["entries"][number]) => {
    setEditEntryId(e.id);
    setEntryMinutes(e.minutes);
    setEntrySubject(e.subject);
    setEntryLabel(e.label);
    // datetime-local wants a local, seconds-free value
    const d = new Date(e.completedAt);
    const pad = (n: number) => String(n).padStart(2, "0");
    setEntryDate(
      `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(
        d.getMinutes()
      )}`
    );
  };

  const saveEntry = async () => {
    if (!editEntryId) return;
    setBusy(true);
    try {
      await api(`/api/focus-sessions/${editEntryId}`, {
        method: "PATCH",
        body: {
          minutes: entryMinutes,
          subject: entrySubject,
          label: entryLabel,
          completedAt: entryDate ? new Date(entryDate).toISOString() : undefined,
        },
      });
      push("success", "Time entry updated");
      setEditEntryId(null);
      await load();
    } catch (err) {
      push("error", err instanceof Error ? err.message : "Couldn't update that entry");
    } finally {
      setBusy(false);
    }
  };

  const deleteEntry = async (id: string) => {
    setData((d) => (d ? { ...d, entries: d.entries.filter((e) => e.id !== id) } : d));
    try {
      await api(`/api/focus-sessions/${id}`, { method: "DELETE" });
      push("success", "Time entry deleted");
    } catch {
      push("error", "Couldn't delete that entry");
    }
    await load();
  };

  if (!data) {
    return (
      <p className="py-8 text-center text-[13px]" style={{ color: "var(--ink-faint)" }}>
        Loading progress…
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      {/* ---------- Daily / Weekly / Monthly ---------- */}
      <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <SectionLabel>Study time · {VIEW_LABEL[view].toLowerCase()} view</SectionLabel>
          <div className="flex gap-1 rounded-full p-1" style={{ background: "var(--surface-2)" }}>
            {(["daily", "weekly", "monthly"] as View[]).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className="rounded-full px-3 py-1 text-[11px] font-bold transition-all"
                style={{
                  background: view === v ? "var(--accent)" : "transparent",
                  color: view === v ? "var(--accent-ink)" : "var(--ink-soft)",
                }}
              >
                {VIEW_LABEL[v]}
              </button>
            ))}
          </div>
        </div>
        <BarChart buckets={buckets} />
        <div className="mt-3 flex items-center justify-between text-[11.5px]">
          <span style={{ color: "var(--ink-faint)" }}>
            {view === "daily"
              ? "Last 14 days"
              : view === "weekly"
                ? "Last 8 weeks"
                : "Last 6 months"}
          </span>
          <span className="font-bold tabular-nums" style={{ color: "var(--accent)" }}>
            {fmtMins(viewTotal)} in view · {fmtMins(data.totalLoggedMinutes)} all time
          </span>
        </div>
      </section>

      {/* ---------- target hours ---------- */}
      <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
        <div className="flex items-center justify-between">
          <SectionLabel>Total target hours</SectionLabel>
          <button
            onClick={() => {
              setShowTargetForm((v) => !v);
              setEditingTargetId(null);
              setRef("");
              setHours(10);
            }}
            className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
          >
            <Plus size={12.5} /> Set target
          </button>
        </div>

        {showTargetForm && (
          <form
            onSubmit={submitTarget}
            className="animate-pop mt-3 flex flex-wrap items-center gap-2 rounded-2xl p-3"
            style={{ background: "var(--accent-soft)", border: "1px dashed var(--accent)" }}
          >
            {!editingTargetId && (
              <>
                <div className="flex overflow-hidden rounded-full" style={{ border: "1px solid var(--line)" }}>
                  {(["subject", "note"] as const).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => {
                        setScope(s);
                        setRef("");
                      }}
                      className="px-3 py-1.5 text-[11px] font-bold capitalize transition-all"
                      style={{
                        background: scope === s ? "var(--accent)" : "var(--surface)",
                        color: scope === s ? "var(--accent-ink)" : "var(--ink-soft)",
                      }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <select
                  className="input-box !w-auto !min-w-40 !px-2 !py-1.5 !text-[12px]"
                  value={ref}
                  onChange={(e) => setRef(e.target.value)}
                  aria-label={scope === "subject" ? "Subject" : "Note"}
                >
                  <option value="">
                    {scope === "subject" ? "Choose a subject…" : "Choose a note…"}
                  </option>
                  {scope === "subject"
                    ? subjects.map((s) => (
                        <option key={s.id} value={s.name}>
                          {s.name}
                        </option>
                      ))
                    : notes.map((n) => (
                        <option key={n.id} value={n.id}>
                          {n.title || "Untitled note"}
                        </option>
                      ))}
                </select>
              </>
            )}
            <label className="flex items-center gap-1.5 text-[11.5px] font-semibold" style={{ color: "var(--ink-soft)" }}>
              <input
                type="number"
                min={0.25}
                step={0.25}
                max={2000}
                className="input-box !w-[84px] !px-2 !py-1.5 text-center !text-[12px]"
                value={hours}
                onChange={(e) => setHours(Number(e.target.value) || 0)}
                aria-label="Target hours"
              />
              target hours
            </label>
            <button type="submit" disabled={busy} className="btn-accent px-3.5 py-1.5 text-[11.5px] font-semibold disabled:opacity-50">
              <Check size={12} /> {editingTargetId ? "Save changes" : "Set target"}
            </button>
            <button
              type="button"
              onClick={() => {
                setShowTargetForm(false);
                setEditingTargetId(null);
              }}
              className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
            >
              Cancel
            </button>
          </form>
        )}

        <div className="mt-3 flex flex-col gap-2.5">
          {data.targets.map((t) => (
            <div key={t.id} className="group">
              <div className="flex items-center justify-between gap-2">
                <p className="flex min-w-0 items-center gap-1.5 text-[12.5px] font-semibold" style={{ color: "var(--ink)" }}>
                  {t.scope === "note" ? (
                    <NotebookPen size={11.5} style={{ color: "var(--ink-faint)" }} />
                  ) : (
                    <Target size={11.5} style={{ color: "var(--ink-faint)" }} />
                  )}
                  <span className="truncate">{t.name}</span>
                  <span
                    className="shrink-0 rounded-full px-1.5 py-0.5 text-[9.5px] font-bold uppercase"
                    style={{ background: "var(--surface-3)", color: "var(--ink-faint)" }}
                  >
                    {t.scope}
                  </span>
                </p>
                <div className="flex shrink-0 items-center gap-1.5">
                  <span className="text-[11.5px] font-bold tabular-nums" style={{ color: "var(--accent)" }}>
                    {fmtMins(t.loggedMinutes)} / {t.targetHours}h
                  </span>
                  <button
                    onClick={() => {
                      setEditingTargetId(t.id);
                      setHours(t.targetHours);
                      setShowTargetForm(true);
                    }}
                    aria-label={`Edit target for ${t.name}`}
                    className="flex h-6 w-6 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-[var(--surface-3)]"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Pencil size={11} />
                  </button>
                  <button
                    onClick={() => deleteTarget(t.id)}
                    aria-label={`Delete target for ${t.name}`}
                    className="flex h-6 w-6 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              </div>
              <div className="mt-1.5 h-3 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${t.percent}%`,
                    minWidth: t.loggedMinutes ? 6 : 0,
                    background: DEADLINE_COLORS[t.color] ?? "var(--accent)",
                  }}
                />
              </div>
              <p className="mt-1 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                {t.percent}% complete ·{" "}
                {t.remainingMinutes > 0 ? `${fmtMins(t.remainingMinutes)} to go` : "target reached 🎉"}
              </p>
            </div>
          ))}
          {data.targets.length === 0 && (
            <p className="py-4 text-center text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
              No targets yet — set total target hours for a subject or a single note, and
              the study timer will count toward it automatically.
            </p>
          )}
        </div>
      </section>

      {/* ---------- logged entries ---------- */}
      <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
        <div className="flex items-center justify-between">
          <SectionLabel>Logged time entries</SectionLabel>
          <span className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
            {data.entries.length} record{data.entries.length === 1 ? "" : "s"}
          </span>
        </div>

        <div className="mt-3 flex max-h-[420px] flex-col gap-1.5 overflow-y-auto pr-1">
          {data.entries.map((e) =>
            editEntryId === e.id ? (
              <div
                key={e.id}
                className="animate-pop flex flex-wrap items-center gap-2 rounded-2xl p-3"
                style={{ background: "var(--accent-soft)", border: "1px dashed var(--accent)" }}
              >
                <input
                  type="number"
                  min={1}
                  max={1440}
                  className="input-box !w-[74px] !px-2 !py-1 text-center !text-[12px]"
                  value={entryMinutes}
                  onChange={(ev) => setEntryMinutes(Math.max(1, Number(ev.target.value) || 1))}
                  aria-label="Minutes"
                />
                <span className="text-[11px] font-semibold" style={{ color: "var(--ink-faint)" }}>min</span>
                <select
                  className="input-box !w-auto !px-2 !py-1 !text-[12px]"
                  value={entrySubject}
                  onChange={(ev) => setEntrySubject(ev.target.value)}
                  aria-label="Subject"
                >
                  <option value="">No subject</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
                <input
                  className="input-line min-w-24 flex-1 !text-[12px]"
                  placeholder="Label"
                  value={entryLabel}
                  maxLength={40}
                  onChange={(ev) => setEntryLabel(ev.target.value)}
                />
                <input
                  type="datetime-local"
                  className="input-box !w-[186px] !px-2 !py-1 !text-[11.5px]"
                  value={entryDate}
                  onChange={(ev) => setEntryDate(ev.target.value)}
                  aria-label="Logged at"
                />
                <button onClick={saveEntry} disabled={busy} className="btn-accent h-8 px-3 text-[11.5px] font-semibold disabled:opacity-50">
                  <Check size={12} /> Save
                </button>
                <button onClick={() => setEditEntryId(null)} className="btn-ghost h-8 w-8 !p-0" aria-label="Cancel edit">
                  <X size={12} />
                </button>
              </div>
            ) : (
              <div
                key={e.id}
                className="group flex items-center gap-2.5 rounded-xl px-3 py-2"
                style={{ background: "var(--surface-2)" }}
              >
                <Clock3
                  size={13}
                  className="shrink-0"
                  style={{
                    color:
                      e.kind === "focus" || e.kind === "custom" ? "#52796f" : "var(--ink-faint)",
                  }}
                />
                <span className="shrink-0 text-[12.5px] font-bold tabular-nums" style={{ color: "var(--ink)" }}>
                  {fmtMins(e.minutes)}
                </span>
                <span className="min-w-0 flex-1 truncate text-[12px]" style={{ color: "var(--ink-soft)" }}>
                  {TIMER_KIND_META[(e.kind ?? "focus") as TimerKind]?.label ?? "Focus"}
                  {e.label ? ` · ${e.label}` : ""}
                  {e.noteTitle ? ` · ${e.noteTitle}` : ""}
                </span>
                {e.subject && (
                  <span
                    className="hidden shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold sm:inline"
                    style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                  >
                    {e.subject}
                  </span>
                )}
                <span className="shrink-0 text-[10.5px] tabular-nums" style={{ color: "var(--ink-faint)" }}>
                  {new Date(e.completedAt).toLocaleDateString(undefined, {
                    month: "short",
                    day: "numeric",
                  })}{" "}
                  {new Date(e.completedAt).toLocaleTimeString(undefined, {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
                <div className="flex shrink-0 gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={() => beginEditEntry(e)}
                    aria-label="Edit entry"
                    className="flex h-6 w-6 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-3)]"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Pencil size={11} />
                  </button>
                  <button
                    onClick={() => deleteEntry(e.id)}
                    aria-label="Delete entry"
                    className="flex h-6 w-6 items-center justify-center rounded-full transition-colors hover:bg-red-500/10 hover:text-red-500"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              </div>
            )
          )}
          {data.entries.length === 0 && (
            <p className="py-6 text-center text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
              No time logged yet — finish a focus session and it will appear here.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}
