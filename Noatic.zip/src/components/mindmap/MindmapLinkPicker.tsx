"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { BookMarked, Link2, NotebookPen, Search, Unlink } from "lucide-react";
import { api } from "@/lib/api";
import { useDashboard } from "@/lib/dashboard-context";
import { useToast } from "@/lib/toast";
import type { MindMapInfo } from "@/lib/mindmap-nav";
import type { MindMapLink } from "@/lib/types";

/**
 * "Link this map" — attaches a mind map to notes and subjects so either side
 * can jump straight to the other. A map can hold an unlimited number of
 * links: each pick toggles that entry on or off, and the panel stays open so
 * several can be chosen in one go. The panel is portalled + fixed-positioned
 * so drawers with overflow scrolling never clip it.
 */
export default function MindmapLinkPicker({
  map,
  onChanged,
  className = "btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold",
  iconSize = 12,
  label = "Link",
}: {
  map: MindMapInfo;
  onChanged: (m: MindMapInfo) => void;
  className?: string;
  iconSize?: number;
  label?: string;
}) {
  const { notes, subjects } = useDashboard();
  const { push } = useToast();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const btnRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  const links = map.links ?? [];
  const isOn = (type: "note" | "subject", id: string) =>
    links.some((l) => l.type === type && l.id === id);

  /* latest list holding every optimistic toggle, so rapid successive picks
     never overwrite each other while saves are still in flight */
  const latestRef = useRef<MindMapLink[]>(map.links ?? []);
  useEffect(() => {
    latestRef.current = map.links ?? [];
  }, [map.links]);

  /* place next to the button, flipped/clamped to stay on screen */
  useEffect(() => {
    if (!open) return;
    const place = () => {
      const a = btnRef.current?.getBoundingClientRect();
      if (!a) return;
      const w = 288;
      const h = panelRef.current?.offsetHeight ?? 340;
      const M = 8;
      const vw = document.documentElement.clientWidth;
      const vh = document.documentElement.clientHeight;
      let top = a.bottom + 6;
      if (top + h > vh - M) top = Math.max(M, a.top - 6 - h);
      let left = Math.min(Math.max(M, a.left), Math.max(M, vw - M - w));
      setPos({ top, left });
    };
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open]);

  /* dismiss on Escape or an outside click */
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    const onDown = (e: PointerEvent) => {
      if (
        !panelRef.current?.contains(e.target as Node) &&
        !btnRef.current?.contains(e.target as Node)
      )
        setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onDown);
    };
  }, [open]);

  const q = query.trim().toLowerCase();
  const noteMatches = useMemo(
    () =>
      notes
        .filter((n) => !q || n.title.toLowerCase().includes(q) || n.subject.toLowerCase().includes(q))
        .slice(0, 6),
    [notes, q]
  );
  const subjectMatches = useMemo(
    () => subjects.filter((s) => !q || s.name.toLowerCase().includes(q)).slice(0, 6),
    [subjects, q]
  );

  /** write a whole new links list for this map */
  const commit = async (next: MindMapLink[], message: string | null) => {
    try {
      const updated = await api<MindMapInfo>(`/api/mindmaps/${map.id}`, {
        method: "PATCH",
        body: { links: next },
      });
      onChanged(updated);
      if (message) push("success", message);
    } catch {
      push("error", "Couldn't update that link");
    }
  };

  /** toggle a single note/subject in or out of the map's links — no cap */
  const toggleLink = (type: "note" | "subject", id: string, labelText: string) => {
    const cur = latestRef.current;
    const on = cur.some((l) => l.type === type && l.id === id);
    if (on) {
      const next = cur.filter((l) => !(l.type === type && l.id === id));
      latestRef.current = next;
      void commit(next, `Unlinked ${labelText} from “${map.name}”`);
    } else {
      const next = [...cur, { type, id }];
      latestRef.current = next;
      void commit(next, `Linked “${map.name}” to ${labelText}`);
    }
  };

  const clearAll = () => {
    latestRef.current = [];
    void commit([], `Cleared every link from “${map.name}”`);
    setOpen(false);
  };

  const rowCls =
    "flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left transition-colors hover:bg-[var(--surface-2)]";
  const headCls =
    "px-1 pb-1 pt-2 text-[9.5px] font-bold tracking-[0.12em] uppercase";

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen((v) => !v);
        }}
        aria-expanded={open}
        title="Link this map to notes and subjects"
        className={className}
        style={links.length ? { background: "var(--accent-soft)", color: "var(--accent)" } : undefined}
      >
        <Link2 size={iconSize} /> {links.length ? `Linked · ${links.length}` : label}
      </button>

      {open &&
        pos &&
        createPortal(
          <div
            ref={panelRef}
            onPointerDown={(e) => e.stopPropagation()}
            className="animate-pop rail-scroll fixed z-[3000] max-h-[340px] w-[288px] overflow-y-auto rounded-2xl p-2.5"
            style={{
              top: pos.top,
              left: pos.left,
              background: "var(--surface)",
              border: "1px solid var(--line)",
              boxShadow: "0 20px 44px rgba(24,18,10,0.22)",
            }}
          >
            <p
              className="mb-1.5 px-0.5 text-[9.5px] font-bold tracking-[0.12em] uppercase"
              style={{ color: "var(--ink-faint)" }}
            >
              Link “{map.name}” to…
            </p>

            <div
              className="mb-1.5 flex items-center gap-1.5 rounded-xl px-2 py-1.5"
              style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
            >
              <Search size={12} style={{ color: "var(--ink-faint)" }} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search notes & subjects…"
                className="min-w-0 flex-1 bg-transparent text-[12px] font-medium outline-none placeholder:opacity-60"
                style={{ color: "var(--ink)" }}
              />
            </div>

            {/* how many are already tied to this map */}
            <p className="px-1 pb-0.5 text-[10px] font-semibold" style={{ color: "var(--ink-faint)" }}>
              {links.length === 0
                ? "Nothing linked yet — pick as many as you like"
                : `${links.length} linked — tap any entry to add or remove it`}
            </p>

            <p className={headCls} style={{ color: "var(--ink-faint)" }}>
              Notes
            </p>
            {noteMatches.map((n) => {
              const on = isOn("note", n.id);
              return (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => void toggleLink("note", n.id, `“${n.title || "Untitled note"}”`)}
                  className={rowCls}
                  style={on ? { background: "var(--accent-soft)" } : undefined}
                >
                  <NotebookPen size={11.5} style={{ color: "var(--accent)" }} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12px] font-semibold" style={{ color: "var(--ink)" }}>
                      {n.title || "Untitled note"}
                    </span>
                    {n.subject && (
                      <span className="block truncate text-[10px]" style={{ color: "var(--ink-faint)" }}>
                        {n.subject}
                      </span>
                    )}
                  </span>
                  {on && (
                    <span
                      className="rounded-full px-1.5 text-[8.5px] font-bold"
                      style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
                    >
                      ON
                    </span>
                  )}
                </button>
              );
            })}
            {noteMatches.length === 0 && (
              <p className="px-1 py-2 text-[11px]" style={{ color: "var(--ink-faint)" }}>
                No matching notes.
              </p>
            )}

            <p className={headCls} style={{ color: "var(--ink-faint)" }}>
              Subjects
            </p>
            {subjectMatches.map((s) => {
              const on = isOn("subject", s.id);
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => void toggleLink("subject", s.id, s.name)}
                  className={rowCls}
                  style={on ? { background: "var(--accent-soft)" } : undefined}
                >
                  <BookMarked size={11.5} style={{ color: "var(--accent)" }} />
                  <span className="min-w-0 flex-1 truncate text-[12px] font-semibold" style={{ color: "var(--ink)" }}>
                    {s.name}
                  </span>
                  {on && (
                    <span
                      className="rounded-full px-1.5 text-[8.5px] font-bold"
                      style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
                    >
                      ON
                    </span>
                  )}
                </button>
              );
            })}
            {subjectMatches.length === 0 && (
              <p className="px-1 py-2 text-[11px]" style={{ color: "var(--ink-faint)" }}>
                No matching subjects.
              </p>
            )}

            {links.length > 0 && (
              <button
                type="button"
                onClick={clearAll}
                className="btn-ghost mt-2 w-full justify-center py-1.5 text-[11px] font-semibold hover:!text-red-500"
              >
                <Unlink size={11} /> Clear all {links.length} link{links.length === 1 ? "" : "s"}
              </button>
            )}
          </div>,
          document.body
        )}
    </>
  );
}
