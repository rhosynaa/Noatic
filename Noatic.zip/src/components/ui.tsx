"use client";

import { useEffect, type ReactNode } from "react";
import { AVATAR_IMG } from "@/lib/assets";
import { createPortal } from "react-dom";
import { X } from "lucide-react";

export function Modal({
  open,
  onClose,
  children,
  wide,
  full,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
  /** fill the whole viewport — a dedicated full-screen space instead of a floating box */
  full?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;

  return createPortal(
    <div
      className={`fixed inset-0 z-[110] flex ${
        full ? "" : "items-end justify-center sm:items-center"
      }`}
    >
      <div
        className="absolute inset-0 backdrop-blur-sm"
        style={{ background: "rgba(24,18,10,0.42)" }}
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal
        className={
          full
            ? "animate-pop relative m-0 flex h-full w-full flex-col overflow-hidden"
            : `animate-pop relative m-0 flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-[1.75rem] sm:m-6 sm:rounded-[1.75rem] ${
                wide ? "sm:max-w-2xl" : "sm:max-w-lg"
              }`
        }
        style={{
          background: "var(--surface)",
          ...(full
            ? { borderRadius: 0 }
            : {
                border: "1px solid var(--line)",
                boxShadow: "0 32px 80px -24px rgba(20,14,6,0.55)",
              }),
        }}
      >
        {children}
      </div>
    </div>,
    document.body
  );
}

export function ModalHeader({
  title,
  subtitle,
  onClose,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
}) {
  return (
    <div
      className="flex items-start justify-between gap-4 border-b px-6 py-5"
      style={{ borderColor: "var(--line-soft)" }}
    >
      <div>
        <h2 className="font-display text-xl font-semibold" style={{ color: "var(--ink)" }}>
          {title}
        </h2>
        {subtitle && (
          <p className="mt-0.5 text-[13px]" style={{ color: "var(--ink-soft)" }}>
            {subtitle}
          </p>
        )}
      </div>
      <button
        onClick={onClose}
        aria-label="Close"
        className="btn-ghost h-8 w-8 shrink-0 !p-0"
        style={{ border: "none" }}
      >
        <X size={17} />
      </button>
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="group flex w-full items-center justify-between gap-4 rounded-2xl px-4 py-3 text-left transition-colors"
      style={{ background: checked ? "var(--accent-soft)" : "var(--surface-2)" }}
    >
      <span>
        <span className="block text-[13.5px] font-semibold" style={{ color: "var(--ink)" }}>
          {label}
        </span>
        {hint && (
          <span className="mt-0.5 block text-[12px]" style={{ color: "var(--ink-soft)" }}>
            {hint}
          </span>
        )}
      </span>
      <span
        className="relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300"
        style={{ background: checked ? "var(--accent)" : "var(--line)" }}
      >
        <span
          className="absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-300"
          style={{
            transform: checked ? "translateX(20px)" : "translateX(0)",
            transitionTimingFunction: "cubic-bezier(0.34,1.56,0.64,1)",
          }}
        />
      </span>
    </button>
  );
}

export function Avatar({
  src,
  name,
  size = 36,
  ring = false,
}: {
  src: string;
  name: string;
  size?: number;
  ring?: boolean;
}) {
  return (
    <span
      className="relative inline-block shrink-0 overflow-hidden rounded-full"
      style={{
        width: size,
        height: size,
        border: ring ? "2px solid var(--accent)" : "2px solid var(--line)",
        background: "var(--surface-2)",
      }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src || AVATAR_IMG}
        alt={name}
        width={size}
        height={size}
        className="h-full w-full object-cover"
        onError={(e) => {
          (e.target as HTMLImageElement).src = AVATAR_IMG;
        }}
      />
    </span>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <p
      className="text-[10.5px] font-bold tracking-[0.14em] uppercase"
      style={{ color: "var(--ink-faint)" }}
    >
      {children}
    </p>
  );
}

/** Right-anchored slide-over panel used by every sidebar section. */
export function Drawer({
  open,
  onClose,
  title,
  subtitle,
  icon,
  children,
  size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  children: ReactNode;
  size?: "md" | "lg" | "xl";
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (typeof document === "undefined") return null;

  const maxW = size === "md" ? "max-w-md" : size === "lg" ? "max-w-2xl" : "max-w-5xl";

  return createPortal(
    <>
      <div
        className={`fixed inset-0 z-[105] transition-opacity duration-300 ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        style={{ background: "rgba(24,18,10,0.42)", backdropFilter: "blur(4px)" }}
        onClick={onClose}
      />
      <aside
        aria-hidden={!open}
        className={`fixed top-0 right-0 bottom-0 z-[106] flex w-full ${maxW} flex-col transition-transform duration-500`}
        style={{
          transform: open ? "translateX(0)" : "translateX(102%)",
          transitionTimingFunction: "cubic-bezier(0.22,1,0.36,1)",
          background: "var(--bg)",
          borderLeft: "1px solid var(--line)",
          boxShadow: "-24px 0 60px -24px rgba(20,14,6,0.4)",
        }}
      >
        <div
          className="flex items-center justify-between gap-4 border-b px-6 py-5"
          style={{ borderColor: "var(--line-soft)", background: "var(--surface)" }}
        >
          <div className="flex items-center gap-3">
            {icon && (
              <span
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
                style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
              >
                {icon}
              </span>
            )}
            <div>
              <h2 className="font-display text-xl font-semibold" style={{ color: "var(--ink)" }}>
                {title}
              </h2>
              {subtitle && (
                <p className="mt-0.5 text-[12px]" style={{ color: "var(--ink-soft)" }}>
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          <button onClick={onClose} aria-label="Close" className="btn-ghost h-8 w-8 shrink-0 !p-0" style={{ border: "none" }}>
            <X size={17} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">{children}</div>
      </aside>
    </>,
    document.body
  );
}
