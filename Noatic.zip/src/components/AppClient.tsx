"use client";

import { useMemo } from "react";
import { loadDB, loadInitialData } from "@/lib/local-db";
import { DashboardProvider } from "@/lib/dashboard-context";
import { ACCENTS } from "@/lib/types";
import { AppProviders } from "@/components/providers";
import DashboardShell from "@/components/dashboard/DashboardShell";
import ProfileClient from "@/components/profile/ProfileClient";
import { useRoute } from "@/lib/router";

/** Apply the persisted theme before first paint (mirrors the old SSR <html> attrs). */
function applyInitialTheme() {
  if (typeof document === "undefined") return;
  const s = loadDB().settings;
  const root = document.documentElement;
  root.classList.toggle("dark", s.darkMode);
  const accent = ACCENTS[s.accent] ?? ACCENTS.rosewood;
  root.style.setProperty("--accent", accent.accent);
  root.style.setProperty("--accent-soft", accent.soft);
  root.style.setProperty("--accent-ink", accent.ink);
  root.style.setProperty("--font-display", "'Fraunces', serif");
  root.style.setProperty("--font-sans", "'Instrument Sans', sans-serif");
  root.dataset.accent = s.accent;
}

applyInitialTheme();

function DashboardRoute() {
  // fresh snapshot each time the dashboard mounts (data lives in localStorage)
  const initial = useMemo(() => loadInitialData(), []);
  return <DashboardShell initial={initial} />;
}

function ProfileRoute() {
  const data = useMemo(() => loadInitialData(), []);
  return (
    /* the avatar's "Library" pick button reads the media library through
       useDashboard, so the profile page needs the same provider the
       dashboard route gets */
    <DashboardProvider initial={data}>
      <ProfileClient
        initial={data.profile}
        stats={{
          notes: data.notes.length,
          tasks: data.tasks.length,
          deadlines: data.deadlines.filter((d) => !d.done).length,
          quotes: data.quotes.length,
        }}
      />
    </DashboardProvider>
  );
}

export default function App() {
  const route = useRoute();
  const initial = useMemo(() => {
    const d = loadInitialData();
    return { settings: d.settings, profile: d.profile };
  }, []);

  return (
    <>
      {/* ambient glow layers (from the original root layout) */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          background:
            "radial-gradient(60rem 40rem at 85% -10%, var(--glow), transparent 60%), radial-gradient(50rem 36rem at -10% 110%, var(--accent-soft), transparent 55%)",
        }}
      />
      <AppProviders initialSettings={initial.settings} initialProfile={initial.profile}>
        <div className="grain relative z-10">
          {route === "/profile" ? <ProfileRoute /> : <DashboardRoute />}
        </div>
      </AppProviders>
    </>
  );
}
