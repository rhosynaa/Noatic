"use client";

import { useRef, useState } from "react";
import { AVATAR_IMG } from "@/lib/assets";
import Link from "@/lib/router";
import {
  ArrowLeft,
  BadgeCheck,
  BookOpenText,
  CalendarClock,
  Camera,
  Check,
  ClipboardList,
  CloudCog,
  Link2,
  Moon,
  Pencil,
  Quote,
  RefreshCcw,
  Settings2,
  Unplug,
} from "lucide-react";
import { useProfile } from "@/lib/profile-context";
import { useSettings } from "@/lib/settings-context";
import { fileToDataUrl } from "@/lib/api";
import LibraryPickButton from "@/components/media/LibraryPickButton";
import { useToast } from "@/lib/toast";
import { Avatar, Modal, ModalHeader, SectionLabel, Toggle } from "@/components/ui";
import Scaler from "@/components/dashboard/Scaler";
import type { Profile } from "@/lib/types";

type Stats = { notes: number; tasks: number; deadlines: number; quotes: number };

function GoogleLogo({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden>
      <path fill="#4285F4" d="M23.5 12.27c0-.85-.08-1.66-.22-2.45H12v4.64h6.46a5.52 5.52 0 0 1-2.39 3.62v3h3.87c2.26-2.09 3.56-5.16 3.56-8.81z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.96-1.07 7.94-2.91l-3.87-3c-1.07.72-2.44 1.15-4.07 1.15-3.13 0-5.78-2.11-6.73-4.96H1.29v3.1A12 12 0 0 0 12 24z" />
      <path fill="#FBBC05" d="M5.27 14.28A7.2 7.2 0 0 1 4.89 12c0-.79.14-1.56.38-2.28v-3.1H1.29a12 12 0 0 0 0 10.84l3.98-3.18z" />
      <path fill="#EA4335" d="M12 4.77c1.76 0 3.34.61 4.59 1.8l3.44-3.44A11.97 11.97 0 0 0 12 0 12 12 0 0 0 1.29 6.62l3.98 3.1C6.22 6.88 8.87 4.77 12 4.77z" />
    </svg>
  );
}

function ProfileInner({ stats }: { stats: Stats }) {
  const { profile, update } = useProfile();
  const { dark, setDark, openSettings } = useSettings();
  const { push } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [nameDraft, setNameDraft] = useState("");

  const [editingName, setEditingName] = useState(false);
  const [gmailDraft, setGmailDraft] = useState("");
  const [connecting, setConnecting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [avatarOpen, setAvatarOpen] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState("");

  if (!profile) return null;

  const syncNow = async () => {
    setSyncing(true);
    await update({ syncNow: true }, { silent: true });
    setTimeout(() => setSyncing(false), 700);
    push("success", "Synced — everything is safely stored");
  };

  const connect = async () => {
    const email = gmailDraft.trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      push("error", "Enter a valid Gmail address");
      return;
    }
    setConnecting(true);
    await new Promise((r) => setTimeout(r, 900)); // handshake theatre
    await update({ googleConnected: true, googleEmail: email });
    setConnecting(false);
    setGmailDraft("");
  };

  const statCards = [
    { icon: BookOpenText, label: "Notes", value: stats.notes },
    { icon: ClipboardList, label: "Plan items", value: stats.tasks },
    { icon: CalendarClock, label: "Open deadlines", value: stats.deadlines },
    { icon: Quote, label: "Saved lines", value: stats.quotes },
  ];

  return (
    <div className="mx-auto min-h-screen max-w-[980px] px-4 pb-24 sm:px-6">
      <Scaler>
        {/* topbar */}
        <div className="flex items-center justify-between py-5">
          <Link href="/" className="btn-ghost px-3.5 py-2 text-[12.5px] font-semibold" style={{ background: "var(--surface)" }}>
            <ArrowLeft size={15} />
            Back to dashboard
          </Link>
          <button onClick={openSettings} className="btn-ghost px-3.5 py-2 text-[12.5px] font-semibold" style={{ background: "var(--surface)" }}>
            <Settings2 size={15} />
            Settings
          </button>
        </div>

        {/* identity card */}
        <section className="card animate-fade-up relative overflow-hidden p-6 sm:p-8">
          <div
            aria-hidden
            className="pointer-events-none absolute -top-24 -right-24 h-64 w-64 rounded-full"
            style={{ background: "radial-gradient(circle, var(--accent-soft), transparent 70%)" }}
          />
          <div className="relative flex flex-col items-start gap-6 sm:flex-row sm:items-center">
            <div className="relative">
              <Avatar src={profile.avatarUrl} name={profile.username} size={104} ring />
              <button
                onClick={() => fileRef.current?.click()}
                aria-label="Change avatar"
                className="btn-accent absolute -right-1 -bottom-1 h-9 w-9 !rounded-full !p-0"
              >
                <Camera size={15} />
              </button>
              <LibraryPickButton
                label=""
                iconSize={14}
                className="btn-ghost absolute -right-1 -top-1 h-8 w-8 !rounded-full !p-0"
                onPick={(u) => void update({ avatarUrl: u })}
              />
            </div>

            <div className="min-w-0 flex-1">
              {editingName ? (
                <form
                  className="flex items-center gap-2"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const ok = await update({ username: nameDraft });
                    if (ok) setEditingName(false);
                  }}
                >
                  <input
                    className="input-line !text-[24px] font-display font-semibold"
                    value={nameDraft}
                    onChange={(e) => setNameDraft(e.target.value)}
                    maxLength={40}
                    autoFocus
                  />
                  <button type="submit" className="btn-accent h-9 w-9 !p-0" aria-label="Save name">
                    <Check size={15} />
                  </button>
                </form>
              ) : (
                <button
                  onClick={() => {
                    setNameDraft(profile.username);
                    setEditingName(true);
                  }}
                  className="group flex items-center gap-2"
                  title="Click to edit your name"
                >
                  <h1 className="font-display text-[28px] leading-tight font-semibold" style={{ color: "var(--ink)" }}>
                    {profile.username}
                  </h1>
                  <Pencil size={14} className="opacity-0 transition-opacity group-hover:opacity-70" style={{ color: "var(--ink-soft)" }} />
                </button>
              )}

              <p className="mt-1 text-[13.5px]" style={{ color: "var(--ink-soft)" }}>
                {profile.pronouns && <span>{profile.pronouns} · </span>}
                {profile.email}
              </p>
              {profile.bio && (
                <p className="mt-2 max-w-md text-[13px] leading-relaxed" style={{ color: "var(--ink-faint)" }}>
                  {profile.bio}
                </p>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                <button onClick={() => setAvatarOpen(true)} className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold">
                  <Link2 size={12.5} /> Avatar via link
                </button>
                {profile.avatarUrl !== AVATAR_IMG && (
                  <button onClick={() => update({ avatarUrl: AVATAR_IMG })} className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold">
                    <RefreshCcw size={12.5} /> Reset avatar
                  </button>
                )}
              </div>
            </div>

            <div className="grid w-full grid-cols-2 gap-2.5 sm:w-auto sm:grid-cols-2">
              {statCards.map((s) => (
                <div key={s.label} className="rounded-2xl px-4 py-3 text-center" style={{ background: "var(--surface-2)" }}>
                  <s.icon size={15} className="mx-auto" style={{ color: "var(--accent)" }} />
                  <p className="font-display mt-1.5 text-[20px] leading-none font-semibold" style={{ color: "var(--ink)" }}>
                    {s.value}
                  </p>
                  <p className="mt-1 text-[10.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
                    {s.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-2">
          {/* account details */}
          <section className="card animate-fade-up p-6" style={{ animationDelay: "0.06s" }}>
            <SectionLabel>Account details</SectionLabel>
            <form
              className="mt-4 flex flex-col gap-4"
              onSubmit={async (e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                await update({
                  email: String(fd.get("email") ?? ""),
                  pronouns: String(fd.get("pronouns") ?? ""),
                  bio: String(fd.get("bio") ?? ""),
                });
              }}
            >
              <label className="block">
                <span className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                  Email
                </span>
                <input name="email" type="email" className="input-box" defaultValue={profile.email} key={profile.email} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                  Pronouns
                </span>
                <input name="pronouns" className="input-box" defaultValue={profile.pronouns} key={profile.pronouns} placeholder="she/her, they/them…" maxLength={24} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[11.5px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                  Bio — a line about you
                </span>
                <textarea name="bio" className="input-box min-h-[68px] resize-y" defaultValue={profile.bio} key={profile.bio} maxLength={200} placeholder="Chasing deadlines and daydreams." />
              </label>
              <div className="flex justify-end">
                <button type="submit" className="btn-accent px-4 py-2 text-[12.5px] font-semibold">
                  <Check size={14} /> Save details
                </button>
              </div>
            </form>

            <div className="mt-5 border-t pt-5" style={{ borderColor: "var(--line-soft)" }}>
              <Toggle checked={dark} onChange={setDark} label="Dark mode" hint="The profile page wears it well too" />
              <button onClick={openSettings} className="btn-ghost mt-2.5 w-full justify-center px-4 py-2.5 text-[12.5px] font-semibold">
                <Moon size={14} /> More appearance & layout settings
              </button>
            </div>
          </section>

          {/* google integration */}
          <section className="card animate-fade-up flex flex-col p-6" style={{ animationDelay: "0.12s" }}>
            <div className="flex items-center justify-between">
              <SectionLabel>Google integration</SectionLabel>
              {profile.googleConnected ? (
                <span className="flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-bold" style={{ background: "#35a8531a", color: "#2f9350" }}>
                  <BadgeCheck size={12} /> Connected
                </span>
              ) : (
                <span className="rounded-full px-2.5 py-1 text-[10.5px] font-bold" style={{ background: "var(--surface-3)", color: "var(--ink-faint)" }}>
                  Not connected
                </span>
              )}
            </div>

            {profile.googleConnected ? (
              <>
                <div className="mt-4 flex items-center gap-3 rounded-2xl p-4" style={{ background: "var(--surface-2)" }}>
                  <span className="flex h-10 w-10 items-center justify-center rounded-full" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
                    <GoogleLogo />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[14px] font-semibold" style={{ color: "var(--ink)" }}>
                      {profile.googleEmail}
                    </p>
                    <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                      Linked Google account
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex flex-col gap-2">
                  <Toggle
                    checked={profile.autoSync}
                    onChange={(v) => {
                      update({ autoSync: v });
                      if (v) {
                        update({ syncNow: true }, { silent: true });
                        push("success", "Auto-sync on — syncing every 15 min");
                      }
                    }}
                    label="Auto-sync"
                    hint="Notes, plan, quotes & layout re-sync every 15 minutes"
                  />
                  <div className="flex items-center gap-2.5">
                    <button onClick={syncNow} disabled={syncing} className="btn-accent flex-1 px-4 py-2.5 text-[12.5px] font-semibold disabled:opacity-60">
                      <CloudCog size={14} className={syncing ? "animate-spin" : ""} />
                      {syncing ? "Syncing…" : "Sync now"}
                    </button>
                    <button
                      onClick={() => update({ googleConnected: false, googleEmail: null, autoSync: false })}
                      className="btn-ghost px-4 py-2.5 text-[12.5px] font-semibold hover:!text-red-500"
                    >
                      <Unplug size={14} /> Disconnect
                    </button>
                  </div>
                  <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
                    {profile.lastSyncAt
                      ? `Last synced ${new Date(profile.lastSyncAt).toLocaleString()}`
                      : "Never synced yet — press Sync now."}
                  </p>
                </div>
              </>
            ) : (
              <>
                <p className="mt-4 text-[12.5px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>
                  Link your Google account to keep this workspace backed up and synced
                  between your phone and laptop.
                </p>
                <form
                  className="mt-3 flex flex-col gap-2.5"
                  onSubmit={(e) => {
                    e.preventDefault();
                    connect();
                  }}
                >
                  <input
                    type="email"
                    className="input-box"
                    placeholder="you@gmail.com"
                    value={gmailDraft}
                    onChange={(e) => setGmailDraft(e.target.value)}
                  />
                  <button type="submit" disabled={connecting || !gmailDraft.trim()} className="btn-accent px-4 py-2.5 text-[13px] font-semibold disabled:opacity-50">
                    <GoogleLogo size={15} />
                    {connecting ? "Connecting…" : "Connect account"}
                  </button>
                </form>
                <p className="mt-3 text-[11px] leading-relaxed" style={{ color: "var(--ink-faint)" }}>
                  Running this project yourself? Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET
                  env vars to upgrade this to true Google OAuth — steps live in Help → Google.
                </p>
              </>
            )}
          </section>
        </div>
      </Scaler>

      {/* hidden file input + avatar-link modal */}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          try {
            const dataUrl = await fileToDataUrl(f, 512);
            await update({ avatarUrl: dataUrl });
          } catch (err) {
            push("error", err instanceof Error ? err.message : "Couldn't read that image");
          }
        }}
      />
      <Modal open={avatarOpen} onClose={() => setAvatarOpen(false)}>
        <ModalHeader title="Avatar via link" subtitle="Paste any image URL" onClose={() => setAvatarOpen(false)} />
        <form
          className="flex items-center gap-2 px-6 py-5"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!avatarUrl.trim()) return;
            await update({ avatarUrl: avatarUrl.trim() });
            setAvatarUrl("");
            setAvatarOpen(false);
          }}
        >
          <input className="input-line flex-1" placeholder="https://…" value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} autoFocus />
          <button type="submit" className="btn-accent px-4 py-2 text-[12.5px] font-semibold" disabled={!avatarUrl.trim()}>
            <Check size={14} /> Use avatar
          </button>
        </form>
      </Modal>
    </div>
  );
}

export default function ProfileClient({ initial, stats }: { initial: Profile; stats: Stats }) {
  void initial; // the layout-level provider already holds this profile
  return <ProfileInner stats={stats} />;
}
