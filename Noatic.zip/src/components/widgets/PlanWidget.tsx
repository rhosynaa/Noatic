"use client";

import { useState, type FormEvent } from "react";
import { Check, ClipboardList, Plus, Trash2 } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import WidgetFrame from "@/components/dashboard/WidgetFrame";

export default function PlanWidget() {
  const { tasks, toggleTask, addTask, deleteTask } = useDashboard();
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("");
  const done = tasks.filter((t) => t.done).length;
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    addTask(title.trim(), time.trim());
    setTitle("");
    setTime("");
  };

  return (
    <WidgetFrame
      className="flex h-full flex-col"
      header={
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--accent)" }}>
              Today&apos;s plan
            </p>
            <h2 className="font-display mt-1 text-[21px] font-semibold" style={{ color: "var(--ink)" }}>
              {done === tasks.length && tasks.length > 0
                ? "All done — you float today"
                : `${done} of ${tasks.length} complete`}
            </h2>
          </div>
          <div
            className="relative flex h-14 w-14 items-center justify-center rounded-full"
            style={{ background: "var(--surface-2)" }}
          >
            <svg viewBox="0 0 40 40" className="h-14 w-14 -rotate-90">
              <circle cx="20" cy="20" r="16" fill="none" stroke="var(--line)" strokeWidth="4" />
              <circle
                cx="20"
                cy="20"
                r="16"
                fill="none"
                stroke="var(--accent)"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={`${(pct / 100) * 100.5} 100.5`}
                style={{ transition: "stroke-dasharray 0.6s cubic-bezier(0.22,1,0.36,1)" }}
              />
            </svg>
            <span className="absolute text-[11.5px] font-bold tabular-nums" style={{ color: "var(--ink)" }}>
              {pct}%
            </span>
          </div>
        </div>
      }
    >
      <div className="mt-4 flex-1 space-y-1 overflow-y-auto pr-1">
        {tasks.map((t, i) => (
          <div
            key={t.id}
            className={`group flex items-center gap-3 rounded-2xl px-3 py-2.5 transition-colors ${t.done ? "checked" : ""}`}
            style={{ background: t.done ? "var(--surface-2)" : "transparent" }}
          >
            <button
              role="checkbox"
              aria-checked={t.done}
              aria-label={`${t.done ? "Uncheck" : "Check"} ${t.title}`}
              onClick={() => toggleTask(t.id)}
              className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg transition-transform hover:scale-110 active:scale-95"
              style={{
                border: `1.5px solid ${t.done ? "var(--accent)" : "var(--line)"}`,
                background: t.done ? "var(--accent)" : "transparent",
                transition: "border-color 0.25s ease, background 0.25s ease, transform 0.2s cubic-bezier(0.34,1.56,0.64,1)",
              }}
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="var(--accent-ink)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <path className="check-path" d="M5 12.5l4.5 4.5L19 7.5" />
              </svg>
            </button>
            {t.time && (
              <span className="w-11 shrink-0 text-[11px] font-semibold tabular-nums" style={{ color: "var(--ink-faint)" }}>
                {t.time}
              </span>
            )}
            <span
              className="strike-line flex-1 text-[14px] leading-snug"
              style={{
                color: t.done ? "var(--ink-faint)" : "var(--ink)",
                transitionDelay: `${i * 20}ms`,
              }}
            >
              {t.title}
            </span>
            <button
              onClick={() => deleteTask(t.id)}
              aria-label={`Delete ${t.title}`}
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
              style={{ color: "var(--ink-faint)" }}
            >
              <Trash2 size={13} />
            </button>
          </div>
        ))}
        {tasks.length === 0 && (
          <div className="flex flex-col items-center gap-2 py-10 text-center" style={{ color: "var(--ink-faint)" }}>
            <ClipboardList size={22} />
            <p className="text-[13px]">A blank page. Add the first small win below.</p>
          </div>
        )}
      </div>

      <form onSubmit={submit} className="mt-3 flex items-center gap-2 border-t pt-3" style={{ borderColor: "var(--line-soft)" }}>
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
          <Plus size={15} />
        </div>
        <input
          className="input-line flex-1"
          placeholder="Add a task — press enter to plant it"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          className="input-box !w-[86px] !px-2.5 !py-1.5 text-center text-[12px]"
          placeholder="--:--"
          type="time"
          value={time}
          onChange={(e) => setTime(e.target.value)}
          aria-label="Time (optional)"
        />
        <button type="submit" disabled={!title.trim()} className="btn-accent px-3.5 py-1.5 text-[12px] font-semibold disabled:opacity-40">
          <Check size={14} />
        </button>
      </form>
    </WidgetFrame>
  );
}
