"use client";

import { Quote as QuoteIcon, Sparkles } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import { pickOfDay } from "@/lib/pick";
import WidgetFrame from "@/components/dashboard/WidgetFrame";

export default function QuoteWidget() {
  const { quotes } = useDashboard();
  const quote = pickOfDay(quotes.filter((q) => q.kind === "quote"));
  const motivation = pickOfDay(quotes.filter((q) => q.kind === "motivation"));

  return (
    <WidgetFrame
      className="relative flex h-full flex-col overflow-hidden"
      header={
        <div className="flex items-center justify-between">
          <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
            Quote of the day &amp; motivation · change daily
          </p>
          <QuoteIcon size={15} style={{ color: "var(--accent)" }} />
        </div>
      }
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -top-8 -right-8 h-36 w-36 rounded-full opacity-60"
        style={{ background: "radial-gradient(circle, var(--accent-soft), transparent 70%)" }}
      />

      {/* quote & motivation sit side-by-side so neither wastes a full row */}
      <div className="mt-3 grid flex-1 grid-cols-1 items-stretch gap-4 @md:grid-cols-2 @md:gap-5">
        <figure className="flex flex-col">
          <span
            className="mb-2 flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
          >
            <QuoteIcon size={13} />
          </span>
          {quote ? (
            <>
              <blockquote
                className="font-display text-[clamp(1.02rem,1.7vw,1.22rem)] leading-[1.42] font-medium italic"
                style={{ color: "var(--ink)" }}
              >
                “{quote.text}”
              </blockquote>
              {quote.author && (
                <figcaption className="mt-auto pt-2 text-[12px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                  — {quote.author}
                </figcaption>
              )}
            </>
          ) : (
            <p className="text-[12.5px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>
              Your sidebar collection is empty — add a quote there and tomorrow it might
              greet you here.
            </p>
          )}
        </figure>

        <div
          className="flex flex-col rounded-2xl px-4 py-3.5"
          style={{ background: "var(--accent-soft)" }}
        >
          <span className="mb-2 flex items-center gap-1.5 text-[10px] font-bold tracking-[0.12em] uppercase" style={{ color: "var(--accent)" }}>
            <Sparkles size={12.5} className="animate-floaty" />
            Motivation
          </span>
          <p className="text-[12.5px] leading-relaxed font-medium" style={{ color: "var(--ink)" }}>
            {motivation
              ? motivation.text
              : "Add a daily motivation in the sidebar and it will shimmer here."}
          </p>
        </div>
      </div>
    </WidgetFrame>
  );
}
