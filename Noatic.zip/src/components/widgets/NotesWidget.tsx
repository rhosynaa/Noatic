"use client";

import { useCallback, useMemo, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  Hash,
  ImagePlus,
  ImageOff,
  LayoutTemplate,
  Link2,
  MessageSquareQuote,
  Network,
  NotebookPen,
  Pin,
  PinOff,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import { useSections } from "@/lib/sections-context";
import { findLinkedMap, useMindmapsList } from "@/lib/mindmap-nav";
import { api, fileToDataUrl } from "@/lib/api";
import LibraryPickButton from "@/components/media/LibraryPickButton";
import CoverShuffleButton from "@/components/media/CoverShuffleButton";
import { useToast } from "@/lib/toast";
import { Modal, ModalHeader } from "@/components/ui";
import WidgetFrame from "@/components/dashboard/WidgetFrame";
import NoteFocusWidget from "@/components/focus/NoteFocusWidget";
import TagFilterRow from "@/components/notes/TagFilterRow";
import { NOTE_COLORS, normalizeTag, type Note } from "@/lib/types";

export function NoteEditor({ note, onClose }: { note: Note; onClose: () => void }) {
  const { updateNote, deleteNote, subjects, notes: allNotes } = useDashboard();
  const { openMindmap } = useSections();
  const { maps: mindmaps } = useMindmapsList();
  const { push } = useToast();
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [color, setColor] = useState(note.color);
  const [subject, setSubject] = useState(note.subject ?? "");
  const [tags, setTags] = useState<string[]>(note.tags ?? []);
  const [tagDraft, setTagDraft] = useState("");
  const [imageUrl, setImageUrl] = useState(note.imageUrl);
  const [pinned, setPinned] = useState(note.pinned);
  const [urlDraft, setUrlDraft] = useState("");
  const [showUrl, setShowUrl] = useState(false);
  /* collapsible tool panel — fold it away for a distraction-free writing canvas */
  const [toolsOpen, setToolsOpen] = useState(true);
  const [showAssess, setShowAssess] = useState(false);
  const [aScore, setAScore] = useState("");
  const [aMax, setAMax] = useState("100");
  const [aComment, setAComment] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const dirty =
    title !== note.title ||
    content !== note.content ||
    color !== note.color ||
    subject !== (note.subject ?? "") ||
    JSON.stringify(tags) !== JSON.stringify(note.tags ?? []) ||
    imageUrl !== note.imageUrl ||
    pinned !== note.pinned;

  const save = async () => {
    await updateNote(note.id, { title, content, color, subject, tags, imageUrl, pinned });
    push("success", "Note saved");
    onClose();
  };

  /* the mind map that links back to this note, if any */
  const linkedMap = findLinkedMap(mindmaps, "note", note.id);
  const openLinkedMap = async () => {
    if (!linkedMap) return;
    await save(); // never lose edits on the way out
    openMindmap({ id: linkedMap.id, name: linkedMap.name });
  };

  /* grade this note — creates a new entry in the Self-Assessment section */
  const saveAssessment = async () => {
    if (aScore === "") return;
    try {
      await api("/api/self-assessments", {
        method: "POST",
        body: {
          title: title.trim() || "Untitled note",
          subject: subject.trim(),
          score: Number(aScore),
          maxScore: aMax === "" ? 100 : Number(aMax),
          comment: aComment.trim(),
        },
      });
      push("success", "Self-assessment added — see it in the Self-assessment page");
      setShowAssess(false);
      setAScore("");
      setAMax("100");
      setAComment("");
    } catch {
      push("error", "Couldn't add that self-assessment");
    }
  };

  /** every tag already used anywhere, keyed by lowercase → canonical spelling */
  const knownTags = useMemo(() => {
    const m = new Map<string, string>();
    for (const n of allNotes)
      for (const t of n.tags ?? []) if (!m.has(t.toLowerCase())) m.set(t.toLowerCase(), t);
    return m;
  }, [allNotes]);

  /** adds the drafted tag, snapping to an existing tag's spelling when one matches */
  const commitTag = useCallback(() => {
    const raw = normalizeTag(tagDraft);
    if (!raw) {
      setTagDraft("");
      return;
    }
    const canonical = knownTags.get(raw.toLowerCase()) ?? raw;
    setTags((prev) =>
      prev.some((x) => x.toLowerCase() === canonical.toLowerCase())
        ? prev
        : [...prev, canonical].slice(0, 12)
    );
    setTagDraft("");
  }, [tagDraft, knownTags]);

  return (
    <Modal open onClose={save} full>
      <ModalHeader title="Edit note" onClose={save} />
      <div className="relative flex flex-1 flex-col overflow-y-auto px-6 py-5" style={{ background: "var(--surface)" }}>
        <div className="flex items-start gap-3">
          <input
            className="font-display min-w-0 flex-1 bg-transparent text-[26px] leading-tight font-semibold outline-none placeholder:opacity-50"
            style={{ color: "var(--ink)" }}
            placeholder="Give it a title…"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          {/* mini focus timer lives in the top-right of the note view */}
          <NoteFocusWidget note={{ ...note, subject }} />
        </div>
        <textarea
          className="mt-3 min-h-[220px] w-full flex-1 resize-y bg-transparent text-[14.5px] leading-relaxed outline-none placeholder:opacity-50"
          style={{ color: "var(--ink-soft)" }}
          placeholder="Start writing…"
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
      </div>

      <div className="border-t" style={{ borderColor: "var(--line)", background: "var(--surface)" }}>
        {/* collapse toggle — folds the whole tool panel downwards so the writing canvas gets maximum height */}
        <button
          type="button"
          onClick={() => setToolsOpen((v) => !v)}
          aria-expanded={toolsOpen}
          aria-label={toolsOpen ? "Hide note tools" : "Show note tools"}
          title={toolsOpen ? "Hide note tools" : "Show note tools"}
          className="flex w-full items-center justify-center gap-1.5 py-1.5 transition-colors hover:bg-black/[0.04]"
          style={{ color: "var(--ink-faint)" }}
        >
          <ChevronDown
            size={15}
            className={`transition-transform duration-300 ${toolsOpen ? "" : "-rotate-180"}`}
          />
        </button>
        <div
          className="grid transition-[grid-template-rows] duration-300 ease-out"
          style={{ gridTemplateRows: toolsOpen ? "1fr" : "0fr" }}
        >
          <div className="min-h-0 overflow-hidden">
            <div className="px-6 pt-1 pb-4">
        {/* tags */}
        <div className="mb-3 flex flex-wrap items-center gap-1.5">
          <Hash size={12.5} style={{ color: "var(--accent)" }} />
          {tags.map((t) => (
            <span
              key={t}
              className="group inline-flex items-center gap-1 rounded-full py-1 pr-1 pl-2.5 text-[11px] font-bold"
              style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
            >
              #{t}
              <button
                onClick={() => setTags((prev) => prev.filter((x) => x !== t))}
                aria-label={`Remove tag ${t}`}
                className="flex h-4 w-4 items-center justify-center rounded-full transition-colors hover:bg-black/10"
              >
                <X size={9} />
              </button>
            </span>
          ))}
          <input
            className="min-w-[124px] flex-1 bg-transparent text-[11.5px] outline-none placeholder:opacity-60"
            style={{ color: "var(--ink)" }}
            placeholder={tags.length ? "Add tag…" : "Add tags — e.g. ExamPrep, Important"}
            value={tagDraft}
            maxLength={24}
            onChange={(e) => setTagDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === ",") {
                e.preventDefault();
                commitTag();
              } else if (e.key === "Backspace" && !tagDraft && tags.length) {
                setTags((prev) => prev.slice(0, -1));
              }
            }}
            onBlur={commitTag}
            list="dreamy-known-tags"
            aria-label="Add a tag"
          />
          {/* reuse existing tags instead of spawning near-duplicates */}
          <datalist id="dreamy-known-tags">
            {[...knownTags.values()]
              .filter((t) => !tags.some((x) => x.toLowerCase() === t.toLowerCase()))
              .map((t) => (
                <option key={t} value={t} />
              ))}
          </datalist>
        </div>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
          <div className="flex items-center gap-1.5">
            {Object.entries(NOTE_COLORS).map(([key, c]) => (
              <button
                key={key}
                aria-label={c.label}
                title={c.label}
                onClick={() => setColor(key)}
                className="h-6 w-6 rounded-full transition-transform hover:scale-110"
                style={{
                  background: c.bg,
                  border: "1px solid var(--line)",
                  boxShadow: color === key ? "0 0 0 2px var(--surface), 0 0 0 4px var(--accent)" : "none",
                }}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            {imageUrl ? (
              <>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={imageUrl} alt="" className="h-8 w-8 rounded-lg object-cover" style={{ border: "1px solid var(--line)" }} />
                <button onClick={() => fileRef.current?.click()} className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold">
                  <ImagePlus size={12.5} /> Change
                </button>
                <LibraryPickButton onPick={(u) => setImageUrl(u)} iconSize={12.5} />
                <CoverShuffleButton target="note" refId={note.id} iconSize={12.5} />
                <button onClick={() => setImageUrl("")} className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold">
                  <ImageOff size={12.5} /> Remove
                </button>
              </>
            ) : (
              <>
                <button onClick={() => fileRef.current?.click()} className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold">
                  <ImagePlus size={12.5} /> Upload image
                </button>
                <button onClick={() => setShowUrl((v) => !v)} className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold">
                  <Link2 size={12.5} /> Paste link
                </button>
                <LibraryPickButton onPick={(u) => setImageUrl(u)} iconSize={12.5} />
              </>
            )}
          </div>

          <select
            className="input-box !w-auto !px-2.5 !py-1.5 !text-[11.5px] !font-semibold"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            aria-label="Note subject"
            title="Which subject this note belongs to"
          >
            <option value="">No subject</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.name}>
                {s.name}
              </option>
            ))}
          </select>

          <button
            onClick={() => setPinned((p) => !p)}
            className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
            style={pinned ? { color: "var(--accent)", borderColor: "var(--accent)" } : undefined}
          >
            {pinned ? <PinOff size={12.5} /> : <Pin size={12.5} />}
            {pinned ? "Unpin" : "Pin"}
          </button>

          <button
            onClick={() => setShowAssess((v) => !v)}
            aria-expanded={showAssess}
            className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
            style={showAssess ? { color: "var(--accent)", borderColor: "var(--accent)" } : undefined}
          >
            <MessageSquareQuote size={12.5} /> Self-assessment
          </button>

          {linkedMap && (
            <button
              onClick={() => void openLinkedMap()}
              title={`Jump to the mind map linked to this note: ${linkedMap.name}`}
              className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold"
              style={{ color: "var(--accent)", borderColor: "var(--accent)" }}
            >
              <Network size={12.5} /> Mind map: {linkedMap.name}
            </button>
          )}

          <span className="flex-1" />

          <button
            onClick={() => {
              deleteNote(note.id);
              onClose();
            }}
            className="btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold hover:!text-red-500"
          >
            <Trash2 size={12.5} /> Delete
          </button>
          <button onClick={save} className="btn-accent px-4 py-2 text-[12.5px] font-semibold" disabled={!dirty && false}>
            <Check size={14} /> {dirty ? "Save & close" : "Close"}
          </button>
        </div>

        {showAssess && (
          <div
            className="animate-pop mt-3 flex flex-col gap-2 rounded-2xl p-3"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
          >
            <div className="flex items-center gap-2">
              <MessageSquareQuote size={13} style={{ color: "var(--accent)" }} />
              <span className="flex-1 text-[11.5px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                Grade this note — it lands in Self-assessment
              </span>
              <input
                type="number"
                min={0}
                max={1000}
                placeholder="Score"
                value={aScore}
                onChange={(e) => setAScore(e.target.value)}
                aria-label="Your grade for this note"
                className="input-box w-16 !px-2 !py-1 text-center text-[11.5px]"
              />
              <span className="text-[11px] font-bold" style={{ color: "var(--ink-faint)" }}>/</span>
              <input
                type="number"
                min={1}
                max={1000}
                value={aMax}
                onChange={(e) => setAMax(e.target.value)}
                aria-label="Maximum grade"
                className="input-box w-16 !px-2 !py-1 text-center text-[11.5px]"
              />
            </div>
            <textarea
              rows={2}
              value={aComment}
              onChange={(e) => setAComment(e.target.value)}
              maxLength={280}
              placeholder="Commentary — how did this note turn out?"
              aria-label="Commentary for this note"
              className="input-box resize-none !py-1.5 text-[12px]"
            />
            <div className="flex items-center justify-end gap-1.5">
              <button
                onClick={() => setShowAssess(false)}
                className="btn-ghost h-7 px-2.5 text-[11px] font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={() => void saveAssessment()}
                disabled={aScore === ""}
                className="btn-accent h-7 px-2.5 text-[11px] font-semibold disabled:opacity-40"
              >
                <Check size={12} /> Add assessment
              </button>
            </div>
          </div>
        )}

        {showUrl && !imageUrl && (
          <div className="mt-3 flex items-center gap-2">
            <Link2 size={13} style={{ color: "var(--ink-faint)" }} />
            <input
              className="input-line flex-1"
              placeholder="https://… image link"
              value={urlDraft}
              onChange={(e) => setUrlDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && urlDraft.trim()) {
                  setImageUrl(urlDraft.trim());
                  setShowUrl(false);
                }
              }}
            />
            <button
              onClick={() => {
                if (urlDraft.trim()) {
                  setImageUrl(urlDraft.trim());
                  setShowUrl(false);
                }
              }}
              className="btn-accent px-3 py-1.5 text-[11.5px] font-semibold"
              disabled={!urlDraft.trim()}
            >
              Use
            </button>
          </div>
        )}
            </div>
          </div>
        </div>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          try {
            setImageUrl(await fileToDataUrl(f, 1024));
          } catch (err) {
            push("error", err instanceof Error ? err.message : "Couldn't read that image");
          }
        }}
      />
    </Modal>
  );
}

export default function NotesWidget({ onOpenTemplates }: { onOpenTemplates: () => void }) {
  const { notes, templates, addNote, updateNote, deleteNote, editingNoteId, setEditingNote } = useDashboard();
  const [pickerOpen, setPickerOpen] = useState(false);
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const editor = notes.find((n) => n.id === editingNoteId) ?? null;

  /**
   * Every tag in use, most-used first. Case variants of the same tag
   * ("Biology" / "biology") are merged into one chip and displayed using the
   * spelling that appears most often, so the filter row never shows duplicates.
   */
  const allTags = useMemo(() => {
    const groups = new Map<string, { total: number; variants: Map<string, number> }>();
    for (const n of notes) {
      for (const t of n.tags ?? []) {
        const key = t.toLowerCase();
        const g = groups.get(key) ?? { total: 0, variants: new Map<string, number>() };
        g.total += 1;
        g.variants.set(t, (g.variants.get(t) ?? 0) + 1);
        groups.set(key, g);
      }
    }
    return [...groups.values()]
      .map((g) => ({
        display: [...g.variants.entries()].sort(
          (a, b) => b[1] - a[1] || a[0].localeCompare(b[0])
        )[0][0],
        total: g.total,
      }))
      .sort((a, b) => b.total - a.total || a.display.localeCompare(b.display))
      .map((g) => g.display);
  }, [notes]);

  const visible = useMemo(
    () =>
      tagFilter
        ? notes.filter((n) => (n.tags ?? []).some((t) => t.toLowerCase() === tagFilter.toLowerCase()))
        : notes,
    [notes, tagFilter]
  );

  const newFromTemplate = async (templateId: string) => {
    const t = templates.find((x) => x.id === templateId);
    const note = await (t
      ? addNote({ title: t.title, content: t.content, color: "cream" })
      : addNote({}));
    setPickerOpen(false);
    if (note) setEditingNote(note.id);
  };

  return (
    <WidgetFrame
      className="flex h-full flex-col"
      header={
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--accent)" }}>
              Recent notes
            </p>
            <h2 className="font-display mt-1 text-[21px] font-semibold" style={{ color: "var(--ink)" }}>
              {notes.length ? `${notes.length} little worlds` : "Nothing written yet"}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <button onClick={() => setPickerOpen((v) => !v)} className="btn-ghost px-3 py-1.5 text-[12px] font-semibold" aria-expanded={pickerOpen}>
                <LayoutTemplate size={13.5} /> Template
              </button>
              {pickerOpen && (
                <>
                  <div className="fixed inset-0 z-[60]" onClick={() => setPickerOpen(false)} />
                  <div className="animate-pop absolute right-0 z-[61] mt-2 w-52 overflow-hidden rounded-2xl p-1.5" style={{ background: "var(--surface)", border: "1px solid var(--line)", boxShadow: "var(--card-shadow-hover)" }}>
                    {templates.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => newFromTemplate(t.id)}
                        className="w-full rounded-xl px-3 py-2 text-left text-[12.5px] font-medium transition-colors hover:bg-[var(--surface-2)]"
                        style={{ color: "var(--ink)" }}
                      >
                        {t.title}
                      </button>
                    ))}
                    {templates.length === 0 && (
                      <p className="px-3 py-2 text-[12px]" style={{ color: "var(--ink-faint)" }}>
                        No templates yet — create one from the sidebar.
                      </p>
                    )}
                  </div>
                </>
              )}
            </div>
            <button onClick={async () => { const n = await addNote({}); if (n) setEditingNote(n.id); }} className="btn-accent px-3 py-1.5 text-[12px] font-semibold">
              <Plus size={13.5} /> New note
            </button>
          </div>
        </div>
      }
    >
      {allTags.length > 0 && (
        <TagFilterRow tags={allTags} active={tagFilter} onSelect={setTagFilter} />
      )}

      <div className="mt-4 grid flex-1 grid-cols-1 gap-3 sm:grid-cols-2">
        {visible.slice(0, 4).map((n) => (
          <article
            key={n.id}
            onClick={() => setEditingNote(n.id)}
            className="group relative cursor-pointer overflow-hidden rounded-2xl p-4 transition-transform duration-300 hover:-translate-y-1"
            style={{
              background: NOTE_COLORS[n.color]?.bg ?? NOTE_COLORS.cream.bg,
              border: "1px solid rgba(80,60,30,0.10)",
              minHeight: 128,
            }}
          >
            {n.imageUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={n.imageUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-90" />
            )}
            <div
              className="relative flex h-full flex-col"
              style={n.imageUrl ? { textShadow: "0 1px 8px rgba(255,255,255,0.8)" } : undefined}
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-display line-clamp-2 text-[16px] leading-snug font-semibold text-[#3a2c1d]">
                  {n.title || "Untitled note"}
                </h3>
                <div className="flex shrink-0 items-center gap-0.5">
                  <button
                    aria-label={n.pinned ? "Unpin note" : "Pin note"}
                    onClick={(e) => {
                      e.stopPropagation();
                      updateNote(n.id, { pinned: !n.pinned });
                    }}
                    className="flex h-7 w-7 items-center justify-center rounded-full transition-all hover:bg-black/5"
                    style={{ color: n.pinned ? "#b05c4a" : "rgba(58,44,29,0.35)" }}
                  >
                    <Pin size={13} style={n.pinned ? { fill: "#b05c4a" } : undefined} />
                  </button>
                  <button
                    aria-label="Delete note"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteNote(n.id);
                    }}
                    className="flex h-7 w-7 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-black/5"
                    style={{ color: "rgba(58,44,29,0.45)" }}
                  >
                    <Trash2 size={12.5} />
                  </button>
                </div>
              </div>
              <p className="mt-1.5 line-clamp-2 flex-1 text-[12.5px] leading-relaxed whitespace-pre-line" style={{ color: "rgba(58,44,29,0.72)" }}>
                {n.content || "An empty thought, waiting…"}
              </p>
              {(n.tags ?? []).length > 0 && (
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {(n.tags ?? []).slice(0, 3).map((t) => (
                    <button
                      key={t}
                      onClick={(e) => {
                        e.stopPropagation();
                        setTagFilter((cur) => (cur === t ? null : t));
                      }}
                      className="rounded-full px-1.5 py-0.5 text-[9.5px] font-bold transition-transform hover:scale-105"
                      style={{ background: "rgba(58,44,29,0.09)", color: "rgba(58,44,29,0.68)" }}
                    >
                      #{t}
                    </button>
                  ))}
                </div>
              )}
              <p className="mt-2 text-[10.5px] font-semibold" style={{ color: "rgba(58,44,29,0.45)" }}>
                {new Date(n.updatedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
              </p>
            </div>
          </article>
        ))}
        {visible.length === 0 && (
          <div className="col-span-2 flex flex-col items-center gap-2 py-10 text-center" style={{ color: "var(--ink-faint)" }}>
            <NotebookPen size={22} />
            <p className="text-[13px]">
              {tagFilter
                ? `No notes tagged #${tagFilter}.`
                : "Your notebook is empty. Plant the first thought."}
            </p>
          </div>
        )}
      </div>

      {visible.length > 4 && (
        <p className="mt-3 text-center text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
          + {visible.length - 4} more — the newest and pinned stay on top
        </p>
      )}

      {editor && <NoteEditor note={editor} onClose={() => setEditingNote(null)} />}
    </WidgetFrame>
  );
}
