"use client";

import { useState, type FormEvent } from "react";
import { AlarmClockCheck, CalendarPlus, Check, Trash2 } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import { DEADLINE_COLORS } from "@/lib/types";
import WidgetFrame from "@/components/dashboard/WidgetFrame";

export function dueLabel(dueDate: string): { text: string; tone: "over" | "soon" | "later" } {
  const now = new Date();
  const due = new Date(dueDate);
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startDue = new Date(due.getFullYear(), due.getMonth(), due.getDate());
  const days = Math.round((startDue.getTime() - startToday.getTime()) / 86400000);
  if (days < 0) return { text: `${-days}d overdue`, tone: "over" };
  if (days === 0) return { text: "Due today", tone: "over" };
  if (days === 1) return { text: "Tomorrow", tone: "soon" };
  if (days <= 7) return { text: `In ${days} days`, tone: "soon" };
  return { text: due.toLocaleDateString(undefined, { month: "short", day: "numeric" }), tone: "later" };
}

export default function DeadlinesWidget() {
  const { deadlines, addDeadline, toggleDeadline, deleteDeadline, subjects } = useDashboard();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [date, setDate] = useState("");
  const [color, setColor] = useState("rose");

  const active = deadlines.filter((d) => !d.done);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date) return;
    await addDeadline({ title: title.trim(), subject: subject.trim(), color, dueDate: date });
    setTitle("");
    setSubject("");
    setDate("");
    setOpen(false);
  };

  return (
    <WidgetFrame
      className="flex h-full flex-col"
      header={
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--accent)" }}>
              Deadlines
            </p>
            <h2 className="font-display mt-1 text-[21px] font-semibold" style={{ color: "var(--ink)" }}>
              {active.length ? `${active.length} on the horizon` : "Nothing looming"}
            </h2>
          </div>
          <button
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            className="btn-ghost px-3 py-1.5 text-[12px] font-semibold"
          >
            <CalendarPlus size={14} />
            Add
          </button>
        </div>
      }
    >
      {open && (
        <form
          onSubmit={submit}
          className="animate-pop mt-3 flex flex-col gap-2.5 rounded-2xl p-4"
          style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
        >
          <input className="input-line" placeholder="What's due? *" value={title} onChange={(e) => setTitle(e.target.value)} required />
          <div className="flex gap-2.5">
            <input
              className="input-line flex-1"
              placeholder="Subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              list="subject-options"
            />
            <datalist id="subject-options">
              {subjects.map((s) => (
                <option key={s.id} value={s.name} />
              ))}
            </datalist>
            <input className="input-box !w-[150px]" type="date" value={date} onChange={(e) => setDate(e.target.value)} required aria-label="Due date" />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex gap-1.5">
              {Object.entries(DEADLINE_COLORS).map(([key, c]) => (
                <button
                  key={key}
                  type="button"
                  aria-label={key}
                  onClick={() => setColor(key)}
                  className="h-5 w-5 rounded-full transition-transform hover:scale-110"
                  style={{
                    background: c,
                    boxShadow: color === key ? `0 0 0 2px var(--surface), 0 0 0 3.5px ${c}` : "none",
                  }}
                />
              ))}
            </div>
            <button type="submit" className="btn-accent px-3.5 py-1.5 text-[12px] font-semibold" disabled={!title.trim() || !date}>
              <Check size={13} /> Save
            </button>
          </div>
        </form>
      )}

      {/* five rows visible — anything beyond scrolls inside the widget */}
      <div className="mt-3 max-h-[296px] flex-1 space-y-1 overflow-y-auto pr-1">
        {deadlines.map((d) => {
          const chip = dueLabel(d.dueDate);
          return (
            <div key={d.id} className="group flex items-center gap-3 rounded-2xl px-3 py-2.5 transition-colors hover:bg-[var(--surface-2)]">
              <button
                role="checkbox"
                aria-checked={d.done}
                aria-label={`Mark ${d.title} ${d.done ? "not done" : "done"}`}
                onClick={() => toggleDeadline(d.id)}
                className="flex h-5.5 w-5.5 shrink-0 items-center justify-center rounded-md transition-all hover:scale-110"
                style={{
                  width: 22,
                  height: 22,
                  border: `1.5px solid ${d.done ? DEADLINE_COLORS[d.color] ?? "var(--accent)" : "var(--line)"}`,
                  background: d.done ? DEADLINE_COLORS[d.color] ?? "var(--accent)" : "transparent",
                }}
              >
                {d.done && <Check size={13} color="#fff" strokeWidth={3} />}
              </button>
              <div className="min-w-0 flex-1">
                <p
                  className="truncate text-[13.5px] leading-snug font-medium"
                  style={{ color: d.done ? "var(--ink-faint)" : "var(--ink)", textDecoration: d.done ? "line-through" : "none" }}
                >
                  {d.title}
                </p>
                {d.subject && (
                  <p className="mt-0.5 text-[11px]" style={{ color: "var(--ink-faint)" }}>
                    {d.subject}
                  </p>
                )}
              </div>
              {!d.done && (
                <span
                  className="shrink-0 rounded-full px-2 py-1 text-[10.5px] font-bold"
                  style={{
                    background: chip.tone === "over" ? "#d060541e" : chip.tone === "soon" ? "var(--accent-soft)" : "var(--surface-3)",
                    color: chip.tone === "over" ? "#c5503f" : chip.tone === "soon" ? "var(--accent)" : "var(--ink-soft)",
                  }}
                >
                  {chip.text}
                </span>
              )}
              <button
                onClick={() => deleteDeadline(d.id)}
                aria-label={`Delete ${d.title}`}
                className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                style={{ color: "var(--ink-faint)" }}
              >
                <Trash2 size={12.5} />
              </button>
            </div>
          );
        })}
        {deadlines.length === 0 && (
          <div className="flex flex-col items-center gap-2 py-10 text-center" style={{ color: "var(--ink-faint)" }}>
            <AlarmClockCheck size={22} />
            <p className="text-[13px]">No deadlines tracked. Blissfully dangerous.</p>
          </div>
        )}
      </div>
    </WidgetFrame>
  );
}
