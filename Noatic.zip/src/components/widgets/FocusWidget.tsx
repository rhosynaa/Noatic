"use client";

import { Expand, Pause, Play, RotateCcw, Timer, TrendingUp, X } from "lucide-react";
import WidgetFrame from "@/components/dashboard/WidgetFrame";
import { useFocus } from "@/lib/focus-context";
import { useSections } from "@/lib/sections-context";
import { DEFAULT_PRESETS, TIMER_KIND_META, type TimerKind } from "@/lib/types";

export default function FocusWidget() {
  const focus = useFocus();
  const { openSection } = useSections();

  const mode: "focus" | "short" | "long" =
    focus.kind === "short" ? "short" : focus.kind === "long" ? "long" : "focus";
  const total = focus.totalSec;
  const pct = total ? focus.leftSec / total : 0;
  const mm = Math.floor(focus.leftSec / 60);
  const ss = (focus.leftSec % 60).toString().padStart(2, "0");

  return (
    <WidgetFrame
      className="flex h-full flex-col"
      header={
        <div className="flex items-center justify-between">
          <p className="text-[10.5px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
            Focus timer
          </p>
          <button
            onClick={() => openSection("timer")}
            aria-label="Open full timer"
            className="flex items-center gap-1 transition-colors hover:text-[var(--accent)]"
            style={{ color: "var(--ink-faint)" }}
          >
            <Timer size={15} style={{ color: "var(--accent)" }} />
            <Expand size={12.5} />
          </button>
        </div>
      }
    >
      <div className="mt-2 flex flex-1 items-center justify-center gap-6">
        <div className="relative flex h-[7.5rem] w-[7.5rem] items-center justify-center">
          <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full -rotate-90">
            <circle cx="60" cy="60" r="52" fill="none" stroke="var(--line)" strokeWidth="7" />
            <circle
              cx="60"
              cy="60"
              r="52"
              fill="none"
              stroke="var(--accent)"
              strokeWidth="7"
              strokeLinecap="round"
              strokeDasharray={`${pct * 327} 327`}
              style={{ transition: "stroke-dasharray 0.9s linear" }}
            />
          </svg>
          <div className="text-center">
            <p className="font-display text-[26px] leading-none font-semibold tabular-nums" style={{ color: "var(--ink)" }}>
              {mm}:{ss}
            </p>
            <p className="mt-1 text-[10px] font-semibold tracking-[0.12em] uppercase" style={{ color: focus.running ? "var(--accent)" : "var(--ink-faint)" }}>
              {focus.running ? TIMER_KIND_META[focus.kind as TimerKind]?.label ?? "focusing" : "paused"}
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-2.5">
          <div className="flex gap-1.5">
            {DEFAULT_PRESETS[mode].slice(0, 3).map((p) => (
              <button
                key={p}
                onClick={() => focus.setDraft({ kind: mode, minutes: p })}
                className="rounded-full px-2.5 py-1 text-[11.5px] font-bold transition-all"
                style={{
                  background: focus.minutes === p ? "var(--accent)" : "var(--surface-2)",
                  color: focus.minutes === p ? "var(--accent-ink)" : "var(--ink-soft)",
                  border: "1px solid var(--line)",
                }}
              >
                {p}m
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={focus.toggle} className="btn-accent h-10 w-10 !rounded-full !p-0" aria-label={focus.running ? "Pause" : "Start"}>
              {focus.running ? <Pause size={15} /> : <Play size={15} className="ml-0.5" />}
            </button>
            <button onClick={focus.resetClock} className="btn-ghost h-9 w-9 !p-0" aria-label="Reset time">
              <RotateCcw size={14} />
            </button>
            {focus.sessionActive && (
              <button onClick={focus.cancelSession} className="btn-ghost h-9 w-9 !p-0 hover:!text-red-500" aria-label="Cancel session">
                <X size={14} />
              </button>
            )}
          </div>
          {focus.subject && (
            <span className="max-w-[120px] truncate rounded-full px-2.5 py-1 text-center text-[10.5px] font-bold" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
              {focus.subject}
            </span>
          )}
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between rounded-2xl px-3.5 py-2" style={{ background: "var(--surface-2)" }}>
        <span className="flex items-center gap-1.5 text-[11px] font-semibold" style={{ color: "var(--ink-soft)" }}>
          <TrendingUp size={12.5} style={{ color: "var(--accent)" }} />
          Study progress today
        </span>
        <span className="text-[11.5px] font-bold tabular-nums" style={{ color: "var(--accent)" }}>
          {focus.todayStudyMinutes} min
        </span>
      </div>
    </WidgetFrame>
  );
}
