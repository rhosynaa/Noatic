"use client";

import { useRef } from "react";
import { GALLERY_IMG } from "@/lib/assets";
import { CloudSun, ImagePlus } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import { fileToDataUrl } from "@/lib/api";
import LibraryPickButton from "@/components/media/LibraryPickButton";
import { useToast } from "@/lib/toast";

export default function GalleryWidget() {
  const { images, setImage } = useDashboard();
  const { push } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const url = images.find((i) => i.key === "gallery")?.url ?? GALLERY_IMG;

  return (
    <section className="card group relative h-full min-h-[220px] overflow-hidden">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={url}
        alt="A dreamy view to pause on"
        className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.04]"
        onError={(e) => {
          (e.target as HTMLImageElement).src = GALLERY_IMG;
        }}
      />
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(to top, rgba(24,16,8,0.62), rgba(24,16,8,0.05) 55%)" }}
      />
      <div className="absolute right-0 bottom-0 left-0 flex items-end justify-between gap-4 p-6">
        <div>
          <p className="flex items-center gap-1.5 text-[10.5px] font-bold tracking-[0.16em] uppercase" style={{ color: "rgba(255,246,235,0.75)" }}>
            <CloudSun size={13} />
            Daydream corner
          </p>
          <p className="font-display mt-1.5 max-w-md text-[17px] leading-snug font-medium text-[#fff6eb]">
            Between tasks, look at faraway things. Your eyes will thank you.
          </p>
        </div>
        <button
          onClick={() => fileRef.current?.click()}
          className="flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[11.5px] font-semibold backdrop-blur-md transition-all hover:scale-[1.03]"
          style={{ background: "rgba(255,246,235,0.18)", color: "#fff6eb", border: "1px solid rgba(255,246,235,0.35)" }}
        >
          <ImagePlus size={13} />
          Change image
        </button>
        <LibraryPickButton
          label=""
          iconSize={13}
          className="flex shrink-0 items-center gap-1.5 rounded-full px-3 py-2 text-[11.5px] font-semibold backdrop-blur-md transition-all hover:scale-[1.03]"
          onPick={(u) => void setImage("gallery", u, "Daydream gallery")}
        />
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          try {
            const dataUrl = await fileToDataUrl(f, 1024);
            await setImage("gallery", dataUrl, "Daydream gallery image");
          } catch (err) {
            push("error", err instanceof Error ? err.message : "Couldn't use that image");
          }
        }}
      />
    </section>
  );
}
