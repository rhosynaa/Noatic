"use client";

import { Disc3, ListMusic } from "lucide-react";
import { useMusic } from "@/lib/music-context";
import WidgetFrame from "@/components/dashboard/WidgetFrame";
import PlayerBar from "@/components/music/PlayerBar";

export default function MusicWidget() {
  const m = useMusic();
  const activeList = m.playlists.find((p) => p.id === m.activePlaylistId) ?? null;

  return (
    // no overflow-hidden: it clipped the seek bar + transport when the widget
    // sharing this grid row rendered shorter. min-h keeps room for every control.
    <WidgetFrame className="flex h-full min-h-[300px] flex-col" style={{ padding: 0 }}>
      <div className="flex items-center justify-between px-5 pt-5 sm:px-6">
        <p
          className="text-[10.5px] font-bold tracking-[0.14em] uppercase"
          style={{ color: "var(--ink-faint)" }}
        >
          Music room
        </p>
        <button
          onClick={() => m.setDrawerOpen(true)}
          className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
        >
          <ListMusic size={13} />
          {activeList ? activeList.name : "Music Room"}
        </button>
      </div>

      <div className="flex flex-1 flex-col justify-center px-5 pt-3 pb-5 sm:px-6">
        <PlayerBar variant="compact" />
      </div>

      <p
        className="flex items-center gap-1.5 px-5 pb-4 text-[10.5px] sm:px-6"
        style={{ color: "var(--ink-faint)" }}
      >
        <Disc3 size={11} />
        {activeList
          ? `${m.queue.length} of ${m.tracks.length} songs in ${activeList.name}`
          : `${m.tracks.length} song${m.tracks.length === 1 ? "" : "s"} in your library`}
      </p>
    </WidgetFrame>
  );
}
