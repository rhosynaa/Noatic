/**
 * Entry component — mirrors the repo's src/app/page.tsx, but without
 * next/dynamic (this is already a purely client-side Vite build and the
 * whole app stores its data in localStorage).
 */
import AppClient from "@/components/AppClient";

export default function App() {
  return <AppClient />;
}
