"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { useSettings } from "@/lib/settings-context";

const LAYOUT_WIDTH = 840;

/**
 * "Desktop mode" for mobile: renders the content at a comfortable 840px
 * layout width and scales it down to fit the viewport — like a browser's
 * Desktop Site toggle, but measured so nothing gets unreadably small.
 */
export default function Scaler({ children }: { children: ReactNode }) {
  const { desktopMode } = useSettings();
  const outerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const outer = outerRef.current;
    const inner = innerRef.current;
    if (!outer || !inner) return;

    const apply = () => {
      const vw = document.documentElement.clientWidth;
      if (desktopMode && vw < LAYOUT_WIDTH) {
        const s = vw / LAYOUT_WIDTH;
        inner.style.width = `${LAYOUT_WIDTH}px`;
        inner.style.transform = `scale(${s})`;
        inner.style.transformOrigin = "top left";
        outer.style.overflow = "hidden";
        outer.style.height = `${inner.offsetHeight * s}px`;
      } else {
        inner.style.width = "";
        inner.style.transform = "";
        inner.style.transformOrigin = "";
        outer.style.height = "";
        outer.style.overflow = "";
      }
    };

    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(inner);
    window.addEventListener("resize", apply);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", apply);
    };
  }, [desktopMode]);

  return (
    <div ref={outerRef} className="relative">
      <div ref={innerRef}>{children}</div>
    </div>
  );
}
