"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Hash, NotebookPen, Search, X } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import { NOTE_COLORS } from "@/lib/types";

/** highlight the matched span inside a snippet */
function Highlight({ text, term }: { text: string; term: string }) {
  if (!term) return <>{text}</>;
  const i = text.toLowerCase().indexOf(term.toLowerCase());
  if (i < 0) return <>{text}</>;
  return (
    <>
      {text.slice(0, i)}
      <mark
        style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
        className="rounded-[3px] px-0.5 font-semibold"
      >
        {text.slice(i, i + term.length)}
      </mark>
      {text.slice(i + term.length)}
    </>
  );
}

export default function GlobalSearch() {
  const { notes, setEditingNote } = useDashboard();
  const [term, setTerm] = useState("");
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const boxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  /* ⌘K / Ctrl-K focuses the search */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        inputRef.current?.focus();
        setOpen(true);
      }
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [open]);

  const q = term.trim().toLowerCase();
  // "#tag" searches tags only; anything else matches title, body, subject or tag
  const tagQuery = q.startsWith("#") ? q.slice(1) : "";

  const results = useMemo(() => {
    if (!q) return [];
    return notes
      .map((n) => {
        const tags = n.tags ?? [];
        if (tagQuery) {
          const hit = tags.some((t) => t.toLowerCase().includes(tagQuery));
          return hit ? { note: n, where: "tag" as const, snippet: tags.join(", ") } : null;
        }
        if (n.title.toLowerCase().includes(q))
          return { note: n, where: "title" as const, snippet: n.title };
        const ci = n.content.toLowerCase().indexOf(q);
        if (ci >= 0)
          return {
            note: n,
            where: "content" as const,
            snippet: n.content.slice(Math.max(0, ci - 30), ci + 60).replace(/\n/g, " "),
          };
        if (tags.some((t) => t.toLowerCase().includes(q)))
          return { note: n, where: "tag" as const, snippet: tags.join(", ") };
        if (n.subject.toLowerCase().includes(q))
          return { note: n, where: "subject" as const, snippet: n.subject };
        return null;
      })
      .filter((r): r is NonNullable<typeof r> => r !== null)
      .slice(0, 25);
  }, [notes, q, tagQuery]);

  useEffect(() => setActive(0), [term]);

  const choose = (id: string) => {
    setEditingNote(id);
    setOpen(false);
    setTerm("");
    inputRef.current?.blur();
  };

  return (
    <div ref={boxRef} className="relative w-full">
      <div
        className="flex items-center gap-2 rounded-full px-3 py-2 transition-colors"
        style={{
          background: "var(--surface-2)",
          border: `1px solid ${open ? "var(--accent)" : "var(--line)"}`,
        }}
      >
        <Search size={14} className="shrink-0" style={{ color: "var(--ink-faint)" }} />
        <input
          ref={inputRef}
          className="min-w-0 flex-1 bg-transparent text-[12.5px] outline-none placeholder:opacity-60"
          style={{ color: "var(--ink)" }}
          placeholder="Search notes or #tags…"
          value={term}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setTerm(e.target.value);
            setOpen(true);
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActive((a) => Math.min(a + 1, results.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActive((a) => Math.max(a - 1, 0));
            } else if (e.key === "Enter" && results[active]) {
              e.preventDefault();
              choose(results[active].note.id);
            }
          }}
          aria-label="Search notes"
        />
        {term ? (
          <button
            onClick={() => {
              setTerm("");
              inputRef.current?.focus();
            }}
            aria-label="Clear search"
            className="shrink-0 transition-colors hover:text-[var(--accent)]"
            style={{ color: "var(--ink-faint)" }}
          >
            <X size={13} />
          </button>
        ) : (
          <kbd
            className="hidden shrink-0 rounded px-1.5 py-0.5 text-[9.5px] font-bold sm:block"
            style={{ background: "var(--surface-3)", color: "var(--ink-faint)" }}
          >
            ⌘K
          </kbd>
        )}
      </div>

      {open && term.trim() && (
        <div
          className="animate-pop absolute top-full right-0 left-0 z-[70] mt-2 overflow-hidden rounded-2xl p-1.5"
          style={{
            background: "var(--surface)",
            border: "1px solid var(--line)",
            boxShadow: "var(--card-shadow-hover)",
          }}
        >
          {results.length > 0 && (
            <p
              className="px-2.5 pt-1 pb-1.5 text-[10px] font-bold tracking-[0.1em] uppercase"
              style={{ color: "var(--ink-faint)" }}
            >
              {results.length} note{results.length === 1 ? "" : "s"} found
              {tagQuery ? ` · #${tagQuery}` : ""}
            </p>
          )}
          <div className="max-h-[min(58vh,340px)] overflow-y-auto">
          {results.map((r, i) => (
            <button
              key={r.note.id}
              onClick={() => choose(r.note.id)}
              onPointerEnter={() => setActive(i)}
              className="flex w-full items-start gap-2.5 rounded-xl px-2.5 py-2 text-left transition-colors"
              style={{ background: i === active ? "var(--surface-2)" : "transparent" }}
            >
              <span
                className="mt-0.5 h-6 w-6 shrink-0 rounded-lg"
                style={{
                  background: NOTE_COLORS[r.note.color]?.bg ?? NOTE_COLORS.cream.bg,
                  border: "1px solid var(--line)",
                }}
              />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[12.5px] font-semibold" style={{ color: "var(--ink)" }}>
                  <Highlight text={r.note.title || "Untitled note"} term={tagQuery ? "" : q} />
                </span>
                <span className="block truncate text-[11px]" style={{ color: "var(--ink-faint)" }}>
                  {r.where === "content" ? "…" : ""}
                  <Highlight text={r.snippet || "Empty note"} term={tagQuery || q} />
                </span>
              </span>
              <span
                className="mt-0.5 shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase"
                style={{ background: "var(--surface-3)", color: "var(--ink-faint)" }}
              >
                {r.where}
              </span>
            </button>
          ))}
          </div>
          {results.length === 0 && (
            <p className="px-3 py-4 text-center text-[12px]" style={{ color: "var(--ink-faint)" }}>
              Nothing matches “{term.trim()}”.
              <span className="mt-1 flex items-center justify-center gap-1 text-[11px]">
                <Hash size={10} /> try a tag like #ExamPrep
              </span>
            </p>
          )}
          {results.length > 0 && (
            <p
              className="mt-1 flex items-center gap-1 border-t px-2.5 pt-1.5 text-[10px]"
              style={{ borderColor: "var(--line-soft)", color: "var(--ink-faint)" }}
            >
              <NotebookPen size={9.5} /> ↑↓ to move · Enter to open
            </p>
          )}
        </div>
      )}
    </div>
  );
}
