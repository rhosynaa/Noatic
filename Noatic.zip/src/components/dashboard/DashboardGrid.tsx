"use client";

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { GripVertical } from "lucide-react";
import { useSettings } from "@/lib/settings-context";
import { WIDGET_META } from "@/lib/types";

/**
 * Pointer-based drag & drop grid with FLIP-animated sibling shuffling.
 * Works with mouse and touch, and persists the order through settings.
 */
export default function DashboardGrid({
  widgets,
}: {
  widgets: Record<string, ReactNode>;
}) {
  const { order, hidden, reorder } = useSettings();
  const visible = useMemo(
    () => order.filter((k) => !hidden.includes(k) && widgets[k]),
    [order, hidden, widgets]
  );
  const [preview, setPreview] = useState<string[] | null>(null);
  const [dragKey, setDragKey] = useState<string | null>(null);
  const shown = preview ?? visible;

  const containerRef = useRef<HTMLDivElement>(null);
  const rects = useRef(new Map<string, DOMRect>());
  const dragState = useRef<{
    key: string;
    pointerId: number;
    startX: number;
    startY: number;
    dx: number;
    dy: number;
    moved: boolean;
  } | null>(null);

  /* FLIP: after every order change, animate items from their old rects. */
  useLayoutEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const prev = rects.current;
    const next = new Map<string, DOMRect>();
    container.querySelectorAll<HTMLElement>("[data-flip]").forEach((el) => {
      const key = el.dataset.flip!;
      const r = el.getBoundingClientRect();
      // neutralize the dragged element's live transform when storing its rect
      const stored =
        dragState.current && dragState.current.key === key
          ? new DOMRect(r.left - dragState.current.dx, r.top - dragState.current.dy, r.width, r.height)
          : r;
      next.set(key, stored as DOMRect);

      const old = prev.get(key);
      if (old && Math.abs(old.left - stored.left) > 1 && Math.abs(old.top - stored.top) > 1) {
        const dx = old.left - stored.left;
        const dy = old.top - stored.top;
        el.style.transition = "none";
        el.style.transform = `translate(${dx}px, ${dy}px)`;
        el.getBoundingClientRect(); // force reflow
        el.style.transition = `transform 0.38s cubic-bezier(0.22,1,0.36,1)`;
        el.style.transform = dragState.current?.key === key
          ? `translate(${dragState.current.dx}px, ${dragState.current.dy}px) scale(1.02)`
          : "";
      }
    });
    rects.current = next;
  }, [shown]);

  const findSlot = useCallback(
    (x: number, y: number): number => {
      // index in `shown` where the dragged item should be inserted
      const others = shown.filter((k) => k !== dragState.current?.key);
      for (let i = 0; i < others.length; i++) {
        const r = rects.current.get(others[i]);
        if (!r) continue;
        const midY = r.top + r.height / 2;
        if (y < midY) return i;
      }
      return others.length;
    },
    [shown]
  );

  useEffect(() => {
    if (!dragKey) return;

    const move = (e: PointerEvent) => {
      const st = dragState.current;
      if (!st || e.pointerId !== st.pointerId) return;
      e.preventDefault();
      st.dx = e.clientX - st.startX;
      st.dy = e.clientY - st.startY;
      st.moved = st.moved || Math.abs(st.dx) + Math.abs(st.dy) > 6;

      const container = containerRef.current;
      const el = container?.querySelector<HTMLElement>(`[data-flip="${st.key}"]`);
      if (el) {
        el.style.transition = "box-shadow 0.2s ease";
        el.style.transform = `translate(${st.dx}px, ${st.dy}px) scale(1.02) rotate(0.6deg)`;
        el.style.zIndex = "40";
        el.style.boxShadow = "var(--card-shadow-hover)";
      }

      // auto-scroll near edges
      const margin = 90;
      if (e.clientY < margin) window.scrollBy(0, -12);
      else if (e.clientY > window.innerHeight - margin) window.scrollBy(0, 12);

      // live re-slotting
      const slot = findSlot(e.clientX, e.clientY);
      setPreview((cur) => {
        const base = cur ?? visible;
        const others = base.filter((k) => k !== st.key);
        const next = [...others.slice(0, slot), st.key, ...others.slice(slot)];
        return next.join("|") === base.join("|") ? cur : next;
      });
    };

    const up = (e: PointerEvent) => {
      const st = dragState.current;
      if (!st || e.pointerId !== st.pointerId) return;
      const finalOrder = preview;
      dragState.current = null;
      setDragKey(null);
      setPreview(null);

      const container = containerRef.current;
      const el = container?.querySelector<HTMLElement>(`[data-flip="${st.key}"]`);
      if (el) {
        el.style.transform = "";
        el.style.zIndex = "";
        el.style.boxShadow = "";
        el.style.transition = "";
      }
      if (finalOrder && finalOrder.join("|") !== visible.join("|")) {
        reorder(finalOrder);
      }
    };

    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [dragKey, preview, visible, findSlot, reorder]);

  const startDrag = (key: string) => (e: React.PointerEvent) => {
    if (e.button !== 0 && e.pointerType === "mouse") return;
    e.preventDefault();
    dragState.current = {
      key,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      dx: 0,
      dy: 0,
      moved: false,
    };
    setDragKey(key);
    setPreview(visible);
  };

  return (
    <div ref={containerRef} className="grid grid-cols-1 gap-4 @3xl:grid-cols-12 @3xl:gap-5">
      {shown.map((key) => {
        const meta = WIDGET_META[key];
        const isDragging = dragKey === key;
        return (
          <div
            key={key}
            data-flip={key}
            className={`relative ${meta.span} ${isDragging ? "" : ""}`}
            style={{
              opacity: isDragging ? 0.97 : 1,
              willChange: isDragging ? "transform" : undefined,
            }}
          >
            {/* floating peel handle */}
            <button
              onPointerDown={startDrag(key)}
              aria-label={`Drag ${meta.title} to rearrange`}
              title={`Drag to move ${meta.title}`}
              className="absolute -top-2.5 -right-2 z-30 flex h-8 w-8 cursor-grab items-center justify-center rounded-full transition-all hover:scale-110 active:cursor-grabbing"
              style={{
                background: "var(--surface)",
                border: "1px solid var(--line)",
                color: isDragging ? "var(--accent)" : "var(--ink-faint)",
                boxShadow: "var(--card-shadow)",
                touchAction: "none",
              }}
            >
              <GripVertical size={14} />
            </button>
            <div className={`h-full transition-opacity ${dragKey && !isDragging ? "opacity-95" : ""}`}>
              {widgets[key]}
            </div>
          </div>
        );
      })}
    </div>
  );
}
