"use client";

import { useMemo, useRef } from "react";
import { HERO_IMG } from "@/lib/assets";
import { CalendarDays, CheckCircle2, ImagePlus, ListMusic } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import { useProfile } from "@/lib/profile-context";
import { useMusic } from "@/lib/music-context";
import { fileToDataUrl } from "@/lib/api";
import LibraryPickButton from "@/components/media/LibraryPickButton";
import { useToast } from "@/lib/toast";
import { dueLabel } from "@/components/widgets/DeadlinesWidget";

export default function Banner() {
  const { images, setImage, tasks, deadlines } = useDashboard();
  const { profile } = useProfile();
  const music = useMusic();
  const { push } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const hero = images.find((i) => i.key === "hero")?.url ?? HERO_IMG;

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 5) return "Up late, daydreamer —";
    if (h < 12) return "Good morning,";
    if (h < 18) return "Good afternoon,";
    return "Good evening,";
  }, []);

  const dateStr = new Date().toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  const doneTasks = tasks.filter((t) => t.done).length;
  const nextDeadline = deadlines.find((d) => !d.done);
  const chip = nextDeadline ? dueLabel(nextDeadline.dueDate) : null;

  return (
    <section className="group relative overflow-hidden rounded-[1.75rem]" style={{ border: "1px solid var(--line)", boxShadow: "var(--card-shadow)" }}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={hero}
        alt=""
        className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.6s] ease-out group-hover:scale-[1.03]"
        onError={(e) => { (e.target as HTMLImageElement).src = HERO_IMG; }}
      />
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(100deg, rgba(30,20,10,0.72) 0%, rgba(30,20,10,0.45) 45%, rgba(30,20,10,0.08) 100%)" }}
      />

      <div className="relative flex min-h-[240px] flex-col justify-end gap-4 p-6 sm:p-8 @3xl:flex-row @3xl:items-end @3xl:justify-between">
        <div className="max-w-xl">
          <p className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.16em] uppercase" style={{ color: "rgba(255,244,230,0.8)" }}>
            <CalendarDays size={13} />
            {dateStr}
          </p>
          <h1 className="font-display mt-2.5 text-[clamp(1.7rem,4vw,2.6rem)] leading-[1.08] font-semibold text-[#fff4e6]">
            {greeting}{" "}
            <span className="italic">{profile?.username ?? "Dreamy Student"}</span>
          </h1>
          <p className="mt-2.5 text-[13.5px] leading-relaxed" style={{ color: "rgba(255,244,230,0.82)" }}>
            The desk is tidy, the tea is warm. Let&apos;s make today gently productive.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-2 rounded-full px-3.5 py-2 text-[12px] font-semibold backdrop-blur-md" style={{ background: "rgba(255,244,230,0.16)", color: "#fff4e6", border: "1px solid rgba(255,244,230,0.28)" }}>
            <CheckCircle2 size={14} />
            {doneTasks}/{tasks.length} tasks
          </span>
          {nextDeadline && chip && (
            <span className="flex items-center gap-2 rounded-full px-3.5 py-2 text-[12px] font-semibold backdrop-blur-md" style={{ background: chip.tone === "over" ? "rgba(200,70,50,0.4)" : "rgba(255,244,230,0.16)", color: "#fff4e6", border: "1px solid rgba(255,244,230,0.28)" }}>
              {nextDeadline.title} · {chip.text}
            </span>
          )}
          <button
            onClick={() => music.setDrawerOpen(true)}
            className="flex items-center gap-2 rounded-full px-3.5 py-2 text-[12px] font-semibold backdrop-blur-md transition-transform hover:scale-[1.03]"
            style={{ background: "rgba(255,244,230,0.16)", color: "#fff4e6", border: "1px solid rgba(255,244,230,0.28)" }}
          >
            <ListMusic size={14} />
            Music room
          </button>
          <button
            onClick={() => fileRef.current?.click()}
            title="Change banner image"
            className="flex items-center gap-2 rounded-full px-3.5 py-2 text-[12px] font-semibold backdrop-blur-md transition-transform hover:scale-[1.03]"
            style={{ background: "rgba(255,244,230,0.16)", color: "#fff4e6", border: "1px solid rgba(255,244,230,0.28)" }}
          >
            <ImagePlus size={14} />
            <span className="hidden @3xl:inline">Change banner</span>
          </button>
          <LibraryPickButton
            label=""
            iconSize={14}
            className="flex items-center gap-2 rounded-full px-3.5 py-2 text-[12px] font-semibold backdrop-blur-md transition-transform hover:scale-[1.03]"
            onPick={(u) => void setImage("hero", u, "Dashboard banner")}
          />
        </div>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          try {
            const dataUrl = await fileToDataUrl(f, 1200);
            await setImage("hero", dataUrl, "Dashboard banner");
          } catch (err) {
            push("error", err instanceof Error ? err.message : "Couldn't use that image");
          }
        }}
      />
    </section>
  );
}
