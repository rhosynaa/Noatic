"use client";

import { useEffect, useRef, useState } from "react";
import { AVATAR_IMG } from "@/lib/assets";
import Link from "@/lib/router";
import {
  AlarmClock,
  Bell,
  Check,
  Settings2,
  LifeBuoy,
  Menu,
  NotebookPen,
} from "lucide-react";
import { useSettings } from "@/lib/settings-context";
import { useProfile } from "@/lib/profile-context";
import { useDashboard } from "@/lib/dashboard-context";
import { useToast } from "@/lib/toast";
import { Avatar } from "@/components/ui";
import { dueLabel } from "@/components/widgets/DeadlinesWidget";

function BellMenu() {
  const { deadlines, toggleDeadline } = useDashboard();
  const { push } = useToast();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const active = deadlines.filter((d) => !d.done);
  const urgent = active.filter((d) => dueLabel(d.dueDate).tone !== "later");
  const overdue = active.filter((d) => dueLabel(d.dueDate).tone === "over");
  const soon = active.filter((d) => dueLabel(d.dueDate).tone === "soon");
  const later = active.filter((d) => dueLabel(d.dueDate).tone === "later");

  const Row = ({ id, title, subject, dueDate }: { id: string; title: string; subject: string; dueDate: string }) => {
    const chip = dueLabel(dueDate);
    return (
      <div className="flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors hover:bg-[var(--surface-2)]">
        <button
          onClick={() => {
            toggleDeadline(id);
            push("success", "Deadline cleared — nice work");
          }}
          aria-label={`Mark ${title} done`}
          className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-all hover:scale-110"
          style={{ borderColor: "var(--line)", color: "var(--accent)" }}
        >
          <Check size={12} strokeWidth={3} />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-medium" style={{ color: "var(--ink)" }}>{title}</p>
          {subject && <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>{subject}</p>}
        </div>
        <span
          className="shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold"
          style={{
            background: chip.tone === "over" ? "#d060541e" : chip.tone === "soon" ? "var(--accent-soft)" : "var(--surface-3)",
            color: chip.tone === "over" ? "#c5503f" : chip.tone === "soon" ? "var(--accent)" : "var(--ink-soft)",
          }}
        >
          {chip.text}
        </span>
      </div>
    );
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={`Deadline notifications — ${urgent.length} urgent`}
        aria-expanded={open}
        className="btn-ghost relative h-10 w-10 !p-0"
        style={{ background: "var(--surface)" }}
      >
        <Bell size={17} className={urgent.length > 0 ? "animate-ring" : ""} style={urgent.length > 0 ? { color: "var(--accent)" } : undefined} />
        {urgent.length > 0 && (
          <span
            className="absolute -top-1 -right-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full px-1 text-[10px] font-bold text-white"
            style={{ background: "#c5503f", boxShadow: "0 0 0 2px var(--surface)" }}
          >
            {urgent.length}
          </span>
        )}
      </button>

      {open && (
        <div
          className="animate-pop absolute right-0 z-[70] mt-2.5 w-[min(92vw,360px)] overflow-hidden rounded-3xl"
          style={{ background: "var(--surface)", border: "1px solid var(--line)", boxShadow: "var(--card-shadow-hover)" }}
        >
          <div className="flex items-center justify-between border-b px-5 py-4" style={{ borderColor: "var(--line-soft)" }}>
            <p className="font-display text-[16px] font-semibold" style={{ color: "var(--ink)" }}>
              Deadline radar
            </p>
            <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
              {active.length} upcoming
            </p>
          </div>
          <div className="max-h-[22rem] overflow-y-auto p-2">
            {overdue.length > 0 && (
              <>
                <p className="px-3 pt-1.5 pb-1 text-[10px] font-bold tracking-[0.14em] uppercase text-[#c5503f]">
                  Needs you now
                </p>
                {overdue.map((d) => <Row key={d.id} {...d} />)}
              </>
            )}
            {soon.length > 0 && (
              <>
                <p className="px-3 pt-1.5 pb-1 text-[10px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--accent)" }}>
                  This week
                </p>
                {soon.map((d) => <Row key={d.id} {...d} />)}
              </>
            )}
            {later.length > 0 && (
              <>
                <p className="px-3 pt-1.5 pb-1 text-[10px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--ink-faint)" }}>
                  Later
                </p>
                {later.map((d) => <Row key={d.id} {...d} />)}
              </>
            )}
            {active.length === 0 && (
              <div className="flex flex-col items-center gap-2 px-4 py-10 text-center" style={{ color: "var(--ink-faint)" }}>
                <AlarmClock size={22} />
                <p className="text-[13px]">The radar is quiet. No deadlines on the horizon.</p>
              </div>
            )}
          </div>
          <p className="border-t px-5 py-3 text-[11px] leading-relaxed" style={{ borderColor: "var(--line-soft)", color: "var(--ink-faint)" }}>
            Tick a deadline here and it clears everywhere — the widget, the badge, all of it.
          </p>
        </div>
      )}
    </div>
  );
}

export default function Header({ onMenu }: { onMenu: () => void }) {
  const { openSettings, openHelp } = useSettings();
  const { profile } = useProfile();

  return (
    <header className="flex items-center gap-2.5 py-5 sm:gap-3">
      <button onClick={onMenu} aria-label="Open menu" className="btn-ghost h-10 w-10 !p-0 lg:!hidden" style={{ background: "var(--surface)" }}>
        <Menu size={17} />
      </button>

      <Link href="/" className="flex items-center gap-2.5">
        <span className="flex h-10 w-10 items-center justify-center rounded-2xl" style={{ background: "var(--accent)", color: "var(--accent-ink)", boxShadow: "0 10px 22px -8px var(--accent)" }}>
          <NotebookPen size={18} />
        </span>
        <span className="font-display hidden text-[19px] font-semibold tracking-tight sm:block" style={{ color: "var(--ink)" }}>
          Dreamy<span style={{ color: "var(--accent)" }}>Study</span>
        </span>
      </Link>

      <span className="flex-1" />

      <BellMenu />

      <button onClick={openHelp} aria-label="Help and how-tos" title="Help & how-tos" className="btn-ghost h-10 w-10 !p-0" style={{ background: "var(--surface)" }}>
        <LifeBuoy size={17} />
      </button>

      <button onClick={openSettings} aria-label="Settings" title="Settings" className="btn-ghost h-10 w-10 !p-0" style={{ background: "var(--surface)" }}>
        <Settings2 size={17} />
      </button>

      <Link
        href="/profile"
        className="group flex items-center gap-2.5 rounded-full py-1.5 pr-4 pl-1.5 transition-all hover:-translate-y-0.5"
        style={{ background: "var(--surface)", border: "1px solid var(--line)", boxShadow: "var(--card-shadow)" }}
        title="Open your profile"
      >
        <Avatar src={profile?.avatarUrl ?? AVATAR_IMG} name={profile?.username ?? "Dreamy Student"} size={30} />
        <span className="hidden items-center gap-1 text-[13.5px] font-semibold sm:flex" style={{ color: "var(--ink)" }}>
          {profile?.username ?? "Dreamy Student"}
          <span className="text-[11px] font-medium transition-transform group-hover:translate-x-0.5" style={{ color: "var(--ink-faint)" }}>
            →
          </span>
        </span>
      </Link>
    </header>
  );
}
