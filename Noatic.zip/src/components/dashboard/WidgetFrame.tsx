"use client";

import type { CSSProperties, ReactNode } from "react";

export default function WidgetFrame({
  header,
  children,
  className = "",
  style,
}: {
  header?: ReactNode;
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <section className={`card card-hover relative h-full px-5 py-5 sm:px-6 ${className}`} style={style}>
      {header}
      {children}
    </section>
  );
}
