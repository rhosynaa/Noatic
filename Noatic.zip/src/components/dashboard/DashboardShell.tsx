"use client";

import { useMemo, useState } from "react";
import { MousePointerClick } from "lucide-react";
import { DashboardProvider, useDashboard } from "@/lib/dashboard-context";
import { useSettings } from "@/lib/settings-context";
import Header from "@/components/dashboard/Header";
import Sidebar from "@/components/dashboard/Sidebar";
import Scaler from "@/components/dashboard/Scaler";
import GlobalSearch from "@/components/dashboard/GlobalSearch";
import Banner from "@/components/dashboard/Banner";
import DashboardGrid from "@/components/dashboard/DashboardGrid";
import PlanWidget from "@/components/widgets/PlanWidget";
import DeadlinesWidget from "@/components/widgets/DeadlinesWidget";
import MusicWidget from "@/components/widgets/MusicWidget";
import QuoteWidget from "@/components/widgets/QuoteWidget";
import NotesWidget from "@/components/widgets/NotesWidget";
import FocusWidget from "@/components/widgets/FocusWidget";
import GalleryWidget from "@/components/widgets/GalleryWidget";
import TemplatesModal from "@/components/modals/TemplatesModal";
import ImagesPanel from "@/components/modals/ImagesPanel";
import { SectionsProvider, useSections } from "@/lib/sections-context";
import SubjectDashboard from "@/components/subjects/SubjectDashboard";
import WorkspaceSidebar from "@/components/subjects/WorkspaceSidebar";
import SubjectLibrary from "@/components/subjects/SubjectLibrary";
import ImageRotator from "@/lib/rotation";
import { FocusProvider } from "@/lib/focus-context";
import CompletionModal from "@/components/focus/CompletionModal";
import SectionDrawers from "@/components/drawers/SectionDrawers";
import MusicDrawer from "@/components/music/MusicDrawer";
import type { DashboardData } from "@/lib/types";

export default function DashboardShell({ initial }: { initial: DashboardData }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [imagesOpen, setImagesOpen] = useState(false);

  const widgets = useMemo<Record<string, React.ReactNode>>(
    () => ({
      plan: <PlanWidget />,
      deadlines: <DeadlinesWidget />,
      music: <MusicWidget />,
      quote: <QuoteWidget />,
      notes: <NotesWidget onOpenTemplates={() => setTemplatesOpen(true)} />,
      focus: <FocusWidget />,
      gallery: <GalleryWidget />,
    }),
    []
  );

  return (
    <DashboardProvider initial={initial}>
      <SectionsProvider>
      <FocusProvider>
      <div className="mx-auto min-h-screen max-w-[1440px] px-4 sm:px-6 lg:px-8">
        <Scaler>
          <Header onMenu={() => setMenuOpen(true)} />
        </Scaler>

        <div className="flex items-start gap-7">
          <Sidebar
            open={menuOpen}
            onClose={() => setMenuOpen(false)}
            onOpenTemplates={() => setTemplatesOpen(true)}
            onOpenImages={() => setImagesOpen(true)}
          />

          <main className="min-w-0 flex-1 pb-28">
            <Scaler>
              <MainArea widgets={widgets} />
            </Scaler>
          </main>
        </div>
      </div>

      <TemplateBridge open={templatesOpen} onClose={() => setTemplatesOpen(false)} />
      <ImagesPanel open={imagesOpen} onClose={() => setImagesOpen(false)} />
      <SectionDrawers />
      {/* mounted inside DashboardProvider so the cover picker's library/shuffle
          buttons (which need the media library) never crash to a blank page */}
      <MusicDrawer />
      <CompletionModal />
      {/* drives the "shuffle a category" picture setting */}
      <ImageRotator />
      </FocusProvider>
      </SectionsProvider>
    </DashboardProvider>
  );
}

/**
 * Routes the main content area. When a workspace is selected its Subject
 * Dashboard takes over the entire main column — never a drawer or overlay.
 */
function MainArea({ widgets }: { widgets: Record<string, React.ReactNode> }) {
  const { workspace, library } = useSections();
  const { subjects } = useDashboard();

  // The workspace sidebar is a *sibling* of the subject view, so drilling into
  // an individual subject never unmounts or changes it.
  if (workspace) {
    // drilled into one subject → its note library replaces the card grid,
    // while the workspace sidebar on the right stays exactly as it was
    const openSubject = library ? subjects.find((s) => s.id === library.id) : undefined;
    return (
      <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
        <div className="min-w-0 flex-1">
          {openSubject ? <SubjectLibrary subject={openSubject} /> : <SubjectDashboard />}
        </div>
        <WorkspaceSidebar />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 @container @3xl:gap-5">
      {/* Always-visible global note search — comfortable on mobile and desktop. */}
      <div
        className="animate-fade-up relative z-[80] flex w-full items-center gap-3 rounded-2xl p-2 sm:rounded-3xl sm:p-2.5"
        style={{
          background: "var(--surface)",
          border: "1px solid var(--line)",
          boxShadow: "var(--card-shadow)",
        }}
      >
        <div className="hidden shrink-0 pl-2 sm:block">
          <p className="text-[10px] font-bold tracking-[0.13em] uppercase" style={{ color: "var(--accent)" }}>
            Find a note
          </p>
          <p className="mt-0.5 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
            title, content or #tag
          </p>
        </div>
        <GlobalSearch />
      </div>

      <div className="animate-fade-up" style={{ animationDelay: "0.04s" }}>
        <Banner />
      </div>

      <div className="flex items-center justify-between px-1">
        <p className="flex items-center gap-1.5 text-[11px] font-medium" style={{ color: "var(--ink-faint)" }}>
          <MousePointerClick size={12.5} />
          Drag any widget by its grip to rearrange — the layout saves itself
        </p>
        <p className="hidden text-[11px] font-semibold tracking-[0.12em] uppercase sm:block" style={{ color: "var(--ink-faint)" }}>
          Your desk, your rules
        </p>
      </div>

      <div className="animate-fade-up" style={{ animationDelay: "0.08s" }}>
        <DashboardGrid widgets={widgets} />
      </div>
    </div>
  );
}

function TemplateBridge({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { setEditingNote } = useDashboard();
  return (
    <TemplatesModal
      open={open}
      onClose={onClose}
      onUseTemplate={(note) => setEditingNote(note.id)}
    />
  );
}
