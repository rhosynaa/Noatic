"use client";

import { useEffect, useState } from "react";
import {
  BarChart3,
  BookMarked,
  CalendarDays,
  GraduationCap,
  Home,
  Image as ImageIcon,
  Layers,
  LayoutTemplate,
  LifeBuoy,
  ListMusic,
  ListTodo,
  MessageSquareQuote,
  Network,
  Quote,
  Timer,
  Trash2,
  X,
  type LucideIcon,
} from "lucide-react";
import { useSettings } from "@/lib/settings-context";
import { useMusic } from "@/lib/music-context";
import { useSections } from "@/lib/sections-context";
import { api } from "@/lib/api";
import type { TrashBin } from "@/lib/types";

type NavItem = {
  icon: LucideIcon;
  label: string;
  hint: string;
  section?: Parameters<ReturnType<typeof useSections>["openSection"]>[0];
  action?: "music" | "templates" | "images" | "help" | "home";
  badge?: number;
};

function useTrashCount(open: boolean) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    api<TrashBin>("/api/trash")
      .then((bin) =>
        setCount(bin.tasks.length + bin.notes.length + bin.deadlines.length + bin.flashcards.length)
      )
      .catch(() => {});
  }, [open]);
  return count;
}

export function SidebarContent({
  onOpenTemplates,
  onOpenImages,
  onNavigate,
}: {
  onOpenTemplates: () => void;
  onOpenImages: () => void;
  onNavigate?: () => void;
}) {
  const { openHelp } = useSettings();
  const music = useMusic();
  const {
    open: openKey,
    openSection,
    closeSection,
    workspace: activeWorkspace,
    exitWorkspace,
    mindmap: activeMindmap,
  } = useSections();
  const trashCount = useTrashCount(openKey === "trash");

  const groups: { title: string; items: NavItem[] }[] = [
    {
      title: "Home",
      items: [
        { icon: Home, label: "Dashboard", hint: "Back to the overview", action: "home" },
        { icon: ListTodo, label: "Tasks", hint: "Every task, full control", section: "tasks" },
        { icon: CalendarDays, label: "Calendar", hint: "Deadlines by day", section: "calendar" },
      ],
    },
    {
      title: "Study",
      items: [
        { icon: Layers, label: "Flashcards", hint: "Decks & study mode", section: "flashcards" },
        { icon: BookMarked, label: "Subjects", hint: "Colour-coded labels", section: "workspaces" },
        { icon: Network, label: "Mind map", hint: "Connect your ideas", section: "mindmap" },
        { icon: BarChart3, label: "Analytics", hint: "Proof of progress", section: "analytics" },
        {
          icon: MessageSquareQuote,
          label: "Self-assessment",
          hint: "Grade your own work",
          section: "selfassessments",
        },
        {
          icon: GraduationCap,
          label: "GPA Tracker",
          hint: "Grades, goals & semesters",
          section: "gpatracker",
        },
        { icon: Timer, label: "Timer", hint: "Full focus sessions", section: "timer" },
      ],
    },
    {
      title: "Space",
      items: [
        { icon: ListMusic, label: "Music room", hint: "Playlist & player", action: "music" },
        { icon: LayoutTemplate, label: "Templates", hint: "Note skeletons", action: "templates" },
        { icon: Quote, label: "Quotes", hint: "Daily words manager", section: "quotes" },
        { icon: ImageIcon, label: "Images", hint: "Change any picture", action: "images" },
      ],
    },
    {
      title: "System",
      items: [
        { icon: Trash2, label: "Trash", hint: "Restore or erase", section: "trash", badge: trashCount },
        { icon: LifeBuoy, label: "Help & how-tos", hint: "Guides for everything", action: "help" },
      ],
    },
  ];

  const run = (item: NavItem) => {
    if (item.section) {
      openSection(item.section);
    } else if (item.action === "music") {
      music.setDrawerOpen(true);
    } else if (item.action === "templates") {
      onOpenTemplates();
    } else if (item.action === "images") {
      onOpenImages();
    } else if (item.action === "help") {
      openHelp();
    } else if (item.action === "home") {
      closeSection();
      exitWorkspace();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    onNavigate?.();
  };

  return (
    <div className="flex h-full flex-col gap-5 overflow-y-auto pr-1">
      {groups.map((g) => (
        <nav key={g.title} className="flex flex-col gap-0.5">
          <p
            className="px-3 pb-1.5 text-[10px] font-bold tracking-[0.16em] uppercase"
            style={{ color: "var(--ink-faint)" }}
          >
            {g.title}
          </p>
          {g.items.map((item) => {
            const active =
              item.section &&
              (openKey === item.section ||
                // stays lit while a workspace's subject dashboard owns the main area
                (item.section === "workspaces" && !!activeWorkspace) ||
                // stays lit while one mind map's canvas drawer is open
                (item.section === "mindmap" && !!activeMindmap));
            return (
              <button
                key={item.label}
                onClick={() => run(item)}
                aria-current={active ? "page" : undefined}
                className="group flex items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-all hover:translate-x-0.5"
                style={{
                  background: active ? "var(--accent-soft)" : "transparent",
                }}
              >
                <span
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl transition-colors"
                  style={{
                    background: active ? "var(--accent)" : "var(--surface)",
                    color: active ? "var(--accent-ink)" : "var(--accent)",
                    border: active ? "none" : "1px solid var(--line-soft)",
                  }}
                >
                  <item.icon size={15} />
                </span>
                <span className="min-w-0 flex-1">
                  <span
                    className="block truncate text-[13px] font-semibold"
                    style={{ color: active ? "var(--accent)" : "var(--ink)" }}
                  >
                    {item.label}
                  </span>
                  <span
                    className="block truncate text-[10.5px] opacity-0 transition-opacity group-hover:opacity-100"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    {item.hint}
                  </span>
                </span>
                {item.badge ? (
                  <span
                    className="flex h-[19px] min-w-[19px] items-center justify-center rounded-full px-1.5 text-[10px] font-bold"
                    style={{ background: "var(--surface-3)", color: "var(--ink-soft)" }}
                  >
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>
      ))}

      <p className="mt-auto px-3 pb-2 text-[10.5px] leading-relaxed" style={{ color: "var(--ink-faint)" }}>
        DreamyStudy — a soft space to get things done. Everything syncs to PostgreSQL.
      </p>
    </div>
  );
}

export default function Sidebar({
  open,
  onClose,
  onOpenTemplates,
  onOpenImages,
}: {
  open: boolean;
  onClose: () => void;
  onOpenTemplates: () => void;
  onOpenImages: () => void;
}) {
  return (
    <>
      {/* desktop column */}
      <aside className="sticky top-6 hidden max-h-[calc(100vh-3rem)] w-[252px] shrink-0 lg:block">
        <SidebarContent onOpenTemplates={onOpenTemplates} onOpenImages={onOpenImages} />
      </aside>

      {/* mobile drawer */}
      <div
        className={`fixed inset-0 z-[100] transition-opacity duration-300 lg:hidden ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}
        style={{ background: "rgba(24,18,10,0.45)", backdropFilter: "blur(3px)" }}
        onClick={onClose}
      />
      <aside
        className="fixed top-0 left-0 bottom-0 z-[101] w-[300px] max-w-[86vw] overflow-y-auto p-5 transition-transform duration-500 lg:hidden"
        style={{
          transform: open ? "translateX(0)" : "translateX(-103%)",
          transitionTimingFunction: "cubic-bezier(0.22,1,0.36,1)",
          background: "var(--bg)",
          borderRight: "1px solid var(--line)",
        }}
        aria-hidden={!open}
      >
        <button onClick={onClose} aria-label="Close menu" className="btn-ghost mb-4 h-9 w-9 !p-0">
          <X size={16} />
        </button>
        <SidebarContent onOpenTemplates={onOpenTemplates} onOpenImages={onOpenImages} onNavigate={onClose} />
      </aside>
    </>
  );
}
