"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";

/**
 * Tag filter chips that clamp to two rows. Anything that would spill onto a
 * third row is hidden behind a "Show N more" toggle. Row height is measured
 * from the real chips so it stays correct at any width or font scale.
 */
export default function TagFilterRow({
  tags,
  active,
  onSelect,
}: {
  tags: string[];
  active: string | null;
  onSelect: (tag: string | null) => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [maxH, setMaxH] = useState<number | null>(null);
  const [hidden, setHidden] = useState(0);
  const [collapsed, setCollapsed] = useState(true);

  const measure = useCallback(() => {
    const el = wrapRef.current;
    if (!el) return;
    const kids = Array.from(el.children) as HTMLElement[];
    if (kids.length === 0) {
      setMaxH(null);
      setHidden(0);
      return;
    }
    // distinct row offsets — chips on the same row share an offsetTop
    const tops = [...new Set(kids.map((k) => k.offsetTop))].sort((a, b) => a - b);
    if (tops.length <= 2) {
      setMaxH(null);
      setHidden(0);
      return;
    }
    const secondRowTop = tops[1];
    const secondRowChip =
      kids.find((k) => k.offsetTop === secondRowTop) ?? kids[kids.length - 1];
    setMaxH(secondRowTop + secondRowChip.offsetHeight - tops[0]);
    setHidden(kids.filter((k) => k.offsetTop > secondRowTop).length);
  }, []);

  useEffect(() => {
    measure();
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [measure, tags]);

  const clamped = collapsed && maxH !== null;

  return (
    <div className="mt-3">
      <div
        ref={wrapRef}
        className="flex flex-wrap items-center gap-1.5 overflow-hidden"
        style={{
          maxHeight: clamped ? maxH ?? undefined : undefined,
          transition: "max-height 0.25s cubic-bezier(0.22,1,0.36,1)",
        }}
      >
        <button
          onClick={() => onSelect(null)}
          className="rounded-full px-2.5 py-1 text-[10.5px] font-bold transition-all"
          style={{
            background: active === null ? "var(--accent)" : "var(--surface-2)",
            color: active === null ? "var(--accent-ink)" : "var(--ink-soft)",
          }}
        >
          All
        </button>
        {tags.map((t) => (
          <button
            key={t}
            onClick={() => onSelect(active === t ? null : t)}
            className="rounded-full px-2.5 py-1 text-[10.5px] font-bold transition-all"
            style={{
              background: active === t ? "var(--accent)" : "var(--surface-2)",
              color: active === t ? "var(--accent-ink)" : "var(--ink-soft)",
            }}
          >
            #{t}
          </button>
        ))}
      </div>

      {(hidden > 0 || !collapsed) && maxH !== null && (
        <button
          onClick={() => setCollapsed((v) => !v)}
          className="mt-1.5 inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-bold transition-colors"
          style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
          aria-expanded={!collapsed}
        >
          <ChevronDown
            size={11}
            style={{
              transform: collapsed ? "none" : "rotate(180deg)",
              transition: "transform 0.2s",
            }}
          />
          {collapsed ? `Show ${hidden} more` : "Show less"}
        </button>
      )}
    </div>
  );
}
