"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { FolderOpen, Library, Search } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import type { MediaItem } from "@/lib/types";

const UNFILED = "Unfiled";
const catOf = (m: MediaItem) => m.category.trim() || UNFILED;

/**
 * "Pick from my library" — the same control on every surface that can change
 * a picture, so the media library is usable everywhere, not just in Settings.
 *
 * The panel is portalled and fixed-positioned so a parent with
 * `overflow: hidden` (cards, drawers, popovers) can never clip it.
 */
export default function LibraryPickButton({
  onPick,
  label = "Library",
  className = "btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold",
  iconSize = 12,
}: {
  onPick: (url: string) => void;
  label?: string;
  className?: string;
  iconSize?: number;
}) {
  const { media } = useDashboard();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const btnRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  /* place next to the button, flipped/clamped to stay fully on screen */
  useEffect(() => {
    if (!open) return;
    const place = () => {
      const a = btnRef.current?.getBoundingClientRect();
      if (!a) return;
      const w = 288;
      const h = panelRef.current?.offsetHeight ?? 320;
      const M = 8;
      const vw = document.documentElement.clientWidth;
      const vh = document.documentElement.clientHeight;
      let top = a.bottom + 6;
      if (top + h > vh - M) top = Math.max(M, a.top - 6 - h);
      let left = a.left;
      left = Math.min(Math.max(M, left), Math.max(M, vw - M - w));
      setPos({ top, left });
    };
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open]);

  /* dismiss on Escape or an outside click */
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    const onDown = (e: PointerEvent) => {
      if (
        !panelRef.current?.contains(e.target as Node) &&
        !btnRef.current?.contains(e.target as Node)
      )
        setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onDown);
    };
  }, [open]);

  const groups = useMemo(() => {
    const q = query.trim().toLowerCase();
    const pool = q
      ? media.filter(
          (m) => m.name.toLowerCase().includes(q) || catOf(m).toLowerCase().includes(q)
        )
      : media;
    const map = new Map<string, MediaItem[]>();
    for (const m of pool) {
      const c = catOf(m);
      if (!map.has(c)) map.set(c, []);
      map.get(c)!.push(m);
    }
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [media, query]);

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen((v) => !v);
        }}
        aria-expanded={open}
        title="Pick from my picture library"
        className={className}
      >
        <Library size={iconSize} /> {label}
      </button>

      {open &&
        pos &&
        createPortal(
          <div
            ref={panelRef}
            onPointerDown={(e) => e.stopPropagation()}
            className="animate-pop rail-scroll fixed z-[3000] max-h-[340px] w-[288px] overflow-y-auto rounded-2xl p-2.5"
            style={{
              top: pos.top,
              left: pos.left,
              background: "var(--surface)",
              border: "1px solid var(--line)",
              boxShadow: "0 20px 44px rgba(24,18,10,0.22)",
            }}
          >
            {media.length > 6 && (
              <div
                className="mb-2 flex items-center gap-1.5 rounded-xl px-2 py-1"
                style={{ background: "var(--surface-2)" }}
              >
                <Search size={11} style={{ color: "var(--ink-faint)" }} />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search pictures…"
                  aria-label="Search your picture library"
                  className="min-w-0 flex-1 bg-transparent py-0.5 text-[11.5px] outline-none"
                  style={{ color: "var(--ink)" }}
                />
              </div>
            )}

            {groups.map(([cat, items]) => (
              <div key={cat} className="mb-2 last:mb-0">
                <p
                  className="mb-1 flex items-center gap-1 px-0.5 text-[9.5px] font-bold tracking-[0.1em] uppercase"
                  style={{ color: "var(--ink-faint)" }}
                >
                  <FolderOpen size={9.5} style={{ color: "var(--accent)" }} /> {cat}
                  <span className="normal-case opacity-75">· {items.length}</span>
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {items.map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        onPick(m.url);
                        setOpen(false);
                      }}
                      title={m.name}
                      className="h-12 w-16 overflow-hidden rounded-lg transition-transform hover:-translate-y-0.5"
                      style={{ border: "1px solid var(--line)" }}
                    >
                      <img src={m.url} alt={m.name} className="h-full w-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            ))}

            {groups.length === 0 && (
              <p
                className="px-1 py-4 text-center text-[11.5px] leading-relaxed"
                style={{ color: "var(--ink-faint)" }}
              >
                {media.length === 0
                  ? "Your library is empty — add pictures in Settings › Images."
                  : "Nothing matches that search."}
              </p>
            )}
          </div>,
          document.body
        )}
    </>
  );
}
