"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { FolderOpen, Shuffle } from "lucide-react";
import { useDashboard } from "@/lib/dashboard-context";
import {
  DEFAULT_ROTATE_SECONDS,
  ROTATE_INTERVALS,
  type CoverRotation,
  type MediaItem,
} from "@/lib/types";

const UNFILED = "Unfiled";
const catOf = (m: MediaItem) => m.category.trim() || UNFILED;

/**
 * "Shuffle this cover" — points a subject card, note or track at a media
 * category so its picture changes itself at random on a timer.
 *
 * Same behaviour as the site-image shuffle, just aimed at one item.
 */
export default function CoverShuffleButton({
  target,
  refId,
  className = "btn-ghost px-2.5 py-1.5 text-[11.5px] font-semibold",
  iconSize = 12,
  label = "Shuffle",
}: {
  target: CoverRotation["target"];
  refId: string;
  className?: string;
  iconSize?: number;
  label?: string;
}) {
  const { media, coverRotations, setCoverRotation } = useDashboard();
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  const active = coverRotations.find((r) => r.target === target && r.refId === refId);
  const [seconds, setSeconds] = useState(active?.seconds ?? DEFAULT_ROTATE_SECONDS);

  const categories = useMemo(
    () => [...new Set(media.map(catOf))].sort((a, b) => a.localeCompare(b)),
    [media]
  );

  useEffect(() => {
    if (!open) return;
    const place = () => {
      const a = btnRef.current?.getBoundingClientRect();
      if (!a) return;
      const w = 248;
      const h = panelRef.current?.offsetHeight ?? 260;
      const M = 8;
      const vw = document.documentElement.clientWidth;
      const vh = document.documentElement.clientHeight;
      let top = a.bottom + 6;
      if (top + h > vh - M) top = Math.max(M, a.top - 6 - h);
      let left = Math.min(Math.max(M, a.left), Math.max(M, vw - M - w));
      setPos({ top, left });
    };
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    const onDown = (e: PointerEvent) => {
      if (
        !panelRef.current?.contains(e.target as Node) &&
        !btnRef.current?.contains(e.target as Node)
      )
        setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onDown);
    };
  }, [open]);

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen((v) => !v);
        }}
        aria-expanded={open}
        title={
          active ? `Shuffling “${active.category}” — click to change` : "Shuffle this cover"
        }
        className={className}
        style={active ? { background: "var(--accent)", color: "var(--accent-ink)" } : undefined}
      >
        <Shuffle size={iconSize} /> {active ? "Shuffling" : label}
      </button>

      {open &&
        pos &&
        createPortal(
          <div
            ref={panelRef}
            onPointerDown={(e) => e.stopPropagation()}
            className="animate-pop rail-scroll fixed z-[3000] max-h-[320px] w-[248px] overflow-y-auto rounded-2xl p-2.5"
            style={{
              top: pos.top,
              left: pos.left,
              background: "var(--surface)",
              border: "1px solid var(--line)",
              boxShadow: "0 20px 44px rgba(24,18,10,0.22)",
            }}
          >
            <p
              className="mb-1.5 px-0.5 text-[9.5px] font-bold tracking-[0.12em] uppercase"
              style={{ color: "var(--ink-faint)" }}
            >
              Shuffle from a category
            </p>

            {categories.map((c) => {
              const on = active?.category.trim().toLowerCase() === c.trim().toLowerCase();
              const count = media.filter((m) => catOf(m) === c).length;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => {
                    void setCoverRotation(target, refId, on ? null : c, seconds);
                    if (on) setOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left transition-colors"
                  style={{ background: on ? "var(--accent-soft)" : "transparent" }}
                >
                  <FolderOpen size={11} style={{ color: "var(--accent)" }} />
                  <span
                    className="min-w-0 flex-1 truncate text-[12px] font-semibold"
                    style={{ color: "var(--ink)" }}
                  >
                    {c}
                  </span>
                  <span className="text-[10px]" style={{ color: "var(--ink-faint)" }}>
                    {count}
                  </span>
                  {on && (
                    <span
                      className="rounded-full px-1.5 text-[8.5px] font-bold"
                      style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
                    >
                      ON
                    </span>
                  )}
                </button>
              );
            })}

            {categories.length === 0 && (
              <p className="px-1 py-3 text-[11px]" style={{ color: "var(--ink-faint)" }}>
                Add pictures in Settings › Images first.
              </p>
            )}

            <div
              className="mt-2 border-t pt-2"
              style={{ borderColor: "var(--line-soft)" }}
            >
              <label
                className="mb-1 block px-0.5 text-[9.5px] font-bold tracking-[0.12em] uppercase"
                style={{ color: "var(--ink-faint)" }}
              >
                How often
              </label>
              <select
                value={seconds}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  setSeconds(v);
                  if (active) void setCoverRotation(target, refId, active.category, v);
                }}
                className="w-full cursor-pointer rounded-xl px-2 py-1.5 text-[11.5px] font-semibold outline-none"
                style={{
                  background: "var(--surface-2)",
                  border: "1px solid var(--line)",
                  color: "var(--ink-soft)",
                }}
              >
                {ROTATE_INTERVALS.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>

            {active && (
              <button
                type="button"
                onClick={() => {
                  void setCoverRotation(target, refId, null, seconds);
                  setOpen(false);
                }}
                className="btn-ghost mt-2 w-full justify-center py-1.5 text-[11px] font-semibold"
              >
                Stop shuffling
              </button>
            )}
          </div>,
          document.body
        )}
    </>
  );
}
