"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Flame,
  Layers,
  Play,
  Plus,
  RotateCw,
  Shuffle,
  Trash2,
  X,
} from "lucide-react";
import { Drawer, SectionLabel } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import {
  DEADLINE_COLORS,
  RATING_META,
  type Flashcard,
  type RatingCounts,
  type ReviewRating,
  type ReviewStats,
} from "@/lib/types";

function StudyMode({
  deck,
  initialOrder,
  onExit,
  onRate,
  title,
}: {
  deck: Flashcard[];
  initialOrder: number[];
  onExit: () => void;
  onRate: (card: Flashcard, rating: ReviewRating) => void;
  title: string;
}) {
  const [order, setOrder] = useState(initialOrder);
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [tally, setTally] = useState<RatingCounts>({ easy: 0, good: 0, hard: 0, total: 0 });
  const card = deck[order[idx]];

  const go = (delta: number) => {
    setFlipped(false);
    setTimeout(() => setIdx((i) => (i + delta + order.length) % order.length), 120);
  };
  const shuffle = () => {
    setOrder((o) => [...o].sort(() => Math.random() - 0.5));
    setIdx(0);
    setFlipped(false);
  };

  const rate = (rating: ReviewRating) => {
    if (!card) return;
    onRate(card, rating);
    setTally((t) => ({ ...t, [rating]: t[rating] + 1, total: t.total + 1 }));
    go(1);
  };

  if (!card) return null;
  return (
    <div className="flex flex-col items-center gap-5 px-5 py-6 sm:px-6">
      <div className="flex w-full items-center justify-between">
        <p className="text-[11.5px] font-bold tracking-[0.12em] uppercase" style={{ color: "var(--ink-faint)" }}>
          {title} · card {idx + 1} of {order.length} · {card.subject}
        </p>
        <button onClick={onExit} className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold">
          <X size={13} /> Exit study
        </button>
      </div>

      {/* flip card */}
      <button
        onClick={() => setFlipped((f) => !f)}
        className="flip-scene w-full max-w-lg"
        aria-label={flipped ? "Show question" : "Reveal answer"}
      >
        <div className={`flip-inner ${flipped ? "flipped" : ""}`}>
          <div className="flip-face flex min-h-[240px] flex-col items-center justify-center gap-3 rounded-3xl p-8 text-center">
            <span className="text-[10px] font-bold tracking-[0.16em] uppercase" style={{ color: "var(--accent)" }}>
              Question
            </span>
            <p className="font-display text-[clamp(1.15rem,2.4vw,1.5rem)] leading-snug font-medium" style={{ color: "var(--ink)" }}>
              {card.front}
            </p>
            <span className="mt-2 flex items-center gap-1.5 text-[11px] font-semibold" style={{ color: "var(--ink-faint)" }}>
              <RotateCw size={11} /> tap to flip
            </span>
          </div>
          <div
            className="flip-face flip-back flex min-h-[240px] flex-col items-center justify-center gap-3 rounded-3xl p-8 text-center"
            style={{ background: "var(--accent)" }}
          >
            <span className="text-[10px] font-bold tracking-[0.16em] uppercase" style={{ color: "var(--accent-ink)", opacity: 0.75 }}>
              Answer
            </span>
            <p className="font-display text-[clamp(1.15rem,2.4vw,1.5rem)] leading-snug font-medium" style={{ color: "var(--accent-ink)" }}>
              {card.back}
            </p>
          </div>
        </div>
      </button>

      {/* how well did it go? each tap logs a review and advances */}
      <div className="flex w-full max-w-lg flex-col gap-2.5">
        <div className="grid grid-cols-3 gap-2">
          {(["hard", "good", "easy"] as ReviewRating[]).map((r) => (
            <button
              key={r}
              onClick={() => rate(r)}
              className="flex flex-col items-center gap-0.5 rounded-2xl px-3 py-2.5 font-bold transition-transform hover:-translate-y-0.5"
              style={{
                background: `${RATING_META[r].color}1f`,
                border: `1px solid ${RATING_META[r].color}`,
                color: RATING_META[r].color,
              }}
              title={RATING_META[r].hint}
            >
              <span className="text-[13px]">{RATING_META[r].label}</span>
              <span className="text-[10px] font-semibold opacity-80 tabular-nums">
                {tally[r]}
              </span>
            </button>
          ))}
        </div>

        <div className="flex items-center justify-center gap-2">
          <button onClick={() => go(-1)} aria-label="Previous card" className="btn-ghost h-10 w-10 !p-0">
            <ChevronLeft size={16} />
          </button>
          <button onClick={shuffle} aria-label="Shuffle deck" className="btn-ghost h-10 w-10 !p-0" title="Shuffle">
            <Shuffle size={15} />
          </button>
          <button onClick={() => go(1)} aria-label="Skip card" className="btn-ghost h-10 w-10 !p-0" title="Skip">
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function FlashcardsDrawer() {
  const { open, closeSection } = useSections();
  const { subjects } = useDashboard();
  const { push } = useToast();
  const [cards, setCards] = useState<Flashcard[] | null>(null);
  const [subjectFilter, setSubjectFilter] = useState<string>("all");
  const [study, setStudy] = useState<null | "all" | "hard">(null);
  const [stats, setStats] = useState<ReviewStats | null>(null);
  const [subject, setSubject] = useState("General");
  const [front, setFront] = useState("");
  const [back, setBack] = useState("");

  const load = useCallback(async () => {
    try {
      setCards(await api<Flashcard[]>("/api/flashcards"));
    } catch {
      push("error", "Couldn't load flashcards");
    }
    try {
      setStats(await api<ReviewStats>("/api/flashcard-reviews"));
    } catch {
      /* quiet — stats are a bonus */
    }
  }, [push]);

  useEffect(() => {
    if (open !== "flashcards") return;
    const id = setTimeout(() => {
      void load();
    }, 0);
    return () => clearTimeout(id);
  }, [open, load]);

  const subjectNames = useMemo(() => {
    const names = new Set<string>(subjects.map((s) => s.name));
    names.add("General");
    (cards ?? []).forEach((c) => names.add(c.subject));
    return [...names];
  }, [subjects, cards]);

  const filtered = useMemo(
    () => (cards ?? []).filter((c) => subjectFilter === "all" || c.subject === subjectFilter),
    [cards, subjectFilter]
  );

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!front.trim() || !back.trim()) return;
    try {
      const row = await api<Flashcard>("/api/flashcards", {
        method: "POST",
        body: { front: front.trim(), back: back.trim(), subject },
      });
      setCards((c) => [...(c ?? []), row]);
      setFront("");
      setBack("");
      push("success", "Flashcard added");
    } catch {
      push("error", "Couldn't add that card");
    }
  };

  /** log a rating, then keep the Hard pile in sync */
  const rateCard = useCallback(
    async (card: Flashcard, rating: ReviewRating) => {
      try {
        await api("/api/flashcard-reviews", {
          method: "POST",
          body: { cardId: card.id, rating, subject: card.subject },
        });
        setStats(await api<ReviewStats>("/api/flashcard-reviews"));
      } catch {
        push("error", "Couldn't save that rating");
      }
    },
    [push]
  );

  const hardDeck = useMemo(
    () => (cards ?? []).filter((c) => (stats?.hardCardIds ?? []).includes(c.id)),
    [cards, stats]
  );

  const remove = async (id: string) => {
    const before = cards;
    setCards((c) => (c ?? []).filter((x) => x.id !== id));
    try {
      await api(`/api/flashcards/${id}`, { method: "DELETE" });
      push("info", "Card moved to trash");
    } catch {
      setCards(before);
      push("error", "Couldn't delete that card");
    }
  };

  const colorFor = (name: string) =>
    DEADLINE_COLORS[subjects.find((s) => s.name === name)?.color ?? "blue"] ?? "#6c93bf";

  return (
    <Drawer
      open={open === "flashcards"}
      onClose={() => {
        setStudy(null);
        closeSection();
      }}
      title="Flashcards"
      subtitle={cards ? `${cards.length} cards across ${subjectNames.length} subjects` : "Loading…"}
      icon={<Layers size={18} />}
      size="lg"
    >
      {study === "all" && filtered.length > 0 ? (
        <StudyMode
          deck={filtered}
          initialOrder={filtered.map((_, i) => i)}
          onExit={() => setStudy(null)}
          onRate={rateCard}
          title="Study"
        />
      ) : study === "hard" && hardDeck.length > 0 ? (
        <StudyMode
          deck={hardDeck}
          initialOrder={hardDeck.map((_, i) => i)}
          onExit={() => setStudy(null)}
          onRate={rateCard}
          title="Hard pile"
        />
      ) : (
        <div className="flex flex-col gap-5 px-5 py-5 sm:px-6">
          <form
            onSubmit={submit}
            className="flex flex-col gap-2.5 rounded-3xl p-4"
            style={{ background: "var(--surface)", border: "1px solid var(--line)" }}
          >
            <div className="flex items-center gap-2">
              <Plus size={14} style={{ color: "var(--accent)" }} />
              <SectionLabel>New card</SectionLabel>
            </div>
            <select
              className="input-box"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              aria-label="Subject"
            >
              {subjectNames.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <input className="input-line" placeholder="Front — the question *" value={front} onChange={(e) => setFront(e.target.value)} required />
            <input className="input-line" placeholder="Back — the answer *" value={back} onChange={(e) => setBack(e.target.value)} required />
            <div className="flex justify-end">
              <button type="submit" disabled={!front.trim() || !back.trim()} className="btn-accent px-4 py-2 text-[12px] font-semibold disabled:opacity-50">
                <Check size={13} /> Add card
              </button>
            </div>
          </form>

          {/* cards you last rated Hard — a dedicated second pass */}
          {hardDeck.length > 0 && (
            <div
              className="flex flex-wrap items-center gap-3 rounded-3xl p-4"
              style={{
                background: `${RATING_META.hard.color}14`,
                border: `1px solid ${RATING_META.hard.color}`,
              }}
            >
              <span
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
                style={{ background: "var(--surface)", color: RATING_META.hard.color }}
              >
                <Flame size={18} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[13.5px] font-bold" style={{ color: "var(--ink)" }}>
                  {hardDeck.length} card{hardDeck.length === 1 ? "" : "s"} to review
                </p>
                <p className="text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
                  Everything you last marked Hard — drill them until they click.
                </p>
              </div>
              <button
                onClick={() => setStudy("hard")}
                className="px-4 py-2 text-[12px] font-bold text-white transition-transform hover:-translate-y-0.5"
                style={{ background: RATING_META.hard.color, borderRadius: 999 }}
              >
                <Play size={13} className="mr-1 inline" /> Review hard
              </button>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setSubjectFilter("all")}
              className="rounded-full px-3 py-1.5 text-[11.5px] font-bold"
              style={{
                background: subjectFilter === "all" ? "var(--accent)" : "var(--surface-2)",
                color: subjectFilter === "all" ? "var(--accent-ink)" : "var(--ink-soft)",
              }}
            >
              All · {cards?.length ?? 0}
            </button>
            {subjectNames.map((s) => (
              <button
                key={s}
                onClick={() => setSubjectFilter(s)}
                className="rounded-full px-3 py-1.5 text-[11.5px] font-bold"
                style={{
                  background: subjectFilter === s ? colorFor(s) : "var(--surface-2)",
                  color: subjectFilter === s ? "#fff" : "var(--ink-soft)",
                }}
              >
                {s}
              </button>
            ))}
            <span className="flex-1" />
            <button
              onClick={() => setStudy("all")}
              disabled={filtered.length === 0}
              className="btn-accent px-4 py-2 text-[12px] font-semibold disabled:opacity-40"
            >
              <Play size={13} /> Study {filtered.length > 0 ? `(${filtered.length})` : ""}
            </button>
          </div>

          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {filtered.map((c) => (
              <article
                key={c.id}
                className="group relative flex flex-col gap-1.5 rounded-2xl p-4"
                style={{ background: "var(--surface)", border: "1px solid var(--line-soft)" }}
              >
                <span
                  className="absolute top-4 left-0 h-9 w-1 rounded-r-full"
                  style={{ background: colorFor(c.subject) }}
                />
                <p className="pl-2 text-[10px] font-bold tracking-[0.12em] uppercase" style={{ color: colorFor(c.subject) }}>
                  {c.subject}
                </p>
                <p className="pl-2 text-[13.5px] leading-snug font-semibold" style={{ color: "var(--ink)" }}>
                  {c.front}
                </p>
                <p className="pl-2 text-[12.5px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>
                  {c.back}
                </p>
                <button
                  onClick={() => remove(c.id)}
                  aria-label="Delete card"
                  className="absolute top-3 right-3 flex h-7 w-7 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                  style={{ color: "var(--ink-faint)" }}
                >
                  <Trash2 size={12.5} />
                </button>
              </article>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="rounded-2xl px-4 py-10 text-center text-[13px]" style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}>
              No cards here yet — add your first above.
            </p>
          )}
        </div>
      )}
      <style>{`
        .flip-scene {
          perspective: 1200px;
          display: block;
          cursor: pointer;
        }
        .flip-inner {
          position: relative;
          min-height: 240px;
          transform-style: preserve-3d;
          transition: transform 0.55s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .flip-inner.flipped {
          transform: rotateY(180deg);
        }
        .flip-face {
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
          position: absolute;
          inset: 0;
          background: var(--surface);
          border: 1px solid var(--line);
          box-shadow: var(--card-shadow);
        }
        .flip-back {
          transform: rotateY(180deg);
          border: none;
        }
      `}</style>
    </Drawer>
  );
}
