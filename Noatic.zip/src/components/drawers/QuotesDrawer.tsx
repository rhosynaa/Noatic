"use client";

import { useState, type FormEvent } from "react";
import { Check, Pencil, Plus, Quote as QuoteIcon, Sparkles, Trash2 } from "lucide-react";
import { Drawer } from "@/components/ui";
import { useDashboard } from "@/lib/dashboard-context";
import { useSections } from "@/lib/sections-context";
import type { QuoteRow } from "@/lib/types";

function QuoteEditor({ q, onDone }: { q: QuoteRow; onDone: () => void }) {
  const { updateQuote } = useDashboard();
  const [text, setText] = useState(q.text);
  const [author, setAuthor] = useState(q.author);

  return (
    <form
      className="animate-pop flex flex-col gap-2.5 rounded-2xl p-3.5"
      style={{ background: "var(--surface)", border: "1px solid var(--line)" }}
      onSubmit={async (e) => {
        e.preventDefault();
        await updateQuote(q.id, { text, author });
        onDone();
      }}
    >
      <textarea
        className="min-h-[64px] w-full resize-y bg-transparent text-[13.5px] leading-relaxed outline-none"
        style={{ color: "var(--ink)" }}
        value={text}
        onChange={(e) => setText(e.target.value)}
        autoFocus
      />
      {q.kind === "quote" && (
        <input
          className="bg-transparent text-[12px] outline-none"
          style={{ color: "var(--ink-soft)" }}
          placeholder="Author"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
        />
      )}
      <div className="flex justify-end gap-1.5">
        <button type="button" onClick={onDone} className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold">
          Cancel
        </button>
        <button type="submit" disabled={!text.trim()} className="btn-accent px-3.5 py-1.5 text-[11.5px] font-semibold disabled:opacity-50">
          <Check size={12} /> Save
        </button>
      </div>
    </form>
  );
}

function QuoteGroup({ kind, title, icon }: { kind: "quote" | "motivation"; title: string; icon: React.ReactNode }) {
  const { quotes, addQuote, deleteQuote } = useDashboard();
  const [adding, setAdding] = useState(false);
  const [text, setText] = useState("");
  const [author, setAuthor] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const items = quotes.filter((q) => q.kind === kind);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    await addQuote({ text: text.trim(), author: author.trim(), kind });
    setText("");
    setAuthor("");
    setAdding(false);
  };

  return (
    <section>
      <div className="flex items-center justify-between px-1">
        <p className="flex items-center gap-2 text-[12.5px] font-bold" style={{ color: "var(--ink)" }}>
          <span style={{ color: "var(--accent)" }}>{icon}</span>
          {title}
          <span
            className="rounded-full px-2 py-0.5 text-[10px] font-bold"
            style={{ background: "var(--surface-3)", color: "var(--ink-soft)" }}
          >
            {items.length}
          </span>
        </p>
        <button
          onClick={() => setAdding((v) => !v)}
          className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
        >
          <Plus size={12.5} className={adding ? "rotate-45 transition-transform" : "transition-transform"} />
          Add
        </button>
      </div>

      {adding && (
        <form
          onSubmit={submit}
          className="animate-pop mt-2.5 flex flex-col gap-2.5 rounded-2xl p-3.5"
          style={{ background: "var(--accent-soft)", border: "1px dashed var(--accent)" }}
        >
          <textarea
            className="min-h-[52px] w-full resize-y bg-transparent text-[13.5px] leading-relaxed outline-none placeholder:opacity-60"
            style={{ color: "var(--ink)" }}
            placeholder={kind === "quote" ? "A line worth remembering…" : "A nudge for tired days…"}
            value={text}
            onChange={(e) => setText(e.target.value)}
            autoFocus
          />
          {kind === "quote" && (
            <input
              className="bg-transparent text-[12px] outline-none placeholder:opacity-60"
              style={{ color: "var(--ink-soft)" }}
              placeholder="Author (optional)"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
            />
          )}
          <div className="flex justify-end">
            <button type="submit" disabled={!text.trim()} className="btn-accent px-3.5 py-1.5 text-[11.5px] font-semibold disabled:opacity-50">
              <Check size={12} /> Add
            </button>
          </div>
        </form>
      )}

      <ul className="mt-2.5 flex flex-col gap-1.5">
        {items.map((q) =>
          editingId === q.id ? (
            <li key={q.id}>
              <QuoteEditor q={q} onDone={() => setEditingId(null)} />
            </li>
          ) : (
            <li
              key={q.id}
              className="group rounded-2xl p-3.5 transition-colors"
              style={{ background: "var(--surface)", border: "1px solid var(--line-soft)" }}
            >
              <p className="text-[13px] leading-relaxed" style={{ color: "var(--ink)" }}>
                “{q.text}”
              </p>
              <div className="mt-2 flex items-center justify-between gap-2">
                <p className="text-[11px] font-semibold" style={{ color: "var(--ink-faint)" }}>
                  {q.author ? `— ${q.author}` : ""}
                </p>
                <div className="flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={() => setEditingId(q.id)}
                    aria-label="Edit"
                    className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-3)]"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Pencil size={12} />
                  </button>
                  <button
                    onClick={() => deleteQuote(q.id)}
                    aria-label="Delete"
                    className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-red-500/10 hover:text-red-500"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            </li>
          )
        )}
        {items.length === 0 && (
          <li
            className="rounded-2xl px-4 py-6 text-center text-[12.5px]"
            style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}
          >
            Nothing here yet — press Add to plant one.
          </li>
        )}
      </ul>
    </section>
  );
}

export default function QuotesDrawer() {
  const { open, closeSection } = useSections();
  return (
    <Drawer
      open={open === "quotes"}
      onClose={closeSection}
      title="Daily words"
      subtitle="A random pair is drawn onto the dashboard every day"
      icon={<QuoteIcon size={18} />}
    >
      <div className="flex flex-col gap-7 px-5 py-5 sm:px-6">
        <div
          className="flex items-start gap-2.5 rounded-2xl px-4 py-3 text-[12px] leading-relaxed"
          style={{ background: "var(--accent-soft)", color: "var(--ink-soft)" }}
        >
          <Sparkles size={14} className="mt-0.5 shrink-0" style={{ color: "var(--accent)" }} />
          Quotes and motivations shuffle every midnight — keep at least one of each kind so
          the dashboard always has something lovely to say.
        </div>
        <QuoteGroup kind="quote" title="Quotes of the day" icon={<QuoteIcon size={14} />} />
        <QuoteGroup kind="motivation" title="Daily motivations" icon={<Sparkles size={14} />} />
      </div>
    </Drawer>
  );
}
