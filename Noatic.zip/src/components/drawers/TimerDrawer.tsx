"use client";

import { useState, type FormEvent } from "react";
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Coffee,
  ListPlus,
  Moon,
  Pause,
  Pencil,
  Play,
  Plus,
  RotateCcw,
  Save,
  SkipForward,
  Square,
  Sun,
  Timer,
  Trash2,
  Workflow,
  X,
} from "lucide-react";
import { Drawer, SectionLabel } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { useFocus } from "@/lib/focus-context";
import { useToast } from "@/lib/toast";
import {
  DEFAULT_PRESETS,
  TIMER_KIND_META,
  type ChainStep,
  type TimerChain,
  type TimerKind,
  type TimerPreset,
} from "@/lib/types";

const MODE_ICONS: Record<"focus" | "short" | "long", typeof Sun> = {
  focus: Sun,
  short: Coffee,
  long: Moon,
};

function fmt(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = (sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function TimerDrawer() {
  const { open, closeSection } = useSections();
  const { subjects } = useDashboard();
  const focus = useFocus();
  const { push } = useToast();

  const [builderOpen, setBuilderOpen] = useState(false);
  const [presetLabel, setPresetLabel] = useState("");
  const [presetMinutes, setPresetMinutes] = useState(40);
  const [presetSubject, setPresetSubject] = useState("");
  const [showPresetForm, setShowPresetForm] = useState(false);
  const [editingPresetId, setEditingPresetId] = useState<string | null>(null);

  /* builder state */
  const [chainName, setChainName] = useState("");
  const [steps, setSteps] = useState<ChainStep[]>([
    { kind: "focus", minutes: 40, label: "" },
    { kind: "short", minutes: 10, label: "" },
  ]);

  const [mode, setMode] = useState<"focus" | "short" | "long">("focus");

  const total = focus.totalSec;
  const pct = total ? focus.leftSec / total : 0;

  const selectPreset = (kind: TimerKind, minutes: number) => {
    setMode(kind === "short" ? "short" : kind === "long" ? "long" : "focus");
    focus.setDraft({ kind, minutes });
  };

  const closePresetForm = () => {
    setShowPresetForm(false);
    setEditingPresetId(null);
    setPresetLabel("");
    setPresetMinutes(40);
    setPresetSubject("");
  };

  const beginEditPreset = (p: TimerPreset) => {
    setEditingPresetId(p.id);
    setPresetLabel(p.label);
    setPresetMinutes(p.minutes);
    setPresetSubject(p.subject ?? "");
    setMode(p.kind === "short" ? "short" : p.kind === "long" ? "long" : "focus");
    setShowPresetForm(true);
  };

  const savePreset = async (e: FormEvent) => {
    e.preventDefault();
    if (!presetLabel.trim()) {
      push("error", "Give the preset a label first");
      return;
    }
    if (presetMinutes < 1) {
      push("error", "A preset needs at least 1 minute");
      return;
    }
    const ok = editingPresetId
      ? await focus.updatePreset(editingPresetId, {
          label: presetLabel.trim(),
          minutes: presetMinutes,
          kind: mode,
          subject: presetSubject,
        })
      : await focus.addPreset(presetLabel.trim(), presetMinutes, mode, presetSubject);
    if (ok) closePresetForm();
  };

  /* ---------- builder helpers ---------- */
  const updateStep = (i: number, patch: Partial<ChainStep>) =>
    setSteps((s) => s.map((st, idx) => (idx === i ? { ...st, ...patch } : st)));
  const moveStep = (i: number, dir: -1 | 1) =>
    setSteps((s) => {
      const j = i + dir;
      if (j < 0 || j >= s.length) return s;
      const copy = [...s];
      [copy[i], copy[j]] = [copy[j], copy[i]];
      return copy;
    });

  const builtChain = (saved?: TimerChain): TimerChain =>
    saved ?? {
      id: "draft",
      name: chainName.trim() || "Custom sequence",
      steps,
      subject: chainSubject,
      transitionSec: focus.transitionSec,
    };

  const canBuild = steps.length > 0 && steps.every((s) => s.minutes >= 1);

  /**
   * The chain's subject is derived from its steps — when every subject-bearing
   * step points at the same subject the chain belongs to it, otherwise it's a
   * mixed/any-subject sequence.
   */
  const chainSubject = (() => {
    const named = [...new Set(steps.map((s) => (s.subject ?? "").trim()).filter(Boolean))];
    return named.length === 1 ? named[0] : "";
  })();

  const [saving, setSaving] = useState(false);

  const saveChain = async () => {
    if (saving) return;
    if (!chainName.trim()) {
      push("error", "Give the sequence a name first");
      return;
    }
    if (!canBuild) {
      push("error", "Every step needs a duration of at least 1 minute");
      return;
    }
    setSaving(true);
    const row = await focus.addChain({
      name: chainName.trim(),
      steps,
      subject: chainSubject,
      transitionSec: focus.transitionSec,
    });
    setSaving(false);
    if (row) {
      setChainName("");
      setBuilderOpen(false);
    }
  };

  const todays = focus.sessions.filter(
    (s) => new Date(s.completedAt).toDateString() === new Date().toDateString()
  );

  return (
    <Drawer
      open={open === "timer"}
      onClose={closeSection}
      title="Focus timer"
      subtitle="Focus, breaks & custom sequences — every finish gets logged to analytics"
      icon={<Timer size={18} />}
      size="lg"
    >
      <div className="flex flex-col gap-6 px-5 py-6 sm:px-6">
        {/* ---------- chain progress ---------- */}
        {focus.chainRun && (
          <section
            className="rounded-3xl p-4"
            style={{ background: "var(--accent-soft)", border: "1px solid var(--accent)" }}
          >
            <div className="flex items-center justify-between gap-3">
              <p className="flex items-center gap-2 text-[12.5px] font-bold" style={{ color: "var(--ink)" }}>
                <Workflow size={14} style={{ color: "var(--accent)" }} />
                {focus.chainRun.name}
              </p>
              <span className="text-[11.5px] font-bold tabular-nums" style={{ color: "var(--accent)" }}>
                Session {focus.chainRun.index + 1} of {focus.chainRun.steps.length}
              </span>
            </div>
            <div className="mt-2.5 h-2 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${(((focus.chainRun.index + (total ? 1 - focus.leftSec / total : 0)) / focus.chainRun.steps.length) * 100).toFixed(1)}%`,
                  background: "var(--accent)",
                }}
              />
            </div>
            {focus.transition && (
              <p className="mt-2 text-[12px] font-bold tabular-nums" style={{ color: "var(--accent)" }}>
                Next: {focus.transition.next?.label || focus.transition.next?.kind}
                {focus.transition.next?.minutes ? ` (${focus.transition.next.minutes}m)` : ""} in{" "}
                {focus.transition.count}s…
              </p>
            )}
            <div className="mt-3 flex flex-wrap gap-2">
              <button onClick={focus.skipToNext} className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold">
                <SkipForward size={12.5} /> Skip to next
              </button>
              <button
                onClick={() => focus.pauseChain(!focus.chainPaused)}
                className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
              >
                {focus.chainPaused ? <Play size={12.5} /> : <Pause size={12.5} />}
                {focus.chainPaused ? "Resume chain" : "Pause chain"}
              </button>
              <button
                onClick={focus.stopChain}
                className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold hover:!text-red-500"
              >
                <Square size={12} /> Stop chain
              </button>
            </div>
          </section>
        )}

        {/* ---------- modes & presets ---------- */}
        <section className="flex flex-col items-center gap-4">
          <div
            className="flex w-full max-w-sm gap-1 rounded-full p-1"
            style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}
          >
            {(["focus", "short", "long"] as const).map((m) => {
              const Icon = MODE_ICONS[m];
              return (
                <button
                  key={m}
                  onClick={() => {
                    setMode(m);
                    focus.setDraft({ kind: m, minutes: DEFAULT_PRESETS[m][0] });
                  }}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-full px-3 py-2 text-[12px] font-bold transition-all"
                  style={{
                    background: mode === m ? "var(--accent)" : "transparent",
                    color: mode === m ? "var(--accent-ink)" : "var(--ink-soft)",
                  }}
                >
                  <Icon size={13} />
                  {TIMER_KIND_META[m].label}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap justify-center gap-1.5">
            {DEFAULT_PRESETS[mode].map((p) => (
              <button
                key={p}
                onClick={() => selectPreset(mode, p)}
                className="rounded-full px-4 py-2 text-[12px] font-bold transition-all"
                style={{
                  background: focus.kind === mode && focus.minutes === p ? "var(--accent)" : "var(--surface)",
                  color: focus.kind === mode && focus.minutes === p ? "var(--accent-ink)" : "var(--ink-soft)",
                  border: "1px solid var(--line)",
                }}
              >
                {p}m
              </button>
            ))}
            <button
              onClick={() => (showPresetForm ? closePresetForm() : setShowPresetForm(true))}
              className="rounded-full px-3.5 py-2 text-[12px] font-bold transition-all"
              style={{ background: "var(--accent-soft)", color: "var(--accent)", border: "1px dashed var(--accent)" }}
            >
              <Plus size={12} className="mr-0.5 inline" /> Custom time
            </button>
          </div>

          {showPresetForm && (
            <form
              onSubmit={savePreset}
              className="animate-pop flex w-full max-w-md flex-wrap items-center justify-center gap-2 rounded-2xl p-3"
              style={{ background: "var(--surface)", border: "1px solid var(--line)" }}
            >
              <input
                className="input-line !w-36"
                placeholder='Label — e.g. "Deep Work"'
                value={presetLabel}
                onChange={(e) => setPresetLabel(e.target.value)}
                maxLength={40}
                autoFocus
              />
              <input
                type="number"
                min={1}
                max={480}
                className="input-box !w-[76px] !px-2 !py-1.5 text-center !text-[12.5px]"
                value={presetMinutes}
                onChange={(e) => setPresetMinutes(Math.max(1, Number(e.target.value) || 1))}
                aria-label="Minutes"
              />
              <span className="text-[11.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
                min · {TIMER_KIND_META[mode].label}
              </span>
              <select
                className="input-box !w-auto !px-2 !py-1.5 !text-[12px]"
                value={presetSubject}
                onChange={(e) => setPresetSubject(e.target.value)}
                aria-label="Subject this preset belongs to"
                title="Which subject can use this preset"
              >
                <option value="">Any Subject</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.name}
                  </option>
                ))}
              </select>
              <button type="submit" className="btn-accent px-3 py-1.5 text-[11.5px] font-semibold">
                <Save size={12} /> {editingPresetId ? "Save changes" : "Save preset"}
              </button>
              {editingPresetId && (
                <button type="button" onClick={closePresetForm} className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold">
                  Cancel
                </button>
              )}
            </form>
          )}

          {focus.presets.length > 0 && (
            <div className="flex flex-wrap items-center justify-center gap-1.5">
              <span className="text-[10.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                Your presets
              </span>
              {focus.presets.map((p) => (
                <span
                  key={p.id}
                  className="group flex items-center overflow-hidden rounded-full"
                  style={{
                    background: focus.label === p.label && focus.minutes === p.minutes ? "var(--accent)" : "var(--surface)",
                    border: "1px solid var(--line)",
                  }}
                >
                  <button
                    onClick={() => {
                      focus.setDraft({ kind: p.kind, minutes: p.minutes, label: p.label });
                      setMode(p.kind === "short" ? "short" : p.kind === "long" ? "long" : "focus");
                    }}
                    className="px-3 py-1.5 text-[11.5px] font-bold"
                    style={{
                      color: focus.label === p.label && focus.minutes === p.minutes ? "var(--accent-ink)" : "var(--ink-soft)",
                    }}
                    title={`${TIMER_KIND_META[p.kind].label} · ${p.minutes} min · ${p.subject || "Any Subject"}`}
                  >
                    {p.label} · {p.minutes}m
                    <span className="ml-1 opacity-60">· {p.subject || "Any"}</span>
                  </button>
                  <button
                    onClick={() => beginEditPreset(p)}
                    aria-label={`Edit preset ${p.label}`}
                    className="px-0.5 opacity-40 transition-opacity group-hover:opacity-100 hover:!opacity-100"
                    style={{ color: "inherit" }}
                  >
                    <Pencil size={10.5} />
                  </button>
                  <button
                    onClick={() => focus.deletePreset(p.id)}
                    aria-label={`Delete preset ${p.label}`}
                    className="pr-2 pl-0.5 opacity-40 transition-opacity group-hover:opacity-100 hover:!opacity-100"
                    style={{ color: "inherit" }}
                  >
                    <X size={11} />
                  </button>
                </span>
              ))}
            </div>
          )}
        </section>

        {/* ---------- ring ---------- */}
        <section className="flex flex-col items-center gap-5">
          <div className="relative flex h-56 w-56 items-center justify-center">
            <svg viewBox="0 0 220 220" className="h-56 w-56 -rotate-90">
              <circle cx="110" cy="110" r="98" fill="none" stroke="var(--line)" strokeWidth="9" />
              <circle
                cx="110" cy="110" r="98"
                fill="none" stroke="var(--accent)" strokeWidth="9" strokeLinecap="round"
                strokeDasharray={`${pct * 615.7} 615.7`}
                style={{ transition: "stroke-dasharray 0.95s linear" }}
              />
            </svg>
            <div className="absolute text-center">
              <p className="font-display text-[52px] leading-none font-semibold tabular-nums" style={{ color: "var(--ink)" }}>
                {fmt(focus.leftSec)}
              </p>
              <p
                className="mt-2 text-[11px] font-bold tracking-[0.14em] uppercase"
                style={{ color: focus.running ? "var(--accent)" : "var(--ink-faint)" }}
              >
                {focus.running
                  ? TIMER_KIND_META[focus.kind].hint
                  : focus.sessionActive
                    ? "paused"
                    : "ready when you are"}
              </p>
              {focus.label ? (
                <p className="mt-1 max-w-[150px] truncate text-[11px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                  {focus.label}
                </p>
              ) : null}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={focus.toggle} className="btn-accent h-14 w-14 !rounded-full !p-0" aria-label={focus.running ? "Pause" : "Start"}>
              {focus.running ? <Pause size={20} /> : <Play size={20} className="ml-0.5" />}
            </button>
            <button onClick={focus.resetClock} className="btn-ghost h-12 w-12 !p-0" aria-label="Reset time">
              <RotateCcw size={17} />
            </button>
            {focus.sessionActive && (
              <button
                onClick={focus.cancelSession}
                className="btn-ghost h-12 w-12 !p-0 hover:!text-red-500"
                aria-label="Cancel session"
                title="Cancel session"
              >
                <X size={17} />
              </button>
            )}
          </div>

          <div className="flex w-full max-w-md flex-wrap items-center justify-center gap-2">
            <select
              className="input-box !w-auto !px-3 !py-1.5 !text-[12.5px]"
              value={focus.subject}
              onChange={(e) => focus.setDraft({ subject: e.target.value })}
              aria-label="Link session to a subject"
            >
              <option value="">Any Subject</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
            <input
              className="input-box !w-44 !px-3 !py-1.5 !text-[12.5px]"
              placeholder="Label (optional) — e.g. Reading"
              value={focus.label}
              maxLength={40}
              onChange={(e) => focus.setDraft({ label: e.target.value })}
            />
            <label className="flex items-center gap-1.5 text-[11.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
              Auto-advance
              <input
                type="number"
                min={0}
                max={60}
                className="input-box !w-[60px] !px-2 !py-1 text-center !text-[12px]"
                value={focus.transitionSec}
                onChange={(e) => focus.setTransitionSec(Number(e.target.value))}
                aria-label="Seconds between chain sessions"
              />
              s
            </label>
          </div>
        </section>

        {/* ---------- today's sessions ---------- */}
        <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
          <div className="flex items-center justify-between">
            <SectionLabel>Today&apos;s sessions</SectionLabel>
            <span className="text-[11.5px] font-bold tabular-nums" style={{ color: "var(--accent)" }}>
              {todays.reduce((a, s) => a + s.minutes, 0)} min total · {focus.todayStudyMinutes} min study
            </span>
          </div>
          <div className="mt-3 flex flex-col gap-1.5">
            {todays.map((s) => (
              <div key={s.id} className="flex items-center gap-3 rounded-xl px-3 py-2" style={{ background: "var(--surface-2)" }}>
                <CheckCircle2 size={14} style={{ color: "#52796f" }} />
                <span className="text-[12.5px] font-semibold" style={{ color: "var(--ink)" }}>
                  {s.minutes} min{" "}
                  {TIMER_KIND_META[(s.kind ?? "focus") as TimerKind]?.label.toLowerCase() ?? "focus"}
                  {s.label ? ` · ${s.label}` : ""}
                </span>
                {s.subject && (
                  <span className="rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                    {s.subject}
                  </span>
                )}
                <span className="flex-1" />
                <span className="text-[11px] tabular-nums" style={{ color: "var(--ink-faint)" }}>
                  {new Date(s.completedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            ))}
            {todays.length === 0 && (
              <p className="py-5 text-center text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
                No sessions yet today — pick a preset and press play.
              </p>
            )}
          </div>
        </section>

        {/* ---------- sequence builder ---------- */}
        <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
          <div className="flex items-center justify-between">
            <SectionLabel>Timer sequences</SectionLabel>
            <button
              onClick={() => setBuilderOpen((v) => !v)}
              className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
              style={builderOpen ? { color: "var(--accent)", borderColor: "var(--accent)" } : undefined}
            >
              <ListPlus size={13} /> Create Custom Sequence
            </button>
          </div>

          {builderOpen && (
            <div className="animate-pop mt-4 flex flex-col gap-3">
              {steps.map((st, i) => (
                <div
                  key={i}
                  className="flex flex-wrap items-center gap-2 rounded-2xl p-2.5"
                  style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
                >
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10.5px] font-bold" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                    {i + 1}
                  </span>
                  <select
                    className="input-box !w-[104px] !px-2 !py-1 !text-[12px]"
                    value={st.kind}
                    onChange={(e) => updateStep(i, { kind: e.target.value as TimerKind })}
                    aria-label="Step type"
                  >
                    {(Object.keys(TIMER_KIND_META) as TimerKind[]).map((k) => (
                      <option key={k} value={k}>
                        {TIMER_KIND_META[k].label}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min={1}
                    max={480}
                    className="input-box !w-[64px] !px-2 !py-1 text-center !text-[12px]"
                    value={st.minutes}
                    onChange={(e) => updateStep(i, { minutes: Math.max(1, Number(e.target.value) || 1) })}
                    aria-label="Duration in minutes"
                  />
                  <span className="text-[11px] font-semibold" style={{ color: "var(--ink-faint)" }}>min</span>
                  <select
                    className="input-box !w-[104px] !px-2 !py-1 !text-[12px]"
                    value={st.subject ?? ""}
                    onChange={(e) => updateStep(i, { subject: e.target.value || undefined })}
                    aria-label="Subject for this step"
                    title="Which subject this step is assigned to"
                  >
                    <option value="">Any Subject</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.name}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                  <input
                    className="input-line min-w-24 flex-1 !text-[12px]"
                    placeholder='Label — e.g. "Read Chapter 5"'
                    value={st.label ?? ""}
                    maxLength={40}
                    onChange={(e) => updateStep(i, { label: e.target.value || undefined })}
                  />
                  <div className="flex gap-0.5">
                    <button onClick={() => moveStep(i, -1)} className="btn-ghost h-7 w-7 !p-0" aria-label="Move up" disabled={i === 0}>
                      <ArrowUp size={12} />
                    </button>
                    <button onClick={() => moveStep(i, 1)} className="btn-ghost h-7 w-7 !p-0" aria-label="Move down" disabled={i === steps.length - 1}>
                      <ArrowDown size={12} />
                    </button>
                    <button
                      onClick={() => setSteps((s) => s.filter((_, idx) => idx !== i))}
                      className="btn-ghost h-7 w-7 !p-0 hover:!text-red-500"
                      aria-label="Remove step"
                      disabled={steps.length <= 1}
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}

              <button
                onClick={() => setSteps((s) => [...s, { kind: "focus", minutes: 25, label: "" }])}
                className="btn-ghost justify-center px-3 py-2 text-[12px] font-semibold"
              >
                <Plus size={13} /> Add step
              </button>

              <div className="flex flex-wrap items-center gap-2">
                <input
                  className="input-box flex-1 !min-w-40 !px-3 !py-2 !text-[12.5px]"
                  placeholder='Chain name — e.g. "Exam Prep Routine"'
                  value={chainName}
                  maxLength={60}
                  onChange={(e) => setChainName(e.target.value)}
                />
              </div>

              <div className="flex flex-wrap gap-2">
                <button onClick={saveChain} disabled={saving} className="btn-ghost px-3.5 py-2 text-[12px] font-semibold disabled:opacity-40">
                  <Save size={13} /> {saving ? "Saving…" : "Save chain"}
                </button>
                <button
                  onClick={() => canBuild && focus.startChain(builtChain())}
                  disabled={!canBuild}
                  className="btn-accent px-3.5 py-2 text-[12px] font-semibold disabled:opacity-40"
                >
                  <Play size={13} /> Start Chain
                </button>
              </div>
            </div>
          )}

          <div className="mt-4 flex flex-col gap-1.5">
            {focus.chains.map((c) => (
              <div key={c.id} className="group flex items-center gap-3 rounded-2xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}>
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                  <Workflow size={14} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-bold" style={{ color: "var(--ink)" }}>
                    {c.name}
                    {c.subject && (
                      <span className="ml-2 rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                        {c.subject}
                      </span>
                    )}
                  </p>
                  <p className="truncate text-[11px]" style={{ color: "var(--ink-faint)" }}>
                    {c.steps.length} sessions · {c.steps.reduce((a, s) => a + s.minutes, 0)} min total
                  </p>
                </div>
                <button onClick={() => focus.startChain(c)} className="btn-accent h-8 w-8 !rounded-full !p-0" aria-label={`Start chain ${c.name}`}>
                  <Play size={13} className="ml-0.5" />
                </button>
                <button
                  onClick={() => focus.deleteChain(c.id)}
                  className="flex h-8 w-8 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                  style={{ color: "var(--ink-faint)" }}
                  aria-label={`Delete chain ${c.name}`}
                >
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
            {focus.chains.length === 0 && !builderOpen && (
              <p className="py-4 text-center text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
                No saved sequences — build one to run study blocks back-to-back.
              </p>
            )}
          </div>
        </section>

      </div>
    </Drawer>
  );
}
