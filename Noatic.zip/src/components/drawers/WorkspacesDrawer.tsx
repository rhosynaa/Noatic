"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { BookMarked, Check, ChevronRight, Pencil, Plus, Trash2, X } from "lucide-react";
import { Drawer } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import type { Workspace } from "@/lib/types";

type WorkspaceWithCount = Workspace & { subjectCount: number };

export default function WorkspacesDrawer() {
  const { open, closeSection, openWorkspace, workspace: activeWs } = useSections();
  const { reloadAll } = useDashboard();
  const { push } = useToast();
  const isOpen = open === "workspaces";

  const [workspaces, setWorkspaces] = useState<WorkspaceWithCount[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      setWorkspaces(await api<WorkspaceWithCount[]>("/api/workspaces"));
    } catch {
      /* quiet */
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [isOpen, load]);

  useEffect(() => {
    if (editingId) inputRef.current?.focus();
  }, [editingId]);

  const addWorkspace = async () => {
    try {
      const row = await api<WorkspaceWithCount>("/api/workspaces", { method: "POST", body: {} });
      setWorkspaces((w) => [...w, row]);
      push("success", `"${row.name}" created — click it to manage its subjects`);
      // jump straight into rename so the default "Workspace n" is easy to change
      setEditingId(row.id);
      setDraft(row.name);
    } catch {
      push("error", "Couldn't create that workspace");
    }
  };

  const saveRename = async (id: string) => {
    const name = draft.trim();
    const current = workspaces.find((w) => w.id === id);
    setEditingId(null);
    if (!name || name === current?.name) {
      setDraft("");
      return;
    }
    setWorkspaces((w) => w.map((x) => (x.id === id ? { ...x, name } : x)));
    try {
      await api(`/api/workspaces/${id}`, { method: "PATCH", body: { name } });
      push("success", "Workspace renamed");
    } catch {
      push("error", "Couldn't rename that workspace");
      void load();
    }
  };

  const remove = async (ws: WorkspaceWithCount) => {
    const before = workspaces;
    setWorkspaces((w) => w.filter((x) => x.id !== ws.id));
    try {
      await api(`/api/workspaces/${ws.id}`, { method: "DELETE" });
      push("success", `"${ws.name}" deleted`);
      // its subjects went with it — keep every subject picker in sync
      await reloadAll();
    } catch {
      setWorkspaces(before);
      push("error", "Couldn't delete that workspace");
    }
  };

  return (
    <Drawer
      open={isOpen}
      onClose={closeSection}
      title="Subjects"
      subtitle="Pick a workspace to open its subject dashboard"
      icon={<BookMarked size={18} />}
    >
      <div className="flex flex-col gap-5 px-5 py-5 sm:px-6">
        <button
          onClick={addWorkspace}
          className="btn-ghost w-full justify-center gap-2 rounded-3xl px-4 py-3.5 text-[13px] font-semibold"
          style={{ background: "var(--surface)", borderStyle: "dashed" }}
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-full" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
            <Plus size={14} />
          </span>
          Add workspace
        </button>

        <div className="flex flex-col gap-2">
          {workspaces.map((ws) => {
            const editing = editingId === ws.id;
            return (
              <div
                key={ws.id}
                role="button"
                tabIndex={0}
                onClick={() => {
                  if (!editing) openWorkspace({ id: ws.id, name: ws.name });
                }}
                onKeyDown={(e) => {
                  if (!editing && (e.key === "Enter" || e.key === " "))
                    openWorkspace({ id: ws.id, name: ws.name });
                }}
                className="group flex cursor-pointer items-center gap-3.5 rounded-2xl p-4 transition-all hover:-translate-y-0.5"
                style={{
                  background: "var(--surface)",
                  border: `1px solid ${activeWs?.id === ws.id ? "var(--accent)" : "var(--line-soft)"}`,
                }}
              >
                <span
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl"
                  style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                >
                  <BookMarked size={17} />
                </span>
                <div className="min-w-0 flex-1">
                  {editing ? (
                    <div
                      className="flex items-center gap-1.5"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <input
                        ref={inputRef}
                        className="input-line flex-1 !py-1 font-display text-[16.5px] font-semibold"
                        value={draft}
                        onChange={(e) => setDraft(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") void saveRename(ws.id);
                          if (e.key === "Escape") {
                            setEditingId(null);
                            setDraft("");
                          }
                        }}
                        maxLength={40}
                        aria-label="Workspace name"
                      />
                      <button
                        onClick={() => void saveRename(ws.id)}
                        aria-label="Save name"
                        className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-[var(--accent-soft)]"
                        style={{ color: "var(--accent)" }}
                      >
                        <Check size={13} />
                      </button>
                      <button
                        onClick={() => {
                          setEditingId(null);
                          setDraft("");
                        }}
                        aria-label="Cancel rename"
                        className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-2)]"
                        style={{ color: "var(--ink-faint)" }}
                      >
                        <X size={13} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <p className="font-display truncate text-[16.5px] font-semibold" style={{ color: "var(--ink)" }}>
                        {ws.name}
                      </p>
                      <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                        {ws.subjectCount
                          ? `${ws.subjectCount} subject${ws.subjectCount === 1 ? "" : "s"}`
                          : "No subjects yet"}
                      </p>
                    </>
                  )}
                </div>
                {!editing && (
                  <>
                    <span className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingId(ws.id);
                          setDraft(ws.name);
                        }}
                        aria-label={`Rename ${ws.name}`}
                        className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-[var(--accent-soft)] hover:text-[var(--accent)]"
                        style={{ color: "var(--ink-faint)" }}
                      >
                        <Pencil size={13} />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          void remove(ws);
                        }}
                        aria-label={`Delete ${ws.name}`}
                        className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-red-500/10 hover:text-red-500"
                        style={{ color: "var(--ink-faint)" }}
                      >
                        <Trash2 size={13.5} />
                      </button>
                    </span>
                    <ChevronRight
                      size={15}
                      className="shrink-0 transition-transform group-hover:translate-x-0.5"
                      style={{ color: "var(--ink-faint)" }}
                    />
                  </>
                )}
              </div>
            );
          })}
          {workspaces.length === 0 && (
            <p className="rounded-2xl px-4 py-10 text-center text-[13px]" style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}>
              No workspaces yet — add one above to start grouping your subjects.
            </p>
          )}
        </div>

        <p className="rounded-2xl px-4 py-3 text-[11.5px] leading-relaxed" style={{ background: "var(--accent-soft)", color: "var(--ink-soft)" }}>
          Each workspace keeps its own subjects. Deleting a workspace removes only its
          labels — notes, deadlines and flashcards are never touched.
        </p>
      </div>
    </Drawer>
  );
}
