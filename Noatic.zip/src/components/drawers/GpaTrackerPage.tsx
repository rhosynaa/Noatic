"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  ArrowLeft,
  Award,
  BarChart3,
  CalendarDays,
  Check,
  ClipboardList,
  GraduationCap,
  NotebookPen,
  Plus,
  Scale,
  SlidersHorizontal,
  Target,
  Trash2,
  X,
} from "lucide-react";
import { useSections } from "@/lib/sections-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import { Modal, ModalHeader, Toggle } from "@/components/ui";
import {
  GPA_COURSE_NOTES_MAX_WORDS,
  GPA_COURSE_NOTES_WORDS_PER_LINE,
  GPA_GOAL_MAX_WORDS,
  GPA_GOAL_WORDS_PER_LINE,
  GPA_NOTES_MAX_WORDS,
  GPA_NOTES_WORDS_PER_LINE,
  GPA_PERCENT,
  GPA_WEIGHTS,
  GRADE_POINTS,
  countWords,
  wrapByWords,
  type GpaCourse,
  type GpaSemester,
  type GpaSettings,
} from "@/lib/types";

/**
 * Textarea that caps its content at `maxWords` and reflows the text so a line
 * never holds more than `perLine` words.
 */
function WordArea({
  value,
  onChange,
  maxWords,
  perLine,
  rows,
  placeholder,
  ariaLabel,
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  maxWords: number;
  perLine: number;
  rows: number;
  placeholder?: string;
  ariaLabel: string;
  className?: string;
}) {
  const used = countWords(value);
  const full = used >= maxWords;
  return (
    <div>
      <textarea
        rows={rows}
        value={value}
        placeholder={placeholder}
        aria-label={ariaLabel}
        onChange={(e) => onChange(wrapByWords(e.target.value, maxWords, perLine))}
        className={`input-box w-full resize-y leading-relaxed ${className}`}
        style={{ whiteSpace: "pre-wrap" }}
      />
      <p
        className="mt-1 text-[10px] font-semibold"
        style={{ color: full ? "var(--accent)" : "var(--ink-faint)" }}
      >
        {used}/{maxWords} words{full ? " — limit reached" : ""} · {perLine} per line
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* calculation logic — the same formulas the GPA calculator uses       */
/* ------------------------------------------------------------------ */

const gradePoints = (grade: string, settings: GpaSettings) => settings.scale[grade] ?? 0;

/** points in effect for a course under the active weighted/unweighted mode */
const effectivePoints = (c: GpaCourse, settings: GpaSettings) =>
  gradePoints(c.grade, settings) + (settings.weighted ? c.weight : 0);

const qualityPoints = (c: GpaCourse, settings: GpaSettings) =>
  c.credits * effectivePoints(c, settings);

function summarize(courses: GpaCourse[], settings: GpaSettings) {
  const credits = courses.reduce((a, c) => a + c.credits, 0);
  const qp = courses.reduce((a, c) => a + qualityPoints(c, settings), 0);
  return { credits, qp, gpa: credits > 0 ? qp / credits : 0 };
}

const fmt1 = (n: number) => (Number.isInteger(n) ? String(n) : n.toFixed(1));
const fmt2 = (n: number) => n.toFixed(2);

/* small building blocks ------------------------------------------------ */

function Card({
  icon,
  title,
  subtitle,
  action,
  children,
  className = "",
}: {
  icon?: React.ReactNode;
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`card p-5 ${className}`}>
      <div className="mb-3.5 flex items-center gap-2">
        {icon && (
          <span
            className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl"
            style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
          >
            {icon}
          </span>
        )}
        <div className="min-w-0 flex-1">
          <h3
            className="text-[11px] font-bold tracking-[0.12em] uppercase"
            style={{ color: "var(--ink-soft)" }}
          >
            {title}
          </h3>
          {subtitle && (
            <p className="mt-0.5 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
              {subtitle}
            </p>
          )}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function StatLine({
  label,
  value,
  big = false,
  operator,
}: {
  label: string;
  value: string;
  big?: boolean;
  operator?: string;
}) {
  return (
    <>
      {operator && (
        <p
          aria-hidden
          className="pl-1 text-[11px] font-bold"
          style={{ color: "var(--ink-faint)" }}
        >
          {operator}
        </p>
      )}
      <div className="flex items-center gap-3">
        <span className="flex-1 text-[12.5px]" style={{ color: "var(--ink-soft)" }}>
          {label}
        </span>
        <span
          className={`rounded-xl px-3 py-1.5 text-right ${big ? "min-w-[86px]" : "min-w-[64px]"}`}
          style={{
            background: big ? "var(--accent-soft)" : "var(--surface-2)",
            color: big ? "var(--accent)" : "var(--ink)",
          }}
        >
          <span className={`font-semibold ${big ? "font-display text-[19px]" : "text-[13px]"}`}>
            {value}
          </span>
        </span>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* grading scale settings modal                                          */
/* ------------------------------------------------------------------ */

function ScaleSettingsModal({
  settings,
  onPatch,
  onClose,
}: {
  settings: GpaSettings;
  onPatch: (body: Partial<GpaSettings>) => void;
  onClose: () => void;
}) {
  return (
    <Modal open onClose={onClose}>
      <ModalHeader
        title="Grading scale settings"
        subtitle="Point values per grade — the whole tracker uses these"
        onClose={onClose}
      />
      <div
        className="flex-1 overflow-y-auto px-6 py-5"
        style={{ background: "var(--surface)" }}
      >
        <Toggle
          checked={settings.weighted}
          onChange={(v) => onPatch({ weighted: v })}
          label="Weighted calculation"
          hint="Apply AP/IB & Honors bonuses (+1.0 / +0.5) on top of grade points"
        />
        {!settings.weighted && (
          <p className="mt-1.5 text-[11px]" style={{ color: "var(--ink-faint)" }}>
            Unweighted mode — quality points use the plain grade value.
          </p>
        )}

        <p
          className="mt-5 mb-2 text-[10.5px] font-bold tracking-[0.12em] uppercase"
          style={{ color: "var(--ink-faint)" }}
        >
          Point value per grade
        </p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
          {Object.keys(GRADE_POINTS).map((g) => (
            <label key={g} className="flex items-center gap-2">
              <span
                className="w-6 shrink-0 text-[12px] font-bold"
                style={{ color: "var(--ink)" }}
              >
                {g}
              </span>
              <input
                type="number"
                min={0}
                max={10}
                step={0.1}
                value={settings.scale[g] ?? 0}
                onChange={(e) => onPatch({ scale: { ...settings.scale, [g]: Number(e.target.value) } })}
                aria-label={`Point value for ${g}`}
                className="input-box w-full !px-2 !py-1 text-center text-[12px]"
              />
              <span className="w-14 shrink-0 text-[10px]" style={{ color: "var(--ink-faint)" }}>
                {GPA_PERCENT[g]}
              </span>
            </label>
          ))}
        </div>

        <div
          className="mt-5 rounded-2xl px-3.5 py-2.5 text-[11.5px] leading-relaxed"
          style={{ background: "var(--surface-2)", color: "var(--ink-soft)" }}
        >
          <p className="font-bold" style={{ color: "var(--ink)" }}>
            Course bonuses in weighted mode
          </p>
          {GPA_WEIGHTS.map((w) => (
            <p key={w.value} className="mt-0.5 flex justify-between">
              <span>{w.label}</span>
              <span className="font-bold">+{w.value.toFixed(1)}</span>
            </p>
          ))}
        </div>

        <div className="mt-5 flex items-center justify-between gap-2 pb-1">
          <button
            onClick={() => onPatch({ scale: { ...GRADE_POINTS } })}
            className="btn-ghost px-3 py-1.5 text-[12px] font-semibold"
          >
            Reset to defaults
          </button>
          <button onClick={onClose} className="btn-accent px-4 py-2 text-[12.5px] font-semibold">
            <Check size={13} /> Done
          </button>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ */
/* the GPA tracker page                                                  */
/* ------------------------------------------------------------------ */

export default function GpaTrackerPage() {
  const { open, closeSection } = useSections();
  const { push } = useToast();
  const isOpen = open === "gpatracker";

  const [courses, setCourses] = useState<GpaCourse[]>([]);
  const [semesters, setSemesters] = useState<GpaSemester[]>([]);
  const [settings, setSettings] = useState<GpaSettings | null>(null);
  const [activeIdx, setActiveIdx] = useState(0);
  const [scaleOpen, setScaleOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const [cs, sems, st] = await Promise.all([
        api<GpaCourse[]>("/api/gpa-courses"),
        api<GpaSemester[]>("/api/gpa-semesters"),
        api<GpaSettings>("/api/gpa-settings"),
      ]);
      setCourses(cs);
      setSemesters(sems);
      setSettings(st);
    } catch {
      /* quiet */
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [isOpen, load]);

  /* Escape closes + body scroll locks while the page owns the screen */
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeSection();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [isOpen, closeSection]);

  /* ---------- mutations (optimistic, rollback on error) ---------- */

  const patchCourse = async (id: string, body: Partial<GpaCourse>) => {
    setCourses((cs) => cs.map((c) => (c.id === id ? { ...c, ...body } : c)));
    try {
      await api(`/api/gpa-courses/${id}`, { method: "PATCH", body });
    } catch {
      push("error", "Couldn't update that course");
      void load();
    }
  };

  const addCourse = async () => {
    const active = semesters[activeIdx];
    if (!active) return;
    try {
      const row = await api<GpaCourse>("/api/gpa-courses", {
        method: "POST",
        body: { name: "", grade: "A", credits: 3, weight: 0, semesterId: active.id, notes: "" },
      });
      setCourses((cs) => [...cs, row]);
    } catch {
      push("error", "Couldn't add that course");
    }
  };

  const removeCourse = async (id: string) => {
    const before = courses;
    setCourses((cs) => cs.filter((c) => c.id !== id));
    try {
      await api(`/api/gpa-courses/${id}`, { method: "DELETE" });
    } catch {
      setCourses(before);
      push("error", "Couldn't remove that course");
    }
  };

  const patchSemester = async (id: string, body: Partial<GpaSemester>) => {
    setSemesters((ss) => ss.map((s) => (s.id === id ? { ...s, ...body } : s)));
    try {
      await api(`/api/gpa-semesters/${id}`, { method: "PATCH", body });
    } catch {
      push("error", "Couldn't save that semester");
      void load();
    }
  };

  const patchSettings = async (body: Partial<GpaSettings>) => {
    setSettings((s) => (s ? { ...s, ...body } : s));
    try {
      await api("/api/gpa-settings", { method: "PATCH", body });
    } catch {
      push("error", "Couldn't save those settings");
      void load();
    }
  };

  /* ---------- action-plan steps (fully editable: tick / type / add / delete) ---------- */

  const PLAN_STEP_CAP = 20;
  const planListRef = useRef<HTMLDivElement | null>(null);

  /** put the caret into step `index` once the row has rendered */
  const focusPlanStep = (index: number) =>
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        planListRef.current
          ?.querySelectorAll<HTMLInputElement>("input[data-plan-step]")
          [index]?.focus();
      })
    );

  const togglePlanStep = (index: number) => {
    const active = semesters[activeIdx];
    if (!active) return;
    patchSemester(active.id, {
      checklist: active.checklist.map((c, j) => (j === index ? { ...c, done: !c.done } : c)),
    });
  };

  const editPlanStep = (index: number, text: string) => {
    const active = semesters[activeIdx];
    if (!active) return;
    patchSemester(active.id, {
      checklist: active.checklist.map((c, j) => (j === index ? { ...c, text } : c)),
    });
  };

  /** insert a blank step at `index` (defaults to the end) and focus it */
  const addPlanStep = (index?: number) => {
    const active = semesters[activeIdx];
    if (!active || active.checklist.length >= PLAN_STEP_CAP) return;
    const at = index ?? active.checklist.length;
    const next = [...active.checklist];
    next.splice(at, 0, { text: "", done: false });
    patchSemester(active.id, { checklist: next });
    focusPlanStep(at);
  };

  const removePlanStep = (index: number) => {
    const active = semesters[activeIdx];
    if (!active) return;
    patchSemester(active.id, { checklist: active.checklist.filter((_, j) => j !== index) });
    focusPlanStep(Math.max(0, index - 1));
  };

  /* ---------- derived ---------- */

  const active = semesters[activeIdx];
  const activeCourses = useMemo(
    () => (active ? courses.filter((c) => c.semesterId === active.id) : []),
    [courses, active]
  );
  const semSum = useMemo(
    () => (settings ? summarize(activeCourses, settings) : { credits: 0, qp: 0, gpa: 0 }),
    [activeCourses, settings]
  );
  const cumSum = useMemo(
    () => (settings ? summarize(courses, settings) : { credits: 0, qp: 0, gpa: 0 }),
    [courses, settings]
  );
  const alt = useMemo(() => {
    if (!settings) return { sem: { u: 0, w: 0 }, cum: { u: 0, w: 0 } };
    const un: GpaSettings = { ...settings, weighted: false };
    const wn: GpaSettings = { ...settings, weighted: true };
    return {
      sem: { u: summarize(activeCourses, un).gpa, w: summarize(activeCourses, wn).gpa },
      cum: { u: summarize(courses, un).gpa, w: summarize(courses, wn).gpa },
    };
  }, [settings, activeCourses, courses]);

  const semesterGpa = useCallback(
    (semId: string) => {
      if (!settings) return 0;
      return summarize(courses.filter((c) => c.semesterId === semId), settings).gpa;
    },
    [courses, settings]
  );

  if (!isOpen || typeof document === "undefined") return null;

  const thCls = "px-2 py-2 text-left align-middle whitespace-nowrap";
  const thStyle = {
    background: "rgba(109, 158, 125, 0.14)",
    color: "var(--ink-soft)",
    borderBottom: "1px solid var(--line-soft)",
  } as const;
  const tdCls = "px-2 py-1.5 align-middle";
  const tdStyle = { borderBottom: "1px solid var(--line-soft)" } as const;

  return createPortal(
    <div
      role="dialog"
      aria-modal
      aria-label="GPA tracker"
      className="animate-fade-up fixed inset-0 z-[108] flex flex-col"
      style={{ background: "var(--bg)" }}
    >
      {/* ---------- page header ---------- */}
      <div
        className="shrink-0 border-b"
        style={{ borderColor: "var(--line-soft)", background: "var(--surface)" }}
      >
        <div className="mx-auto flex w-full max-w-5xl items-center gap-3 px-5 py-4 sm:px-6">
          <button onClick={closeSection} className="btn-ghost h-9 w-9 shrink-0 !p-0" aria-label="Back">
            <ArrowLeft size={16} />
          </button>
          <span
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
            style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
          >
            <GraduationCap size={18} />
          </span>
          <div className="min-w-0 flex-1">
            <h2 className="font-display truncate text-xl font-semibold" style={{ color: "var(--ink)" }}>
              GPA Tracker
            </h2>
            <p className="mt-0.5 truncate text-[12px]" style={{ color: "var(--ink-soft)" }}>
              Track your progress. Stay consistent. Reach your goals.
            </p>
          </div>
          {settings && (
            <span
              className="hidden shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold tracking-[0.08em] uppercase sm:block"
              style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
            >
              {settings.weighted ? "Weighted" : "Unweighted"}
            </span>
          )}
          <button
            onClick={() => setScaleOpen(true)}
            aria-label="Grading scale settings"
            className="btn-ghost shrink-0 px-3 py-1.5 text-[12px] font-semibold"
          >
            <SlidersHorizontal size={13} />
            <span className="hidden sm:inline">Grading scale</span>
          </button>
          <button
            onClick={closeSection}
            aria-label="Close"
            className="btn-ghost h-8 w-8 shrink-0 !p-0"
            style={{ border: "none" }}
          >
            <X size={17} />
          </button>
        </div>
      </div>

      {/* ---------- page body ---------- */}
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto flex w-full max-w-5xl flex-col gap-4 px-5 py-6 sm:px-6">
          {settings && active && (
            <>
              {/* semester switcher */}
              <div className="animate-fade-up flex flex-wrap items-center gap-1.5">
                <span
                  className="mr-1 text-[10.5px] font-bold tracking-[0.12em] uppercase"
                  style={{ color: "var(--ink-faint)" }}
                >
                  Semester
                </span>
                {semesters.map((s, i) => (
                  <button
                    key={s.id}
                    onClick={() => setActiveIdx(i)}
                    aria-pressed={i === activeIdx}
                    title={s.name}
                    className="flex h-8 w-8 items-center justify-center rounded-full text-[12px] font-bold transition-all hover:-translate-y-0.5"
                    style={{
                      background: i === activeIdx ? "var(--accent)" : "var(--surface)",
                      color: i === activeIdx ? "var(--accent-ink)" : "var(--ink-soft)",
                      border: i === activeIdx ? "none" : "1px solid var(--line)",
                      boxShadow: i === activeIdx ? "0 8px 18px -8px var(--accent)" : "none",
                    }}
                  >
                    {i + 1}
                  </button>
                ))}
              </div>

              {/* 1 — header inputs: semester + academic year */}
              <Card icon={<CalendarDays size={14} />} title="Term details" className="animate-fade-up">
                <div className="flex flex-col gap-3 sm:flex-row">
                  <label className="flex-1">
                    <span className="mb-1 block text-[10.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                      Semester
                    </span>
                    <input
                      className="input-line w-full"
                      placeholder="e.g. Fall — Semester 1"
                      value={active.name}
                      maxLength={40}
                      onChange={(e) => patchSemester(active.id, { name: e.target.value })}
                      aria-label="Semester"
                    />
                  </label>
                  <label className="flex-1">
                    <span className="mb-1 block text-[10.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                      Academic year
                    </span>
                    <input
                      className="input-line w-full"
                      placeholder="e.g. 2024 – 2025"
                      value={active.academicYear}
                      maxLength={24}
                      onChange={(e) => patchSemester(active.id, { academicYear: e.target.value })}
                      aria-label="Academic year"
                    />
                  </label>
                </div>
              </Card>

              {/* 2 — dynamic course table */}
              <Card
                icon={<GraduationCap size={14} />}
                title="Course table"
                subtitle={`${active.name || `Semester ${activeIdx + 1}`}${active.academicYear ? ` · ${active.academicYear}` : ""}`}
                action={
                  <button
                    onClick={() => void addCourse()}
                    className="btn-ghost px-2.5 py-1 text-[10.5px] font-bold"
                    style={{ background: "var(--surface-2)", borderStyle: "dashed" }}
                  >
                    <Plus size={11} /> Add course
                  </button>
                }
                className="animate-fade-up"
              >
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[720px] border-collapse">
                    <thead>
                      <tr>
                        <th className={thCls} style={{ ...thStyle, borderTopLeftRadius: 12 }}>
                          Course
                          <span className="block text-[9px] font-semibold normal-case opacity-70">
                            Subject &amp; number
                          </span>
                        </th>
                        <th className={`${thCls} text-center`} style={thStyle}>
                          Credits
                          <span className="block text-[9px] font-semibold normal-case opacity-70">Hours</span>
                        </th>
                        <th className={`${thCls} text-center`} style={thStyle}>
                          Grade
                          <span className="block text-[9px] font-semibold normal-case opacity-70">Earned</span>
                        </th>
                        <th className={`${thCls} text-center`} style={thStyle}>
                          Grade points
                          <span className="block text-[9px] font-semibold normal-case opacity-70">Value</span>
                        </th>
                        <th className={`${thCls} text-center`} style={thStyle}>
                          Quality points
                          <span className="block text-[9px] font-semibold normal-case opacity-70">
                            Credits × Value
                          </span>
                        </th>
                        <th className={thCls} style={thStyle}>
                          Notes
                        </th>
                        <th className={thCls} style={{ ...thStyle, borderTopRightRadius: 12 }} aria-label="Row actions" />
                      </tr>
                    </thead>
                    <tbody>
                      {activeCourses.map((c) => (
                        <tr key={c.id} className="group">
                          <td className={tdCls} style={tdStyle}>
                            <input
                              className="input-line w-full min-w-[150px] !py-1.5 text-[12.5px]"
                              placeholder="e.g. BIO 101"
                              value={c.name}
                              maxLength={40}
                              onChange={(e) => patchCourse(c.id, { name: e.target.value })}
                              aria-label={`Course name for ${c.name || "new course"}`}
                            />
                          </td>
                          <td className={`${tdCls} text-center`} style={tdStyle}>
                            <input
                              type="number"
                              min={0}
                              max={20}
                              step={0.5}
                              className="input-box w-14 !px-1.5 !py-1 text-center text-[12px]"
                              value={c.credits}
                              onChange={(e) => patchCourse(c.id, { credits: Number(e.target.value) })}
                              aria-label={`Credit hours for ${c.name}`}
                            />
                          </td>
                          <td className={`${tdCls} text-center`} style={tdStyle}>
                            <select
                              className="input-box cursor-pointer !px-1.5 !py-1 text-[12px]"
                              value={c.grade}
                              onChange={(e) => patchCourse(c.id, { grade: e.target.value })}
                              aria-label={`Grade earned for ${c.name}`}
                            >
                              {Object.keys(GRADE_POINTS).map((g) => (
                                <option key={g} value={g}>
                                  {g}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td
                            className={`${tdCls} text-center text-[12.5px] font-semibold`}
                            style={{ ...tdStyle, color: "var(--ink-soft)" }}
                          >
                            {gradePoints(c.grade, settings).toFixed(1)}
                            {settings.weighted && c.weight > 0 && (
                              <span className="block text-[9px] font-bold" style={{ color: "var(--accent)" }}>
                                +{c.weight.toFixed(1)} bonus
                              </span>
                            )}
                          </td>
                          <td
                            className={`${tdCls} text-center text-[13px] font-bold`}
                            style={{ ...tdStyle, color: "var(--accent)" }}
                          >
                            {qualityPoints(c, settings).toFixed(1)}
                          </td>
                          <td className={tdCls} style={tdStyle}>
                            {/* behaves like the goal box: up to 70 words, max 25 per line */}
                            {(() => {
                              const text = c.notes ?? "";
                              const used = countWords(text);
                              const full = used >= GPA_COURSE_NOTES_MAX_WORDS;
                              const rows = Math.min(4, Math.max(1, text.split("\n").length));
                              return (
                                <>
                                  <textarea
                                    rows={rows}
                                    className="input-line w-full min-w-[190px] resize-y !py-1 text-[12px] leading-relaxed"
                                    style={{ whiteSpace: "pre-wrap" }}
                                    placeholder="—"
                                    value={text}
                                    onChange={(e) =>
                                      patchCourse(c.id, {
                                        notes: wrapByWords(
                                          e.target.value,
                                          GPA_COURSE_NOTES_MAX_WORDS,
                                          GPA_COURSE_NOTES_WORDS_PER_LINE
                                        ),
                                      })
                                    }
                                    aria-label={`Notes for ${c.name || "course"}`}
                                  />
                                  {used >= 55 && (
                                    <p
                                      className="pr-0.5 text-right text-[9px] font-semibold"
                                      style={{ color: full ? "var(--accent)" : "var(--ink-faint)" }}
                                    >
                                      {used}/{GPA_COURSE_NOTES_MAX_WORDS} words
                                      {full ? " — max" : ""}
                                    </p>
                                  )}
                                </>
                              );
                            })()}
                          </td>
                          <td className={`${tdCls} text-center`} style={tdStyle}>
                            <button
                              onClick={() => void removeCourse(c.id)}
                              aria-label={`Remove ${c.name}`}
                              className="flex h-7 w-7 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                              style={{ color: "var(--ink-faint)" }}
                            >
                              <Trash2 size={12.5} />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {activeCourses.length === 0 && (
                        <tr>
                          <td
                            colSpan={7}
                            className="px-2 py-8 text-center text-[12.5px]"
                            style={{ color: "var(--ink-faint)" }}
                          >
                            No courses in this semester yet — tap &ldquo;+ Add course&rdquo;.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* semester totals strip — auto-updates in real time */}
                <div
                  className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-2xl px-4 py-3"
                  style={{ background: "var(--accent-soft)" }}
                >
                  <span
                    className="text-[10px] font-bold tracking-[0.12em] uppercase"
                    style={{ color: "var(--accent)" }}
                  >
                    Semester totals
                  </span>
                  <span className="flex-1" />
                  <span className="text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
                    Total credits earned{" "}
                    <b className="ml-1" style={{ color: "var(--ink)" }}>
                      {fmt1(semSum.credits)}
                    </b>
                  </span>
                  <span className="text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
                    Total quality points{" "}
                    <b className="ml-1" style={{ color: "var(--ink)" }}>
                      {semSum.qp.toFixed(1)}
                    </b>
                  </span>
                  <span className="text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
                    Semester GPA{" "}
                    <b className="font-display ml-1 text-[18px]" style={{ color: "var(--accent)" }}>
                      {fmt2(semSum.gpa)}
                    </b>
                  </span>
                </div>
                <p className="mt-2 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                  Grade points come from your grading scale
                  {settings.weighted ? " plus AP/IB & Honors bonuses (weighted mode)" : " (unweighted mode)"}
                  {" — "}editable in Grading scale settings.
                </p>
              </Card>

              {/* 3 — summaries */}
              <div className="grid gap-4 sm:grid-cols-2">
                <Card icon={<Award size={14} />} title="Semester GPA summary" className="animate-fade-up">
                  <div className="flex flex-col gap-1.5">
                    <StatLine label="Total quality points" value={semSum.qp.toFixed(1)} />
                    <StatLine label="Total credits earned" value={fmt1(semSum.credits)} operator="÷" />
                    <StatLine
                      label={`Semester GPA (${settings.weighted ? "weighted" : "unweighted"})`}
                      value={fmt2(semSum.gpa)}
                      big
                      operator="="
                    />
                  </div>
                  <p className="mt-2.5 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                    Unweighted {fmt2(alt.sem.u)} · Weighted {fmt2(alt.sem.w)}
                  </p>
                </Card>
                <Card icon={<BarChart3 size={14} />} title="Cumulative GPA tracker" className="animate-fade-up">
                  <div className="flex flex-col gap-1.5">
                    <StatLine label="Total quality points earned (all semesters)" value={cumSum.qp.toFixed(1)} />
                    <StatLine label="Total credits earned (all semesters)" value={fmt1(cumSum.credits)} operator="÷" />
                    <StatLine
                      label={`Cumulative GPA (${settings.weighted ? "weighted" : "unweighted"})`}
                      value={fmt2(cumSum.gpa)}
                      big
                      operator="="
                    />
                  </div>
                  <p className="mt-2.5 text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                    Unweighted {fmt2(alt.cum.u)} · Weighted {fmt2(alt.cum.w)}
                  </p>
                </Card>
              </div>

              {/* 4 — scale reference · goal */}
              <div className="grid gap-4 lg:grid-cols-2">
                <Card icon={<Scale size={14} />} title="GPA scale" subtitle="Reference — values follow your settings" className="animate-fade-up">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="text-left text-[9.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                        <th className="pb-1.5">Grade</th>
                        <th className="pb-1.5 text-center">Value</th>
                        <th className="pb-1.5 text-right">Percentage</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.keys(GRADE_POINTS).map((g) => (
                        <tr key={g} style={{ borderTop: "1px solid var(--line-soft)" }}>
                          <td className="py-1 text-[12px] font-bold" style={{ color: "var(--ink)" }}>
                            {g}
                          </td>
                          <td className="py-1 text-center text-[12px] font-semibold" style={{ color: "var(--accent)" }}>
                            {(settings.scale[g] ?? 0).toFixed(1)}
                          </td>
                          <td className="py-1 text-right text-[11px]" style={{ color: "var(--ink-soft)" }}>
                            {GPA_PERCENT[g]}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </Card>

                <Card icon={<Target size={14} />} title="GPA goal" subtitle={`for ${active.name || `Semester ${activeIdx + 1}`}`} className="animate-fade-up">
                  <label className="block">
                    <span className="mb-1 block text-[9.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                      My goal
                    </span>
                    <WordArea
                      value={active.targetGpa}
                      onChange={(v) => patchSemester(active.id, { targetGpa: v })}
                      maxWords={GPA_GOAL_MAX_WORDS}
                      perLine={GPA_GOAL_WORDS_PER_LINE}
                      rows={3}
                      placeholder="e.g. Hold a 4.0 by handing every lab report in two days early and revising with active recall."
                      ariaLabel="My goal"
                      className="!p-2.5 text-[12.5px]"
                    />
                  </label>
                  <label className="mt-2.5 block">
                    <span className="mb-1 block text-[9.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                      I will achieve this by
                    </span>
                    <input
                      type="date"
                      className="input-box w-full !py-1.5 text-[12px]"
                      value={active.achieveBy}
                      onChange={(e) => patchSemester(active.id, { achieveBy: e.target.value })}
                      aria-label="I will achieve this by"
                    />
                  </label>

                  <div className="mt-3.5 mb-1.5 flex items-center gap-2">
                    <p className="flex-1 text-[9.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                      Action plan
                    </p>
                    <span className="text-[10px]" style={{ color: "var(--ink-faint)" }}>
                      {active.checklist.filter((c) => c.done).length}/{active.checklist.length} done
                    </span>
                  </div>
                  {/* every step is editable: tick it, retype it, delete it, add more.
                      the list scrolls on its own once there are more than five. */}
                  <div
                    ref={planListRef}
                    className="gpa-plan-scroll flex max-h-[172px] flex-col gap-1 overflow-y-auto pr-1"
                  >
                    {active.checklist.map((item, i) => (
                      <div key={i} className="flex shrink-0 items-center gap-1.5">
                        <button
                          onClick={() => togglePlanStep(i)}
                          role="checkbox"
                          aria-checked={item.done}
                          title={item.done ? "Mark not done" : "Mark done"}
                          aria-label={`Mark step "${item.text || `step ${i + 1}`}" ${item.done ? "not done" : "done"}`}
                          className="flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-md transition-all hover:scale-110"
                          style={{
                            border: `1.5px solid ${item.done ? "var(--accent)" : "var(--ink-faint)"}`,
                            background: item.done ? "var(--accent)" : "transparent",
                          }}
                        >
                          {item.done && <Check size={11} color="var(--accent-ink)" strokeWidth={3.5} />}
                        </button>
                        <input
                          value={item.text}
                          maxLength={80}
                          data-plan-step
                          placeholder="New step…"
                          aria-label={`Action plan step ${i + 1}`}
                          onChange={(e) => editPlanStep(i, e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              addPlanStep(i + 1);
                            }
                          }}
                          className="input-line min-w-0 flex-1 !py-1 text-[12px]"
                          style={{
                            color: item.done ? "var(--ink-faint)" : "var(--ink)",
                            textDecoration: item.done ? "line-through" : "none",
                          }}
                        />
                        {/* always visible — deleting a step shouldn't require discovering a hover state */}
                        <button
                          onClick={() => removePlanStep(i)}
                          aria-label={`Delete step ${i + 1}`}
                          title="Delete step"
                          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md opacity-50 transition-all hover:bg-red-500/10 hover:text-red-500 hover:opacity-100 focus-visible:opacity-100"
                          style={{ color: "var(--ink-faint)" }}
                        >
                          <Trash2 size={11} />
                        </button>
                      </div>
                    ))}
                    {active.checklist.length === 0 && (
                      <p className="px-1 py-3 text-center text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                        No steps yet — add your first one below.
                      </p>
                    )}
                  </div>
                  <button
                    onClick={() => addPlanStep()}
                    disabled={active.checklist.length >= PLAN_STEP_CAP}
                    className="btn-ghost mt-1.5 w-full justify-center py-1.5 text-[11.5px] font-semibold disabled:opacity-40"
                    style={{ borderStyle: "dashed" }}
                  >
                    <Plus size={12} />{" "}
                    {active.checklist.length >= PLAN_STEP_CAP ? `${PLAN_STEP_CAP} steps max` : "Add step"}
                  </button>
                </Card>

              </div>

              {/* 4c — semester progress (full width: the goals are sentences now) */}
              <Card icon={<ClipboardList size={14} />} title="Semester progress" subtitle="Tick a semester off yourself once you've hit its goal" className="animate-fade-up">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[640px] border-collapse">
                    <thead>
                      <tr className="text-left text-[9.5px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                        <th className="pb-1.5 pl-1">Semester</th>
                        <th className="pb-1.5 text-center">GPA</th>
                        <th className="pb-1.5 pl-3">Goal</th>
                        <th className="pb-1.5 pr-1 text-center">
                          Achieved?
                          <span
                            className="mt-0.5 block text-[8.5px] font-semibold tracking-[0.02em] normal-case"
                            style={{ color: "var(--ink-faint)" }}
                          >
                            tap the box
                          </span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {semesters.map((s, i) => {
                        const has = courses.some((c) => c.semesterId === s.id);
                        const gpa = semesterGpa(s.id);
                        return (
                          <tr
                            key={s.id}
                            style={{
                              borderTop: "1px solid var(--line-soft)",
                              background:
                                i === activeIdx
                                  ? "var(--accent-soft)"
                                  : s.achieved
                                    ? "rgba(109, 158, 125, 0.06)"
                                    : "transparent",
                            }}
                          >
                            <td className="py-1.5 pr-1 pl-1 align-top text-[12px] font-bold whitespace-nowrap" style={{ color: "var(--ink)" }}>
                              {i + 1}
                              <span className="ml-1.5 font-medium" style={{ color: "var(--ink-faint)" }}>
                                {s.name.replace(/^Semester \d$/, "")}
                              </span>
                            </td>
                            <td className="py-1.5 text-center align-top text-[12px] font-semibold" style={{ color: has ? "var(--accent)" : "var(--ink-faint)" }}>
                              {has ? fmt2(gpa) : "—"}
                            </td>
                            <td className="py-1 pl-3 align-top">
                              {(() => {
                                const used = countWords(s.targetGpa);
                                const full = used >= GPA_GOAL_MAX_WORDS;
                                // grow the box with the goal: up to 4 visible lines,
                                // then the textarea scrolls — it never hides your words
                                const lineCount = s.targetGpa.split("\n").length;
                                const rows = Math.min(4, Math.max(2, lineCount));
                                return (
                                  <>
                                    <textarea
                                      rows={rows}
                                      className="input-line w-full min-w-[220px] resize-y !py-1 !text-[11.5px] leading-relaxed"
                                      style={{ whiteSpace: "pre-wrap" }}
                                      placeholder="What does success look like this semester?"
                                      value={s.targetGpa}
                                      onChange={(e) =>
                                        patchSemester(s.id, {
                                          targetGpa: wrapByWords(
                                            e.target.value,
                                            GPA_GOAL_MAX_WORDS,
                                            GPA_GOAL_WORDS_PER_LINE
                                          ),
                                        })
                                      }
                                      aria-label={`Goal for semester ${i + 1}`}
                                    />
                                    {used >= 40 && (
                                      <p
                                        className="pr-0.5 text-right text-[9px] font-semibold"
                                        style={{ color: full ? "var(--accent)" : "var(--ink-faint)" }}
                                      >
                                        {used}/{GPA_GOAL_MAX_WORDS} words
                                        {full ? " — max" : ""}
                                      </p>
                                    )}
                                  </>
                                );
                              })()}
                            </td>
                            <td className="py-1.5 pr-1 text-center align-top">
                              {/*
                                  a tick box you can actually see: 2px ink border + a
                                  faint ghost tick when empty, solid green when done
                                */}
                              <button
                                role="checkbox"
                                aria-checked={!!s.achieved}
                                aria-label={`Semester ${i + 1} goal ${s.achieved ? "achieved — click to untick" : "not achieved — click to tick"}`}
                                title={s.achieved ? "Achieved — click to untick" : "Click to tick it off"}
                                onClick={() => patchSemester(s.id, { achieved: !s.achieved })}
                                className="group/tick mx-auto mt-0.5 flex h-7 w-7 items-center justify-center rounded-lg transition-all duration-150 hover:scale-110 hover:shadow-md active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6d9e7d]"
                                style={{
                                  border: `2px solid ${s.achieved ? "#6d9e7d" : "var(--ink-faint)"}`,
                                  background: s.achieved ? "#6d9e7d" : "var(--surface-2)",
                                  boxShadow: s.achieved
                                    ? "0 2px 10px rgba(109, 158, 125, 0.4)"
                                    : "inset 0 1px 2px rgba(0, 0, 0, 0.05)",
                                }}
                              >
                                <Check
                                  size={15}
                                  strokeWidth={3.5}
                                  color={s.achieved ? "#ffffff" : "var(--ink-soft)"}
                                  className={
                                    s.achieved
                                      ? ""
                                      : "opacity-30 transition-opacity duration-150 group-hover/tick:opacity-70"
                                  }
                                />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <p className="mt-2 text-[10px]" style={{ color: "var(--ink-faint)" }}>
                  Tick the box yourself — it stays exactly how you leave it.
                </p>
              </Card>

              {/* 5 — notes & reflections */}
              <Card icon={<NotebookPen size={14} />} title="Notes & reflections" className="animate-fade-up">
                <WordArea
                  value={settings.notes}
                  onChange={(v) => patchSettings({ notes: v })}
                  maxWords={GPA_NOTES_MAX_WORDS}
                  perLine={GPA_NOTES_WORDS_PER_LINE}
                  rows={5}
                  placeholder="Anything to remember — what worked, what to change next term…"
                  ariaLabel="Notes and reflections"
                  className="min-h-[130px] !p-3 text-[13px]"
                />
              </Card>

              <p
                className="rounded-2xl px-4 py-3 text-center text-[11.5px] font-semibold tracking-[0.06em]"
                style={{ background: "var(--accent-soft)", color: "var(--ink-soft)" }}
              >
                Consistent effort today, a brighter future tomorrow.
              </p>
            </>
          )}
        </div>
      </div>

      {/* ---------- grading scale settings modal ---------- */}
      {settings && scaleOpen && (
        <ScaleSettingsModal settings={settings} onPatch={patchSettings} onClose={() => setScaleOpen(false)} />
      )}
    </div>,
    document.body
  );
}
