"use client";

import { useEffect, useRef, useState } from "react";
import {
  BookMarked,
  Check,
  ChevronLeft,
  ChevronRight,
  Link2,
  Network,
  NotebookPen,
  Pencil,
  Pin,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import { Drawer } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import MindmapLinkPicker from "@/components/mindmap/MindmapLinkPicker";
import {
  useMindmapsList,
  useOpenLinkTarget,
  type MindMapInfo,
} from "@/lib/mindmap-nav";
import type { MindMapLink } from "@/lib/types";

export default function MindmapsDrawer() {
  const { open, closeSection, openMindmap, closeMindmap, mindmap: activeMap } = useSections();
  const { notes, subjects } = useDashboard();
  const { push } = useToast();
  const isOpen = open === "mindmap";

  const { maps, refresh } = useMindmapsList();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const openTarget = useOpenLinkTarget();

  /* "maps" = the regular list · "links" = the grouped links space */
  const [view, setView] = useState<"maps" | "links">("maps");
  /* the map a "view all" button was pressed on — scrolled into focus */
  const [focusMapId, setFocusMapId] = useState<string | null>(null);
  const groupRefs = useRef<Record<string, HTMLElement | null>>({});

  /* reopening the drawer always lands back on the plain map list */
  const [wasOpen, setWasOpen] = useState(isOpen);
  if (isOpen !== wasOpen) {
    setWasOpen(isOpen);
    if (isOpen) {
      setView("maps");
      setFocusMapId(null);
      setEditingId(null);
    }
  }

  useEffect(() => {
    if (!isOpen) return;
    void refresh();
  }, [isOpen, refresh]);

  useEffect(() => {
    if (editingId) inputRef.current?.focus();
  }, [editingId]);

  /* landing in the links space from a map's "view all" scrolls to its group */
  useEffect(() => {
    if (view !== "links" || !focusMapId) return;
    const raf = requestAnimationFrame(() => {
      groupRefs.current[focusMapId]?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    return () => cancelAnimationFrame(raf);
  }, [view, focusMapId]);

  const addMap = async () => {
    try {
      const row = await api<MindMapInfo>("/api/mindmaps", { method: "POST", body: {} });
      await refresh();
      push("success", `"${row.name}" created — click it to open the canvas`);
      // jump straight into rename so the default "Mind map n" is easy to change
      setEditingId(row.id);
      setDraft(row.name);
    } catch {
      push("error", "Couldn't create that mind map");
    }
  };

  const saveRename = async (id: string) => {
    const name = draft.trim();
    const current = maps.find((m) => m.id === id);
    setEditingId(null);
    if (!name || name === current?.name) {
      setDraft("");
      return;
    }
    try {
      await api(`/api/mindmaps/${id}`, { method: "PATCH", body: { name } });
      await refresh();
      push("success", "Mind map renamed");
    } catch {
      push("error", "Couldn't rename that mind map");
    }
  };

  const remove = async (m: MindMapInfo) => {
    try {
      await api(`/api/mindmaps/${m.id}`, { method: "DELETE" });
      await refresh();
      // deleting the map whose canvas is open closes the canvas too
      if (activeMap?.id === m.id) closeMindmap();
      push("success", `"${m.name}" deleted`);
    } catch {
      push("error", "Couldn't delete that mind map");
    }
  };

  const patchLink = (updated: MindMapInfo) => {
    void refresh();
    void updated;
  };

  /* ---------------- links ---------------- */

  const linksOf = (m: MindMapInfo): MindMapLink[] => m.links ?? [];

  /** label for one link — works for notes and subjects, alive or deleted */
  const linkLabel = (link: MindMapLink): { kind: "note" | "subject"; text: string } => {
    if (link.type === "note") {
      const n = notes.find((x) => x.id === link.id);
      return { kind: "note", text: n ? n.title || "Untitled note" : "Missing note" };
    }
    const s = subjects.find((x) => x.id === link.id);
    return { kind: "subject", text: s ? s.name : "Missing subject" };
  };

  const totalLinks = maps.reduce((n, m) => n + linksOf(m).length, 0);
  const linkedMaps = maps.filter((m) => linksOf(m).length > 0);

  const openLinksSpace = (mapId: string | null) => {
    setEditingId(null);
    setDraft("");
    setFocusMapId(mapId);
    setView("links");
  };

  return (
    <Drawer
      open={isOpen}
      onClose={closeSection}
      title="Mind maps"
      subtitle={
        view === "links"
          ? "Every note & subject your maps point to"
          : "Pick a map to open its canvas"
      }
      icon={<Network size={18} />}
    >
      <div className="flex flex-col gap-5 px-5 py-5 sm:px-6">
        {view === "maps" ? (
          <>
            <button
              onClick={addMap}
              className="btn-ghost w-full justify-center gap-2 rounded-3xl px-4 py-3.5 text-[13px] font-semibold"
              style={{ background: "var(--surface)", borderStyle: "dashed" }}
            >
              <span
                className="flex h-7 w-7 items-center justify-center rounded-full"
                style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
              >
                <Plus size={14} />
              </span>
              Add mind map
            </button>

            {/* the links space — pinned at the top of the subbar, can't be deleted */}
            <button
              type="button"
              onClick={() => openLinksSpace(null)}
              title="Every note and subject your maps point to — pinned here, it can't be removed"
              className="group flex w-full cursor-pointer items-center gap-3.5 rounded-2xl p-4 text-left transition-all hover:-translate-y-0.5"
              style={{ background: "var(--surface-2)", border: "1px solid var(--line-soft)" }}
            >
              <span
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl"
                style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
              >
                <Link2 size={17} />
              </span>
              <span className="min-w-0 flex-1">
                <span
                  className="font-display flex items-center gap-1.5 text-[16.5px] font-semibold"
                  style={{ color: "var(--ink)" }}
                >
                  All linked items
                  <Pin
                    size={11}
                    style={{ color: "var(--ink-faint)" }}
                    aria-label="Pinned — can't be deleted"
                  />
                </span>
                <span className="block text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                  {totalLinks === 0
                    ? "Every link you add gathers here, grouped by map"
                    : `${totalLinks} link${totalLinks === 1 ? "" : "s"} across ${linkedMaps.length} map${linkedMaps.length === 1 ? "" : "s"}`}
                </span>
              </span>
              <ChevronRight
                size={15}
                className="shrink-0 transition-transform group-hover:translate-x-0.5"
                style={{ color: "var(--ink-faint)" }}
              />
            </button>

            <div className="flex flex-col gap-2">
              {maps.map((m) => {
                const editing = editingId === m.id;
                const ml = linksOf(m);
                const first = ml[0] ? linkLabel(ml[0]) : null;
                return (
                  <div
                    key={m.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => {
                      if (!editing) openMindmap({ id: m.id, name: m.name });
                    }}
                    onKeyDown={(e) => {
                      if (!editing && (e.key === "Enter" || e.key === " "))
                        openMindmap({ id: m.id, name: m.name });
                    }}
                    className="group flex cursor-pointer items-center gap-3.5 rounded-2xl p-4 transition-all hover:-translate-y-0.5"
                    style={{
                      background: "var(--surface)",
                      border: `1px solid ${activeMap?.id === m.id ? "var(--accent)" : "var(--line-soft)"}`,
                    }}
                  >
                    <span
                      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl"
                      style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                    >
                      <Network size={17} />
                    </span>
                    <div className="min-w-0 flex-1">
                      {editing ? (
                        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                          <input
                            ref={inputRef}
                            className="input-line flex-1 !py-1 font-display text-[16.5px] font-semibold"
                            value={draft}
                            onChange={(e) => setDraft(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") void saveRename(m.id);
                              if (e.key === "Escape") {
                                setEditingId(null);
                                setDraft("");
                              }
                            }}
                            maxLength={40}
                            aria-label="Mind map name"
                          />
                          <button
                            onClick={() => void saveRename(m.id)}
                            aria-label="Save name"
                            className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-[var(--accent-soft)]"
                            style={{ color: "var(--accent)" }}
                          >
                            <Check size={13} />
                          </button>
                          <button
                            onClick={() => {
                              setEditingId(null);
                              setDraft("");
                            }}
                            aria-label="Cancel rename"
                            className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-2)]"
                            style={{ color: "var(--ink-faint)" }}
                          >
                            <X size={13} />
                          </button>
                        </div>
                      ) : (
                        <>
                          <p
                            className="font-display truncate text-[16.5px] font-semibold"
                            style={{ color: "var(--ink)" }}
                          >
                            {m.name}
                          </p>
                          <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                            {m.nodeCount ? `${m.nodeCount} node${m.nodeCount === 1 ? "" : "s"}` : "Empty canvas"}
                          </p>
                          {first && (
                            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  void openTarget({ type: first.kind, id: ml[0].id });
                                }}
                                title={`Open linked ${first.kind}: ${first.text}`}
                                className="flex max-w-full items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-bold transition-transform hover:scale-[1.03]"
                                style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                              >
                                {first.kind === "note" ? <NotebookPen size={10.5} /> : <BookMarked size={10.5} />}
                                <span className="truncate">{first.text}</span>
                                <ChevronRight size={10} />
                              </button>
                              {/* more than one link → small straight-to-the-space button */}
                              {ml.length > 1 && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    openLinksSpace(m.id);
                                  }}
                                  title={`${m.name} has ${ml.length} links — view them all grouped`}
                                  className="flex items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-bold transition-transform hover:scale-[1.03]"
                                  style={{
                                    border: "1px dashed var(--accent)",
                                    color: "var(--accent)",
                                  }}
                                >
                                  +{ml.length - 1} · View all
                                </button>
                              )}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                    {!editing && (
                      <>
                        <span
                          className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MindmapLinkPicker
                            map={m}
                            onChanged={patchLink}
                            label="Link"
                            className="flex h-8 items-center gap-1 rounded-full px-2 text-[11px] font-semibold transition-colors hover:bg-[var(--accent-soft)] hover:text-[var(--accent)]"
                            iconSize={11.5}
                          />
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingId(m.id);
                              setDraft(m.name);
                            }}
                            aria-label={`Rename ${m.name}`}
                            className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-[var(--accent-soft)] hover:text-[var(--accent)]"
                            style={{ color: "var(--ink-faint)" }}
                          >
                            <Pencil size={13} />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              void remove(m);
                            }}
                            aria-label={`Delete ${m.name}`}
                            className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-red-500/10 hover:text-red-500"
                            style={{ color: "var(--ink-faint)" }}
                          >
                            <Trash2 size={13.5} />
                          </button>
                        </span>
                        <ChevronRight
                          size={15}
                          className="shrink-0 transition-transform group-hover:translate-x-0.5"
                          style={{ color: "var(--ink-faint)" }}
                        />
                      </>
                    )}
                  </div>
                );
              })}
              {maps.length === 0 && (
                <p
                  className="rounded-2xl px-4 py-10 text-center text-[13px]"
                  style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}
                >
                  No mind maps yet — add one above and start connecting ideas.
                </p>
              )}
            </div>

            <div
              className="rounded-2xl px-4 py-3 text-[11.5px] leading-relaxed"
              style={{ background: "var(--accent-soft)", color: "var(--ink-soft)" }}
            >
              Each map keeps its own canvas of nodes. Use <b>Link</b> on any map to tie
              it to as many notes and subjects as you like — the chips jump you there
              in one click, and <b>All linked items</b> above keeps every link grouped
              by its map. That space is pinned: it can’t be renamed or deleted.
            </div>
          </>
        ) : (
          /* -------- the links space: every map as a group, its links as chips -------- */
          <>
            <button
              type="button"
              onClick={() => setView("maps")}
              className="btn-ghost self-start gap-1.5 px-3.5 py-2 text-[12px] font-semibold"
            >
              <ChevronLeft size={13} /> All maps
            </button>

            <div className="flex flex-col gap-3">
              {linkedMaps.map((m) => {
                const ml = linksOf(m);
                return (
                  <section
                    key={m.id}
                    ref={(el) => {
                      groupRefs.current[m.id] = el;
                    }}
                    aria-label={`Links of ${m.name}`}
                    className="rounded-2xl p-3.5 transition-colors"
                    style={{
                      background: "var(--surface)",
                      border: `1.5px solid ${focusMapId === m.id ? "var(--accent)" : "var(--line-soft)"}`,
                    }}
                  >
                    <div
                      role="button"
                      tabIndex={0}
                      onClick={() => openMindmap({ id: m.id, name: m.name })}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ")
                          openMindmap({ id: m.id, name: m.name });
                      }}
                      className="group flex w-full cursor-pointer items-center gap-3 rounded-xl p-1.5 text-left transition-colors hover:bg-[var(--surface-2)]"
                    >
                      <span
                        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                        style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                      >
                        <Network size={15} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span
                          className="font-display block truncate text-[15px] font-semibold"
                          style={{ color: "var(--ink)" }}
                        >
                          {m.name}
                        </span>
                        <span className="block text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                          {ml.length} linked · {m.nodeCount} node{m.nodeCount === 1 ? "" : "s"} · open canvas
                        </span>
                      </span>
                      <ChevronRight
                        size={14}
                        className="shrink-0 transition-transform group-hover:translate-x-0.5"
                        style={{ color: "var(--ink-faint)" }}
                      />
                    </div>

                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {ml.map((l) => {
                        const meta = linkLabel(l);
                        return (
                          <button
                            key={`${l.type}-${l.id}`}
                            type="button"
                            onClick={() => void openTarget({ type: l.type, id: l.id })}
                            title={`Open linked ${meta.kind}: ${meta.text}`}
                            className="flex max-w-full items-center gap-1.5 rounded-full px-2.5 py-1.5 text-[11px] font-bold transition-transform hover:scale-[1.03]"
                            style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                          >
                            {meta.kind === "note" ? (
                              <NotebookPen size={11} />
                            ) : (
                              <BookMarked size={11} />
                            )}
                            <span className="truncate">{meta.text}</span>
                            <ChevronRight size={10.5} />
                          </button>
                        );
                      })}
                    </div>
                  </section>
                );
              })}
              {linkedMaps.length === 0 && (
                <p
                  className="rounded-2xl px-4 py-10 text-center text-[13px]"
                  style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}
                >
                  No links yet — head back and use <b>Link</b> on any map to tie it to
                  notes and subjects. They’ll show up here, grouped by map.
                </p>
              )}
            </div>
          </>
        )}
      </div>
    </Drawer>
  );
}
