"use client";

import { useMemo, useState, type FormEvent } from "react";
import { CalendarClock, Check, ListTodo, Pencil, Plus, Trash2 } from "lucide-react";
import { Drawer } from "@/components/ui";
import { useDashboard } from "@/lib/dashboard-context";
import { useSections } from "@/lib/sections-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import { DEADLINE_COLORS, type Task, type TaskPriority } from "@/lib/types";

type StatusFilter = "all" | "pending" | "completed";

const PRIORITY_META: Record<TaskPriority, { label: string; color: string }> = {
  low: { label: "Low", color: "#6c93bf" },
  medium: { label: "Medium", color: "#cf9c44" },
  high: { label: "High", color: "#d4705c" },
};

function dueChip(t: Task): { text: string; overdue: boolean } | null {
  if (!t.dueDate) return null;
  const due = new Date(t.dueDate);
  const today = new Date();
  const startToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const startDue = new Date(due.getFullYear(), due.getMonth(), due.getDate());
  const days = Math.round((startDue.getTime() - startToday.getTime()) / 86400000);
  const base =
    days === 0
      ? "Due today"
      : days === 1
        ? "Tomorrow"
        : days < 0
          ? `${-days}d overdue`
          : due.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  // show the specific due time when one was picked
  const text = t.time ? `${base} · ${t.time}` : base;
  return { text, overdue: days < 0 && !t.done };
}

function TaskRow({ task }: { task: Task }) {
  const { toggleTask, deleteTask, reloadAll } = useDashboard();
  const { push } = useToast();
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [time, setTime] = useState(task.time);
  const prio = PRIORITY_META[task.priority ?? "medium"];
  const chip = dueChip(task);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api(`/api/tasks/${task.id}`, { method: "PATCH", body: { title, time } });
      await reloadAll();
      setEditing(false);
      push("success", "Task updated");
    } catch {
      push("error", "Couldn't update that task");
    }
  };

  if (editing) {
    return (
      <form
        onSubmit={save}
        className="animate-pop flex items-center gap-2.5 rounded-2xl p-3"
        style={{ background: "var(--accent-soft)", border: "1px dashed var(--accent)" }}
      >
        <input
          className="input-line flex-1 !text-[13.5px]"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          autoFocus
        />
        <input
          type="time"
          className="input-box !w-[86px] !px-2 !py-1 text-center !text-[12px]"
          value={time}
          onChange={(e) => setTime(e.target.value)}
        />
        <button type="submit" disabled={!title.trim()} className="btn-accent h-8 w-8 !p-0" aria-label="Save">
          <Check size={13} />
        </button>
      </form>
    );
  }

  return (
    <div
      className={`group flex items-center gap-3 rounded-2xl p-3 transition-colors ${task.done ? "checked" : ""}`}
      style={{ background: "var(--surface)", border: "1px solid var(--line-soft)", opacity: task.done ? 0.75 : 1 }}
    >
      <button
        role="checkbox"
        aria-checked={task.done}
        aria-label={task.title}
        onClick={() => toggleTask(task.id)}
        className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg transition-transform hover:scale-110"
        style={{
          border: `1.5px solid ${task.done ? "var(--accent)" : "var(--line)"}`,
          background: task.done ? "var(--accent)" : "transparent",
        }}
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="var(--accent-ink)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          <path className="check-path" d="M5 12.5l4.5 4.5L19 7.5" />
        </svg>
      </button>
      <span
        className="h-2.5 w-2.5 shrink-0 rounded-full"
        title={`${prio.label} priority`}
        style={{ background: prio.color, opacity: task.done ? 0.45 : 1 }}
      />
      {task.time && (
        <span className="w-11 shrink-0 text-[11px] font-semibold tabular-nums" style={{ color: "var(--ink-faint)" }}>
          {task.time}
        </span>
      )}
      <span className="strike-line min-w-0 flex-1 truncate text-[13.5px]" style={{ color: task.done ? "var(--ink-faint)" : "var(--ink)" }}>
        {task.title}
      </span>
      {task.subject && (
        <span className="hidden shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold sm:inline" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
          {task.subject}
        </span>
      )}
      {chip && (
        <span
          className="hidden shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold sm:flex"
          style={{
            background: chip.overdue ? "rgba(212,112,92,0.14)" : "var(--surface-3)",
            color: chip.overdue ? "#d4705c" : "var(--ink-soft)",
          }}
        >
          <CalendarClock size={10} />
          {chip.text}
        </span>
      )}
      <div className="flex gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
        <button
          onClick={() => {
            setTitle(task.title);
            setTime(task.time);
            setEditing(true);
          }}
          aria-label="Edit task"
          className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-[var(--surface-3)]"
          style={{ color: "var(--ink-faint)" }}
        >
          <Pencil size={12} />
        </button>
        <button
          onClick={() => deleteTask(task.id)}
          aria-label="Delete task"
          className="flex h-7 w-7 items-center justify-center rounded-full transition-colors hover:bg-red-500/10 hover:text-red-500"
          style={{ color: "var(--ink-faint)" }}
        >
          <Trash2 size={12} />
        </button>
      </div>
    </div>
  );
}

export default function TasksDrawer() {
  const { open, closeSection } = useSections();
  const { tasks, addTask, subjects } = useDashboard();
  const [filter, setFilter] = useState<StatusFilter>("all");
  const [subjectFilter, setSubjectFilter] = useState("");

  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState<TaskPriority>("medium");
  const [dueDate, setDueDate] = useState("");
  const [dueTime, setDueTime] = useState("");
  const [subject, setSubject] = useState("");

  const subjectOptions = useMemo(() => {
    const names = new Set(subjects.map((s) => s.name));
    for (const t of tasks) if (t.subject) names.add(t.subject);
    return [...names];
  }, [subjects, tasks]);

  const shown = tasks.filter((t) => {
    if (filter === "pending" && t.done) return false;
    if (filter === "completed" && !t.done) return false;
    if (subjectFilter && t.subject.trim().toLowerCase() !== subjectFilter.toLowerCase())
      return false;
    return true;
  });
  const done = tasks.filter((t) => t.done).length;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const clean = title.trim();
    if (!clean) return;
    // a due time is optional; without one the task lands at midday on its date
    const iso = dueDate
      ? new Date(`${dueDate}T${dueTime || "12:00"}:00`).toISOString()
      : null;
    await addTask(clean, dueTime, {
      priority,
      subject: subject.trim(),
      dueDate: iso,
    });
    setTitle("");
    setPriority("medium");
    setDueDate("");
    setDueTime("");
    setSubject("");
  };

  return (
    <Drawer
      open={open === "tasks"}
      onClose={closeSection}
      title="All tasks"
      subtitle={`${done} of ${tasks.length} complete · changes sync to the dashboard & calendar`}
      icon={<ListTodo size={18} />}
    >
      <div className="flex flex-col gap-4 px-5 py-5 sm:px-6">
        {/* ---------- quick-add bar: objective · priority · due date · subject · add ---------- */}
        <form
          onSubmit={submit}
          className="flex flex-col gap-2.5 rounded-2xl p-3"
          style={{ background: "var(--surface)", border: "1px solid var(--line)" }}
        >
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
              <Plus size={14} />
            </span>
            <input
              className="input-line flex-1"
              placeholder="Task name / objective…"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <button type="submit" disabled={!title.trim()} className="btn-accent h-9 px-3.5 text-[12px] font-semibold disabled:opacity-40" aria-label="Add task">
              <Check size={14} /> Add task
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-2 pl-11">
            <div className="flex overflow-hidden rounded-full" style={{ border: "1px solid var(--line)" }}>
              {(Object.keys(PRIORITY_META) as TaskPriority[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className="px-2.5 py-1.5 text-[11px] font-bold transition-all"
                  style={{
                    background: priority === p ? PRIORITY_META[p].color : "var(--surface-2)",
                    color: priority === p ? "#fff" : "var(--ink-soft)",
                  }}
                >
                  {PRIORITY_META[p].label}
                </button>
              ))}
            </div>
            <input
              type="date"
              className="input-box !w-[132px] !px-2 !py-1.5 !text-[12px]"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              aria-label="Date due"
              title="Date due"
            />
            <input
              type="time"
              className="input-box !w-[100px] !px-2 !py-1.5 !text-[12px]"
              value={dueTime}
              onChange={(e) => setDueTime(e.target.value)}
              aria-label="Time due"
              title="Time due"
            />
            <select
              className="input-box !w-auto !px-2 !py-1.5 !text-[12px]"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              aria-label="Subject"
            >
              <option value="">No subject</option>
              {subjectOptions.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </form>

        {/* ---------- filters: status + subject ---------- */}
        <div className="flex flex-wrap items-center gap-1.5">
          {(["all", "pending", "completed"] as StatusFilter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="rounded-full px-3.5 py-1.5 text-[11.5px] font-bold capitalize transition-all"
              style={{
                background: filter === f ? "var(--accent)" : "var(--surface-2)",
                color: filter === f ? "var(--accent-ink)" : "var(--ink-soft)",
              }}
            >
              {f}
              <span className="ml-1.5 opacity-70">
                {f === "all" ? tasks.length : f === "completed" ? done : tasks.length - done}
              </span>
            </button>
          ))}
          <span className="flex-1" />
          <select
            className="input-box !w-auto !px-2.5 !py-1.5 !text-[11.5px] !font-bold"
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            aria-label="Filter by subject"
          >
            <option value="">All subjects</option>
            {subjectOptions.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1.5">
          {shown.map((t) => (
            <TaskRow key={t.id} task={t} />
          ))}
          {shown.length === 0 && (
            <p className="rounded-2xl px-4 py-8 text-center text-[13px]" style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}>
              {filter === "completed"
                ? "Nothing finished yet — go tick something!"
                : filter === "pending"
                  ? "Everything's done. Sit with that feeling."
                  : subjectFilter
                    ? `No tasks under ${subjectFilter}.`
                    : "No tasks yet."}
            </p>
          )}
        </div>
        <p className="px-1 text-[11px]" style={{ color: "var(--ink-faint)" }}>
          Deleted tasks retire to the Trash, where they can be restored.
        </p>
      </div>
    </Drawer>
  );
}
