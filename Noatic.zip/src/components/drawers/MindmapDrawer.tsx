"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  BookMarked,
  ChevronLeft,
  ChevronRight,
  Crosshair,
  Minus,
  Network,
  NotebookPen,
  Pencil,
  Plus,
  Trash2,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { Drawer } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import MindmapLinkPicker from "@/components/mindmap/MindmapLinkPicker";
import { useOpenLinkTarget, type MindMapInfo } from "@/lib/mindmap-nav";
import type { MindNode } from "@/lib/types";

const AREA_W = 1800;
const AREA_H = 1100;
const CX = AREA_W / 2;
const CY = AREA_H / 2;
const NODE_H = 44;

function NodeCard({
  node,
  isRoot,
  selected,
  editing,
  onSelect,
  onStartDrag,
  onRename,
  onOpenEdit,
}: {
  node: MindNode;
  isRoot: boolean;
  selected: boolean;
  editing: boolean;
  onSelect: () => void;
  onStartDrag: (e: React.PointerEvent) => void;
  onRename: (text: string) => void;
  onOpenEdit: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div
      onPointerDown={(e) => {
        if (editing) return;
        onSelect();
        onStartDrag(e);
      }}
      onDoubleClick={onOpenEdit}
      className="absolute select-none"
      style={{
        left: CX + node.x,
        top: CY + node.y,
        transform: "translate(-50%, -50%)",
        cursor: editing ? "text" : "grab",
        touchAction: "none",
        zIndex: selected ? 20 : 10,
      }}
      role="button"
      aria-label={`Mind map node: ${node.text}`}
    >
      <div
        className="flex items-center gap-2 rounded-2xl px-4 py-2.5 whitespace-nowrap transition-shadow"
        style={{
          background: isRoot ? "var(--accent)" : "var(--surface)",
          color: isRoot ? "var(--accent-ink)" : "var(--ink)",
          border: `1.5px solid ${selected ? "var(--accent)" : "var(--line)"}`,
          boxShadow: selected ? "var(--card-shadow-hover)" : "var(--card-shadow)",
          maxWidth: 220,
        }}
      >
        {isRoot && <Network size={13} />}
        {editing ? (
          <input
            ref={inputRef}
            defaultValue={node.text}
            onPointerDown={(e) => e.stopPropagation()}
            onKeyDown={(e) => {
              const val = inputRef.current?.value.trim() ?? "";
              if (e.key === "Enter" && val) onRename(val);
              if (e.key === "Escape") onRename(node.text);
            }}
            onBlur={() => {
              const val = inputRef.current?.value.trim() ?? "";
              if (val) onRename(val);
            }}
            autoFocus
            className="w-36 bg-transparent text-[13px] font-semibold outline-none"
            style={{ color: "inherit" }}
            maxLength={120}
          />
        ) : (
          <span className="overflow-hidden text-[13px] font-semibold text-ellipsis">
            {node.text}
          </span>
        )}
      </div>
    </div>
  );
}

export default function MindmapDrawer() {
  const { mindmap, closeMindmap, openSection } = useSections();
  const { notes, subjects } = useDashboard();
  const { push } = useToast();
  const [nodes, setNodes] = useState<MindNode[] | null>(null);
  const [mapInfo, setMapInfo] = useState<MindMapInfo | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const scrollRef = useRef<HTMLDivElement>(null);
  const openTarget = useOpenLinkTarget();
  const dragRef = useRef<{
    id: string;
    pointerId: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    moved: boolean;
  } | null>(null);

  const root = useMemo(() => nodes?.find((n) => !n.parentId) ?? null, [nodes]);
  const selected = nodes?.find((n) => n.id === selectedId) ?? null;

  const load = useCallback(async () => {
    if (!mindmap) return;
    try {
      let rows = await api<MindNode[]>(`/api/mindnodes?mapId=${encodeURIComponent(mindmap.id)}`);
      if (rows.length === 0) {
        // a map always shows at least its root idea
        const r = await api<MindNode>("/api/mindnodes", {
          method: "POST",
          body: { mapId: mindmap.id, text: mindmap.name, x: 0, y: 0 },
        });
        rows = [r];
      }
      setNodes(rows);
      setSelectedId((cur) =>
        cur && rows.some((n) => n.id === cur) ? cur : rows.find((n) => !n.parentId)?.id ?? null
      );
    } catch {
      push("error", "Couldn't load the mind map");
    }
  }, [mindmap, push]);

  /** pull link/name state for this map (for the toolbar chip + picker) */
  const loadMapInfo = useCallback(async () => {
    if (!mindmap) return;
    try {
      const rows = await api<MindMapInfo[]>("/api/mindmaps");
      setMapInfo(rows.find((m) => m.id === mindmap.id) ?? null);
    } catch {
      /* cosmetic only */
    }
  }, [mindmap]);

  useEffect(() => {
    if (mindmap) {
      setNodes(null);
      setEditingId(null);
      setSelectedId(null);
      load();
      loadMapInfo();
      requestAnimationFrame(() => {
        const sc = scrollRef.current;
        if (sc) {
          sc.scrollLeft = (AREA_W * zoom - sc.clientWidth) / 2;
          sc.scrollTop = (AREA_H * zoom - sc.clientHeight) / 2;
        }
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mindmap?.id, load, loadMapInfo]);

  useEffect(() => {
    const move = (e: PointerEvent) => {
      const st = dragRef.current;
      if (!st || e.pointerId !== st.pointerId) return;
      const dx = (e.clientX - st.startX) / zoom;
      const dy = (e.clientY - st.startY) / zoom;
      if (!st.moved && Math.abs(dx) + Math.abs(dy) > 4) st.moved = true;
      if (!st.moved) return;
      setNodes((ns) =>
        (ns ?? []).map((n) =>
          n.id === st.id ? { ...n, x: st.origX + dx, y: st.origY + dy } : n
        )
      );
    };
    const up = (e: PointerEvent) => {
      const st = dragRef.current;
      if (!st || e.pointerId !== st.pointerId) return;
      dragRef.current = null;
      if (st.moved) {
        setNodes((ns) => {
          const node = (ns ?? []).find((n) => n.id === st.id);
          if (node) {
            api(`/api/mindnodes/${st.id}`, {
              method: "PATCH",
              body: { x: Math.round(node.x), y: Math.round(node.y) },
            }).catch(() => push("error", "Couldn't save that position"));
          }
          return ns;
        });
      }
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [zoom, push]);

  const startDrag = (node: MindNode) => (e: React.PointerEvent) => {
    e.preventDefault();
    dragRef.current = {
      id: node.id,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      origX: node.x,
      origY: node.y,
      moved: false,
    };
  };

  const addChild = async () => {
    if (!selected || !mindmap) return;
    // fan children out to the right, alternating above/below the parent
    const siblings = (nodes ?? []).filter((n) => n.parentId === selected.id).length;
    const dir = siblings % 2 === 0 ? 1 : -1;
    const tier = Math.ceil(siblings / 2);
    const x = selected.x + 210;
    const y = siblings === 0 ? selected.y : selected.y + dir * tier * 95;
    try {
      const row = await api<MindNode>("/api/mindnodes", {
        method: "POST",
        body: {
          mapId: mindmap.id,
          parentId: selected.id,
          text: "New idea",
          x: Math.round(x),
          y: Math.round(y),
        },
      });
      setNodes((ns) => [...(ns ?? []), row]);
      setSelectedId(row.id);
      setEditingId(row.id);
    } catch {
      push("error", "Couldn't add that idea");
    }
  };

  const deleteNode = async () => {
    if (!selected || !selected.parentId) return;
    const before = nodes;
    const doomed = new Set<string>([selected.id]);
    let changed = true;
    const all = nodes ?? [];
    while (changed) {
      changed = false;
      for (const n of all) {
        if (n.parentId && doomed.has(n.parentId) && !doomed.has(n.id)) {
          doomed.add(n.id);
          changed = true;
        }
      }
    }
    setNodes((ns) => (ns ?? []).filter((n) => !doomed.has(n.id)));
    setSelectedId(root?.id ?? null);
    try {
      await api(`/api/mindnodes/${selected.id}`, { method: "DELETE" });
      push("info", `Removed ${doomed.size} node${doomed.size === 1 ? "" : "s"}`);
    } catch {
      setNodes(before);
      push("error", "Couldn't delete that branch");
    }
  };

  const rename = async (id: string, text: string) => {
    setEditingId(null);
    setNodes((ns) => (ns ?? []).map((n) => (n.id === id ? { ...n, text } : n)));
    try {
      await api(`/api/mindnodes/${id}`, { method: "PATCH", body: { text } });
    } catch {
      push("error", "Couldn't rename that");
    }
  };

  const centerView = () => {
    const sc = scrollRef.current;
    if (sc) {
      sc.scrollTo({
        left: (AREA_W * zoom - sc.clientWidth) / 2,
        top: (AREA_H * zoom - sc.clientHeight) / 2,
        behavior: "smooth",
      });
    }
  };

  const edges = useMemo(() => {
    const byId = new Map((nodes ?? []).map((n) => [n.id, n]));
    return (nodes ?? [])
      .filter((n) => n.parentId && byId.has(n.parentId))
      .map((n) => {
        const p = byId.get(n.parentId!)!;
        return { id: n.id, x1: CX + p.x, y1: CY + p.y + NODE_H / 2, x2: CX + n.x, y2: CY + n.y - NODE_H / 2 };
      });
  }, [nodes]);

  /** label for the first linked note/subject chip in the toolbar */
  const linkChip = useMemo(() => {
    const first = mapInfo?.links?.[0];
    if (!first) return null;
    if (first.type === "note") {
      const n = notes.find((x) => x.id === first.id);
      return n ? ({ kind: "note" as const, id: first.id, text: n.title || "Untitled note" }) : null;
    }
    const s = subjects.find((x) => x.id === first.id);
    return s ? ({ kind: "subject" as const, id: first.id, text: s.name }) : null;
  }, [mapInfo, notes, subjects]);

  /** links beyond the one shown on the chip */
  const extraLinkCount = linkChip ? Math.max(0, (mapInfo?.links?.length ?? 1) - 1) : 0;

  return (
    <Drawer
      open={!!mindmap}
      onClose={closeMindmap}
      title={mindmap?.name ?? "Mind map"}
      subtitle="Drag nodes anywhere · double-click to rename · select a node for actions"
      icon={<Network size={18} />}
      size="xl"
    >
      <div className="flex h-full flex-col">
        {/* toolbar */}
        <div
          className="flex flex-wrap items-center gap-2 border-b px-5 py-3"
          style={{ borderColor: "var(--line-soft)", background: "var(--surface)" }}
        >
          <button
            onClick={() => openSection("mindmap")}
            className="btn-ghost px-3.5 py-2 text-[12px] font-semibold"
            title="Back to all mind maps"
          >
            <ChevronLeft size={13} /> All maps
          </button>
          <span
            className="hidden h-5 w-px sm:block"
            style={{ background: "var(--line)" }}
            aria-hidden
          />
          <button onClick={addChild} disabled={!selected} className="btn-accent px-3.5 py-2 text-[12px] font-semibold disabled:opacity-40">
            <Plus size={13} /> Child idea
          </button>
          <button
            onClick={() => selected && setEditingId(selected.id)}
            disabled={!selected}
            className="btn-ghost px-3.5 py-2 text-[12px] font-semibold disabled:opacity-40"
          >
            <Pencil size={13} /> Rename
          </button>
          <button
            onClick={deleteNode}
            disabled={!selected || !selected.parentId}
            className="btn-ghost px-3.5 py-2 text-[12px] font-semibold disabled:opacity-40 hover:!text-red-500"
          >
            <Trash2 size={13} /> Delete branch
          </button>

          {mapInfo && (
            <>
              <span className="hidden h-5 w-px sm:block" style={{ background: "var(--line)" }} aria-hidden />
              {linkChip && (
                <button
                  type="button"
                  onClick={() => void openTarget({ type: linkChip.kind, id: linkChip.id })}
                  title={
                    extraLinkCount > 0
                      ? `Open linked ${linkChip.kind}: ${linkChip.text} (+${extraLinkCount} more linked — see Link)`
                      : `Open linked ${linkChip.kind}: ${linkChip.text}`
                  }
                  className="flex items-center gap-1.5 rounded-full px-3 py-2 text-[12px] font-bold transition-transform hover:scale-[1.03]"
                  style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                >
                  {linkChip.kind === "note" ? <NotebookPen size={12} /> : <BookMarked size={12} />}
                  <span className="max-w-40 truncate">{linkChip.text}</span>
                  {extraLinkCount > 0 && (
                    <span
                      className="rounded-full px-1.5 text-[9px] font-bold"
                      style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
                    >
                      +{extraLinkCount}
                    </span>
                  )}
                  <ChevronRight size={11} />
                </button>
              )}
              <MindmapLinkPicker
                map={mapInfo}
                onChanged={(m) => setMapInfo(m)}
                label="Link"
                className="btn-ghost px-3.5 py-2 text-[12px] font-semibold"
                iconSize={13}
              />
            </>
          )}

          <span className="flex-1" />
          <button onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.15).toFixed(2)))} aria-label="Zoom out" className="btn-ghost h-9 w-9 !p-0">
            <ZoomOut size={15} />
          </button>
          <span className="w-11 text-center text-[11.5px] font-bold tabular-nums" style={{ color: "var(--ink-soft)" }}>
            {Math.round(zoom * 100)}%
          </span>
          <button onClick={() => setZoom((z) => Math.min(1.6, +(z + 0.15).toFixed(2)))} aria-label="Zoom in" className="btn-ghost h-9 w-9 !p-0">
            <ZoomIn size={15} />
          </button>
          <button onClick={centerView} aria-label="Center map" className="btn-ghost h-9 w-9 !p-0">
            <Crosshair size={15} />
          </button>
        </div>

        {/* canvas */}
        <div ref={scrollRef} className="relative flex-1 overflow-auto" style={{ background: "var(--bg)" }}>
          <div
            className="relative"
            style={{
              width: AREA_W * zoom,
              height: AREA_H * zoom,
            }}
          >
            <div
              className="absolute"
              style={{
                left: 0,
                top: 0,
                width: AREA_W,
                height: AREA_H,
                transform: `scale(${zoom})`,
                transformOrigin: "top left",
                backgroundImage:
                  "radial-gradient(circle, var(--line) 1.2px, transparent 1.2px)",
                backgroundSize: "26px 26px",
              }}
            >
              <svg width={AREA_W} height={AREA_H} className="absolute inset-0" style={{ pointerEvents: "none" }}>
                {edges.map((e) => {
                  const midY = (e.y1 + e.y2) / 2;
                  return (
                    <path
                      key={e.id}
                      d={`M ${e.x1} ${e.y1} C ${e.x1} ${midY}, ${e.x2} ${midY}, ${e.x2} ${e.y2}`}
                      fill="none"
                      stroke="var(--ink-faint)"
                      strokeWidth={1.6}
                      strokeDasharray="1 0"
                      opacity={0.55}
                    />
                  );
                })}
              </svg>

              {(nodes ?? []).map((n) => (
                <NodeCard
                  key={n.id}
                  node={n}
                  isRoot={!n.parentId}
                  selected={selectedId === n.id}
                  editing={editingId === n.id}
                  onSelect={() => setSelectedId(n.id)}
                  onStartDrag={startDrag(n)}
                  onRename={(text) => rename(n.id, text)}
                  onOpenEdit={() => {
                    setSelectedId(n.id);
                    setEditingId(n.id);
                  }}
                />
              ))}
            </div>
          </div>
          {!nodes && (
            <p className="absolute inset-0 flex items-center justify-center text-[13px]" style={{ color: "var(--ink-faint)" }}>
              Sketching the canvas…
            </p>
          )}
        </div>

        <div className="flex items-center gap-2 border-t px-5 py-3 text-[11px]" style={{ borderColor: "var(--line-soft)", color: "var(--ink-faint)", background: "var(--surface)" }}>
          <Minus size={11} />
          Positions save automatically. Deleting a node removes its whole branch — the root is anchored forever.
        </div>
      </div>
    </Drawer>
  );
}
