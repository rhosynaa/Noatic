"use client";

import { useMemo, useState, type FormEvent } from "react";
import { CalendarDays, Check, ChevronLeft, ChevronRight, ListTodo, Plus, Trash2 } from "lucide-react";
import { Drawer } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { DEADLINE_COLORS } from "@/lib/types";
import { dueLabel } from "@/components/widgets/DeadlinesWidget";

function dayKey(y: number, m: number, d: number): string {
  return `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

const TASK_DOT = "#52796f";

export default function CalendarDrawer() {
  const { open, closeSection, openSection } = useSections();
  const { deadlines, toggleDeadline, addDeadline, deleteDeadline, tasks, toggleTask, subjects } =
    useDashboard();

  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selected, setSelected] = useState(
    dayKey(today.getFullYear(), today.getMonth(), today.getDate())
  );

  /* quick-add deadline form state */
  const [adding, setAdding] = useState(false);
  const [dlTitle, setDlTitle] = useState("");
  const [dlSubject, setDlSubject] = useState("");
  const [dlColor, setDlColor] = useState("rose");

  const byDay = useMemo(() => {
    const map = new Map<string, typeof deadlines>();
    for (const dl of deadlines) {
      const dt = new Date(dl.dueDate);
      const key = dayKey(dt.getFullYear(), dt.getMonth(), dt.getDate());
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(dl);
    }
    return map;
  }, [deadlines]);

  const tasksByDay = useMemo(() => {
    const map = new Map<string, typeof tasks>();
    for (const t of tasks) {
      if (!t.dueDate) continue;
      const dt = new Date(t.dueDate);
      const key = dayKey(dt.getFullYear(), dt.getMonth(), dt.getDate());
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(t);
    }
    return map;
  }, [tasks]);

  const firstDay = new Date(viewYear, viewMonth, 1);
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  // weeks start on Monday
  const leadBlanks = (firstDay.getDay() + 6) % 7;
  const cells: (number | null)[] = [
    ...Array(leadBlanks).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const moveMonth = (delta: number) => {
    const next = new Date(viewYear, viewMonth + delta, 1);
    setViewYear(next.getFullYear());
    setViewMonth(next.getMonth());
  };

  const todayKey = dayKey(today.getFullYear(), today.getMonth(), today.getDate());
  const selectedItems = byDay.get(selected) ?? [];
  const selectedTasks = tasksByDay.get(selected) ?? [];
  const monthName = new Date(viewYear, viewMonth, 1).toLocaleDateString(undefined, {
    month: "long",
    year: "numeric",
  });

  const submitDeadline = async (e: FormEvent) => {
    e.preventDefault();
    if (!dlTitle.trim()) return;
    await addDeadline({
      title: dlTitle.trim(),
      subject: dlSubject,
      color: dlColor,
      dueDate: new Date(`${selected}T12:00:00`).toISOString(),
    });
    setDlTitle("");
    setAdding(false);
  };

  return (
    <Drawer
      open={open === "calendar"}
      onClose={closeSection}
      title="Calendar"
      subtitle="Deadlines & dated tasks, pinned to their days"
      icon={<CalendarDays size={18} />}
      size="lg"
    >
      <div className="flex flex-col gap-5 px-5 py-5 sm:px-6 lg:flex-row">
        <div className="min-w-0 flex-1">
          <div
            className="mb-2.5 flex items-center justify-between px-1"
          >
            <button onClick={() => moveMonth(-1)} className="btn-ghost h-8 w-8 !p-0" aria-label="Previous month">
              <ChevronLeft size={15} />
            </button>
            <p className="font-display text-[16px] font-semibold" style={{ color: "var(--ink)" }}>
              {monthName}
            </p>
            <button onClick={() => moveMonth(1)} className="btn-ghost h-8 w-8 !p-0" aria-label="Next month">
              <ChevronRight size={15} />
            </button>
          </div>
          <div
            className="overflow-hidden rounded-3xl p-4"
            style={{ background: "var(--surface)", border: "1px solid var(--line)" }}
          >
            <div className="grid grid-cols-7 gap-1.5">
              {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => (
                <p key={d} className="pb-1.5 text-center text-[10px] font-bold tracking-[0.1em] uppercase" style={{ color: "var(--ink-faint)" }}>
                  {d}
                </p>
              ))}
              {cells.map((day, i) => {
                if (day === null) return <span key={`b-${i}`} />;
                const key = dayKey(viewYear, viewMonth, day);
                const items = byDay.get(key) ?? [];
                const dayTasks = tasksByDay.get(key) ?? [];
                const isToday = key === todayKey;
                const isSel = key === selected;
                return (
                  <button
                    key={key}
                    onClick={() => setSelected(key)}
                    className="relative flex aspect-square flex-col items-center justify-center rounded-2xl text-[12.5px] font-semibold transition-all hover:scale-[1.04]"
                    style={{
                      background: isSel ? "var(--accent)" : isToday ? "var(--accent-soft)" : "transparent",
                      color: isSel ? "var(--accent-ink)" : isToday ? "var(--accent)" : "var(--ink-soft)",
                      border: isToday && !isSel ? "1.5px solid var(--accent)" : "1.5px solid transparent",
                    }}
                  >
                    {day}
                    {(items.length > 0 || dayTasks.length > 0) && (
                      <span className="mt-1 flex items-center gap-0.5">
                        {items.slice(0, 2).map((dl) => (
                          <span
                            key={dl.id}
                            className="h-1.5 w-1.5 rounded-full"
                            style={{
                              background: isSel
                                ? "var(--accent-ink)"
                                : DEADLINE_COLORS[dl.color] ?? "var(--ink-faint)",
                              opacity: dl.done ? 0.35 : 1,
                            }}
                          />
                        ))}
                        {dayTasks.length > 0 && (
                          <span
                            className="h-1.5 w-1.5 rounded-[3px]"
                            title={`${dayTasks.length} task${dayTasks.length === 1 ? "" : "s"} due`}
                            style={{
                              background: isSel ? "var(--accent-ink)" : TASK_DOT,
                              opacity: dayTasks.every((t) => t.done) ? 0.35 : 1,
                            }}
                          />
                        )}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div
            className="mt-3 flex items-center gap-2 rounded-2xl px-4 py-2.5 text-[11.5px]"
            style={{ background: "var(--surface-2)", color: "var(--ink-soft)" }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: DEADLINE_COLORS.rose }} />
            deadline
            <span className="ml-3 h-1.5 w-1.5 rounded-[3px]" style={{ background: TASK_DOT }} />
            task due
            <span className="flex-1" />
            <button
              onClick={() => openSection("tasks")}
              className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
            >
              <ListTodo size={12.5} /> Open tasks
            </button>
          </div>
        </div>

        <div className="min-w-0 flex-1">
          <div className="mb-2.5 flex items-center justify-between px-1">
            <p className="text-[11px] font-bold tracking-[0.12em] uppercase" style={{ color: "var(--ink-faint)" }}>
              {new Date(selected + "T12:00:00").toLocaleDateString(undefined, {
                weekday: "long",
                month: "short",
                day: "numeric",
              })}
            </p>
            <button
              onClick={() => setAdding((v) => !v)}
              className="btn-ghost px-3 py-1.5 text-[11.5px] font-semibold"
              style={adding ? { color: "var(--accent)", borderColor: "var(--accent)" } : undefined}
            >
              <Plus size={12.5} className={adding ? "rotate-45 transition-transform" : "transition-transform"} />
              Deadline
            </button>
          </div>

          {adding && (
            <form
              onSubmit={submitDeadline}
              className="animate-pop mb-3 flex flex-col gap-2.5 rounded-2xl p-3.5"
              style={{ background: "var(--accent-soft)", border: "1px dashed var(--accent)" }}
            >
              <input
                className="input-line"
                placeholder={`Deadline on ${new Date(selected + "T12:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" })}…`}
                value={dlTitle}
                onChange={(e) => setDlTitle(e.target.value)}
                autoFocus
              />
              <div className="flex flex-wrap items-center gap-2">
                <select
                  className="input-box !w-auto !px-2 !py-1.5 !text-[12px]"
                  value={dlSubject}
                  onChange={(e) => setDlSubject(e.target.value)}
                  aria-label="Subject"
                >
                  <option value="">No subject</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
                <div className="flex items-center gap-1">
                  {Object.entries(DEADLINE_COLORS).map(([key, c]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setDlColor(key)}
                      aria-label={key}
                      className="h-5 w-5 rounded-full transition-transform hover:scale-110"
                      style={{
                        background: c,
                        boxShadow: dlColor === key ? `0 0 0 2px var(--surface), 0 0 0 3.5px ${c}` : "none",
                      }}
                    />
                  ))}
                </div>
                <span className="flex-1" />
                <button type="submit" disabled={!dlTitle.trim()} className="btn-accent px-3.5 py-1.5 text-[11.5px] font-semibold disabled:opacity-50">
                  <Check size={12} /> Add
                </button>
              </div>
            </form>
          )}

          <div className="flex flex-col gap-1.5">
            {selectedItems.map((dl) => {
              const chip = dueLabel(dl.dueDate);
              return (
                <div
                  key={dl.id}
                  className="group flex items-center gap-3 rounded-2xl p-3.5"
                  style={{ background: "var(--surface)", border: "1px solid var(--line-soft)" }}
                >
                  <button
                    role="checkbox"
                    aria-checked={dl.done}
                    onClick={() => toggleDeadline(dl.id)}
                    aria-label={`Mark ${dl.title} done`}
                    className="flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-md transition-transform hover:scale-110"
                    style={{
                      border: `1.5px solid ${dl.done ? DEADLINE_COLORS[dl.color] : "var(--line)"}`,
                      background: dl.done ? DEADLINE_COLORS[dl.color] : "transparent",
                    }}
                  >
                    {dl.done && <Check size={13} color="#fff" strokeWidth={3} />}
                  </button>
                  <span
                    className="h-8 w-1 rounded-full"
                    style={{ background: DEADLINE_COLORS[dl.color] ?? "var(--accent)" }}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-medium" style={{ color: dl.done ? "var(--ink-faint)" : "var(--ink)", textDecoration: dl.done ? "line-through" : "none" }}>
                      {dl.title}
                    </p>
                    {dl.subject && (
                      <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>{dl.subject}</p>
                    )}
                  </div>
                  {!dl.done && (
                    <span className="rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ background: "var(--surface-3)", color: "var(--ink-soft)" }}>
                      {chip.text}
                    </span>
                  )}
                  <button
                    onClick={() => deleteDeadline(dl.id)}
                    aria-label={`Delete ${dl.title}`}
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              );
            })}

            {selectedTasks.length > 0 && (
              <p className="mt-2 px-1 text-[10.5px] font-bold tracking-[0.12em] uppercase" style={{ color: "var(--ink-faint)" }}>
                Tasks due
              </p>
            )}
            {selectedTasks.map((t) => (
              <div
                key={t.id}
                className="flex items-center gap-3 rounded-2xl p-3"
                style={{ background: "var(--surface)", border: "1px solid var(--line-soft)" }}
              >
                <button
                  role="checkbox"
                  aria-checked={t.done}
                  onClick={() => toggleTask(t.id)}
                  aria-label={`Mark ${t.title} done`}
                  className="flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-md transition-transform hover:scale-110"
                  style={{
                    border: `1.5px solid ${t.done ? TASK_DOT : "var(--line)"}`,
                    background: t.done ? TASK_DOT : "transparent",
                  }}
                >
                  {t.done && <Check size={13} color="#fff" strokeWidth={3} />}
                </button>
                <span className="h-8 w-1 rounded-[3px]" style={{ background: TASK_DOT }} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium" style={{ color: t.done ? "var(--ink-faint)" : "var(--ink)", textDecoration: t.done ? "line-through" : "none" }}>
                    {t.title}
                  </p>
                  {t.subject && <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>{t.subject}</p>}
                </div>
                <button
                  onClick={() => openSection("tasks")}
                  className="rounded-full px-2.5 py-0.5 text-[10px] font-bold transition-colors hover:bg-[var(--surface-3)]"
                  style={{ background: "var(--surface-3)", color: "var(--ink-soft)" }}
                >
                  in Tasks
                </button>
              </div>
            ))}

            {selectedItems.length === 0 && selectedTasks.length === 0 && (
              <p className="rounded-2xl px-4 py-8 text-center text-[13px]" style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}>
                Nothing due this day — press + Deadline to pin one here.
              </p>
            )}
          </div>
        </div>
      </div>
    </Drawer>
  );
}
