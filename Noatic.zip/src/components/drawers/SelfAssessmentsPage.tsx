"use client";

import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowLeft, MessageSquareQuote, Trash2, X } from "lucide-react";
import { useSections } from "@/lib/sections-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import type { SelfAssessment } from "@/lib/types";

const toneFor = (p: number) => (p >= 85 ? "#6d9e7d" : p >= 70 ? "#cf9c44" : "#d4705c");

/**
 * Full page takeover listing every self-assessment, opened from the main
 * sidebar tab or the "View all" button in the workspace sidebar widget.
 */
export default function SelfAssessmentsPage() {
  const { open, closeSection } = useSections();
  const { push } = useToast();
  const [rows, setRows] = useState<SelfAssessment[]>([]);
  const isOpen = open === "selfassessments";

  const load = useCallback(async () => {
    try {
      setRows(await api<SelfAssessment[]>("/api/self-assessments"));
    } catch {
      /* quiet */
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [isOpen, load]);

  /* Escape closes + body scroll locks while the page owns the screen */
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeSection();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [isOpen, closeSection]);

  const remove = async (row: SelfAssessment) => {
    const before = rows;
    setRows((r) => r.filter((x) => x.id !== row.id));
    try {
      await api(`/api/self-assessments/${row.id}`, { method: "DELETE" });
      push("success", "Self-assessment removed");
    } catch {
      setRows(before);
      push("error", "Couldn't remove that self-assessment");
    }
  };

  if (!isOpen || typeof document === "undefined") return null;

  return createPortal(
    <div
      role="dialog"
      aria-modal
      aria-label="All self-assessments"
      className="animate-fade-up fixed inset-0 z-[108] flex flex-col"
      style={{ background: "var(--bg)" }}
    >
      {/* ---------- page header ---------- */}
      <div
        className="shrink-0 border-b"
        style={{ borderColor: "var(--line-soft)", background: "var(--surface)" }}
      >
        <div className="mx-auto flex w-full max-w-5xl items-center gap-3 px-5 py-5 sm:px-6">
          <button
            onClick={closeSection}
            className="btn-ghost h-9 w-9 shrink-0 !p-0"
            aria-label="Back"
          >
            <ArrowLeft size={16} />
          </button>
          <span
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
            style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
          >
            <MessageSquareQuote size={18} />
          </span>
          <div className="min-w-0 flex-1">
            <h2
              className="font-display truncate text-xl font-semibold"
              style={{ color: "var(--ink)" }}
            >
              Self-assessment
            </h2>
            <p className="mt-0.5 text-[12px]" style={{ color: "var(--ink-soft)" }}>
              {rows.length} entr{rows.length === 1 ? "y" : "ies"} — honest scores on your finished work
            </p>
          </div>
          <button
            onClick={closeSection}
            aria-label="Close"
            className="btn-ghost h-8 w-8 shrink-0 !p-0"
            style={{ border: "none" }}
          >
            <X size={17} />
          </button>
        </div>
      </div>

      {/* ---------- page body ---------- */}
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-5xl px-5 py-6 sm:px-6">
          {rows.length === 0 ? (
            <div
              className="card flex flex-col items-center gap-2 px-6 py-16 text-center"
            >
              <MessageSquareQuote size={24} style={{ color: "var(--ink-faint)" }} />
              <p className="font-display text-[17px] font-semibold" style={{ color: "var(--ink)" }}>
                No self-assessments yet
              </p>
              <p className="max-w-sm text-[13px]" style={{ color: "var(--ink-faint)" }}>
                Grade finished work from the workspace sidebar, or straight from any open note.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {rows.map((r) => {
                const pctScore = Math.round((r.score / r.maxScore) * 100);
                const tone = toneFor(pctScore);
                return (
                  <article
                    key={r.id}
                    className="card card-hover group relative flex flex-col p-5"
                  >
                    <button
                      onClick={() => void remove(r)}
                      aria-label={`Delete self-assessment ${r.title}`}
                      className="absolute top-3.5 right-3.5 flex h-8 w-8 items-center justify-center rounded-full opacity-0 transition-all group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500"
                      style={{ color: "var(--ink-faint)" }}
                    >
                      <Trash2 size={13.5} />
                    </button>

                    <div className="flex items-center gap-3">
                      <span
                        className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-[15px] font-bold"
                        style={{ background: `${tone}22`, color: tone }}
                      >
                        {pctScore}
                      </span>
                      <div className="min-w-0 flex-1 pr-8">
                        <p
                          className="truncate text-[14px] font-semibold"
                          style={{ color: "var(--ink)" }}
                        >
                          {r.title}
                        </p>
                        <p className="mt-0.5 text-[11px]" style={{ color: "var(--ink-faint)" }}>
                          {r.subject && `${r.subject} · `}
                          {new Date(r.assessedAt).toLocaleDateString(undefined, {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                          {" · "}
                          {r.score}/{r.maxScore}
                        </p>
                      </div>
                    </div>

                    {r.comment ? (
                      <p
                        className="mt-3 text-[12.5px] leading-relaxed italic"
                        style={{ color: "var(--ink-soft)" }}
                      >
                        “{r.comment}”
                      </p>
                    ) : (
                      <p className="mt-3 text-[12px]" style={{ color: "var(--ink-faint)" }}>
                        No commentary.
                      </p>
                    )}
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}
