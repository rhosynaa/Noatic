"use client";

import { useCallback, useEffect, useState } from "react";
import { AlarmClock, Layers, NotebookPen, RotateCcw, Trash2, XCircle } from "lucide-react";
import { Drawer, SectionLabel } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { useDashboard } from "@/lib/dashboard-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import type { TrashBin, TrashType } from "@/lib/types";

const TYPE_META: Record<
  TrashType,
  { label: string; icon: typeof NotebookPen; bin: keyof TrashBin; getText: (x: never) => string }
> = {
  task: {
    label: "Tasks",
    icon: NotebookPen,
    bin: "tasks",
    getText: (x) => (x as { title: string }).title,
  },
  deadline: {
    label: "Deadlines",
    icon: AlarmClock,
    bin: "deadlines",
    getText: (x) => (x as { title: string }).title,
  },
  note: {
    label: "Notes",
    icon: NotebookPen,
    bin: "notes",
    getText: (x) => (x as { title: string }).title,
  },
  flashcard: {
    label: "Flashcards",
    icon: Layers,
    bin: "flashcards",
    getText: (x) => (x as { front: string }).front,
  },
};

export default function TrashDrawer() {
  const { open, closeSection } = useSections();
  const { reloadAll } = useDashboard();
  const { push } = useToast();
  const [bin, setBin] = useState<TrashBin | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setBin(await api<TrashBin>("/api/trash"));
    } catch {
      push("error", "Couldn't load the trash");
    }
  }, [push]);

  useEffect(() => {
    if (open !== "trash") return;
    const id = setTimeout(() => {
      void load();
    }, 0);
    return () => clearTimeout(id);
  }, [open, load]);

  const total = bin
    ? bin.tasks.length + bin.notes.length + bin.deadlines.length + bin.flashcards.length
    : 0;

  const restore = async (type: TrashType, id: string) => {
    setBusy(true);
    try {
      await api("/api/trash", { method: "PATCH", body: { type, id } });
      await Promise.all([load(), reloadAll()]);
      push("success", "Restored — it's back where it belongs");
    } catch {
      push("error", "Couldn't restore that");
    }
    setBusy(false);
  };

  const destroy = async (type: TrashType, id: string) => {
    setBusy(true);
    try {
      await api("/api/trash", { method: "DELETE", body: { type, id } });
      await load();
      push("info", "Gone for good");
    } catch {
      push("error", "Couldn't delete that");
    }
    setBusy(false);
  };

  const emptyAll = async () => {
    setBusy(true);
    try {
      await api("/api/trash", { method: "DELETE", body: { all: true } });
      await load();
      push("info", "Trash emptied");
    } catch {
      push("error", "Couldn't empty the trash");
    }
    setBusy(false);
  };

  return (
    <Drawer
      open={open === "trash"}
      onClose={closeSection}
      title="Trash"
      subtitle={total ? `${total} item${total === 1 ? "" : "s"} — restore or erase forever` : "Nothing discarded right now"}
      icon={<Trash2 size={18} />}
    >
      <div className="flex flex-col gap-5 px-5 py-5 sm:px-6">
        {total > 0 && (
          <button
            onClick={emptyAll}
            disabled={busy}
            className="btn-ghost w-full justify-center px-4 py-2.5 text-[12.5px] font-semibold hover:!text-red-500 disabled:opacity-50"
          >
            <XCircle size={14} /> Empty the trash ({total})
          </button>
        )}

        {(Object.keys(TYPE_META) as TrashType[]).map((type) => {
          const meta = TYPE_META[type];
          const items = bin?.[meta.bin] ?? [];
          if (items.length === 0) return null;
          return (
            <section key={type}>
              <div className="mb-2 flex items-center justify-between px-1">
                <SectionLabel>
                  {meta.label} · {items.length}
                </SectionLabel>
              </div>
              <div className="flex flex-col gap-1.5">
                {items.map((item) => {
                  const text = meta.getText(item as never);
                  const deletedAt = (item as { deletedAt?: string | null }).deletedAt;
                  return (
                    <div
                      key={(item as { id: string }).id}
                      className="flex items-center gap-3 rounded-2xl p-3"
                      style={{ background: "var(--surface)", border: "1px solid var(--line-soft)" }}
                    >
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl" style={{ background: "var(--surface-2)", color: "var(--ink-faint)" }}>
                        <meta.icon size={14} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-medium" style={{ color: "var(--ink)" }}>
                          {text}
                        </p>
                        {deletedAt && (
                          <p className="text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                            Trashed {new Date(deletedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                          </p>
                        )}
                      </div>
                      <button
                        onClick={() => restore(type, (item as { id: string }).id)}
                        disabled={busy}
                        aria-label="Restore"
                        title="Restore"
                        className="flex h-8 w-8 items-center justify-center rounded-full transition-all hover:scale-105"
                        style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                      >
                        <RotateCcw size={13} />
                      </button>
                      <button
                        onClick={() => destroy(type, (item as { id: string }).id)}
                        disabled={busy}
                        aria-label="Delete forever"
                        title="Delete forever"
                        className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-red-500/10 hover:text-red-500"
                        style={{ color: "var(--ink-faint)" }}
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}

        {bin && total === 0 && (
          <div className="flex flex-col items-center gap-2.5 py-14 text-center" style={{ color: "var(--ink-faint)" }}>
            <Trash2 size={26} />
            <p className="text-[13.5px]">The trash is empty — deleted tasks, notes, deadlines and flashcards rest here first.</p>
          </div>
        )}
        {!bin && (
          <p className="py-10 text-center text-[13px]" style={{ color: "var(--ink-faint)" }}>
            Loading…
          </p>
        )}
      </div>
    </Drawer>
  );
}
