"use client";

import { useCallback, useEffect, useState } from "react";
import { BarChart3, Brain, ChevronLeft, Flame, Layers, LineChart, NotebookPen, Quote } from "lucide-react";
import { Drawer, SectionLabel } from "@/components/ui";
import { useSections } from "@/lib/sections-context";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import { DEADLINE_COLORS, type AnalyticsData } from "@/lib/types";
import ProgressPanel from "@/components/analytics/ProgressPanel";
import RecallPanel from "@/components/analytics/RecallPanel";

function Stat({ icon: Icon, value, label }: { icon: typeof Layers; value: number; label: string }) {
  return (
    <div className="rounded-2xl px-4 py-3.5 text-center" style={{ background: "var(--surface)", border: "1px solid var(--line-soft)" }}>
      <Icon size={15} className="mx-auto" style={{ color: "var(--accent)" }} />
      <p className="font-display mt-1.5 text-[22px] leading-none font-semibold" style={{ color: "var(--ink)" }}>
        {value}
      </p>
      <p className="mt-1 text-[10.5px] font-semibold" style={{ color: "var(--ink-faint)" }}>
        {label}
      </p>
    </div>
  );
}

export default function AnalyticsDrawer() {
  const { open, closeSection } = useSections();
  const { push } = useToast();
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [panel, setPanel] = useState<null | "progress" | "recall">(null);

  const load = useCallback(async () => {
    try {
      setData(await api<AnalyticsData>("/api/analytics"));
    } catch {
      push("error", "Couldn't load analytics");
    }
  }, [push]);

  useEffect(() => {
    if (open !== "analytics") setPanel(null);
    if (open !== "analytics") return;
    const id = setTimeout(() => {
      void load();
    }, 0);
    return () => clearTimeout(id);
  }, [open, load]);

  const maxDone = Math.max(1, ...(data?.doneLast7.map((d) => d.count) ?? [1]));
  const maxFocus = Math.max(1, ...(data?.focusLast7.map((d) => d.minutes) ?? [1]));
  const subjectMax = Math.max(1, ...(data?.deadlinesBySubject.map((s) => s.count) ?? [1]));
  const studyMax = Math.max(1, ...(data?.studyBySubject.map((s) => s.weekMinutes) ?? [1]));
  const fmtMinutes = (m: number) => (m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`);
  const pct = data ? Math.round((data.totals.tasksDone / Math.max(1, data.totals.tasksTotal)) * 100) : 0;

  return (
    <Drawer
      open={open === "analytics"}
      onClose={closeSection}
      title={
        panel === "progress" ? "All progress" : panel === "recall" ? "Flashcard recall" : "Analytics"
      }
      subtitle={
        panel === "progress"
          ? "Targets, time entries & daily / weekly / monthly views"
          : panel === "recall"
            ? "Easy / good / hard rates over time, with entry control"
            : "Your gentle proof of progress"
      }
      icon={<BarChart3 size={18} />}
      size="lg"
    >
      <div className="flex flex-col gap-6 px-5 py-5 sm:px-6">
        {panel ? (
          <>
            <button
              onClick={() => setPanel(null)}
              className="btn-ghost self-start px-3 py-1.5 text-[11.5px] font-semibold"
            >
              <ChevronLeft size={13} /> Back to overview
            </button>
            {panel === "progress" ? <ProgressPanel /> : <RecallPanel />}
          </>
        ) : !data ? (
          <p className="py-10 text-center text-[13px]" style={{ color: "var(--ink-faint)" }}>Crunching numbers…</p>
        ) : (
          <>
            {/* hero stats */}
            <div
              className="flex items-center gap-4 rounded-3xl p-5"
              style={{ background: "var(--surface)", border: "1px solid var(--line)" }}
            >
              <div className="relative flex h-20 w-20 shrink-0 items-center justify-center">
                <svg viewBox="0 0 80 80" className="h-20 w-20 -rotate-90">
                  <circle cx="40" cy="40" r="34" fill="none" stroke="var(--line)" strokeWidth="8" />
                  <circle
                    cx="40" cy="40" r="34" fill="none" stroke="var(--accent)" strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${(pct / 100) * 214} 214`}
                    style={{ transition: "stroke-dasharray 0.8s cubic-bezier(0.22,1,0.36,1)" }}
                  />
                </svg>
                <span className="absolute text-[15px] font-bold tabular-nums" style={{ color: "var(--ink)" }}>{pct}%</span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-display text-[18px] font-semibold" style={{ color: "var(--ink)" }}>
                  {data.totals.tasksDone} of {data.totals.tasksTotal} tasks done
                </p>
                <p className="mt-1 flex items-center gap-1.5 text-[12.5px]" style={{ color: "var(--ink-soft)" }}>
                  <Flame size={13} style={{ color: "var(--accent)" }} />
                  {data.streak > 0
                    ? `${data.streak}-day streak — keep the flame alive`
                    : "Complete a task today to light a streak"}
                </p>
              </div>
            </div>

            <button
              onClick={() => setPanel("progress")}
              className="flex items-center gap-3 rounded-3xl p-4 text-left transition-transform hover:-translate-y-0.5"
              style={{ background: "var(--accent-soft)", border: "1px solid var(--accent)" }}
            >
              <span
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
                style={{ background: "var(--surface)", color: "var(--accent)" }}
              >
                <LineChart size={18} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[13.5px] font-bold" style={{ color: "var(--ink)" }}>
                  View All Progress
                </span>
                <span className="block text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
                  Target hours, daily / weekly / monthly charts, and every logged entry
                </span>
              </span>
              <ChevronLeft size={15} className="rotate-180" style={{ color: "var(--accent)" }} />
            </button>

            <button
              onClick={() => setPanel("recall")}
              className="flex items-center gap-3 rounded-3xl p-4 text-left transition-transform hover:-translate-y-0.5"
              style={{ background: "var(--surface)", border: "1px solid var(--line)" }}
            >
              <span
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
                style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
              >
                <Brain size={18} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[13.5px] font-bold" style={{ color: "var(--ink)" }}>
                  Flashcard recall
                </span>
                <span className="block text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
                  How often cards land easy, good or hard — daily, weekly, monthly
                </span>
              </span>
              <ChevronLeft size={15} className="rotate-180" style={{ color: "var(--accent)" }} />
            </button>

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Stat icon={NotebookPen} value={data.totals.notes} label="Notes" />
              <Stat icon={Layers} value={data.totals.flashcards} label="Flashcards" />
              <Stat icon={Quote} value={data.totals.quotes} label="Saved lines" />
              <Stat icon={BarChart3} value={data.totals.subjects} label="Subjects" />
            </div>

            {/* tasks per day */}
            <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
              <SectionLabel>Tasks completed · last 7 days</SectionLabel>
              <div className="mt-4 flex h-32 items-end gap-2.5">
                {data.doneLast7.map((d) => (
                  <div key={d.date} className="group flex flex-1 flex-col items-center gap-1.5">
                    <span className="text-[10.5px] font-bold tabular-nums opacity-0 transition-opacity group-hover:opacity-100" style={{ color: "var(--accent)" }}>
                      {d.count || ""}
                    </span>
                    <div
                      className="w-full rounded-t-lg transition-all duration-700"
                      style={{
                        height: `${(d.count / maxDone) * 82}px`,
                        minHeight: d.count ? 10 : 4,
                        background: d.count ? "var(--accent)" : "var(--surface-3)",
                        opacity: d.count ? 0.55 + (0.45 * d.count) / maxDone : 1,
                        borderRadius: "6px 6px 3px 3px",
                      }}
                    />
                    <span className="text-[10px] font-semibold" style={{ color: "var(--ink-faint)" }}>{d.label}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* focus minutes */}
            <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
              <SectionLabel>Focus minutes · last 7 days</SectionLabel>
              <div className="mt-4 flex h-24 items-end gap-2.5">
                {data.focusLast7.map((d) => (
                  <div key={d.date} className="group flex flex-1 flex-col items-center gap-1.5">
                    <span className="text-[10.5px] font-bold tabular-nums opacity-0 transition-opacity group-hover:opacity-100" style={{ color: "#52796f" }}>
                      {d.minutes || ""}
                    </span>
                    <div
                      className="w-full transition-all duration-700"
                      style={{
                        height: `${(d.minutes / maxFocus) * 56}px`,
                        minHeight: d.minutes ? 8 : 4,
                        background: d.minutes ? "#52796f" : "var(--surface-3)",
                        opacity: d.minutes ? 0.6 + (0.4 * d.minutes) / maxFocus : 1,
                        borderRadius: "6px 6px 3px 3px",
                      }}
                    />
                    <span className="text-[10px] font-semibold" style={{ color: "var(--ink-faint)" }}>{d.label}</span>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11px]" style={{ color: "var(--ink-faint)" }}>
                Sessions logged by the Timer section (sidebar → Timer).
              </p>
            </section>

            {/* study progress by subject (fed by note + timer sessions) */}
            <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
              <div className="flex items-center justify-between">
                <SectionLabel>Study progress by subject</SectionLabel>
                <span className="text-[11px] font-semibold" style={{ color: "var(--ink-faint)" }}>
                  this week · all time
                </span>
              </div>
              <div className="mt-4 flex flex-col gap-2.5">
                {data.studyBySubject.map((s) => (
                  <div key={s.subject} className="flex items-center gap-3">
                    <span className="w-24 truncate text-[12px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                      {s.subject}
                    </span>
                    <div className="h-3.5 flex-1 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${(s.weekMinutes / studyMax) * 100}%`,
                          minWidth: s.weekMinutes ? 8 : 0,
                          background: DEADLINE_COLORS[s.color] ?? "var(--accent)",
                        }}
                      />
                    </div>
                    <span className="w-28 text-right text-[12px] font-bold tabular-nums" style={{ color: "var(--ink)" }}>
                      {fmtMinutes(s.weekMinutes)} · {fmtMinutes(s.totalMinutes)}
                    </span>
                  </div>
                ))}
                {data.studyBySubject.length === 0 && (
                  <p className="py-4 text-center text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
                    No study time logged yet — start a focus session from a note or the
                    Timer section.
                  </p>
                )}
              </div>
            </section>

            {/* deadlines by subject */}
            <section className="rounded-3xl p-5" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
              <SectionLabel>Open deadlines by subject</SectionLabel>
              <div className="mt-4 flex flex-col gap-2.5">
                {data.deadlinesBySubject.map((s) => (
                  <div key={s.subject} className="flex items-center gap-3">
                    <span className="w-24 truncate text-[12px] font-semibold" style={{ color: "var(--ink-soft)" }}>
                      {s.subject}
                    </span>
                    <div className="h-3.5 flex-1 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${(s.count / subjectMax) * 100}%`,
                          background: DEADLINE_COLORS[s.color] ?? "var(--accent)",
                        }}
                      />
                    </div>
                    <span className="w-6 text-right text-[12px] font-bold tabular-nums" style={{ color: "var(--ink)" }}>
                      {s.count}
                    </span>
                  </div>
                ))}
                {data.deadlinesBySubject.length === 0 && (
                  <p className="py-4 text-center text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
                    No open deadlines — enjoy the clarity.
                  </p>
                )}
              </div>
            </section>
          </>
        )}
      </div>
    </Drawer>
  );
}
