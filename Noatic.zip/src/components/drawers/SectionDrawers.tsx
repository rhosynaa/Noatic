"use client";

import TasksDrawer from "@/components/drawers/TasksDrawer";
import CalendarDrawer from "@/components/drawers/CalendarDrawer";
import FlashcardsDrawer from "@/components/drawers/FlashcardsDrawer";
import WorkspacesDrawer from "@/components/drawers/WorkspacesDrawer";
import MindmapsDrawer from "@/components/drawers/MindmapsDrawer";
import MindmapDrawer from "@/components/drawers/MindmapDrawer";
import AnalyticsDrawer from "@/components/drawers/AnalyticsDrawer";
import TimerDrawer from "@/components/drawers/TimerDrawer";
import QuotesDrawer from "@/components/drawers/QuotesDrawer";
import TrashDrawer from "@/components/drawers/TrashDrawer";
import SelfAssessmentsPage from "@/components/drawers/SelfAssessmentsPage";
import GpaTrackerPage from "@/components/drawers/GpaTrackerPage";

export default function SectionDrawers() {
  return (
    <>
      <TasksDrawer />
      <CalendarDrawer />
      <FlashcardsDrawer />
      <WorkspacesDrawer />
      <MindmapsDrawer />
      <MindmapDrawer />
      <AnalyticsDrawer />
      <TimerDrawer />
      <QuotesDrawer />
      <TrashDrawer />
      <SelfAssessmentsPage />
      <GpaTrackerPage />
    </>
  );
}
