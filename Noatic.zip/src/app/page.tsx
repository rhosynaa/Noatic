"use client";

import dynamic from "next/dynamic";

/**
 * The whole app is a client-side experience backed by localStorage,
 * so it must never render on the server.
 */
const NoaticApp = dynamic(() => import("@/components/NoaticApp"), { ssr: false });

export default function HomePage() {
  return <NoaticApp />;
}
