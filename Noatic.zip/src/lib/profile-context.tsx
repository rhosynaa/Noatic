"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import type { Profile } from "@/lib/types";

type ProfileCtxType = {
  profile: Profile | null;
  update: (patch: Record<string, unknown>, opts?: { silent?: boolean }) => Promise<boolean>;
  refresh: () => Promise<void>;
};

const ProfileCtx = createContext<ProfileCtxType>({
  profile: null,
  update: async () => false,
  refresh: async () => {},
});

export function useProfile() {
  return useContext(ProfileCtx);
}

export function ProfileProvider({
  children,
  initial,
}: {
  children: ReactNode;
  initial?: Profile | null;
}) {
  const [profile, setProfile] = useState<Profile | null>(initial ?? null);
  const { push } = useToast();

  const refresh = useCallback(async () => {
    try {
      const p = await api<Profile>("/api/profile");
      setProfile(p);
    } catch {
      /* keep stale */
    }
  }, []);

  useEffect(() => {
    if (initial) return;
    const id = setTimeout(() => {
      refresh();
    }, 0);
    return () => clearTimeout(id);
  }, [initial, refresh]);

  const update = useCallback(
    async (patch: Record<string, unknown>, opts?: { silent?: boolean }) => {
      const prev = profile;
      // optimistic merge (except pure side-effect calls like syncNow)
      if (prev && !("syncNow" in patch)) {
        setProfile({ ...prev, ...(patch as Partial<Profile>) });
      }
      try {
        const next = await api<Profile>("/api/profile", { method: "PATCH", body: patch });
        setProfile(next);
        if (!opts?.silent) push("success", "Profile saved");
        return true;
      } catch (e) {
        if (prev) setProfile(prev);
        push("error", e instanceof Error ? e.message : "Couldn't save");
        return false;
      }
    },
    [profile, push]
  );

  const value = useMemo(() => ({ profile, update, refresh }), [profile, update, refresh]);
  return <ProfileCtx.Provider value={value}>{children}</ProfileCtx.Provider>;
}
