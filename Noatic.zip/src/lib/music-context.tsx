"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api } from "@/lib/api";
import { saveAudioUpload } from "@/lib/local-db";
import { useToast } from "@/lib/toast";
import type { Playlist, Track } from "@/lib/types";

type MusicCtxType = {
  tracks: Track[];
  current: Track | null;
  playing: boolean;
  shuffle: boolean;
  /** off = stop at end of queue · all = loop the queue · one = loop this song */
  repeat: "off" | "all" | "one";
  progress: number;
  duration: number;
  volume: number;
  drawerOpen: boolean;
  broken: Set<string>;
  play: (track: Track) => void;
  toggle: () => void;
  next: () => void;
  prev: () => void;
  seek: (sec: number) => void;
  setVolume: (v: number) => void;
  toggleShuffle: () => void;
  /** cycles off → all → one → off */
  toggleRepeat: () => void;
  setDrawerOpen: (v: boolean) => void;
  addTrack: (data: {
    title: string;
    artist: string;
    url: string;
    coverUrl?: string;
    playlistId?: string | null;
  }) => Promise<boolean>;
  removeTrack: (id: string) => Promise<void>;
  updateTrackCover: (id: string, coverUrl: string, silent?: boolean) => Promise<void>;
  uploadTrack: (
    file: File,
    meta?: {
      title?: string;
      artist?: string;
      playlistId?: string | null;
      coverUrl?: string;
    }
  ) => Promise<boolean>;

  /* playlists */
  playlists: Playlist[];
  activePlaylistId: string | null;
  /** the tracks that playback walks through — the active playlist, or everything */
  queue: Track[];
  setActivePlaylist: (id: string | null) => void;
  createPlaylist: (name: string) => Promise<Playlist | null>;
  renamePlaylist: (id: string, name: string) => Promise<void>;
  deletePlaylist: (id: string) => Promise<void>;
  addToPlaylist: (playlistId: string, trackId: string) => Promise<void>;
  removeFromPlaylist: (playlistId: string, trackId: string) => Promise<void>;
};

const MusicCtx = createContext<MusicCtxType | null>(null);

export function useMusic(): MusicCtxType {
  const ctx = useContext(MusicCtx);
  if (!ctx) throw new Error("useMusic must be used inside AppProviders");
  return ctx;
}

export function MusicProvider({
  children,
  initialShuffle = false,
  onShufflePersist,
}: {
  children: ReactNode;
  initialShuffle?: boolean;
  onShufflePersist?: (v: boolean) => void;
}) {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [shuffle, setShuffle] = useState(initialShuffle);
  const [repeat, setRepeat] = useState<"off" | "all" | "one">("off");
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.85);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [broken, setBroken] = useState<Set<string>>(new Set());
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [activePlaylistId, setActivePlaylistId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const tracksRef = useRef<Track[]>([]);
  const currentRef = useRef<Track | null>(null);
  const shuffleRef = useRef(shuffle);
  const repeatRef = useRef(repeat);
  const { push } = useToast();

  tracksRef.current = tracks;
  shuffleRef.current = shuffle;
  repeatRef.current = repeat;

  const current = useMemo(
    () => tracks.find((t) => t.id === currentId) ?? null,
    [tracks, currentId]
  );
  currentRef.current = current;

  /**
   * Playback walks this list. With a playlist selected it contains only that
   * playlist's songs (in playlist order), so next/prev/shuffle/auto-advance
   * never wander outside it.
   */
  const queue = useMemo(() => {
    if (!activePlaylistId) return tracks;
    const pl = playlists.find((p) => p.id === activePlaylistId);
    if (!pl) return tracks;
    return pl.trackIds
      .map((id) => tracks.find((t) => t.id === id))
      .filter((t): t is Track => Boolean(t));
  }, [tracks, playlists, activePlaylistId]);

  const queueRef = useRef<Track[]>([]);
  queueRef.current = queue;

  // Load library + playlists
  useEffect(() => {
    api<Track[]>("/api/tracks")
      .then((rows) => {
        setTracks(rows);
        if (rows.length && !currentRef.current) setCurrentId(rows[0].id);
      })
      .catch(() => {});
    api<Playlist[]>("/api/playlists").then(setPlaylists).catch(() => {});
  }, []);

  // Create the audio element once
  useEffect(() => {
    const audio = new Audio();
    audio.preload = "metadata";
    audio.volume = 0.85;
    audioRef.current = audio;

    const onTime = () => setProgress(audio.currentTime);
    const onMeta = () => setDuration(audio.duration || 0);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onEnded = () => advanceRef.current(true);
    const onError = () => {
      const cur = currentRef.current;
      if (!cur) return;
      setPlaying(false);
      setBroken((b) => new Set(b).add(cur.id));
      push("error", "That audio link didn't load — try replacing it");
    };

    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);
    return () => {
      audio.pause();
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onMeta);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
      audioRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const play = useCallback(
    (track: Track) => {
      const audio = audioRef.current;
      setCurrentId(track.id);
      setBroken((b) => {
        if (!b.has(track.id)) return b;
        const next = new Set(b);
        next.delete(track.id);
        return next;
      });

      // never let the previous song's timings bleed into the new one
      setProgress(0);
      setDuration(0);

      if (track.sourceType === "audio") {
        if (audio) {
          audio.src = track.url;
          audio.currentTime = 0;
          audio.play().catch(() => {
            setPlaying(false);
            push("error", "Couldn't start playback — tap play again");
          });
        }
      } else {
        // embeds: pause any <audio> and let the iframe autoplay
        if (audio && !audio.paused) audio.pause();
        setPlaying(true);
        push("info", track.sourceType === "youtube" ? "Playing via YouTube embed" : "Playing via Spotify embed");
      }
    },
    [push]
  );

  const advance = useCallback(
    (auto = false, backwards = false) => {
      const list = queueRef.current.length ? queueRef.current : tracksRef.current;
      if (list.length === 0) return;
      const cur = currentRef.current;
      const idx = Math.max(
        0,
        cur ? list.findIndex((t) => t.id === cur.id) : 0
      );
      let nextIdx: number;
      if (shuffleRef.current && list.length > 1 && !backwards) {
        do {
          nextIdx = Math.floor(Math.random() * list.length);
        } while (nextIdx === idx);
      } else {
        nextIdx = backwards
          ? (idx - 1 + list.length) % list.length
          : (idx + 1) % list.length;
      }
      // with repeat off, auto-advance stops at the end of the queue
      if (auto && !backwards && repeatRef.current === "off" && idx === list.length - 1) {
        const audio = audioRef.current;
        if (audio) audio.pause();
        setPlaying(false);
        return;
      }
      const nextTrack = list[nextIdx];
      if (!nextTrack) return;
      play(nextTrack);
    },
    [play]
  );
  const advanceRef = useRef(advance);
  advanceRef.current = advance;

  const toggle = useCallback(() => {
    const audio = audioRef.current;
    const cur = currentRef.current;
    if (!cur) {
      const first = (queueRef.current.length ? queueRef.current : tracksRef.current)[0];
      if (first) play(first);
      return;
    }
    if (cur.sourceType !== "audio") {
      setPlaying((p) => !p); // hide/show embed
      return;
    }
    if (!audio) return;
    if (!audio.src || audio.src === "") {
      play(cur);
      return;
    }
    if (audio.paused) {
      audio.play().catch(() => setPlaying(false));
    } else {
      audio.pause();
    }
  }, [play]);

  const next = useCallback(() => advance(false, false), [advance]);
  const prev = useCallback(() => {
    const audio = audioRef.current;
    // If we're more than 3s in, restart the track instead
    if (audio && currentRef.current?.sourceType === "audio" && audio.currentTime > 3) {
      audio.currentTime = 0;
      return;
    }
    advance(false, true);
  }, [advance]);

  const seek = useCallback((sec: number) => {
    const audio = audioRef.current;
    if (audio && currentRef.current?.sourceType === "audio") {
      audio.currentTime = Math.max(0, Math.min(sec, audio.duration || 0));
      setProgress(audio.currentTime);
    }
  }, []);

  const setVolume = useCallback((v: number) => {
    const clamped = Math.max(0, Math.min(1, v));
    setVolumeState(clamped);
    if (audioRef.current) audioRef.current.volume = clamped;
  }, []);

  const toggleShuffle = useCallback(() => {
    setShuffle((s) => {
      const v = !s;
      onShufflePersist?.(v);
      push("info", v ? "Shuffle on — surprise me" : "Shuffle off");
      return v;
    });
  }, [onShufflePersist, push]);

  const toggleRepeat = useCallback(() => {
    setRepeat((r) => {
      const nextMode = r === "off" ? "all" : r === "all" ? "one" : "off";
      push(
        "info",
        nextMode === "off"
          ? "Repeat off — playback stops at the end"
          : nextMode === "all"
            ? "Repeating the whole queue"
            : "Repeating this song"
      );
      return nextMode;
    });
  }, [push]);

  const refreshPlaylists = useCallback(async () => {
    try {
      setPlaylists(await api<Playlist[]>("/api/playlists"));
    } catch {
      /* quiet */
    }
  }, []);

  const addTrack = useCallback(
    async (data: {
      title: string;
      artist: string;
      url: string;
      coverUrl?: string;
      playlistId?: string | null;
    }) => {
      try {
        const row = await api<Track>("/api/tracks", { method: "POST", body: data });
        setTracks((t) => [...t, row]);
        if (data.playlistId) {
          await api(`/api/playlists/${data.playlistId}/tracks`, {
            method: "POST",
            body: { trackId: row.id },
          });
          await refreshPlaylists();
          push("success", `"${row.title}" added to the playlist`);
        } else {
          push("success", `"${row.title}" added to your library`);
        }
        return true;
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't add that track");
        return false;
      }
    },
    [push, refreshPlaylists]
  );

  /** Upload a song from the device, then register it as a track. */
  const uploadTrack = useCallback(
    async (
      file: File,
      meta?: {
        title?: string;
        artist?: string;
        playlistId?: string | null;
        coverUrl?: string;
      }
    ) => {
      try {
        const up = await saveAudioUpload(file);
        const title =
          meta?.title?.trim() || file.name.replace(/\.[^.]+$/, "").slice(0, 80) || "Untitled";
        return await addTrack({
          title,
          artist: meta?.artist?.trim() ?? "",
          url: up.url,
          // the cover picked in the Add Music form was being dropped here
          coverUrl: meta?.coverUrl ?? "",
          playlistId: meta?.playlistId ?? null,
        });
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't upload that file");
        return false;
      }
    },
    [addTrack, push]
  );

  /* ---------- playlists ---------- */

  const setActivePlaylist = useCallback((id: string | null) => {
    setActivePlaylistId(id);
  }, []);

  const createPlaylist = useCallback(
    async (name: string) => {
      try {
        const row = await api<Playlist>("/api/playlists", {
          method: "POST",
          body: { name },
        });
        setPlaylists((p) => [...p, { ...row, trackIds: row.trackIds ?? [] }]);
        push("success", `Playlist "${row.name}" created`);
        return row;
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't create that playlist");
        return null;
      }
    },
    [push]
  );

  const renamePlaylist = useCallback(
    async (id: string, name: string) => {
      setPlaylists((p) => p.map((x) => (x.id === id ? { ...x, name } : x)));
      try {
        await api(`/api/playlists/${id}`, { method: "PATCH", body: { name } });
      } catch {
        push("error", "Couldn't rename that playlist");
        await refreshPlaylists();
      }
    },
    [push, refreshPlaylists]
  );

  const deletePlaylist = useCallback(
    async (id: string) => {
      setPlaylists((p) => p.filter((x) => x.id !== id));
      setActivePlaylistId((cur) => (cur === id ? null : cur));
      try {
        await api(`/api/playlists/${id}`, { method: "DELETE" });
        push("info", "Playlist deleted — your songs are still in the library");
      } catch {
        push("error", "Couldn't delete that playlist");
        await refreshPlaylists();
      }
    },
    [push, refreshPlaylists]
  );

  const addToPlaylist = useCallback(
    async (playlistId: string, trackId: string) => {
      setPlaylists((p) =>
        p.map((x) =>
          x.id === playlistId && !x.trackIds.includes(trackId)
            ? { ...x, trackIds: [...x.trackIds, trackId] }
            : x
        )
      );
      try {
        await api(`/api/playlists/${playlistId}/tracks`, {
          method: "POST",
          body: { trackId },
        });
      } catch {
        push("error", "Couldn't add to that playlist");
        await refreshPlaylists();
      }
    },
    [push, refreshPlaylists]
  );

  /** Removes the link only — the song itself stays in the library. */
  const removeFromPlaylist = useCallback(
    async (playlistId: string, trackId: string) => {
      setPlaylists((p) =>
        p.map((x) =>
          x.id === playlistId
            ? { ...x, trackIds: x.trackIds.filter((t) => t !== trackId) }
            : x
        )
      );
      try {
        await api(`/api/playlists/${playlistId}/tracks?trackId=${trackId}`, {
          method: "DELETE",
        });
        push("info", "Removed from playlist — the song is still in your library");
      } catch {
        push("error", "Couldn't remove from that playlist");
        await refreshPlaylists();
      }
    },
    [push, refreshPlaylists]
  );

  const removeTrack = useCallback(
    async (id: string) => {
      const prev = tracks;
      setTracks((t) => t.filter((x) => x.id !== id));
      if (currentId === id) {
        const audio = audioRef.current;
        if (audio) audio.pause();
        setPlaying(false);
        setCurrentId(null);
      }
      try {
        await api(`/api/tracks/${id}`, { method: "DELETE" });
      } catch {
        setTracks(prev);
        push("error", "Couldn't remove that track");
      }
    },
    [tracks, currentId, push]
  );

  const updateTrackCover = useCallback(
    async (id: string, coverUrl: string, silent = false) => {
      const prev = tracks;
      setTracks((t) => t.map((x) => (x.id === id ? { ...x, coverUrl } : x)));
      try {
        await api(`/api/tracks/${id}`, {
          method: "PATCH",
          body: { coverUrl },
        });
        // an auto-shuffle saves constantly, so it opts out of the toast
        if (!silent) push("success", "Cover updated");
      } catch {
        setTracks(prev);
        push("error", "Couldn't update the cover");
      }
    },
    [tracks, push]
  );

  const value = useMemo<MusicCtxType>(
    () => ({
      tracks,
      current,
      playing,
      shuffle,
      repeat,
      progress,
      duration,
      volume,
      drawerOpen,
      broken,
      play,
      toggle,
      next,
      prev,
      seek,
      setVolume,
      toggleShuffle,
      toggleRepeat,
      setDrawerOpen,
      addTrack,
      removeTrack,
      updateTrackCover,
      uploadTrack,
      playlists,
      activePlaylistId,
      queue,
      setActivePlaylist,
      createPlaylist,
      renamePlaylist,
      deletePlaylist,
      addToPlaylist,
      removeFromPlaylist,
    }),
    [
      tracks,
      current,
      playing,
      shuffle,
      repeat,
      progress,
      duration,
      volume,
      drawerOpen,
      broken,
      play,
      toggle,
      next,
      prev,
      seek,
      setVolume,
      toggleShuffle,
      toggleRepeat,
      addTrack,
      removeTrack,
      updateTrackCover,
      uploadTrack,
      playlists,
      activePlaylistId,
      queue,
      setActivePlaylist,
      createPlaylist,
      renamePlaylist,
      deletePlaylist,
      addToPlaylist,
      removeFromPlaylist,
    ]
  );

  return <MusicCtx.Provider value={value}>{children}</MusicCtx.Provider>;
}
