/**
 * Central asset resolver — maps the original app's public/ URLs
 * ("/images/hero.jpg", "/covers/rain.svg", …) to inlined data URLs
 * so nothing 404s in the static single-file build.
 *
 * The photographs live in `photo-assets.ts` as base64 text so they can't be
 * stripped out of a download the way binary files were.
 */

// Cover SVGs are inlined as data URLs (see cover-data.ts) — same artwork as
// public/covers, but they can't 404 in the single-file build.
import {
  COVER_SUNRISE,
  COVER_DUSK,
  COVER_RAIN,
  COVER_MEADOW,
  COVER_EMBER,
} from "@/lib/cover-data";
const coverSunrise = COVER_SUNRISE;
const coverDusk = COVER_DUSK;
const coverRain = COVER_RAIN;
const coverMeadow = COVER_MEADOW;
const coverEmber = COVER_EMBER;
import {
  AVATAR_PHOTO,
  GALLERY_PHOTO,
  HERO_PHOTO,
  SUBJECT_BIOLOGY_PHOTO,
  SUBJECT_CHEMISTRY_PHOTO,
  SUBJECT_ENGLISH_PHOTO,
  SUBJECT_HISTORY_PHOTO,
  SUBJECT_MATH_PHOTO,
} from "@/lib/photo-assets";

export const HERO_IMG = HERO_PHOTO;
export const GALLERY_IMG = GALLERY_PHOTO;
export const AVATAR_IMG = AVATAR_PHOTO;

export const ASSET_MAP: Record<string, string> = {
  // legacy keys — older saves stored these paths, so they must keep resolving
  "/images/hero.jpg": HERO_PHOTO,
  "/images/gallery.jpg": GALLERY_PHOTO,
  "/images/avatar.png": AVATAR_PHOTO,
  "/images/hero.svg": HERO_PHOTO,
  "/images/gallery.svg": GALLERY_PHOTO,
  "/images/avatar.svg": AVATAR_PHOTO,
  "/covers/sunrise.svg": coverSunrise,
  "/covers/dusk.svg": coverDusk,
  "/covers/rain.svg": coverRain,
  "/covers/meadow.svg": coverMeadow,
  "/covers/ember.svg": coverEmber,
};

/** Default per-subject card covers (by lowercase subject name). */
export const SUBJECT_COVERS: Record<string, string> = {
  biology: SUBJECT_BIOLOGY_PHOTO,
  math: SUBJECT_MATH_PHOTO,
  english: SUBJECT_ENGLISH_PHOTO,
  chemistry: SUBJECT_CHEMISTRY_PHOTO,
  history: SUBJECT_HISTORY_PHOTO,
};
export const SUBJECT_COVER_LIST = [
  SUBJECT_BIOLOGY_PHOTO,
  SUBJECT_MATH_PHOTO,
  SUBJECT_ENGLISH_PHOTO,
  SUBJECT_CHEMISTRY_PHOTO,
  SUBJECT_HISTORY_PHOTO,
];

/** Stable fallback cover for a subject id that has no custom art. */
export function coverForSubject(id: string, name: string): string {
  const named = SUBJECT_COVERS[name.trim().toLowerCase()];
  if (named) return named;
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return SUBJECT_COVER_LIST[h % SUBJECT_COVER_LIST.length];
}

/** Resolve a stored URL to something renderable in this build. */
export function asset(url: string | null | undefined): string {
  if (!url) return "";
  return ASSET_MAP[url] ?? url;
}
