/**
 * Dreamy Study — local data layer.
 *
 * The original Next.js app persists everything in Postgres behind /api/* route
 * handlers. This module reimplements those exact contracts in the browser,
 * backed by localStorage, so the UI code works unchanged.
 */

import type {
  AnalyticsData,
  DashboardData,
  Deadline,
  Flashcard,
  FlashcardReview,
  FocusSession,
  MindMap,
  MindMapLink,
  MindNode,
  Note,
  Playlist,
  Profile,
  ProgressBucket,
  ProgressData,
  QuoteRow,
  RatingCounts,
  ReviewBucket,
  ReviewRating,
  ReviewStats,
  Settings,
  SiteImage,
  StudyTarget,
  Subject,
  TargetProgress,
  Task,
  Template,
  TimerChain,
  TimerPreset,
  Track,
  TrashBin,
  TrashType,
  Workspace,
  SelfAssessment,
  GpaCourse,
  GpaChecklistItem,
  GpaSemester,
  GpaSettings,
  MediaItem,
  CoverRotation,
} from "@/lib/types";
import { DEMO_MEDIA } from "@/lib/media-assets";
import { ROTATE_MAX_SECONDS, ROTATE_MIN_SECONDS } from "@/lib/types";
import {
  DEFAULT_GPA_CHECKLIST,
  DEFAULT_WIDGET_ORDER,
  GPA_COURSE_NOTES_MAX_WORDS,
  GPA_COURSE_NOTES_WORDS_PER_LINE,
  GPA_GOAL_MAX_WORDS,
  GPA_GOAL_WORDS_PER_LINE,
  GPA_NOTES_MAX_WORDS,
  GPA_NOTES_WORDS_PER_LINE,
  GRADE_POINTS,
  wrapByWords,
} from "@/lib/types";
import { SUBJECT_COVERS, coverForSubject } from "@/lib/assets";

// Cover SVGs live in /public/covers and are served as plain URLs
const coverSunrise = "/covers/sunrise.svg";
const coverDusk = "/covers/dusk.svg";
const coverRain = "/covers/rain.svg";
const coverMeadow = "/covers/meadow.svg";
const coverEmber = "/covers/ember.svg";
import { HERO_PHOTO as imgHero, GALLERY_PHOTO as imgGallery, AVATAR_PHOTO as imgAvatar } from "@/lib/photo-assets";

export const LIBRARY_COVERS: Record<string, string> = {
  "/covers/sunrise.svg": coverSunrise,
  "/covers/dusk.svg": coverDusk,
  "/covers/rain.svg": coverRain,
  "/covers/meadow.svg": coverMeadow,
  "/covers/ember.svg": coverEmber,
};

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

const LS_KEY = "dreamy-study-db-v1";

export function uuid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

const now = () => new Date().toISOString();
const inDays = (d: number) => new Date(Date.now() + d * 86400000).toISOString();
const ago = (days: number, hour: number) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(hour, 0, 0, 0);
  return d.toISOString();
};

function dayKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}
function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
/** Monday-anchored week start */
function weekStart(d: Date): Date {
  const c = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  c.setDate(c.getDate() - ((c.getDay() + 6) % 7));
  return c;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

/* ------------------------------------------------------------------ */
/* row types (internal — match the old DB serialisation)               */
/* ------------------------------------------------------------------ */

type TaskRow = Task & { createdAt: string; completedAt: string | null; deletedAt: string | null };
type DeadlineRow = Deadline & { createdAt: string; deletedAt: string | null };
type QuoteRowFull = QuoteRow & { createdAt: string };
type TrackRow = Track & { createdAt: string };
type NoteRow = Note & { createdAt: string; deletedAt: string | null };
type TemplateRow = Template & { createdAt: string };
type SubjectRow = Subject & {
  createdAt: string;
  workspaceId: string;
  code: string;
  semester: string;
  coverUrl: string;
};
type WorkspaceRow = Workspace & { createdAt: string };
type SelfAssessmentRow = SelfAssessment & { createdAt: string };
type GpaCourseRow = GpaCourse & { createdAt: string };
type GpaSemesterRow = GpaSemester & { createdAt: string };
type FlashcardRow = Flashcard & { createdAt: string; deletedAt: string | null };
type ReviewRow = FlashcardReview;
type PlaylistRow = { id: string; name: string; coverUrl: string; position: number; createdAt: string };
type PlaylistTrackRow = { id: string; playlistId: string; trackId: string; position: number; addedAt: string };
type MindNodeRow = MindNode & { createdAt: string };
type MindMapRow = MindMap & { createdAt: string };
type TimerPresetRow = TimerPreset & { createdAt: string };
type TimerChainRow = TimerChain & { createdAt: string };
type StudyTargetRow = StudyTarget & { createdAt: string };

export type DB = {
  profile: Profile;
  settings: Settings;
  tasks: TaskRow[];
  deadlines: DeadlineRow[];
  quotes: QuoteRowFull[];
  tracks: TrackRow[];
  notes: NoteRow[];
  templates: TemplateRow[];
  images: (SiteImage & { updatedAt: string })[];
  media: MediaItem[];
  coverRotations: CoverRotation[];
  workspaces: WorkspaceRow[];
  subjects: SubjectRow[];
  selfAssessments: SelfAssessmentRow[];
  gpaCourses: GpaCourseRow[];
  gpaSettings: GpaSettings;
  gpaSemesters: GpaSemesterRow[];
  flashcards: FlashcardRow[];
  flashcardReviews: ReviewRow[];
  playlists: PlaylistRow[];
  playlistTracks: PlaylistTrackRow[];
  mindmaps: MindMapRow[];
  mindnodes: MindNodeRow[];
  focusSessions: FocusSession[];
  timerPresets: TimerPresetRow[];
  timerChains: TimerChainRow[];
  studyTargets: StudyTargetRow[];
};

/** Default grading-scale settings — custom scale mirrors GRADE_POINTS, weighted on. */
export function defaultGpaSettings(): GpaSettings {
  return { scale: { ...GRADE_POINTS }, weighted: true, notes: "" };
}

/** The eight semester slots the GPA tracker always keeps. */
export function defaultGpaSemesters(): GpaSemesterRow[] {
  return Array.from({ length: 8 }, (_, i) => ({
    id: uuid(),
    name: `Semester ${i + 1}`,
    academicYear: "",
    targetGpa: "",
    achieveBy: "",
    checklist: DEFAULT_GPA_CHECKLIST.map((text) => ({ text, done: false })),
    achieved: false,
    createdAt: new Date(Date.now() + i * 1000).toISOString(),
  }));
}

/* ---- demo content so every tracker field shows something on first run ---- */

const GPA_DEMO_GOAL_1 =
  "Hold a 4.0 by turning every lab report in two days early, revising with active recall instead of rereading, and booking one office hours visit each week.";
const GPA_DEMO_GOAL_2 =
  "Keep the 3.8 steady while adding chemistry lab hours and still sleeping before midnight.";
export const GPA_DEMO_NOTES =
  "Weighted mode finally makes the AP load look honest on paper. Sunday past papers carried biology and math this term, so keep that slot sacred. Chemistry slipped when lab reports piled up — start them the night of the lab. Next semester: fewer late nights, more morning revision, and ask for help sooner.";

/** A semester slot the student has never touched — safe to fill with demo content. */
function isPristineSemester(s: GpaSemester): boolean {
  return (
    !s.targetGpa &&
    !s.achieveBy &&
    !s.academicYear &&
    !s.achieved &&
    /^Semester \d$/.test(s.name) &&
    s.checklist.length === DEFAULT_GPA_CHECKLIST.length &&
    s.checklist.every((c) => !c.done)
  );
}

/** Fills the first two semester slots with demo goals, plans and ticks. */
export function applyGpaDemo(sems: GpaSemesterRow[]): GpaSemesterRow[] {
  if (sems[0] && isPristineSemester(sems[0])) {
    sems[0] = {
      ...sems[0],
      name: "Fall — Semester 1",
      academicYear: "2024 – 2025",
      targetGpa: wrapByWords(GPA_DEMO_GOAL_1, GPA_GOAL_MAX_WORDS, GPA_GOAL_WORDS_PER_LINE),
      achieveBy: inDays(60).slice(0, 10),
      // seven steps — more than fits, so the action plan demos its scroll
      checklist: [
        { text: "Attending all classes", done: true },
        { text: "Staying organized", done: true },
        { text: "Completing assignments on time", done: false },
        { text: "Studying consistently", done: true },
        { text: "Asking for help when needed", done: false },
        { text: "Past paper every Sunday morning", done: false },
        { text: "Phone in another room while studying", done: false },
      ],
      achieved: false,
    };
  }
  if (sems[1] && isPristineSemester(sems[1])) {
    sems[1] = {
      ...sems[1],
      name: "Spring — Semester 2",
      academicYear: "2024 – 2025",
      targetGpa: wrapByWords(GPA_DEMO_GOAL_2, GPA_GOAL_MAX_WORDS, GPA_GOAL_WORDS_PER_LINE),
      achieveBy: inDays(210).slice(0, 10),
      // already ticked — demos the Achieved? box in its checked state
      achieved: true,
    };
  }
  return sems;
}

/* ---- media library ---------------------------------------------------- */

/** The six pictures the library starts with, newest first. */
export function defaultMedia(): MediaItem[] {
  const base = Date.now();
  return DEMO_MEDIA.map((m, i) => ({
    id: uuid(),
    url: m.url,
    name: m.name,
    category: m.category,
    createdAt: new Date(base - i * 1000).toISOString(),
  }));
}

/** Clamp a rotation speed to the supported 30s – 1h window. */
export function clampRotateSeconds(n: unknown): number {
  const v = Math.round(Number(n));
  if (!Number.isFinite(v)) return ROTATE_MIN_SECONDS;
  return Math.max(ROTATE_MIN_SECONDS, Math.min(ROTATE_MAX_SECONDS, v));
}

/* ---- demo workspace with enough subjects to show the library rail scroll ---- */

const LIBRARY_DEMO_WS = "Year 2 — Full Load";

/** twelve subjects, so the Libraries rail passes its ten-row cap and scrolls */
const LIBRARY_DEMO_SUBJECTS: [string, string, string][] = [
  ["Anatomy", "rose", "ANA 210"],
  ["Physiology", "green", "PHY 215"],
  ["Biochemistry", "violet", "BCH 230"],
  ["Microbiology", "blue", "MIC 240"],
  ["Pharmacology", "amber", "PHA 250"],
  ["Pathology", "rose", "PAT 260"],
  ["Genetics", "green", "GEN 270"],
  ["Immunology", "violet", "IMM 280"],
  ["Neuroscience", "blue", "NEU 290"],
  ["Statistics", "amber", "STA 200"],
  ["Ethics", "rose", "ETH 205"],
  ["Research Methods", "green", "RES 295"],
];

/**
 * Adds the twelve-subject demo workspace when it isn't there yet.
 * Existing workspaces and subjects are never touched.
 */
export function applyLibraryDemo(
  workspaces: WorkspaceRow[],
  subjects: SubjectRow[]
): { workspaces: WorkspaceRow[]; subjects: SubjectRow[] } {
  if (workspaces.some((w) => w.name === LIBRARY_DEMO_WS)) return { workspaces, subjects };
  const ws: WorkspaceRow = {
    id: uuid(),
    name: LIBRARY_DEMO_WS,
    position: workspaces.length,
    createdAt: now(),
  };
  const rows: SubjectRow[] = LIBRARY_DEMO_SUBJECTS.map(([name, color, code], i) => ({
    id: uuid(),
    name,
    color,
    code,
    semester: i % 2 === 0 ? "Fall 2025" : "Spring 2026",
    coverUrl: SUBJECT_COVERS[name.toLowerCase()] ?? "",
    workspaceId: ws.id,
    createdAt: new Date(Date.now() + i * 1000).toISOString(),
  }));
  return { workspaces: [...workspaces, ws], subjects: [...subjects, ...rows] };
}

/* ------------------------------------------------------------------ */
/* seed                                                                */
/* ------------------------------------------------------------------ */

function seed(): DB {
  const stamp = now();
  const t = <T extends object>(rows: T[]): (T & { createdAt: string })[] =>
    rows.map((r, i) => ({ ...r, createdAt: new Date(Date.now() + i * 1000).toISOString() }));

  const taskRows = t<Task>([
    { id: uuid(), title: "Finish Chapter 7 math exercises", time: "08:00", priority: "high", subject: "Math", dueDate: inDays(1), done: true, position: 0 },
    { id: uuid(), title: "Revise biology flashcards", time: "10:30", priority: "medium", subject: "Biology", dueDate: inDays(2), done: false, position: 1 },
    { id: uuid(), title: "Draft English essay outline", time: "13:00", priority: "high", subject: "English", dueDate: inDays(4), done: false, position: 2 },
    { id: uuid(), title: "20 pages of required reading", time: "16:00", priority: "low", subject: "History", dueDate: null, done: false, position: 3 },
    { id: uuid(), title: "Plan tomorrow's study blocks", time: "21:00", priority: "medium", subject: "", dueDate: null, done: false, position: 4 },
  ]).map((r) => ({ ...r, completedAt: r.done ? stamp : null, deletedAt: null }));

  const dl = (
    title: string,
    subject: string,
    color: string,
    days: number,
    done = false
  ): Deadline => ({ id: uuid(), title, subject, color, dueDate: inDays(days), done });
  const deadlines: DeadlineRow[] = t<Deadline>([
    // Math
    dl("Math worksheet 12", "Math", "rose", 1),
    dl("Trig problem set 4", "Math", "rose", 3),
    dl("Linear algebra quiz prep", "Math", "rose", 6),
    dl("Statistics packet 2", "Math", "rose", 10),
    dl("Geometry proof write-up", "Math", "rose", 13),
    dl("Calculus drill 7", "Math", "rose", -1, true),
    // Biology
    dl("Cell biology quiz", "Biology", "green", 2),
    dl("Lab notebook check", "Biology", "green", 4),
    dl("Ecology reading chapters 3–4", "Biology", "green", 8),
    dl("Genetics worksheet", "Biology", "green", -2, true),
    // English
    dl("Gatsby chapters 4–6 notes", "English", "blue", 2),
    dl("English essay final draft", "English", "blue", 9),
    dl("Poetry response", "English", "blue", -1, true),
    // Chemistry
    dl("Stoichiometry practice set", "Chemistry", "violet", 3),
    dl("Chemistry lab report", "Chemistry", "violet", 5),
    dl("Periodic trends quiz", "Chemistry", "violet", 7),
    // History
    dl("History source analysis", "History", "amber", 2),
    dl("Cold War timeline project", "History", "amber", 4),
    dl("Primary source reading pack", "History", "amber", 8),
    dl("WWI essay", "History", "amber", -3, true),
  ]).map((r) => ({ ...r, deletedAt: null }));

  const quotes: QuoteRowFull[] = t<QuoteRow>([
    { id: uuid(), text: "The secret of getting ahead is getting started.", author: "Mark Twain", kind: "quote" },
    { id: uuid(), text: "It always seems impossible until it's done.", author: "Nelson Mandela", kind: "quote" },
    { id: uuid(), text: "Little by little, a little becomes a lot.", author: "Tanzanian proverb", kind: "quote" },
    { id: uuid(), text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson", kind: "quote" },
    { id: uuid(), text: "Success is the sum of small efforts, repeated day in and day out.", author: "Robert Collier", kind: "quote" },
    { id: uuid(), text: "Either you run the day or the day runs you.", author: "Jim Rohn", kind: "quote" },
    { id: uuid(), text: "You've survived 100% of your hardest days so far.", author: "", kind: "motivation" },
    { id: uuid(), text: "One focused hour beats five distracted ones. Start your timer.", author: "", kind: "motivation" },
    { id: uuid(), text: "Future you is already proud of today's effort.", author: "", kind: "motivation" },
    { id: uuid(), text: "Done is kinder than perfect. Ship the small win.", author: "", kind: "motivation" },
    { id: uuid(), text: "Your only competition is who you were yesterday.", author: "", kind: "motivation" },
    { id: uuid(), text: "Rest is part of the work. Breathe, then begin again.", author: "", kind: "motivation" },
  ]);

  const trackSeeds: [string, string, string, string][] = [
    ["Peach Sunrise", "Dreamy Radio", coverSunrise, "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3"],
    ["Midtown Rooftops", "Night Study Club", coverDusk, "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"],
    ["Rain on Glass", "Window Seat Tapes", coverRain, "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"],
    ["Meadow Notes", "Golden Hour Band", coverMeadow, "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3"],
  ];
  const tracks: TrackRow[] = trackSeeds.map(([title, artist, coverUrl, url], i) => ({
    id: uuid(),
    title,
    artist,
    coverUrl,
    sourceType: "audio" as const,
    url,
    position: i,
    createdAt: new Date(Date.now() + i * 1000).toISOString(),
  }));

  const bioNoteId = uuid();
  const noteSeeds = [
    {
      id: uuid(),
      title: "Exam battle plan",
      content:
        "1. Rank subjects by exam date\n2. Two 50-minute blocks per subject\n3. Active recall over re-reading\n4. Past paper every Sunday morning\n5. Sleep before midnight — non negotiable.",
      color: "blush",
      subject: "Math",
      tags: ["ExamPrep", "Important", "Planning"],
      imageUrl: "",
      pinned: true,
    },
    {
      id: bioNoteId,
      title: "Biology — photosynthesis recap",
      content:
        "Light-dependent reactions happen in the thylakoid membrane → ATP + NADPH.\nCalvin cycle lives in the stroma and fixes CO₂ into G3P.\nMnemonic: Light in the THYLAKES, Sugar in the STROMA.",
      color: "mint",
      subject: "Biology",
      tags: ["Biology", "Revision"],
      imageUrl: imgGallery,
      pinned: false,
    },
    {
      id: uuid(),
      title: "Essay ideas — Great Gatsby",
      content:
        "The green light as a symbol of yearning vs. the valley of ashes as the cost.\nAngle: Gatsby didn't love Daisy, he loved the version of himself he could be next to her.",
      color: "lilac",
      subject: "English",
      tags: ["English", "Essay", "Ideas"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "Things that make the desk feel like home",
      content:
        "Warm lamp, tea within arm's reach, one plant (hopefully alive), playlist on shuffle, phone in another room.",
      color: "sky",
      subject: "",
      tags: ["Wellbeing"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "Chemistry — stoichiometry cheat-sheet",
      content:
        "1. Balance the equation first.\n2. Convert grams → moles with molar mass.\n3. Use the mole ratio from the coefficients.\n4. Convert back to whatever unit they ask for.\nLimiting reagent = whoever runs out first.",
      color: "lilac",
      subject: "Chemistry",
      tags: ["Chemistry", "Revision"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "History — Cold War timeline skeleton",
      content:
        "1945 Yalta & Potsdam → 1947 Truman Doctrine → 1948 Berlin Blockade → 1950 Korean War → 1962 Cuban Missile Crisis → 1989 Wall falls.\nAnchor dates first, weave causes after.",
      color: "cream",
      subject: "History",
      tags: ["History", "Timeline"],
      imageUrl: "",
      pinned: false,
    },
    /* ---- extra shelf stock so each subject library looks like a real shelf ---- */
    {
      id: uuid(),
      title: "Math — integration by parts",
      content:
        "∫u dv = uv − ∫v du.\nPick u with LIATE: Log, Inverse trig, Algebraic, Trig, Exponential.\nIf it loops back on itself, solve for the integral algebraically.",
      color: "blush",
      subject: "Math",
      // several "Re…" tags across the shelf, so typing "re" demos the autocomplete
      tags: ["Math", "Revision", "Recall", "Formulas"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "Math — past paper mistakes",
      content:
        "Dropped marks for not stating units. Sign errors when expanding brackets under a minus. Always sanity-check the answer against the graph.",
      color: "cream",
      subject: "Math",
      tags: ["Math", "ExamPrep", "Revision", "Mistakes"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "Biology — cell respiration",
      content:
        "Glycolysis (cytoplasm) → link reaction → Krebs (matrix) → electron transport chain (inner membrane).\nNet 38 ATP in theory, ~30–32 in practice.",
      color: "mint",
      subject: "Biology",
      tags: ["Biology", "Revision"],
      imageUrl: "",
      pinned: true,
    },
    {
      id: uuid(),
      title: "Biology — lab practical checklist",
      content:
        "Label axes with units. Repeat readings three times and mean them. Note the control variables before touching anything.",
      color: "sky",
      subject: "Biology",
      tags: ["Biology", "Lab"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "English — quote bank",
      content:
        "\"So we beat on, boats against the current…\" — closing line, cyclical time.\n\"Her voice is full of money.\" — Gatsby naming what he actually chases.",
      color: "lilac",
      subject: "English",
      tags: ["English", "Quotes"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "Chemistry — titration method",
      content:
        "Rinse burette with the solution it will hold. Swirl constantly. First drop of permanent pink = endpoint. Repeat until two concordant titres within 0.10 cm³.",
      color: "cream",
      subject: "Chemistry",
      tags: ["Chemistry", "Lab"],
      imageUrl: "",
      pinned: false,
    },
    {
      id: uuid(),
      title: "History — essay structure that scores",
      content:
        "Point, evidence, explain, then link straight back to the question. One clear argument per paragraph. Conclusion must judge, not summarise.",
      color: "blush",
      subject: "History",
      tags: ["History", "Essay"],
      imageUrl: "",
      pinned: false,
    },
  ];
  const notes: NoteRow[] = noteSeeds.map((n, i) => ({
    ...n,
    updatedAt: new Date(Date.now() - i * 3600000).toISOString(),
    createdAt: new Date(Date.now() - i * 3600000 * 2).toISOString(),
    deletedAt: null,
  }));

  const templates: TemplateRow[] = t<Template>([
    { id: uuid(), title: "Cornell Notes", accent: "sun", content: "CUES / QUESTIONS\n• \n\nNOTES\n• \n\nSUMMARY\n• " },
    {
      id: uuid(),
      title: "Lecture Recap",
      accent: "violet",
      content: "TOPIC:\nDATE:\n\nKEY IDEAS\n1. \n2. \n3. \n\nCONFUSING BITS (google later)\n• \n\nONE-LINE TAKEAWAY\n",
    },
    {
      id: uuid(),
      title: "Essay Planner",
      accent: "blush",
      content: "QUESTION:\nTHESIS:\n\nP1 — point / evidence / link\nP2 — point / evidence / link\nP3 — point / evidence / link\n\nCONCLUSION DRAFT:\n",
    },
  ]);

  const images = [
    { key: "hero", label: "Dashboard banner", url: imgHero, updatedAt: stamp },
    { key: "gallery", label: "Daydream gallery image", url: imgGallery, updatedAt: stamp },
  ];

  const mainWorkspace: WorkspaceRow = {
    id: uuid(),
    name: "Workspace 1",
    position: 0,
    createdAt: stamp,
  };
  const sub = (
    name: string,
    color: string,
    code: string,
    semester: string
  ): Subject & { code: string; semester: string; coverUrl: string } => ({
    id: uuid(),
    name,
    color,
    code,
    semester,
    coverUrl: SUBJECT_COVERS[name.toLowerCase()] ?? "",
  });
  const subjects: SubjectRow[] = t<
    Subject & { code: string; semester: string; coverUrl: string }
  >([
    sub("Math", "rose", "MTH 201", "Fall 2024"),
    sub("Biology", "green", "BIO 101", "Fall 2024"),
    sub("History", "amber", "HIS 220", "Spring 2025"),
    sub("English", "blue", "ENG 110", "Fall 2024"),
    sub("Chemistry", "violet", "CHM 130", "Spring 2025"),
  ]).map((s) => ({ ...s, workspaceId: mainWorkspace.id }));

  const flashcards: FlashcardRow[] = t<Flashcard>([
    { id: uuid(), subject: "Biology", front: "Where does the Calvin cycle take place?", back: "In the stroma of the chloroplast — it fixes CO₂ into G3P." },
    { id: uuid(), subject: "Biology", front: "What do light-dependent reactions produce?", back: "ATP and NADPH, made in the thylakoid membrane." },
    { id: uuid(), subject: "Math", front: "Derivative of sin(x)?", back: "cos(x)" },
    { id: uuid(), subject: "Math", front: "Quadratic formula?", back: "x = (−b ± √(b² − 4ac)) / 2a" },
    { id: uuid(), subject: "History", front: "When did the Berlin Wall fall?", back: "9 November 1989." },
  ]).map((r) => ({ ...r, deletedAt: null }));

  // playlists
  const lofi: PlaylistRow = { id: uuid(), name: "Late Night Lo-fi", coverUrl: coverDusk, position: 0, createdAt: stamp };
  const morning: PlaylistRow = { id: uuid(), name: "Morning Focus", coverUrl: coverSunrise, position: 1, createdAt: stamp };
  const playlistTracks: PlaylistTrackRow[] = [
    ...tracks.slice(0, 3).map((tr, i): PlaylistTrackRow => ({ id: uuid(), playlistId: lofi.id, trackId: tr.id, position: i, addedAt: stamp })),
    ...tracks.slice(1, 3).map((tr, i): PlaylistTrackRow => ({ id: uuid(), playlistId: morning.id, trackId: tr.id, position: i, addedAt: stamp })),
  ];

  // review history
  const reviewPlan: [number, number, ReviewRating][] = [
    [0, 9, "easy"], [0, 9, "good"], [0, 10, "hard"], [0, 10, "good"], [0, 11, "easy"],
    [1, 15, "good"], [1, 15, "hard"], [1, 16, "easy"],
    [2, 10, "easy"], [2, 11, "good"],
    [4, 14, "hard"], [4, 14, "good"], [4, 15, "easy"],
    [6, 9, "good"], [6, 10, "easy"],
    [9, 13, "hard"], [9, 13, "good"],
    [12, 11, "easy"], [12, 12, "good"],
  ];
  const flashcardReviews: ReviewRow[] = reviewPlan.map(([days, hour, rating], i) => {
    const card = flashcards[i % flashcards.length];
    return { id: uuid(), cardId: card.id, rating, subject: card.subject, reviewedAt: ago(days, hour) };
  });

  // mind maps — two canvases, each starting from its own seed tree
  const mapOneId = uuid();
  const mapTwoId = uuid();
  const mindmaps: MindMapRow[] = [
    { id: mapOneId, name: "Mind map one", links: [], createdAt: now() },
    {
      id: mapTwoId,
      name: "Mind map two",
      links: [],
      createdAt: new Date(Date.now() + 1000).toISOString(),
    },
  ];
  const rootId = uuid();
  const bioId = uuid();
  const mathId = uuid();
  const rootIdTwo = uuid();
  const mindSeeds: [string, string | null, string, number, number][] = [
    [mapOneId, null, "My semester", 0, 0],
    [mapOneId, rootId, "Biology", -190, -120],
    [mapOneId, rootId, "Math", 190, -120],
    [mapOneId, rootId, "English essay", 0, 175],
    [mapOneId, bioId, "Photosynthesis", -330, -230],
    [mapOneId, bioId, "Cell division", -120, -260],
    [mapOneId, mathId, "Calculus rules", 330, -230],
    // a second, smaller canvas so "Mind map two" isn't empty
    [mapTwoId, null, "Exam season", 0, 0],
    [mapTwoId, rootIdTwo, "Revision plan", -190, -120],
    [mapTwoId, rootIdTwo, "Past papers", 190, -120],
  ];
  const mindIds = [rootId, bioId, mathId, uuid(), uuid(), uuid(), uuid(), rootIdTwo, uuid(), uuid()];
  const mindnodes: MindNodeRow[] = mindSeeds.map(([mapId, parentId, text, x, y], i) => ({
    id: mindIds[i],
    mapId,
    parentId,
    text,
    x,
    y,
    createdAt: new Date(Date.now() + i * 1000).toISOString(),
  }));

  const timerPresets: TimerPresetRow[] = t<TimerPreset>([
    { id: uuid(), label: "Deep Work", minutes: 50, kind: "custom", subject: "" },
    { id: uuid(), label: "Reading Session", minutes: 40, kind: "custom", subject: "English" },
    { id: uuid(), label: "Lab Recap", minutes: 30, kind: "focus", subject: "Biology" },
  ]);

  const timerChains: TimerChainRow[] = t<TimerChain>([
    {
      id: uuid(),
      name: "Math Study Session",
      subject: "Math",
      transitionSec: 5,
      steps: [
        { kind: "focus", minutes: 40, subject: "Math", label: "Practice problems" },
        { kind: "short", minutes: 10, subject: "", label: "Stretch" },
        { kind: "focus", minutes: 40, subject: "Math", label: "Past paper" },
        { kind: "long", minutes: 30, subject: "", label: "Proper break" },
      ],
    },
    {
      id: uuid(),
      name: "Exam Prep Routine",
      subject: "",
      transitionSec: 10,
      steps: [
        { kind: "focus", minutes: 45, subject: "Biology", label: "Active recall" },
        { kind: "short", minutes: 10, subject: "", label: "Tea" },
        { kind: "custom", minutes: 45, subject: "English", label: "Read Chapter 5" },
      ],
    },
  ]);

  const focusSeeds: [number, number, string, number, string, string, string | null][] = [
    [0, 9, "focus", 50, "Biology", "Photosynthesis", bioNoteId],
    [0, 14, "focus", 25, "Math", "Practice problems", null],
    [0, 15, "short", 10, "", "Stretch", null],
    [1, 10, "custom", 45, "English", "Read Chapter 5", null],
    [1, 16, "focus", 40, "Math", "Past paper", null],
    [2, 11, "focus", 35, "Biology", "Cell division", bioNoteId],
    [3, 13, "focus", 30, "History", "Source analysis", null],
    [4, 9, "custom", 55, "Chemistry", "Lab write-up", null],
    [5, 18, "focus", 25, "Math", "Revision", null],
    [6, 10, "focus", 60, "Biology", "Full recap", bioNoteId],
    [7, 16, "focus", 30, "History", "Revision recap", null],
    [9, 15, "focus", 45, "English", "Essay draft", null],
    [12, 11, "custom", 50, "Math", "Deep Work", null],
  ];
  const focusSessions: FocusSession[] = focusSeeds.map(([days, hour, kind, minutes, subject, label, noteId]) => ({
    id: uuid(),
    minutes,
    kind: kind as FocusSession["kind"],
    subject,
    label,
    noteId,
    completedAt: ago(days, hour),
  }));

  /* ---- self-graded scores on recently completed assignments ---- */
  const sa = (
    title: string,
    subject: string,
    score: number,
    days: number,
    comment: string
  ): SelfAssessment => ({
    id: uuid(),
    title,
    subject,
    score,
    maxScore: 100,
    comment,
    assessedAt: ago(days, 17),
  });
  const selfAssessments: SelfAssessmentRow[] = t<SelfAssessment>([
    sa("Poetry response", "English", 92, 1, "Strong thesis — textual evidence was thin."),
    sa("Calculus drill 7", "Math", 74, 1, "Chain rule still shaky. Redo Q7–Q12 tomorrow."),
    sa("Genetics worksheet", "Biology", 88, 2, "Punnett squares clicked. Rushed the last page."),
    sa("WWI essay", "History", 81, 3, "Good structure, conclusion needs a sharper claim."),
  ]);

  /* ---- GPA tracker: settings + 8 semester slots, seeded with demo content ---- */
  const gpaSemesters = applyGpaDemo(defaultGpaSemesters());
  const gpaSettings: GpaSettings = {
    ...defaultGpaSettings(),
    notes: wrapByWords(GPA_DEMO_NOTES, GPA_NOTES_MAX_WORDS, GPA_NOTES_WORDS_PER_LINE),
  };

  /* ---- semester 1: current 3.60 · weighted 4.30 ---- */
  const gpaCourses: GpaCourseRow[] = t<GpaCourse>([
    { id: uuid(), name: "BIO 101", grade: "A", credits: 4, weight: 1, semesterId: gpaSemesters[0].id, notes: "Lab practical carried the grade" },
    { id: uuid(), name: "MTH 201", grade: "A", credits: 4, weight: 1, semesterId: gpaSemesters[0].id, notes: "" },
    {
      id: uuid(),
      name: "CHM 130",
      grade: "A-",
      credits: 4,
      weight: 1,
      semesterId: gpaSemesters[0].id,
      // 29 words — long enough to demo the course-notes wrap onto a second line
      notes: wrapByWords(
        "Rushed the last lab report, so now I start writing it the same night while the procedure is still fresh in my head, even if it costs an hour.",
        GPA_COURSE_NOTES_MAX_WORDS,
        GPA_COURSE_NOTES_WORDS_PER_LINE
      ),
    },
    { id: uuid(), name: "ENG 110", grade: "B+", credits: 4, weight: 0.5, semesterId: gpaSemesters[0].id, notes: "" },
    { id: uuid(), name: "HIS 220", grade: "B", credits: 4, weight: 0, semesterId: gpaSemesters[0].id, notes: "Essay conclusions need work" },
    /* ---- semester 2: gives the cumulative tracker something to add up ---- */
    { id: uuid(), name: "PHY 210", grade: "B+", credits: 3, weight: 0.5, semesterId: gpaSemesters[1].id, notes: "" },
    { id: uuid(), name: "CHM 240", grade: "A-", credits: 4, weight: 1, semesterId: gpaSemesters[1].id, notes: "Loved the titration unit" },
    { id: uuid(), name: "ENG 205", grade: "A", credits: 3, weight: 0, semesterId: gpaSemesters[1].id, notes: "" },
  ]);

  const studyTargets: StudyTargetRow[] = t<StudyTarget>([
    { id: uuid(), scope: "subject", ref: "Biology", targetHours: 6 },
    { id: uuid(), scope: "subject", ref: "Math", targetHours: 8 },
    { id: uuid(), scope: "subject", ref: "English", targetHours: 4 },
    { id: uuid(), scope: "subject", ref: "Chemistry", targetHours: 5 },
    { id: uuid(), scope: "subject", ref: "History", targetHours: 4 },
    { id: uuid(), scope: "note", ref: bioNoteId, targetHours: 3 },
  ]);

  return {
    profile: {
      id: 1,
      username: "Dreamy Student",
      email: "dreamy@student.app",
      bio: "Chasing deadlines and daydreams.",
      pronouns: "she/her",
      avatarUrl: imgAvatar,
      googleConnected: false,
      googleEmail: null,
      autoSync: false,
      lastSyncAt: null,
    },
    settings: {
      darkMode: false,
      accent: "bloom",
      desktopMode: false,
      musicShuffle: false,
      widgetOrder: [...DEFAULT_WIDGET_ORDER],
      hiddenWidgets: [],
    },
    tasks: taskRows,
    deadlines,
    quotes,
    tracks,
    notes,
    templates,
    images,
    media: defaultMedia(),
    coverRotations: [],
    ...applyLibraryDemo([mainWorkspace], subjects),
    selfAssessments,
    gpaCourses,
    gpaSettings,
    gpaSemesters,
    flashcards,
    flashcardReviews,
    playlists: [lofi, morning],
    playlistTracks,
    mindmaps,
    mindnodes,
    focusSessions,
    timerPresets,
    timerChains,
    studyTargets,
  };
}

/* ------------------------------------------------------------------ */
/* persistence                                                         */
/* ------------------------------------------------------------------ */

let cache: DB | null = null;

/** Set when the last write couldn't reach localStorage (usually the ~5MB quota). */
export let lastPersistFailed = false;

function persist(db: DB) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(db));
    lastPersistFailed = false;
  } catch {
    // quota exceeded — we keep running in memory, but callers that just saved
    // something big (a picture) need to know it won't survive a reload
    lastPersistFailed = true;
  }
}

export function loadDB(): DB {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DB;
      if (parsed && parsed.profile && parsed.settings && Array.isArray(parsed.tasks)) {
        // drop tracks that reference long-dead blob URLs from older sessions
        parsed.tracks = (parsed.tracks ?? []).filter((tr) => !tr.url.startsWith("blob:"));
        // migrate: guarantee at least one workspace and assign orphan subjects to it
        if (!Array.isArray(parsed.workspaces) || parsed.workspaces.length === 0) {
          parsed.workspaces = [{ id: uuid(), name: "Workspace 1", position: 0, createdAt: now() }];
        }
        // migrate: sidebar stores added later
        if (!Array.isArray(parsed.selfAssessments)) parsed.selfAssessments = [];
        if (!Array.isArray(parsed.gpaCourses)) parsed.gpaCourses = [];
        // migrate: GPA tracker store added later
        if (!parsed.gpaSettings || typeof parsed.gpaSettings !== "object")
          parsed.gpaSettings = defaultGpaSettings();
        if (!parsed.gpaSettings.scale || typeof parsed.gpaSettings.scale !== "object")
          parsed.gpaSettings.scale = { ...GRADE_POINTS };
        if (typeof parsed.gpaSettings.weighted !== "boolean") parsed.gpaSettings.weighted = true;
        if (typeof parsed.gpaSettings.notes !== "string")
          // older saves predate the notes demo — give them the wrapped sample once
          parsed.gpaSettings.notes = wrapByWords(
            GPA_DEMO_NOTES,
            GPA_NOTES_MAX_WORDS,
            GPA_NOTES_WORDS_PER_LINE
          );
        if (!Array.isArray(parsed.gpaSemesters) || parsed.gpaSemesters.length === 0)
          parsed.gpaSemesters = defaultGpaSemesters();
        for (const s of parsed.gpaSemesters) {
          if (typeof s.achieved !== "boolean") s.achieved = false;
          if (!Array.isArray(s.checklist)) s.checklist = [];
        }
        // fill demo content into slots the student has never touched
        parsed.gpaSemesters = applyGpaDemo(parsed.gpaSemesters);
        for (const c of parsed.gpaCourses) {
          if (!c.semesterId) c.semesterId = parsed.gpaSemesters[0].id;
          if (typeof c.notes !== "string") c.notes = "";
          // older course notes are single unbroken lines — re-flow them to 25 words a line
          else if (c.notes.trim())
            c.notes = wrapByWords(c.notes, GPA_COURSE_NOTES_MAX_WORDS, GPA_COURSE_NOTES_WORDS_PER_LINE);
        }
        const fallbackWs = parsed.workspaces[0].id;
        for (const s of parsed.subjects ?? []) {
          if (!s.workspaceId) s.workspaceId = fallbackWs;
          // migrate: guarantee card code + cover art
          if (!s.code) s.code = `${s.name.trim().slice(0, 3).toUpperCase()} 101`;
          if (typeof s.semester !== "string") s.semester = "";
          if (!s.coverUrl) s.coverUrl = coverForSubject(s.id, s.name);
        }
        // migrate: shuffling covers was added later
        if (!Array.isArray(parsed.coverRotations)) parsed.coverRotations = [];
        // migrate: the media library was added later
        if (!Array.isArray(parsed.media) || parsed.media.length === 0)
          parsed.media = defaultMedia();
        else {
          // swap the first-draft demo art for the refreshed set, but only the
          // untouched originals — anything the student added is left alone
          const OLD_DEMOS = new Set([
            // first draft
            "Dawn desk", "Night window", "Library shelf",
            "Lo-fi loop (animated)", "Meadow walk", "Rain on glass",
            // second draft
            "Golden hour desk", "Moonlit window", "Reading room",
            "Lo-fi night (animated)", "Sage meadow",
            // third draft — the six photos now ship alongside the SVG miniatures
            "Warm welcome", "Daydream postcard", "Open notebook",
            "Desk & greenery", "Quiet corner", "Soft light",
          ]);
          const mine = parsed.media.filter((m) => !OLD_DEMOS.has(m.name));
          if (mine.length !== parsed.media.length)
            parsed.media = [...defaultMedia(), ...mine];
        }
        for (const m of parsed.media) {
          if (typeof m.category !== "string") m.category = "";
          if (typeof m.name !== "string") m.name = "Untitled";
        }
        // add the twelve-subject demo workspace once, so the rail scroll is visible
        {
          const demo = applyLibraryDemo(parsed.workspaces, parsed.subjects ?? []);
          parsed.workspaces = demo.workspaces;
          parsed.subjects = demo.subjects;
        }
        // migrate: named mind maps were added later — gather any loose nodes
        // under "Mind map one" so older saves keep their canvas
        if (!Array.isArray(parsed.mindmaps) || parsed.mindmaps.length === 0) {
          parsed.mindmaps = [
            {
              id: uuid(),
              name: "Mind map one",
              links: [],
              createdAt: now(),
            },
          ];
        }
        for (const m of parsed.mindmaps) {
          // migrate: a map used to hold a single linkType/linkId pair — the
          // list is unlimited now, so fold any legacy link into it
          const legacy = m as MindMapRow & { linkType?: unknown; linkId?: unknown };
          if (!Array.isArray(m.links)) {
            m.links =
              (legacy.linkType === "note" || legacy.linkType === "subject") &&
              typeof legacy.linkId === "string"
                ? [{ type: legacy.linkType, id: legacy.linkId }]
                : [];
          }
          m.links = normalizeLinks(m.links);
          delete legacy.linkType;
          delete legacy.linkId;
        }
        for (const n of parsed.mindnodes ?? []) {
          if (typeof n.mapId !== "string" || !parsed.mindmaps.some((m) => m.id === n.mapId))
            n.mapId = parsed.mindmaps[0].id;
        }
        cache = parsed;
        return cache;
      }
    }
  } catch {
    /* corrupted — reseed */
  }
  cache = seed();
  persist(cache);
  return cache;
}

function save(db: DB) {
  cache = db;
  persist(db);
}

/** wipe everything and reseed (used by settings danger zone, if present) */
export function resetDB(): DB {
  cache = seed();
  persist(cache);
  return cache;
}

/* ------------------------------------------------------------------ */
/* initial dashboard payload (replaces server-side loadDashboard)      */
/* ------------------------------------------------------------------ */

export function loadInitialData(): DashboardData {
  const db = loadDB();
  return {
    profile: db.profile,
    settings: db.settings,
    tasks: db.tasks
      .filter((x) => !x.deletedAt)
      .sort((a, b) => a.position - b.position || a.createdAt.localeCompare(b.createdAt)),
    deadlines: db.deadlines
      .filter((x) => !x.deletedAt)
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()),
    quotes: [...db.quotes].sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
    notes: [...db.notes]
      .filter((x) => !x.deletedAt)
      .sort((a, b) =>
        a.pinned !== b.pinned
          ? a.pinned
            ? -1
            : 1
          : new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      ),
    templates: [...db.templates].sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
    images: db.images.map(({ key, label, url, rotateCategory, rotateSeconds }) => ({ key, label, url, rotateCategory, rotateSeconds })),
    media: [...db.media].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    coverRotations: [...db.coverRotations],
    subjects: [...db.subjects].sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
  };
}

/* ------------------------------------------------------------------ */
/* track url normalisation (ported from the tracks route)              */
/* ------------------------------------------------------------------ */

function normalizeTrackUrl(raw: string): { sourceType: Track["sourceType"]; url: string } {
  const url = raw.trim();
  if (url.includes("youtube.com") || url.includes("youtu.be")) {
    const shortMatch = url.match(/youtu\.be\/([a-zA-Z0-9_-]{6,20})/);
    if (shortMatch) return { sourceType: "youtube", url: shortMatch[1] };
    const embedMatch = url.match(/youtube\.com\/(?:embed|shorts)\/([a-zA-Z0-9_-]{6,20})/);
    if (embedMatch) return { sourceType: "youtube", url: embedMatch[1] };
    const vMatch = url.match(/[?&]v=([a-zA-Z0-9_-]{6,20})/);
    if (vMatch) return { sourceType: "youtube", url: vMatch[1] };
  }
  const sp = url.match(/open\.spotify\.com\/(track|album|playlist|episode|show)\/([a-zA-Z0-9]+)/);
  if (sp) return { sourceType: "spotify", url: `https://open.spotify.com/embed/${sp[1]}/${sp[2]}` };
  return { sourceType: "audio", url };
}

const UUID_RE = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
const TIMER_KINDS = ["focus", "short", "long", "custom"];
const RATINGS: ReviewRating[] = ["easy", "good", "hard"];

/* ------------------------------------------------------------------ */
/* computed endpoints                                                  */
/* ------------------------------------------------------------------ */

function computeAnalytics(db: DB): AnalyticsData {
  const t = db.tasks.filter((x) => !x.deletedAt);
  const n = db.notes.filter((x) => !x.deletedAt);
  const q = db.quotes;
  const d = db.deadlines.filter((x) => !x.deletedAt);
  const f = db.flashcards.filter((x) => !x.deletedAt);
  const sub = db.subjects;
  const fss = db.focusSessions;

  const days: Date[] = [];
  for (let i = 6; i >= 0; i--) {
    const dt = new Date();
    dt.setDate(dt.getDate() - i);
    days.push(dt);
  }
  const doneLast7 = days.map((dt) => {
    const key = dayKey(dt);
    return {
      date: key,
      label: dt.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 2),
      count: t.filter((x) => x.completedAt && dayKey(new Date(x.completedAt)) === key).length,
    };
  });
  const focusLast7 = days.map((dt) => {
    const key = dayKey(dt);
    return {
      date: key,
      label: dt.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 2),
      minutes: fss
        .filter((x) => dayKey(new Date(x.completedAt)) === key)
        .reduce((a, x) => a + x.minutes, 0),
    };
  });

  const doneDays = new Set(
    t.filter((x) => x.completedAt).map((x) => dayKey(new Date(x.completedAt as string)))
  );
  let streak = 0;
  const cursor = new Date();
  if (!doneDays.has(dayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  while (doneDays.has(dayKey(cursor))) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }

  const activeDeadlines = d.filter((x) => !x.done);
  const bySubject = new Map<string, number>();
  for (const x of activeDeadlines) {
    const key = x.subject?.trim() || "General";
    bySubject.set(key, (bySubject.get(key) ?? 0) + 1);
  }
  const colorFor = (name: string) =>
    sub.find((s) => s.name.toLowerCase() === name.toLowerCase())?.color ?? "violet";

  const studyKinds = new Set(["focus", "custom"]);
  const studySessions = fss.filter((x) => studyKinds.has(x.kind ?? "focus"));
  const weekKeys = new Set(days.map(dayKey));
  const byStudy = new Map<string, { total: number; week: number }>();
  for (const x of studySessions) {
    const key = x.subject?.trim() || "General";
    const entry = byStudy.get(key) ?? { total: 0, week: 0 };
    entry.total += x.minutes;
    if (weekKeys.has(dayKey(new Date(x.completedAt)))) entry.week += x.minutes;
    byStudy.set(key, entry);
  }
  const studyBySubject = [...byStudy.entries()]
    .map(([subject, v]) => ({
      subject,
      color: colorFor(subject),
      totalMinutes: v.total,
      weekMinutes: v.week,
    }))
    .sort((a, b) => b.weekMinutes - a.weekMinutes || b.totalMinutes - a.totalMinutes);

  return {
    doneLast7,
    focusLast7,
    studyBySubject,
    todayFocusMinutes: focusLast7[focusLast7.length - 1]?.minutes ?? 0,
    totals: {
      tasksTotal: t.length,
      tasksDone: t.filter((x) => x.done).length,
      notes: n.length,
      quotes: q.length,
      flashcards: f.length,
      subjects: sub.length,
    },
    deadlinesBySubject: [...bySubject.entries()].map(([subject, count]) => ({
      subject,
      color: colorFor(subject),
      count,
    })),
    streak,
  };
}

const STUDY_KINDS = new Set(["focus", "custom"]);

function computeProgress(db: DB): ProgressData {
  const sessions = [...db.focusSessions].sort(
    (a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime()
  );
  const targets = db.studyTargets;
  const sub = db.subjects;
  const noteRows = db.notes.filter((x) => !x.deletedAt);

  const study = sessions.filter((s) => STUDY_KINDS.has(s.kind ?? "focus"));
  const noteById = new Map(noteRows.map((x) => [x.id, x]));
  const colorFor = (name: string) =>
    sub.find((s) => s.name.toLowerCase() === name.trim().toLowerCase())?.color ?? "violet";

  const daily: ProgressBucket[] = [];
  for (let i = 13; i >= 0; i--) {
    const dt = new Date();
    dt.setDate(dt.getDate() - i);
    const key = dayKey(dt);
    daily.push({
      key,
      label: dt.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 2),
      minutes: study
        .filter((s) => dayKey(new Date(s.completedAt)) === key)
        .reduce((a, s) => a + s.minutes, 0),
    });
  }

  const weekly: ProgressBucket[] = [];
  for (let i = 7; i >= 0; i--) {
    const anchor = new Date();
    anchor.setDate(anchor.getDate() - i * 7);
    const start = weekStart(anchor);
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    weekly.push({
      key: dayKey(start),
      label: start.toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      minutes: study
        .filter((s) => {
          const tms = new Date(s.completedAt).getTime();
          return tms >= start.getTime() && tms < end.getTime();
        })
        .reduce((a, s) => a + s.minutes, 0),
    });
  }

  const monthly: ProgressBucket[] = [];
  for (let i = 5; i >= 0; i--) {
    const anchor = new Date();
    anchor.setDate(1);
    anchor.setMonth(anchor.getMonth() - i);
    const key = monthKey(anchor);
    monthly.push({
      key,
      label: anchor.toLocaleDateString(undefined, { month: "short" }),
      minutes: study
        .filter((s) => monthKey(new Date(s.completedAt)) === key)
        .reduce((a, s) => a + s.minutes, 0),
    });
  }

  const targetProgress: TargetProgress[] = targets.map((tgt) => {
    const logged =
      tgt.scope === "note"
        ? study.filter((s) => s.noteId === tgt.ref).reduce((a, s) => a + s.minutes, 0)
        : study
            .filter((s) => (s.subject?.trim().toLowerCase() ?? "") === tgt.ref.trim().toLowerCase())
            .reduce((a, s) => a + s.minutes, 0);
    const targetMinutes = Math.round(tgt.targetHours * 60);
    const name = tgt.scope === "note" ? noteById.get(tgt.ref)?.title ?? "Deleted note" : tgt.ref;
    const color =
      tgt.scope === "note" ? colorFor(noteById.get(tgt.ref)?.subject ?? "") : colorFor(tgt.ref);
    return {
      id: tgt.id,
      scope: tgt.scope,
      ref: tgt.ref,
      name,
      color,
      targetHours: tgt.targetHours,
      loggedMinutes: logged,
      percent: targetMinutes > 0 ? Math.min(100, Math.round((logged / targetMinutes) * 100)) : 0,
      remainingMinutes: Math.max(0, targetMinutes - logged),
    };
  });
  targetProgress.sort((a, b) => b.percent - a.percent || b.loggedMinutes - a.loggedMinutes);

  const entries = sessions.slice(0, 200).map((s) => ({
    ...s,
    noteTitle: s.noteId ? noteById.get(s.noteId)?.title ?? null : null,
  }));

  return {
    daily,
    weekly,
    monthly,
    targets: targetProgress,
    entries,
    totalLoggedMinutes: study.reduce((a, s) => a + s.minutes, 0),
  };
}

function computeReviewStats(db: DB): ReviewStats {
  const rows = [...db.flashcardReviews].sort(
    (a, b) => new Date(b.reviewedAt).getTime() - new Date(a.reviewedAt).getTime()
  );
  const cards = db.flashcards;
  const subs = db.subjects;
  const cardById = new Map(cards.map((c) => [c.id, c]));
  const colorFor = (name: string) =>
    subs.find((s) => s.name.toLowerCase() === name.trim().toLowerCase())?.color ?? "violet";

  const tally = (list: ReviewRow[]): RatingCounts => {
    const c: RatingCounts = { easy: 0, good: 0, hard: 0, total: 0 };
    for (const r of list) {
      const k = (r.rating ?? "good") as ReviewRating;
      if (RATINGS.includes(k)) c[k] += 1;
      c.total += 1;
    }
    return c;
  };

  const daily: ReviewBucket[] = [];
  for (let i = 13; i >= 0; i--) {
    const dt = new Date();
    dt.setDate(dt.getDate() - i);
    const key = dayKey(dt);
    daily.push({
      key,
      label: dt.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 2),
      ...tally(rows.filter((r) => dayKey(new Date(r.reviewedAt)) === key)),
    });
  }

  const weekly: ReviewBucket[] = [];
  for (let i = 7; i >= 0; i--) {
    const anchor = new Date();
    anchor.setDate(anchor.getDate() - i * 7);
    const start = weekStart(anchor);
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    weekly.push({
      key: dayKey(start),
      label: start.toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      ...tally(
        rows.filter((r) => {
          const tms = new Date(r.reviewedAt).getTime();
          return tms >= start.getTime() && tms < end.getTime();
        })
      ),
    });
  }

  const monthly: ReviewBucket[] = [];
  for (let i = 5; i >= 0; i--) {
    const anchor = new Date();
    anchor.setDate(1);
    anchor.setMonth(anchor.getMonth() - i);
    const key = monthKey(anchor);
    monthly.push({
      key,
      label: anchor.toLocaleDateString(undefined, { month: "short" }),
      ...tally(rows.filter((r) => monthKey(new Date(r.reviewedAt)) === key)),
    });
  }

  const bySubjectMap = new Map<string, ReviewRow[]>();
  for (const r of rows) {
    const key = r.subject?.trim() || "General";
    bySubjectMap.set(key, [...(bySubjectMap.get(key) ?? []), r]);
  }
  const bySubject = [...bySubjectMap.entries()]
    .map(([subject, list]) => ({ subject, color: colorFor(subject), ...tally(list) }))
    .sort((a, b) => b.total - a.total);

  const latest = new Map<string, ReviewRating>();
  for (const r of rows) {
    if (!latest.has(r.cardId)) latest.set(r.cardId, (r.rating ?? "good") as ReviewRating);
  }
  const hardCardIds = [...latest.entries()]
    .filter(([cardId, rating]) => rating === "hard" && cardById.has(cardId))
    .map(([cardId]) => cardId);

  return {
    daily,
    weekly,
    monthly,
    totals: tally(rows),
    hardCardIds,
    bySubject,
    recent: rows.slice(0, 50).map((r) => ({
      ...r,
      front: cardById.get(r.cardId)?.front ?? null,
    })),
  };
}

/* ------------------------------------------------------------------ */
/* uploads (audio) — in-memory + best-effort persistence               */
/* ------------------------------------------------------------------ */

export async function saveAudioUpload(
  file: File
): Promise<{ id: string; url: string; filename: string; size: number }> {
  if (!file.type.startsWith("audio/") && !/\.(mp3|m4a|aac|wav|ogg|flac|opus)$/i.test(file.name))
    throw new ApiError("That doesn't look like an audio file");
  if (file.size > 20 * 1024 * 1024) throw new ApiError("That file is too big (max 20MB)", 413);

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new ApiError("Could not read that file"));
    reader.readAsDataURL(file);
  });
  return { id: uuid(), url: dataUrl, filename: file.name.slice(0, 200), size: file.size };
}

/* ================================================================== */
/* request dispatcher — mirrors every /api/* route handler             */
/* ================================================================== */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Body = Record<string, any>;

const ok = () => ({ ok: true });
const notFound = () => new ApiError("Not found", 404);
const badRequest = (msg: string) => new ApiError(msg, 400);

function findById<T extends { id: string }>(rows: T[], id: string): T | undefined {
  return rows.find((r) => r.id === id);
}

/** Clean up an incoming links list — valid pairs only, duplicates dropped. */
function normalizeLinks(raw: unknown): MindMapLink[] {
  if (!Array.isArray(raw)) return [];
  const out: MindMapLink[] = [];
  for (const l of raw as { type?: unknown; id?: unknown }[]) {
    if (!l || (l.type !== "note" && l.type !== "subject") || typeof l.id !== "string" || !l.id)
      continue;
    if (!out.some((x) => x.type === l.type && x.id === l.id))
      out.push({ type: l.type, id: l.id });
  }
  return out;
}

export async function handleApi(method: string, rawPath: string, body?: Body): Promise<unknown> {
  const url = new URL(rawPath, "http://local");
  const segs = url.pathname.split("/").filter(Boolean); // ["api", ...]
  const resource = segs[1];
  const id = segs[2] ? decodeURIComponent(segs[2]) : undefined;
  const sub = segs[3];

  const db = loadDB();
  const M = method.toUpperCase();

  switch (resource) {
    /* ---------------- settings ---------------- */
    case "settings": {
      if (M === "GET") return db.settings;
      if (M === "PATCH") {
        if (typeof body?.darkMode === "boolean") db.settings.darkMode = body.darkMode;
        if (typeof body?.accent === "string") db.settings.accent = body.accent;
        if (typeof body?.desktopMode === "boolean") db.settings.desktopMode = body.desktopMode;
        if (typeof body?.musicShuffle === "boolean") db.settings.musicShuffle = body.musicShuffle;
        if (Array.isArray(body?.widgetOrder)) {
          const valid = body.widgetOrder.filter((w: unknown) =>
            DEFAULT_WIDGET_ORDER.includes(String(w))
          );
          const missing = DEFAULT_WIDGET_ORDER.filter((w) => !valid.includes(w));
          db.settings.widgetOrder = [...valid, ...missing];
        }
        if (Array.isArray(body?.hiddenWidgets)) {
          db.settings.hiddenWidgets = body.hiddenWidgets
            .map(String)
            .filter((w: string) => DEFAULT_WIDGET_ORDER.includes(w));
        }
        save(db);
        return db.settings;
      }
      break;
    }

    /* ---------------- profile ---------------- */
    case "profile": {
      if (M === "GET") return db.profile;
      if (M === "PATCH") {
        const p = db.profile;
        if (typeof body?.username === "string" && body.username.trim())
          p.username = body.username.trim().slice(0, 40);
        if (typeof body?.email === "string") p.email = body.email.trim().slice(0, 120);
        if (typeof body?.bio === "string") p.bio = body.bio.slice(0, 200);
        if (typeof body?.pronouns === "string") p.pronouns = body.pronouns.slice(0, 24);
        if (typeof body?.avatarUrl === "string") {
          if (body.avatarUrl.length > 2_500_000)
            throw new ApiError("Avatar too large — keep under ~2MB", 413);
          p.avatarUrl = body.avatarUrl;
        }
        if (typeof body?.googleConnected === "boolean") p.googleConnected = body.googleConnected;
        if (typeof body?.googleEmail === "string" || body?.googleEmail === null)
          p.googleEmail = body.googleEmail;
        if (typeof body?.autoSync === "boolean") p.autoSync = body.autoSync;
        if (body?.syncNow === true) p.lastSyncAt = now();
        save(db);
        return p;
      }
      break;
    }

    /* ---------------- tasks ---------------- */
    case "tasks": {
      if (!id) {
        if (M === "GET")
          return db.tasks
            .filter((x) => !x.deletedAt)
            .sort((a, b) => a.position - b.position || a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const title = String(body?.title ?? "").trim();
          if (!title) throw new ApiError("Title required");
          const priority = ["low", "medium", "high"].includes(String(body?.priority))
            ? (String(body?.priority) as Task["priority"])
            : "medium";
          const dueDateRaw = String(body?.dueDate ?? "").trim();
          const row: TaskRow = {
            id: uuid(),
            title,
            time: String(body?.time ?? ""),
            priority,
            subject: String(body?.subject ?? "").trim(),
            dueDate: dueDateRaw ? new Date(dueDateRaw).toISOString() : null,
            done: false,
            position: Math.max(-1, ...db.tasks.map((x) => x.position)) + 1,
            createdAt: now(),
            completedAt: null,
            deletedAt: null,
          };
          db.tasks.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.tasks, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.title === "string") row.title = body.title;
          if (typeof body?.time === "string") row.time = body.time;
          if (typeof body?.position === "number") row.position = body.position;
          if (typeof body?.subject === "string") row.subject = body.subject;
          if (["low", "medium", "high"].includes(String(body?.priority)))
            row.priority = String(body?.priority) as Task["priority"];
          if (typeof body?.dueDate === "string")
            row.dueDate = body.dueDate ? new Date(body.dueDate).toISOString() : null;
          if (typeof body?.done === "boolean") {
            row.done = body.done;
            row.completedAt = body.done ? now() : null;
          }
          save(db);
          return row;
        }
        if (M === "DELETE") {
          if (row) {
            row.deletedAt = now();
            save(db);
          }
          return ok();
        }
      }
      break;
    }

    /* ---------------- deadlines ---------------- */
    case "deadlines": {
      if (!id) {
        if (M === "GET")
          return db.deadlines
            .filter((x) => !x.deletedAt)
            .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
        if (M === "POST") {
          const title = String(body?.title ?? "").trim();
          const dueDate = String(body?.dueDate ?? "");
          if (!title || !dueDate) throw new ApiError("Title and due date required");
          const row: DeadlineRow = {
            id: uuid(),
            title,
            subject: String(body?.subject ?? ""),
            color: String(body?.color ?? "rose"),
            dueDate: new Date(dueDate).toISOString(),
            done: false,
            createdAt: now(),
            deletedAt: null,
          };
          db.deadlines.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.deadlines, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.title === "string") row.title = body.title;
          if (typeof body?.subject === "string") row.subject = body.subject;
          if (typeof body?.color === "string") row.color = body.color;
          if (typeof body?.done === "boolean") row.done = body.done;
          if (typeof body?.dueDate === "string") row.dueDate = new Date(body.dueDate).toISOString();
          save(db);
          return row;
        }
        if (M === "DELETE") {
          if (row) {
            row.deletedAt = now();
            save(db);
          }
          return ok();
        }
      }
      break;
    }

    /* ---------------- quotes ---------------- */
    case "quotes": {
      if (!id) {
        if (M === "GET") return [...db.quotes].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const text = String(body?.text ?? "").trim();
          if (!text) throw new ApiError("Text required");
          const row: QuoteRowFull = {
            id: uuid(),
            text,
            author: String(body?.author ?? ""),
            kind: body?.kind === "motivation" ? "motivation" : "quote",
            createdAt: now(),
          };
          db.quotes.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.quotes, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.text === "string") row.text = body.text;
          if (typeof body?.author === "string") row.author = body.author;
          if (body?.kind === "quote" || body?.kind === "motivation") row.kind = body.kind;
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.quotes = db.quotes.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- notes ---------------- */
    case "notes": {
      if (!id) {
        if (M === "GET")
          return [...db.notes]
            .filter((x) => !x.deletedAt)
            .sort((a, b) =>
              a.pinned !== b.pinned
                ? a.pinned
                  ? -1
                  : 1
                : new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
            );
        if (M === "POST") {
          const row: NoteRow = {
            id: uuid(),
            title: String(body?.title ?? "").trim() || "Untitled note",
            content: String(body?.content ?? ""),
            color: String(body?.color ?? "cream"),
            subject: String(body?.subject ?? "").trim(),
            tags: Array.isArray(body?.tags)
              ? ([
                  ...new Set(
                    (body.tags as unknown[])
                      .map((tg) => String(tg).replace(/^#+/, "").trim())
                      .filter((tg: string) => tg.length > 0)
                  ),
                ].slice(0, 12) as string[])
              : [],
            imageUrl: String(body?.imageUrl ?? ""),
            pinned: Boolean(body?.pinned ?? false),
            updatedAt: now(),
            createdAt: now(),
            deletedAt: null,
          };
          db.notes.unshift(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.notes, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          row.updatedAt = now();
          if (typeof body?.title === "string") row.title = body.title;
          if (typeof body?.content === "string") row.content = body.content;
          if (typeof body?.color === "string") row.color = body.color;
          if (typeof body?.subject === "string") row.subject = body.subject;
          if (Array.isArray(body?.tags))
            row.tags = [
              ...new Set(
                (body.tags as unknown[]).map((tg) => String(tg).replace(/^#+/, "").trim()).filter(Boolean)
              ),
            ].slice(0, 12) as string[];
          if (typeof body?.imageUrl === "string") row.imageUrl = body.imageUrl;
          if (typeof body?.pinned === "boolean") row.pinned = body.pinned;
          save(db);
          return row;
        }
        if (M === "DELETE") {
          if (row) {
            row.deletedAt = now();
            save(db);
          }
          return ok();
        }
      }
      break;
    }

    /* ---------------- templates ---------------- */
    case "templates": {
      if (!id) {
        if (M === "GET") return [...db.templates].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const title = String(body?.title ?? "").trim();
          if (!title) throw new ApiError("Title required");
          const row: TemplateRow = {
            id: uuid(),
            title,
            accent: String(body?.accent ?? "sun"),
            content: String(body?.content ?? ""),
            createdAt: now(),
          };
          db.templates.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.templates, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.title === "string") row.title = body.title;
          if (typeof body?.accent === "string") row.accent = body.accent;
          if (typeof body?.content === "string") row.content = body.content;
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.templates = db.templates.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- images ---------------- */
    case "images": {
      if (M === "GET")
        return db.images.map(({ key, label, url: u, rotateCategory, rotateSeconds }) => ({
          key,
          label,
          url: u,
          rotateCategory,
          rotateSeconds,
        }));
      if (M === "PUT" || M === "POST") {
        const key = String(body?.key ?? "").trim();
        const imgUrl = String(body?.url ?? "").trim();
        if (!key || !imgUrl) throw new ApiError("Key and url required");
        if (imgUrl.length > 2_500_000) throw new ApiError("Image too large — keep under ~2MB", 413);
        let row = db.images.find((x) => x.key === key);
        if (row) {
          row.url = imgUrl;
          row.updatedAt = now();
        } else {
          row = { key, label: String(body?.label ?? key), url: imgUrl, updatedAt: now() };
          db.images.push(row);
        }
        // rotation settings ride along with the slot
        if ("rotateCategory" in (body ?? {})) {
          const cat = String(body?.rotateCategory ?? "").trim();
          row.rotateCategory = cat || undefined;
        }
        if (body?.rotateSeconds !== undefined)
          row.rotateSeconds = clampRotateSeconds(body.rotateSeconds);
        save(db);
        return {
          key: row.key,
          label: row.label,
          url: row.url,
          rotateCategory: row.rotateCategory,
          rotateSeconds: row.rotateSeconds,
        };
      }
      break;
    }

    /* ---------------- shuffling covers (subjects / notes / tracks) ------- */
    case "cover-rotations": {
      if (M === "GET") return [...db.coverRotations];
      if (M === "PUT") {
        const target = String(body?.target ?? "") as CoverRotation["target"];
        const refId = String(body?.refId ?? "").trim();
        if (!target || !refId) throw new ApiError("target and refId are required");
        const category = String(body?.category ?? "").trim();
        db.coverRotations = db.coverRotations.filter(
          (r) => !(r.target === target && r.refId === refId)
        );
        // an empty category means "stop shuffling this one"
        if (category) {
          const row: CoverRotation = {
            id: uuid(),
            target,
            refId,
            category,
            seconds: clampRotateSeconds(body?.seconds),
          };
          db.coverRotations.push(row);
          save(db);
          return row;
        }
        save(db);
        return ok();
      }
      break;
    }

    /* ---------------- media library ---------------- */
    case "media": {
      if (!id) {
        if (M === "GET")
          return [...db.media].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        if (M === "POST") {
          const mUrl = String(body?.url ?? "").trim();
          if (!mUrl) throw new ApiError("An image is required");
          if (mUrl.length > 2_500_000)
            throw new ApiError("Image too large — keep under ~2MB", 413);
          const row: MediaItem = {
            id: uuid(),
            url: mUrl,
            name: String(body?.name ?? "").trim().slice(0, 60) || "Untitled",
            category: String(body?.category ?? "").trim().slice(0, 40),
            createdAt: now(),
          };
          db.media.unshift(row);
          save(db);
          if (lastPersistFailed) {
            // roll it back rather than pretend — storage is full
            db.media = db.media.filter((x) => x.id !== row.id);
            save(db);
            throw new ApiError(
              "Storage is full — delete a few pictures to make room",
              507
            );
          }
          return row;
        }
      } else {
        const row = db.media.find((x) => x.id === id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.name === "string")
            row.name = body.name.trim().slice(0, 60) || "Untitled";
          if (typeof body?.category === "string")
            row.category = body.category.trim().slice(0, 40);
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.media = db.media.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- workspaces ---------------- */
    case "workspaces": {
      const withCount = (w: WorkspaceRow) => ({
        ...w,
        subjectCount: db.subjects.filter((s) => s.workspaceId === w.id).length,
      });
      if (!id) {
        if (M === "GET")
          return [...db.workspaces]
            .sort((a, b) => a.position - b.position || a.createdAt.localeCompare(b.createdAt))
            .map(withCount);
        if (M === "POST") {
          let name = String(body?.name ?? "").trim().slice(0, 40);
          if (!name) {
            let n = 1;
            while (db.workspaces.some((w) => w.name === `Workspace ${n}`)) n++;
            name = `Workspace ${n}`;
          }
          const row: WorkspaceRow = {
            id: uuid(),
            name,
            position: Math.max(-1, ...db.workspaces.map((w) => w.position)) + 1,
            createdAt: now(),
          };
          db.workspaces.push(row);
          save(db);
          return withCount(row);
        }
      } else {
        const row = findById(db.workspaces, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.name === "string") {
            const name = body.name.trim().slice(0, 40);
            if (!name) throw new ApiError("Name required");
            row.name = name;
          }
          save(db);
          return withCount(row);
        }
        if (M === "DELETE") {
          if (!row) throw notFound();
          // deleting a workspace also removes its subjects (labels only — never cards/deadlines)
          db.workspaces = db.workspaces.filter((w) => w.id !== id);
          db.subjects = db.subjects.filter((s) => s.workspaceId !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- subjects ---------------- */
    case "subjects": {
      if (!id) {
        if (M === "GET") {
          const ws = url.searchParams.get("workspaceId")?.trim();
          return [...db.subjects]
            .filter((s) => !ws || s.workspaceId === ws)
            .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        }
        if (M === "POST") {
          const name = String(body?.name ?? "").trim();
          if (!name) throw new ApiError("Name required");
          const row: SubjectRow = {
            id: uuid(),
            name: name.slice(0, 40),
            color: String(body?.color ?? "rose"),
            workspaceId: String(body?.workspaceId ?? "") || db.workspaces[0]?.id || "",
            code:
              String(body?.code ?? "")
                .trim()
                .slice(0, 16) || `${name.trim().slice(0, 3).toUpperCase()} 101`,
            semester: String(body?.semester ?? "")
              .trim()
              .slice(0, 32),
            coverUrl: String(body?.coverUrl ?? "") || coverForSubject(uuid(), name),
            createdAt: now(),
          };
          db.subjects.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.subjects, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.name === "string") row.name = body.name.slice(0, 40);
          if (typeof body?.color === "string") row.color = body.color;
          if (typeof body?.code === "string") row.code = body.code.trim().slice(0, 16);
          if (typeof body?.semester === "string")
            row.semester = body.semester.trim().slice(0, 32);
          if (typeof body?.coverUrl === "string") row.coverUrl = body.coverUrl;
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.subjects = db.subjects.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- flashcards ---------------- */
    case "flashcards": {
      if (!id) {
        if (M === "GET")
          return db.flashcards
            .filter((x) => !x.deletedAt)
            .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const front = String(body?.front ?? "").trim();
          const back = String(body?.back ?? "").trim();
          if (!front || !back) throw new ApiError("Front and back are required");
          const row: FlashcardRow = {
            id: uuid(),
            front,
            back,
            subject: String(body?.subject ?? "General").slice(0, 40) || "General",
            createdAt: now(),
            deletedAt: null,
          };
          db.flashcards.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.flashcards, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.front === "string") row.front = body.front;
          if (typeof body?.back === "string") row.back = body.back;
          if (typeof body?.subject === "string") row.subject = body.subject;
          save(db);
          return row;
        }
        if (M === "DELETE") {
          if (row) {
            row.deletedAt = now();
            save(db);
          }
          return ok();
        }
      }
      break;
    }

    /* ---------------- flashcard reviews ---------------- */
    case "flashcard-reviews": {
      if (!id) {
        if (M === "GET") return computeReviewStats(db);
        if (M === "POST") {
          const cardId = String(body?.cardId ?? "").trim();
          const rating = RATINGS.includes(String(body?.rating) as ReviewRating)
            ? (String(body?.rating) as ReviewRating)
            : "good";
          if (!cardId) throw new ApiError("cardId required");
          const row: ReviewRow = {
            id: uuid(),
            cardId,
            rating,
            subject: String(body?.subject ?? "").trim(),
            reviewedAt: now(),
          };
          db.flashcardReviews.push(row);
          save(db);
          return row;
        }
        if (M === "DELETE") {
          const limit = Math.max(1, Math.min(100, Number(url.searchParams.get("last")) || 1));
          const sorted = [...db.flashcardReviews].sort(
            (a, b) => new Date(b.reviewedAt).getTime() - new Date(a.reviewedAt).getTime()
          );
          const doomed = new Set(sorted.slice(0, limit).map((r) => r.id));
          db.flashcardReviews = db.flashcardReviews.filter((r) => !doomed.has(r.id));
          save(db);
          return { ok: true, deleted: doomed.size };
        }
      } else if (M === "DELETE") {
        db.flashcardReviews = db.flashcardReviews.filter((r) => r.id !== id);
        save(db);
        return ok();
      }
      break;
    }

    /* ---------------- tracks ---------------- */
    case "tracks": {
      if (!id) {
        if (M === "GET")
          return [...db.tracks].sort(
            (a, b) => a.position - b.position || a.createdAt.localeCompare(b.createdAt)
          );
        if (M === "POST") {
          const title = String(body?.title ?? "").trim();
          const rawUrl = String(body?.url ?? "").trim();
          if (!title || !rawUrl) throw new ApiError("Title and link required");
          const { sourceType, url: trackUrl } = normalizeTrackUrl(rawUrl);
          const row: TrackRow = {
            id: uuid(),
            title,
            artist: String(body?.artist ?? ""),
            coverUrl: String(body?.coverUrl ?? ""),
            sourceType,
            url: trackUrl,
            position: Math.max(-1, ...db.tracks.map((x) => x.position)) + 1,
            createdAt: now(),
          };
          db.tracks.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.tracks, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.title === "string") row.title = body.title;
          if (typeof body?.artist === "string") row.artist = body.artist;
          if (typeof body?.coverUrl === "string") row.coverUrl = body.coverUrl;
          if (typeof body?.url === "string" && body.url.trim()) {
            const n = normalizeTrackUrl(body.url);
            row.sourceType = n.sourceType;
            row.url = n.url;
          }
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.tracks = db.tracks.filter((x) => x.id !== id);
          db.playlistTracks = db.playlistTracks.filter((x) => x.trackId !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- playlists ---------------- */
    case "playlists": {
      const toPlaylist = (p: PlaylistRow): Playlist => ({
        id: p.id,
        name: p.name,
        coverUrl: p.coverUrl,
        position: p.position,
        trackIds: db.playlistTracks
          .filter((l) => l.playlistId === p.id)
          .sort((a, b) => a.position - b.position || a.addedAt.localeCompare(b.addedAt))
          .map((l) => l.trackId),
      });
      if (!id) {
        if (M === "GET")
          return [...db.playlists]
            .sort((a, b) => a.position - b.position || a.createdAt.localeCompare(b.createdAt))
            .map(toPlaylist);
        if (M === "POST") {
          const name = String(body?.name ?? "").trim();
          if (!name) throw new ApiError("Playlist name required");
          const row: PlaylistRow = {
            id: uuid(),
            name: name.slice(0, 60),
            coverUrl: String(body?.coverUrl ?? "").trim(),
            position: Math.max(-1, ...db.playlists.map((x) => x.position)) + 1,
            createdAt: now(),
          };
          db.playlists.push(row);
          save(db);
          return { ...row, trackIds: [] };
        }
      } else if (sub === "tracks") {
        if (M === "POST") {
          const trackId = String(body?.trackId ?? "").trim();
          if (!trackId) throw new ApiError("trackId required");
          const existing = db.playlistTracks.find((l) => l.playlistId === id && l.trackId === trackId);
          if (existing) return existing;
          const row: PlaylistTrackRow = {
            id: uuid(),
            playlistId: id,
            trackId,
            position:
              Math.max(-1, ...db.playlistTracks.filter((l) => l.playlistId === id).map((l) => l.position)) + 1,
            addedAt: now(),
          };
          db.playlistTracks.push(row);
          save(db);
          return row;
        }
        if (M === "DELETE") {
          const trackId = url.searchParams.get("trackId")?.trim();
          if (!trackId) throw new ApiError("trackId required");
          db.playlistTracks = db.playlistTracks.filter(
            (l) => !(l.playlistId === id && l.trackId === trackId)
          );
          save(db);
          return ok();
        }
      } else {
        const row = findById(db.playlists, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.name === "string" && body.name.trim()) row.name = body.name.trim().slice(0, 60);
          if (typeof body?.coverUrl === "string") row.coverUrl = body.coverUrl;
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.playlistTracks = db.playlistTracks.filter((l) => l.playlistId !== id);
          db.playlists = db.playlists.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- mind maps ---------------- */
    case "mindmaps": {
      if (!id) {
        if (M === "GET")
          return [...db.mindmaps]
            .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
            .map((m) => ({
              id: m.id,
              name: m.name,
              links: m.links ?? [],
              nodeCount: db.mindnodes.filter((n) => n.mapId === m.id).length,
            }));
        if (M === "POST") {
          const row: MindMapRow = {
            id: uuid(),
            name:
              typeof body?.name === "string" && body.name.trim()
                ? body.name.trim().slice(0, 40)
                : `Mind map ${db.mindmaps.length + 1}`,
            links: [],
            createdAt: now(),
          };
          db.mindmaps.push(row);
          // every map starts with its root idea centered on the canvas
          db.mindnodes.push({
            id: uuid(),
            mapId: row.id,
            parentId: null,
            text: row.name,
            x: 0,
            y: 0,
            createdAt: now(),
          });
          save(db);
          return { id: row.id, name: row.name, links: [], nodeCount: 1 };
        }
      } else {
        const row = findById(db.mindmaps, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.name === "string" && body.name.trim())
            row.name = body.name.trim().slice(0, 40);
          // the whole links list is replaceable — a map can hold any number
          if ("links" in (body ?? {})) row.links = normalizeLinks(body?.links);
          // legacy single-link writes still land, folded into the list
          else if ("linkType" in (body ?? {}) || "linkId" in (body ?? {})) {
            const lt = body?.linkType;
            row.links =
              (lt === "note" || lt === "subject") && typeof body?.linkId === "string"
                ? [{ type: lt, id: body.linkId }]
                : [];
          }
          save(db);
          return {
            id: row.id,
            name: row.name,
            links: row.links ?? [],
            nodeCount: db.mindnodes.filter((n) => n.mapId === row.id).length,
          };
        }
        if (M === "DELETE") {
          if (!row) throw notFound();
          db.mindmaps = db.mindmaps.filter((m) => m.id !== id);
          db.mindnodes = db.mindnodes.filter((n) => n.mapId !== id);
          save(db);
          return { ok: true };
        }
      }
      break;
    }

    /* ---------------- mindmap ---------------- */
    case "mindnodes": {
      if (!id) {
        if (M === "GET") {
          const mapId = url.searchParams.get("mapId");
          return [...db.mindnodes]
            .filter((n) => !mapId || n.mapId === mapId)
            .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        }
        if (M === "POST") {
          const mapId = String(body?.mapId ?? "");
          if (!db.mindmaps.some((m) => m.id === mapId)) throw badRequest("Unknown mind map");
          const row: MindNodeRow = {
            id: uuid(),
            mapId,
            parentId: body?.parentId ? String(body.parentId) : null,
            text: String(body?.text ?? "New idea").slice(0, 120),
            x: Number(body?.x ?? 0) || 0,
            y: Number(body?.y ?? 0) || 0,
            createdAt: now(),
          };
          db.mindnodes.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.mindnodes, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.text === "string") row.text = body.text.slice(0, 120);
          if (typeof body?.x === "number") row.x = body.x;
          if (typeof body?.y === "number") row.y = body.y;
          save(db);
          return row;
        }
        if (M === "DELETE") {
          const doomed = new Set<string>([id]);
          let changed = true;
          while (changed) {
            changed = false;
            for (const n of db.mindnodes) {
              if (n.parentId && doomed.has(n.parentId) && !doomed.has(n.id)) {
                doomed.add(n.id);
                changed = true;
              }
            }
          }
          db.mindnodes = db.mindnodes.filter((n) => !doomed.has(n.id));
          save(db);
          return { ok: true, removed: doomed.size };
        }
      }
      break;
    }

    /* ---------------- focus sessions ---------------- */
    case "focus-sessions": {
      if (!id) {
        if (M === "GET")
          return [...db.focusSessions]
            .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime())
            .slice(0, 50);
        if (M === "POST") {
          const minutes = Math.max(1, Math.min(1440, Number(body?.minutes) || 25));
          const kind = TIMER_KINDS.includes(String(body?.kind))
            ? (String(body?.kind) as FocusSession["kind"])
            : "focus";
          const rawNote = String(body?.noteId ?? "").trim();
          const row: FocusSession = {
            id: uuid(),
            minutes,
            kind,
            subject: String(body?.subject ?? "").trim(),
            label: String(body?.label ?? "").trim(),
            noteId: UUID_RE.test(rawNote) ? rawNote : null,
            completedAt: now(),
          };
          db.focusSessions.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.focusSessions, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (body?.minutes !== undefined) {
            const minutes = Math.max(1, Math.min(1440, Number(body.minutes) || 0));
            if (!minutes) throw new ApiError("Minutes must be at least 1");
            row.minutes = minutes;
          }
          if (TIMER_KINDS.includes(String(body?.kind))) row.kind = String(body?.kind) as FocusSession["kind"];
          if (typeof body?.subject === "string") row.subject = body.subject.trim();
          if (typeof body?.label === "string") row.label = body.label.trim();
          if (typeof body?.noteId === "string")
            row.noteId = UUID_RE.test(body.noteId.trim()) ? body.noteId.trim() : null;
          if (body?.noteId === null) row.noteId = null;
          if (typeof body?.completedAt === "string" && body.completedAt.trim()) {
            const dt = new Date(body.completedAt);
            if (Number.isNaN(dt.getTime())) throw new ApiError("Invalid date");
            row.completedAt = dt.toISOString();
          }
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.focusSessions = db.focusSessions.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- timer presets ---------------- */
    case "timer-presets": {
      if (!id) {
        if (M === "GET") return [...db.timerPresets].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const label = String(body?.label ?? "").trim();
          if (!label) throw new ApiError("Label required");
          const minutes = Math.max(1, Math.min(480, Number(body?.minutes) || 25));
          const row: TimerPresetRow = {
            id: uuid(),
            label: label.slice(0, 40),
            minutes,
            kind: TIMER_KINDS.includes(String(body?.kind))
              ? (String(body?.kind) as TimerPreset["kind"])
              : "focus",
            subject: String(body?.subject ?? "").trim(),
            createdAt: now(),
          };
          db.timerPresets.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.timerPresets, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.label === "string") {
            const label = body.label.trim();
            if (!label) throw new ApiError("Label required");
            row.label = label.slice(0, 40);
          }
          if (body?.minutes !== undefined) {
            const minutes = Math.max(1, Math.min(480, Number(body.minutes) || 0));
            if (!minutes) throw new ApiError("Minutes must be at least 1");
            row.minutes = minutes;
          }
          if (TIMER_KINDS.includes(String(body?.kind))) row.kind = String(body?.kind) as TimerPreset["kind"];
          if (typeof body?.subject === "string") row.subject = body.subject.trim();
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.timerPresets = db.timerPresets.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- timer chains ---------------- */
    case "timer-chains": {
      if (!id) {
        if (M === "GET") return [...db.timerChains].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const name = String(body?.name ?? "").trim();
          if (!name) throw new ApiError("Name required");
          const steps = Array.isArray(body?.steps) ? (body.steps as TimerChain["steps"]) : [];
          const row: TimerChainRow = {
            id: uuid(),
            name: name.slice(0, 60),
            steps: steps.filter((s) => s && Number(s.minutes) > 0).map((s) => ({
              kind: TIMER_KINDS.includes(String(s.kind)) ? s.kind : "focus",
              minutes: Math.max(1, Math.min(480, Number(s.minutes) || 25)),
              subject: String(s.subject ?? ""),
              label: String(s.label ?? ""),
            })),
            subject: String(body?.subject ?? "").trim(),
            transitionSec: Math.max(0, Math.min(120, Number(body?.transitionSec) || 5)),
            createdAt: now(),
          };
          db.timerChains.push(row);
          save(db);
          return row;
        }
      } else {
        if (M === "DELETE") {
          db.timerChains = db.timerChains.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- study targets ---------------- */
    case "study-targets": {
      if (!id) {
        if (M === "GET") return [...db.studyTargets].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const scope = body?.scope === "note" ? "note" : "subject";
          const ref = String(body?.ref ?? "").trim();
          const targetHours = Math.max(0.25, Math.min(2000, Number(body?.targetHours) || 0));
          if (!ref) throw new ApiError("Pick a subject or note");
          if (!targetHours) throw new ApiError("Target hours must be at least 0.25");
          const existing = db.studyTargets.find((x) => x.scope === scope && x.ref === ref);
          if (existing) {
            existing.targetHours = targetHours;
            save(db);
            return existing;
          }
          const row: StudyTargetRow = { id: uuid(), scope, ref, targetHours, createdAt: now() };
          db.studyTargets.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.studyTargets, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (body?.targetHours !== undefined) {
            const targetHours = Math.max(0.25, Math.min(2000, Number(body.targetHours) || 0));
            if (!targetHours) throw new ApiError("Target hours must be at least 0.25");
            row.targetHours = targetHours;
          }
          if (typeof body?.ref === "string" && body.ref.trim()) row.ref = body.ref.trim();
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.studyTargets = db.studyTargets.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- self assessments ---------------- */
    case "self-assessments": {
      if (!id) {
        if (M === "GET")
          return [...db.selfAssessments].sort(
            (a, b) => new Date(b.assessedAt).getTime() - new Date(a.assessedAt).getTime()
          );
        if (M === "POST") {
          const title = String(body?.title ?? "").trim();
          if (!title) throw new ApiError("Title required");
          const maxScore = Math.max(1, Math.min(1000, Number(body?.maxScore) || 100));
          const row: SelfAssessmentRow = {
            id: uuid(),
            title: title.slice(0, 120),
            subject: String(body?.subject ?? "").trim(),
            score: Math.max(0, Math.min(maxScore, Number(body?.score) || 0)),
            maxScore,
            comment: String(body?.comment ?? "").slice(0, 280),
            assessedAt:
              typeof body?.assessedAt === "string" && body.assessedAt.trim()
                ? new Date(body.assessedAt).toISOString()
                : now(),
            createdAt: now(),
          };
          db.selfAssessments.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.selfAssessments, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.title === "string") row.title = body.title.trim().slice(0, 120);
          if (typeof body?.subject === "string") row.subject = body.subject.trim();
          if (typeof body?.comment === "string") row.comment = body.comment.slice(0, 280);
          if (body?.maxScore !== undefined)
            row.maxScore = Math.max(1, Math.min(1000, Number(body.maxScore) || 100));
          if (body?.score !== undefined)
            row.score = Math.max(0, Math.min(row.maxScore, Number(body.score) || 0));
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.selfAssessments = db.selfAssessments.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- gpa calculator ---------------- */
    case "gpa-courses": {
      if (!id) {
        if (M === "GET")
          return [...db.gpaCourses].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        if (M === "POST") {
          const row: GpaCourseRow = {
            id: uuid(),
            name: String(body?.name ?? "").trim().slice(0, 40) || "New course",
            grade: String(body?.grade ?? "A").trim().slice(0, 2).toUpperCase(),
            credits: Math.max(0, Math.min(20, Number(body?.credits) || 0)),
            weight: Math.max(0, Math.min(2, Number(body?.weight) || 0)),
            semesterId:
              typeof body?.semesterId === "string" &&
              db.gpaSemesters.some((s) => s.id === body.semesterId)
                ? body.semesterId
                : (db.gpaSemesters[0]?.id ?? ""),
            notes: wrapByWords(
              String(body?.notes ?? "").slice(0, 1200),
              GPA_COURSE_NOTES_MAX_WORDS,
              GPA_COURSE_NOTES_WORDS_PER_LINE
            ),
            createdAt: now(),
          };
          db.gpaCourses.push(row);
          save(db);
          return row;
        }
      } else {
        const row = findById(db.gpaCourses, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.name === "string") row.name = body.name.slice(0, 40);
          if (typeof body?.grade === "string") row.grade = body.grade.trim().toUpperCase().slice(0, 2);
          if (body?.credits !== undefined)
            row.credits = Math.max(0, Math.min(20, Number(body.credits) || 0));
          if (body?.weight !== undefined)
            row.weight = Math.max(0, Math.min(2, Number(body.weight) || 0));
          if (
            typeof body?.semesterId === "string" &&
            db.gpaSemesters.some((s) => s.id === body.semesterId)
          )
            row.semesterId = body.semesterId;
          if (typeof body?.notes === "string")
            row.notes = wrapByWords(
              body.notes.slice(0, 1200),
              GPA_COURSE_NOTES_MAX_WORDS,
              GPA_COURSE_NOTES_WORDS_PER_LINE
            );
          save(db);
          return row;
        }
        if (M === "DELETE") {
          db.gpaCourses = db.gpaCourses.filter((x) => x.id !== id);
          save(db);
          return ok();
        }
      }
      break;
    }

    /* ---------------- gpa tracker settings ---------------- */
    case "gpa-settings": {
      if (M === "GET") return db.gpaSettings;
      if (M === "PATCH") {
        if (body?.scale && typeof body.scale === "object") {
          for (const [g, v] of Object.entries(body.scale)) {
            const key = g.trim().toUpperCase().slice(0, 3);
            const n = Number(v);
            if (key && Number.isFinite(n))
              db.gpaSettings.scale[key] = Math.max(0, Math.min(10, n));
          }
        }
        if (typeof body?.weighted === "boolean") db.gpaSettings.weighted = body.weighted;
        if (typeof body?.notes === "string")
          db.gpaSettings.notes = wrapByWords(
            body.notes.slice(0, 4000),
            GPA_NOTES_MAX_WORDS,
            GPA_NOTES_WORDS_PER_LINE
          );
        save(db);
        return db.gpaSettings;
      }
      break;
    }

    /* ---------------- gpa tracker semesters ---------------- */
    case "gpa-semesters": {
      if (!id) {
        if (M === "GET")
          return [...db.gpaSemesters].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      } else {
        const row = findById(db.gpaSemesters, id);
        if (M === "PATCH") {
          if (!row) throw notFound();
          if (typeof body?.name === "string") row.name = body.name.trim().slice(0, 40);
          if (typeof body?.academicYear === "string")
            row.academicYear = body.academicYear.trim().slice(0, 24);
          if (typeof body?.targetGpa === "string")
            // the goal is a brief sentence now — keep the whole thing
            row.targetGpa = wrapByWords(
              body.targetGpa.slice(0, 600),
              GPA_GOAL_MAX_WORDS,
              GPA_GOAL_WORDS_PER_LINE
            );
          if (typeof body?.achieveBy === "string")
            row.achieveBy = body.achieveBy.trim().slice(0, 24);
          if (typeof body?.achieved === "boolean") row.achieved = body.achieved;
          if (Array.isArray(body?.checklist))
            // empty steps are allowed while typing — only the count is capped
            row.checklist = (body.checklist as Partial<GpaChecklistItem>[])
              .slice(0, 20)
              .map((c) => ({ text: String(c?.text ?? "").slice(0, 80), done: !!c?.done }));
          save(db);
          return row;
        }
      }
      break;
    }

    /* ---------------- computed ---------------- */
    case "analytics":
      if (M === "GET") return computeAnalytics(db);
      break;
    case "progress":
      if (M === "GET") return computeProgress(db);
      break;

    /* ---------------- trash ---------------- */
    case "trash": {
      if (M === "GET") {
        const bin: TrashBin = {
          tasks: db.tasks
            .filter((x) => x.deletedAt)
            .sort((a, b) => (b.deletedAt ?? "").localeCompare(a.deletedAt ?? "")),
          notes: db.notes
            .filter((x) => x.deletedAt)
            .sort((a, b) => (b.deletedAt ?? "").localeCompare(a.deletedAt ?? "")),
          deadlines: db.deadlines
            .filter((x) => x.deletedAt)
            .sort((a, b) => (b.deletedAt ?? "").localeCompare(a.deletedAt ?? "")),
          flashcards: db.flashcards
            .filter((x) => x.deletedAt)
            .sort((a, b) => (b.deletedAt ?? "").localeCompare(a.deletedAt ?? "")),
        };
        return bin;
      }
      const tableFor = (type: TrashType) =>
        type === "task"
          ? ("tasks" as const)
          : type === "note"
            ? ("notes" as const)
            : type === "deadline"
              ? ("deadlines" as const)
              : ("flashcards" as const);
      if (M === "PATCH") {
        const type = body?.type as TrashType;
        const itemId = String(body?.id ?? "");
        const table = db[tableFor(type)] as { id: string; deletedAt: string | null }[];
        const row = table.find((r) => r.id === itemId);
        if (!row) throw notFound();
        row.deletedAt = null;
        save(db);
        return row;
      }
      if (M === "DELETE") {
        if (body?.all === true) {
          db.tasks = db.tasks.filter((x) => !x.deletedAt);
          db.notes = db.notes.filter((x) => !x.deletedAt);
          db.deadlines = db.deadlines.filter((x) => !x.deletedAt);
          db.flashcards = db.flashcards.filter((x) => !x.deletedAt);
          save(db);
          return ok();
        }
        const type = body?.type as TrashType;
        const itemId = String(body?.id ?? "");
        const key = tableFor(type);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (db as any)[key] = (db[key] as { id: string }[]).filter((r) => r.id !== itemId);
        save(db);
        return ok();
      }
      break;
    }
  }

  throw new ApiError(`Unknown endpoint: ${M} ${rawPath}`, 404);
}
