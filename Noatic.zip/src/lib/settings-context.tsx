"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import { ACCENTS, DEFAULT_WIDGET_ORDER, type Settings } from "@/lib/types";

export type SettingsState = {
  dark: boolean;
  accent: string;
  desktopMode: boolean;
  musicShuffle: boolean;
  order: string[];
  hidden: string[];
  setDark: (v: boolean) => void;
  setAccent: (key: string) => void;
  setDesktopMode: (v: boolean) => void;
  setMusicShuffle: (v: boolean) => void;
  reorder: (next: string[]) => void;
  toggleHidden: (key: string) => void;
  resetLayout: () => void;
  settingsOpen: boolean;
  openSettings: () => void;
  closeSettings: () => void;
  helpOpen: boolean;
  openHelp: () => void;
  closeHelp: () => void;
};

const SettingsCtx = createContext<SettingsState | null>(null);

export function useSettings(): SettingsState {
  const ctx = useContext(SettingsCtx);
  if (!ctx) throw new Error("useSettings must be used inside AppProviders");
  return ctx;
}

function applyDark(dark: boolean) {
  document.documentElement.classList.toggle("dark", dark);
}

function applyAccent(key: string) {
  const a = ACCENTS[key];
  if (!a) return;
  const root = document.documentElement;
  root.style.setProperty("--accent", a.accent);
  root.style.setProperty("--accent-soft", a.soft);
  root.style.setProperty("--accent-ink", a.ink);
  root.dataset.accent = key;
}

export function SettingsProvider({
  children,
  initial,
}: {
  children: ReactNode;
  initial?: Settings;
}) {
  const [dark, setDarkState] = useState(initial?.darkMode ?? false);
  const [accent, setAccentState] = useState(initial?.accent ?? "rosewood");
  const [desktopMode, setDesktopModeState] = useState(initial?.desktopMode ?? false);
  const [musicShuffle, setMusicShuffleState] = useState(initial?.musicShuffle ?? false);
  const [order, setOrder] = useState<string[]>(
    initial?.widgetOrder?.length ? initial.widgetOrder : DEFAULT_WIDGET_ORDER
  );
  const [hidden, setHidden] = useState<string[]>(initial?.hiddenWidgets ?? []);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const { push } = useToast();

  // When the server didn't hand us settings (shouldn't happen in the app),
  // fetch them client-side as a fallback.
  useEffect(() => {
    if (initial) return;
    let cancelled = false;
    api<Settings>("/api/settings")
      .then((s) => {
        if (cancelled) return;
        setDarkState(s.darkMode);
        applyDark(s.darkMode);
        setAccentState(s.accent);
        applyAccent(s.accent);
        setDesktopModeState(s.desktopMode);
        setMusicShuffleState(s.musicShuffle);
        setOrder(s.widgetOrder?.length ? s.widgetOrder : DEFAULT_WIDGET_ORDER);
        setHidden(s.hiddenWidgets ?? []);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [initial]);

  const persist = useCallback(
    async (body: Record<string, unknown>, revert: () => void) => {
      try {
        await api("/api/settings", { method: "PATCH", body });
      } catch (e) {
        revert();
        push("error", e instanceof Error ? e.message : "Couldn't save that setting");
      }
    },
    [push]
  );

  const setDark = useCallback(
    (v: boolean) => {
      const prev = dark;
      setDarkState(v);
      applyDark(v);
      persist({ darkMode: v }, () => {
        setDarkState(prev);
        applyDark(prev);
      });
    },
    [dark, persist]
  );

  const setAccent = useCallback(
    (key: string) => {
      const prev = accent;
      setAccentState(key);
      applyAccent(key);
      persist({ accent: key }, () => {
        setAccentState(prev);
        applyAccent(prev);
      });
    },
    [accent, persist]
  );

  const setDesktopMode = useCallback(
    (v: boolean) => {
      const prev = desktopMode;
      setDesktopModeState(v);
      persist({ desktopMode: v }, () => setDesktopModeState(prev));
      push("info", v ? "Desktop mode on — the dashboard is now wider" : "Desktop mode off");
    },
    [desktopMode, persist, push]
  );

  const setMusicShuffle = useCallback(
    (v: boolean) => {
      const prev = musicShuffle;
      setMusicShuffleState(v);
      persist({ musicShuffle: v }, () => setMusicShuffleState(prev));
    },
    [musicShuffle, persist]
  );

  const reorder = useCallback(
    (next: string[]) => {
      const prev = order;
      setOrder(next);
      persist({ widgetOrder: next }, () => {
        setOrder(prev);
        push("error", "Couldn't save the new layout");
      });
    },
    [order, persist, push]
  );

  const toggleHidden = useCallback(
    (key: string) => {
      const prev = hidden;
      const next = hidden.includes(key)
        ? hidden.filter((k) => k !== key)
        : [...hidden, key];
      setHidden(next);
      persist({ hiddenWidgets: next }, () => setHidden(prev));
    },
    [hidden, persist]
  );

  const resetLayout = useCallback(() => {
    const prevOrder = order;
    const prevHidden = hidden;
    setOrder(DEFAULT_WIDGET_ORDER);
    setHidden([]);
    persist({ widgetOrder: DEFAULT_WIDGET_ORDER, hiddenWidgets: [] }, () => {
      setOrder(prevOrder);
      setHidden(prevHidden);
    });
    push("success", "Dashboard layout reset");
  }, [order, hidden, persist, push]);

  const value = useMemo<SettingsState>(
    () => ({
      dark,
      accent,
      desktopMode,
      musicShuffle,
      order,
      hidden,
      setDark,
      setAccent,
      setDesktopMode,
      setMusicShuffle,
      reorder,
      toggleHidden,
      resetLayout,
      settingsOpen,
      openSettings: () => setSettingsOpen(true),
      closeSettings: () => setSettingsOpen(false),
      helpOpen,
      openHelp: () => setHelpOpen(true),
      closeHelp: () => setHelpOpen(false),
    }),
    [
      dark,
      accent,
      desktopMode,
      musicShuffle,
      order,
      hidden,
      setDark,
      setAccent,
      setDesktopMode,
      setMusicShuffle,
      reorder,
      toggleHidden,
      resetLayout,
      settingsOpen,
      helpOpen,
    ]
  );

  return <SettingsCtx.Provider value={value}>{children}</SettingsCtx.Provider>;
}
