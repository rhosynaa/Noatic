"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import type { ChainStep, FocusSession, TimerChain, TimerKind, TimerPreset } from "@/lib/types";

/** Freely editable configuration — never locked by the running session. */
type Draft = { kind: TimerKind; minutes: number; subject: string; label: string };

type Session = Draft & { runId: number; noteId: string | null };

type ChainRun = {
  id: string;
  name: string;
  steps: ChainStep[];
  subject: string;
  transitionSec: number;
  index: number;
  noteId: string | null;
};

export type CompleteInfo = {
  kind: TimerKind;
  minutes: number;
  subject: string;
  label: string;
  hasNext: boolean;
  chainName: string | null;
};

const DEFAULT_DRAFT: Draft = { kind: "focus", minutes: 25, subject: "", label: "" };
/** Only these count as *study* time in analytics — breaks never do. */
const STUDY_KINDS: TimerKind[] = ["focus", "custom"];

type FocusCtxType = {
  presets: TimerPreset[];
  chains: TimerChain[];
  sessions: FocusSession[];
  todayStudyMinutes: number;
  refreshSessions: () => Promise<void>;
  addPreset: (
    label: string,
    minutes: number,
    kind: TimerKind,
    subject?: string
  ) => Promise<TimerPreset | null>;
  updatePreset: (
    id: string,
    patch: { label?: string; minutes?: number; kind?: TimerKind; subject?: string }
  ) => Promise<TimerPreset | null>;
  deletePreset: (id: string) => void;
  /** presets usable for a subject: its own + the "any subject" ones */
  presetsFor: (subject: string) => TimerPreset[];
  addChain: (chain: {
    name: string;
    steps: ChainStep[];
    subject: string;
    transitionSec: number;
  }) => Promise<TimerChain | null>;
  deleteChain: (id: string) => void;

  /** editable draft */
  kind: TimerKind;
  minutes: number;
  subject: string;
  label: string;
  setDraft: (patch: Partial<Draft>) => void;

  totalSec: number;
  leftSec: number;
  running: boolean;
  sessionActive: boolean;
  activeNoteId: string | null;

  chainRun: ChainRun | null;
  chainPaused: boolean;
  transition: { count: number; next: ChainStep | null } | null;
  transitionSec: number;
  setTransitionSec: (n: number) => void;

  completeInfo: CompleteInfo | null;
  alarmOn: boolean;

  toggle: () => void;
  /** back to the configured duration, session stays armed */
  resetClock: () => void;
  /** tear the session down completely */
  cancelSession: () => void;
  startSession: (patch?: Partial<Draft>, noteId?: string | null) => void;
  startChain: (chain: TimerChain, noteId?: string | null) => void;
  restartChain: () => void;
  skipToNext: () => void;
  pauseChain: (paused: boolean) => void;
  stopChain: () => void;
  stopAlarm: () => void;
  dismissComplete: () => void;
  snooze: () => void;
  startNextNow: () => void;
  /** used by the note view so closing a note stops its timer */
  stopSessionFromNote: (noteId: string) => void;
};

const FocusCtx = createContext<FocusCtxType | null>(null);

export function useFocus(): FocusCtxType {
  const ctx = useContext(FocusCtx);
  if (!ctx) throw new Error("useFocus must be used inside FocusProvider");
  return ctx;
}

/* ------------------------------------------------------------------ *
 * Audio: one shared context, unlocked on the first user gesture so the
 * alarm is allowed to sound later (browser autoplay policy).
 * ------------------------------------------------------------------ */
let sharedCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!sharedCtx) {
      const Ctor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return null;
      sharedCtx = new Ctor();
    }
    if (sharedCtx.state === "suspended") void sharedCtx.resume().catch(() => {});
    return sharedCtx;
  } catch {
    return null;
  }
}

export function FocusProvider({ children }: { children: ReactNode }) {
  const { push } = useToast();

  const [presets, setPresets] = useState<TimerPreset[]>([]);
  const [chains, setChains] = useState<TimerChain[]>([]);
  const [sessions, setSessions] = useState<FocusSession[]>([]);

  const [draft, setDraftState] = useState<Draft>(DEFAULT_DRAFT);
  const [session, setSession] = useState<Session | null>(null);
  const [totalSec, setTotalSec] = useState(DEFAULT_DRAFT.minutes * 60);
  const [leftSec, setLeftSec] = useState(DEFAULT_DRAFT.minutes * 60);
  const [running, setRunning] = useState(false);

  const [chainRun, setChainRun] = useState<ChainRun | null>(null);
  const [chainPaused, setChainPaused] = useState(false);
  const [transition, setTransition] = useState<{ count: number; next: ChainStep | null } | null>(
    null
  );
  const [transitionSec, setTransitionSecState] = useState(5);
  const [completeInfo, setCompleteInfo] = useState<CompleteInfo | null>(null);
  const [alarmOn, setAlarmOn] = useState(false);

  const runIdRef = useRef(0);
  const sessionRef = useRef<Session | null>(null);
  sessionRef.current = session;
  const chainRef = useRef<ChainRun | null>(null);
  chainRef.current = chainRun;
  const chainPausedRef = useRef(false);
  chainPausedRef.current = chainPaused;
  const lastChainRef = useRef<TimerChain | null>(null);

  const alarmLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const alarmStopRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  /* ---------- catalogs ---------- */
  const refreshSessions = useCallback(async () => {
    try {
      setSessions(await api<FocusSession[]>("/api/focus-sessions"));
    } catch {
      /* quiet */
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const safe = async <T,>(fn: () => Promise<T>) => {
        try {
          return await fn();
        } catch {
          return null;
        }
      };
      const [p, c, s] = await Promise.all([
        safe(() => api<TimerPreset[]>("/api/timer-presets")),
        safe(() => api<TimerChain[]>("/api/timer-chains")),
        safe(() => api<FocusSession[]>("/api/focus-sessions")),
      ]);
      if (cancelled) return;
      if (p) setPresets(p);
      if (c) setChains(c);
      if (s) setSessions(s);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  /* unlock audio on the very first interaction anywhere in the app */
  useEffect(() => {
    const unlock = () => {
      const ctx = getAudioContext();
      if (!ctx) return;
      try {
        // a silent blip satisfies iOS/Safari's "played during a gesture" rule
        const buf = ctx.createBuffer(1, 1, 22050);
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.start(0);
      } catch {
        /* ignore */
      }
    };
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  /* ---------- alarm ---------- */
  const stopAlarm = useCallback(() => {
    if (alarmLoopRef.current) {
      clearInterval(alarmLoopRef.current);
      alarmLoopRef.current = null;
    }
    if (alarmStopRef.current) {
      clearTimeout(alarmStopRef.current);
      alarmStopRef.current = null;
    }
    setAlarmOn(false);
  }, []);

  const startAlarm = useCallback(() => {
    if (alarmLoopRef.current) {
      clearInterval(alarmLoopRef.current);
      alarmLoopRef.current = null;
    }
    if (alarmStopRef.current) clearTimeout(alarmStopRef.current);

    const chime = () => {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const notes: [number, number][] = [
        [880, 0],
        [659.25, 0.38],
        [880, 0.76],
      ];
      for (const [freq, at] of notes) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + at);
        gain.gain.setValueAtTime(0.0001, now + at);
        gain.gain.exponentialRampToValueAtTime(0.3, now + at + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + at + 0.34);
        osc.connect(gain).connect(ctx.destination);
        osc.start(now + at);
        osc.stop(now + at + 0.36);
      }
    };

    chime();
    alarmLoopRef.current = setInterval(chime, 1500);
    setAlarmOn(true);
    // silence itself after exactly one minute if never dismissed
    alarmStopRef.current = setTimeout(() => {
      if (alarmLoopRef.current) {
        clearInterval(alarmLoopRef.current);
        alarmLoopRef.current = null;
      }
      setAlarmOn(false);
    }, 60_000);
  }, []);

  useEffect(
    () => () => {
      if (alarmLoopRef.current) clearInterval(alarmLoopRef.current);
      if (alarmStopRef.current) clearTimeout(alarmStopRef.current);
    },
    []
  );

  /* ---------- draft (always editable, never locks) ---------- */
  const setDraft = useCallback((patch: Partial<Draft>) => {
    setDraftState((d) => {
      const next = { ...d, ...patch };
      // changing the duration while nothing is running just re-arms the clock
      if (patch.minutes !== undefined && !sessionRef.current) {
        setTotalSec(next.minutes * 60);
        setLeftSec(next.minutes * 60);
      }
      return next;
    });
  }, []);

  /* ---------- session plumbing ---------- */
  const beginSession = useCallback((cfg: Draft, noteId: string | null, autoRun: boolean) => {
    const s: Session = { ...cfg, runId: ++runIdRef.current, noteId };
    sessionRef.current = s;
    setSession(s);
    setTotalSec(cfg.minutes * 60);
    setLeftSec(cfg.minutes * 60);
    setRunning(autoRun);
  }, []);

  const logSession = useCallback(
    async (s: Session) => {
      try {
        const row = await api<FocusSession>("/api/focus-sessions", {
          method: "POST",
          body: {
            minutes: s.minutes,
            kind: s.kind,
            subject: s.subject.trim(),
            label: s.label.trim(),
            // ties the entry to its note so per-note targets fill up
            noteId: s.noteId ?? "",
          },
        });
        setSessions((prev) => [row, ...prev].slice(0, 80));
      } catch {
        push("error", "Session finished but couldn't be logged");
      }
    },
    [push]
  );

  const applyChainStep = useCallback(
    (index: number) => {
      const chain = chainRef.current;
      if (!chain) return;
      const step = chain.steps[index];
      if (!step) return;
      const next = { ...chain, index };
      chainRef.current = next;
      setChainRun(next);
      beginSession(
        {
          kind: step.kind,
          minutes: step.minutes,
          // subject falls back to the chain's subject — never its name
          subject: (step.subject || chain.subject || "").trim(),
          label: step.label ?? "",
        },
        chain.noteId,
        true
      );
    },
    [beginSession]
  );

  /* countdown */
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setLeftSec((l) => (l <= 1 ? 0 : l - 1)), 1000);
    return () => clearInterval(id);
  }, [running]);

  /* completion — always logs, always rings, always shows the modal */
  useEffect(() => {
    if (leftSec !== 0) return;
    const s = sessionRef.current;
    if (!s) return;

    sessionRef.current = null;
    setSession(null);
    setRunning(false);
    void logSession(s);

    const chain = chainRef.current;
    const hasNext = !!chain && chain.index < chain.steps.length - 1;

    startAlarm();
    setCompleteInfo({
      kind: s.kind,
      minutes: s.minutes,
      subject: s.subject,
      label: s.label,
      hasNext,
      chainName: chain?.name ?? null,
    });

    if (chain && hasNext && !chainPausedRef.current) {
      setTransition({
        count: Math.max(0, chain.transitionSec),
        next: chain.steps[chain.index + 1],
      });
    } else if (chain && !hasNext) {
      chainRef.current = null;
      setChainRun(null);
      setChainPaused(false);
      push("success", `Chain “${chain.name}” complete — well played`);
    }
  }, [leftSec, logSession, push, startAlarm]);

  /* auto-advance between chain steps (alarm keeps ringing meanwhile) */
  useEffect(() => {
    if (!transition || chainPaused) return;
    if (transition.count <= 0) {
      const chain = chainRef.current;
      setTransition(null);
      stopAlarm();
      setCompleteInfo(null);
      if (chain) applyChainStep(chain.index + 1);
      return;
    }
    const id = setTimeout(
      () => setTransition((t) => (t ? { ...t, count: t.count - 1 } : null)),
      1000
    );
    return () => clearTimeout(id);
  }, [transition, chainPaused, stopAlarm, applyChainStep]);

  /* ---------- actions ---------- */
  const startSession = useCallback(
    (patch?: Partial<Draft>, noteId: string | null = null) => {
      stopAlarm();
      setCompleteInfo(null);
      setTransition(null);
      chainRef.current = null;
      setChainRun(null);
      setChainPaused(false);
      const cfg = { ...draft, ...patch };
      setDraftState(cfg);
      beginSession(cfg, noteId, true);
    },
    [beginSession, draft, stopAlarm]
  );

  /** play/pause — starts a real (loggable) session if none is live yet */
  const toggle = useCallback(() => {
    if (sessionRef.current) {
      setRunning((r) => !r);
      return;
    }
    stopAlarm();
    setCompleteInfo(null);
    beginSession(draft, null, true);
  }, [beginSession, draft, stopAlarm]);

  const resetClock = useCallback(() => {
    setRunning(false);
    setLeftSec(sessionRef.current ? sessionRef.current.minutes * 60 : draft.minutes * 60);
  }, [draft.minutes]);

  const cancelSession = useCallback(() => {
    stopAlarm();
    setCompleteInfo(null);
    setTransition(null);
    sessionRef.current = null;
    setSession(null);
    setRunning(false);
    chainRef.current = null;
    setChainRun(null);
    setChainPaused(false);
    setTotalSec(draft.minutes * 60);
    setLeftSec(draft.minutes * 60);
  }, [draft.minutes, stopAlarm]);

  const startChain = useCallback(
    (chain: TimerChain, noteId: string | null = null) => {
      if (!chain.steps.length) {
        push("error", "That sequence has no sessions yet");
        return;
      }
      stopAlarm();
      setCompleteInfo(null);
      setTransition(null);
      setChainPaused(false);
      setTransitionSecState(chain.transitionSec);
      lastChainRef.current = chain;
      const run: ChainRun = {
        id: chain.id,
        name: chain.name,
        steps: chain.steps,
        subject: chain.subject,
        transitionSec: chain.transitionSec,
        index: 0,
        noteId,
      };
      chainRef.current = run;
      setChainRun(run);
      const step = chain.steps[0];
      beginSession(
        {
          kind: step.kind,
          minutes: step.minutes,
          subject: (step.subject || chain.subject || "").trim(),
          label: step.label ?? "",
        },
        noteId,
        true
      );
      push("success", `Chain “${chain.name}” started — session 1 of ${chain.steps.length}`);
    },
    [beginSession, push, stopAlarm]
  );

  const restartChain = useCallback(() => {
    const source =
      lastChainRef.current ??
      (chainRef.current
        ? {
            id: chainRef.current.id,
            name: chainRef.current.name,
            steps: chainRef.current.steps,
            subject: chainRef.current.subject,
            transitionSec: chainRef.current.transitionSec,
          }
        : null);
    if (!source) return;
    startChain(source as TimerChain, chainRef.current?.noteId ?? null);
  }, [startChain]);

  const skipToNext = useCallback(() => {
    const chain = chainRef.current;
    if (!chain) return;
    stopAlarm();
    setCompleteInfo(null);
    setTransition(null);
    if (chain.index < chain.steps.length - 1) {
      applyChainStep(chain.index + 1);
    } else {
      chainRef.current = null;
      setChainRun(null);
      sessionRef.current = null;
      setSession(null);
      setRunning(false);
      push("success", `Chain “${chain.name}” finished`);
    }
  }, [applyChainStep, push, stopAlarm]);

  const pauseChain = useCallback((paused: boolean) => {
    chainPausedRef.current = paused;
    setChainPaused(paused);
    setRunning(!paused && !!sessionRef.current);
  }, []);

  const stopChain = useCallback(() => {
    stopAlarm();
    setCompleteInfo(null);
    setTransition(null);
    chainRef.current = null;
    setChainRun(null);
    setChainPaused(false);
    sessionRef.current = null;
    setSession(null);
    setRunning(false);
    setLeftSec(draft.minutes * 60);
    setTotalSec(draft.minutes * 60);
  }, [draft.minutes, stopAlarm]);

  const dismissComplete = useCallback(() => {
    stopAlarm();
    setCompleteInfo(null);
  }, [stopAlarm]);

  const snooze = useCallback(() => {
    stopAlarm();
    setCompleteInfo(null);
    setTransition(null);
    if (chainRef.current) {
      chainPausedRef.current = true;
      setChainPaused(true);
    }
    beginSession({ kind: "short", minutes: 5, subject: "", label: "Snooze" }, null, true);
  }, [beginSession, stopAlarm]);

  const startNextNow = useCallback(() => {
    const chain = chainRef.current;
    stopAlarm();
    setCompleteInfo(null);
    setTransition(null);
    if (!chain) return;
    chainPausedRef.current = false;
    setChainPaused(false);
    if (chain.index < chain.steps.length - 1) applyChainStep(chain.index + 1);
    else {
      chainRef.current = null;
      setChainRun(null);
    }
  }, [applyChainStep, stopAlarm]);

  const stopSessionFromNote = useCallback(
    (noteId: string) => {
      const s = sessionRef.current;
      const c = chainRef.current;
      const owned = (s && s.noteId === noteId) || (c && c.noteId === noteId);
      if (!owned) return;
      stopAlarm();
      setCompleteInfo(null);
      setTransition(null);
      sessionRef.current = null;
      setSession(null);
      setRunning(false);
      chainRef.current = null;
      setChainRun(null);
      setChainPaused(false);
    },
    [stopAlarm]
  );

  /* ---------- catalog actions ---------- */
  const addPreset = useCallback(
    async (label: string, minutes: number, kind: TimerKind, subject = "") => {
      try {
        const row = await api<TimerPreset>("/api/timer-presets", {
          method: "POST",
          body: { label, minutes, kind, subject },
        });
        setPresets((p) => [...p, row]);
        push(
          "success",
          row.subject
            ? `Preset “${row.label}” saved for ${row.subject}`
            : `Preset “${row.label}” saved for any subject`
        );
        return row;
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't save that preset");
        return null;
      }
    },
    [push]
  );

  const updatePreset = useCallback(
    async (
      id: string,
      patch: { label?: string; minutes?: number; kind?: TimerKind; subject?: string }
    ) => {
      try {
        const row = await api<TimerPreset>(`/api/timer-presets/${id}`, {
          method: "PATCH",
          body: patch,
        });
        setPresets((p) => p.map((x) => (x.id === id ? row : x)));
        push("success", `Preset “${row.label}” updated`);
        return row;
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't update that preset");
        return null;
      }
    },
    [push]
  );

  const deletePreset = useCallback(
    (id: string) => {
      setPresets((p) => p.filter((x) => x.id !== id));
      api(`/api/timer-presets/${id}`, { method: "DELETE" }).catch(() => {
        push("error", "Couldn't delete that preset");
        void api<TimerPreset[]>("/api/timer-presets").then(setPresets).catch(() => {});
      });
    },
    [push]
  );

  const addChain = useCallback(
    async (input: { name: string; steps: ChainStep[]; subject: string; transitionSec: number }) => {
      try {
        const row = await api<TimerChain>("/api/timer-chains", {
          method: "POST",
          body: {
            name: input.name,
            subject: input.subject,
            transitionSec: input.transitionSec,
            steps: input.steps.map((s) => ({
              kind: s.kind,
              minutes: s.minutes,
              subject: s.subject ?? "",
              label: s.label ?? "",
            })),
          },
        });
        setChains((c) => [...c, row]);
        push("success", `Chain “${row.name}” saved`);
        return row;
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't save that chain");
        return null;
      }
    },
    [push]
  );

  const deleteChain = useCallback(
    (id: string) => {
      setChains((c) => c.filter((x) => x.id !== id));
      api(`/api/timer-chains/${id}`, { method: "DELETE" }).catch(() => {
        push("error", "Couldn't delete that chain");
        void api<TimerChain[]>("/api/timer-chains").then(setChains).catch(() => {});
      });
    },
    [push]
  );

  const presetsFor = useCallback(
    (subject: string) => {
      const want = subject.trim().toLowerCase();
      return presets.filter(
        (p) => !p.subject.trim() || p.subject.trim().toLowerCase() === want
      );
    },
    [presets]
  );

  const setTransitionSec = useCallback((n: number) => {
    setTransitionSecState(Math.max(0, Math.min(60, Math.round(n) || 0)));
  }, []);

  const todayStudyMinutes = useMemo(() => {
    const key = new Date().toDateString();
    return sessions
      .filter(
        (s) =>
          new Date(s.completedAt).toDateString() === key &&
          STUDY_KINDS.includes((s.kind ?? "focus") as TimerKind)
      )
      .reduce((a, s) => a + s.minutes, 0);
  }, [sessions]);

  const value: FocusCtxType = {
    presets,
    chains,
    sessions,
    todayStudyMinutes,
    refreshSessions,
    addPreset,
    updatePreset,
    deletePreset,
    presetsFor,
    addChain,
    deleteChain,
    kind: draft.kind,
    minutes: draft.minutes,
    subject: draft.subject,
    label: draft.label,
    setDraft,
    totalSec,
    leftSec,
    running,
    sessionActive: session !== null,
    activeNoteId: session?.noteId ?? chainRun?.noteId ?? null,
    chainRun,
    chainPaused,
    transition,
    transitionSec,
    setTransitionSec,
    completeInfo,
    alarmOn,
    toggle,
    resetClock,
    cancelSession,
    startSession,
    startChain,
    restartChain,
    skipToNext,
    pauseChain,
    stopChain,
    stopAlarm,
    dismissComplete,
    snooze,
    startNextNow,
    stopSessionFromNote,
  };

  return <FocusCtx.Provider value={value}>{children}</FocusCtx.Provider>;
}
