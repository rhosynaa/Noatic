/**
 * The apps five note-cover SVGs (originally public/covers/*.svg), inlined
 * as data URLs so they always render in the single-file build. The artwork
 * is byte-identical to the SVG files, just URI-encoded.
 */

export const COVER_SUNRISE =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#f6b17a"/><stop offset="55%" stop-color="#c96f4a"/><stop offset="100%" stop-color="#7a3b2e"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="28%" r="42%">
      <stop offset="0%" stop-color="#fff" stop-opacity=".55"/>
      <stop offset="100%" stop-color="#fff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="400" height="400" fill="url(#g)"/>
  <circle cx="200" cy="112" r="74" fill="url(#glow)"/>
  <g fill="#fff" opacity=".22">
    <circle cx="200" cy="200" r="96" fill="none" stroke="#fff" stroke-width="2.5" opacity=".5"/>
    <circle cx="200" cy="200" r="62" fill="none" stroke="#fff" stroke-width="1.6" opacity=".4"/>
    <circle cx="200" cy="200" r="15"/>
  </g>
  <g opacity=".30" fill="#fff">
    <rect x="86" y="266" width="12" height="34" rx="6"/><rect x="112" y="242" width="12" height="58" rx="6"/><rect x="138" y="274" width="12" height="26" rx="6"/><rect x="164" y="228" width="12" height="72" rx="6"/><rect x="190" y="256" width="12" height="44" rx="6"/><rect x="216" y="236" width="12" height="64" rx="6"/><rect x="242" y="270" width="12" height="30" rx="6"/><rect x="268" y="248" width="12" height="52" rx="6"/><rect x="294" y="262" width="12" height="38" rx="6"/>
  </g>
</svg>`
  );

export const COVER_DUSK =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#8f7bc4"/><stop offset="55%" stop-color="#5b4a92"/><stop offset="100%" stop-color="#2e2450"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="36%" r="42%">
      <stop offset="0%" stop-color="#fff" stop-opacity=".55"/>
      <stop offset="100%" stop-color="#fff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="400" height="400" fill="url(#g)"/>
  <circle cx="200" cy="136" r="68" fill="url(#glow)"/>
  <g fill="#fff" opacity=".22">
    <circle cx="200" cy="200" r="96" fill="none" stroke="#fff" stroke-width="2.5" opacity=".5"/>
    <circle cx="200" cy="200" r="62" fill="none" stroke="#fff" stroke-width="1.6" opacity=".4"/>
    <circle cx="200" cy="200" r="15"/>
  </g>
  <g opacity=".30" fill="#fff">
    <rect x="86" y="266" width="12" height="34" rx="6"/><rect x="112" y="242" width="12" height="58" rx="6"/><rect x="138" y="274" width="12" height="26" rx="6"/><rect x="164" y="228" width="12" height="72" rx="6"/><rect x="190" y="256" width="12" height="44" rx="6"/><rect x="216" y="236" width="12" height="64" rx="6"/><rect x="242" y="270" width="12" height="30" rx="6"/><rect x="268" y="248" width="12" height="52" rx="6"/><rect x="294" y="262" width="12" height="38" rx="6"/>
  </g>
</svg>`
  );

export const COVER_RAIN =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#7fa8c9"/><stop offset="55%" stop-color="#4a6f96"/><stop offset="100%" stop-color="#25384f"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="44%" r="42%">
      <stop offset="0%" stop-color="#fff" stop-opacity=".55"/>
      <stop offset="100%" stop-color="#fff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="400" height="400" fill="url(#g)"/>
  <circle cx="200" cy="160" r="62" fill="url(#glow)"/>
  <g fill="#fff" opacity=".22">
    <circle cx="200" cy="200" r="96" fill="none" stroke="#fff" stroke-width="2.5" opacity=".5"/>
    <circle cx="200" cy="200" r="62" fill="none" stroke="#fff" stroke-width="1.6" opacity=".4"/>
    <circle cx="200" cy="200" r="15"/>
  </g>
  <g opacity=".30" fill="#fff">
    <rect x="86" y="266" width="12" height="34" rx="6"/><rect x="112" y="242" width="12" height="58" rx="6"/><rect x="138" y="274" width="12" height="26" rx="6"/><rect x="164" y="228" width="12" height="72" rx="6"/><rect x="190" y="256" width="12" height="44" rx="6"/><rect x="216" y="236" width="12" height="64" rx="6"/><rect x="242" y="270" width="12" height="30" rx="6"/><rect x="268" y="248" width="12" height="52" rx="6"/><rect x="294" y="262" width="12" height="38" rx="6"/>
  </g>
</svg>`
  );

export const COVER_MEADOW =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#9ec98a"/><stop offset="55%" stop-color="#5f9160"/><stop offset="100%" stop-color="#2c4a33"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="52%" r="42%">
      <stop offset="0%" stop-color="#fff" stop-opacity=".55"/>
      <stop offset="100%" stop-color="#fff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="400" height="400" fill="url(#g)"/>
  <circle cx="200" cy="184" r="56" fill="url(#glow)"/>
  <g fill="#fff" opacity=".22">
    <circle cx="200" cy="200" r="96" fill="none" stroke="#fff" stroke-width="2.5" opacity=".5"/>
    <circle cx="200" cy="200" r="62" fill="none" stroke="#fff" stroke-width="1.6" opacity=".4"/>
    <circle cx="200" cy="200" r="15"/>
  </g>
  <g opacity=".30" fill="#fff">
    <rect x="86" y="266" width="12" height="34" rx="6"/><rect x="112" y="242" width="12" height="58" rx="6"/><rect x="138" y="274" width="12" height="26" rx="6"/><rect x="164" y="228" width="12" height="72" rx="6"/><rect x="190" y="256" width="12" height="44" rx="6"/><rect x="216" y="236" width="12" height="64" rx="6"/><rect x="242" y="270" width="12" height="30" rx="6"/><rect x="268" y="248" width="12" height="52" rx="6"/><rect x="294" y="262" width="12" height="38" rx="6"/>
  </g>
</svg>`
  );

export const COVER_EMBER =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#e8a06a"/><stop offset="55%" stop-color="#b8524a"/><stop offset="100%" stop-color="#5c2430"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="60%" r="42%">
      <stop offset="0%" stop-color="#fff" stop-opacity=".55"/>
      <stop offset="100%" stop-color="#fff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="400" height="400" fill="url(#g)"/>
  <circle cx="200" cy="208" r="50" fill="url(#glow)"/>
  <g fill="#fff" opacity=".22">
    <circle cx="200" cy="200" r="96" fill="none" stroke="#fff" stroke-width="2.5" opacity=".5"/>
    <circle cx="200" cy="200" r="62" fill="none" stroke="#fff" stroke-width="1.6" opacity=".4"/>
    <circle cx="200" cy="200" r="15"/>
  </g>
  <g opacity=".30" fill="#fff">
    <rect x="86" y="266" width="12" height="34" rx="6"/><rect x="112" y="242" width="12" height="58" rx="6"/><rect x="138" y="274" width="12" height="26" rx="6"/><rect x="164" y="228" width="12" height="72" rx="6"/><rect x="190" y="256" width="12" height="44" rx="6"/><rect x="216" y="236" width="12" height="64" rx="6"/><rect x="242" y="270" width="12" height="30" rx="6"/><rect x="268" y="248" width="12" height="52" rx="6"/><rect x="294" y="262" width="12" height="38" rx="6"/>
  </g>
</svg>`
  );
