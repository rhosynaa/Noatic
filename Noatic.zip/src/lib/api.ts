"use client";

import { handleApi, type ApiError } from "@/lib/local-db";

/**
 * Drop-in replacement for the original fetch-based client.
 * It dispatches to an in-browser implementation of the API that
 * persists to localStorage, keeping every call signature identical.
 */
export async function api<T>(
  path: string,
  init?: { method?: string; body?: unknown }
): Promise<T> {
  // yield once so callers behave as they did with a real network boundary
  await Promise.resolve();
  try {
    return (await handleApi(
      init?.method ?? "GET",
      path,
      init?.body as Record<string, unknown> | undefined
    )) as T;
  } catch (e) {
    throw e as ApiError;
  }
}

/** Read a file input into a downscaled base64 data URL (max ~512px). */
export function fileToDataUrl(file: File, maxSize = 768): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) return reject(new Error("That's not an image file"));
    const img = new Image();
    const reader = new FileReader();
    reader.onload = () => {
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas unavailable"));
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      img.onerror = () => reject(new Error("Could not read that image"));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error("Could not read that file"));
    reader.readAsDataURL(file);
  });
}
