"use client";

/**
 * Tiny hash-based router replacing next/link for the SPA build.
 * Routes: "#/" (dashboard) and "#/profile".
 */

import { useCallback, useSyncExternalStore, type AnchorHTMLAttributes, type ReactNode } from "react";

function normalizePath(hash: string): string {
  const h = hash.replace(/^#/, "");
  return h.startsWith("/") ? h : "/";
}

export function useRoute(): string {
  const hash = useSyncExternalStore(
    (cb) => {
      window.addEventListener("hashchange", cb);
      return () => window.removeEventListener("hashchange", cb);
    },
    () => window.location.hash,
    () => ""
  );
  return normalizePath(hash || "#/");
}

export function navigate(to: string) {
  window.location.hash = to.startsWith("/") ? `#${to}` : to;
}

type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & {
  href: string;
  children: ReactNode;
};

export default function Link({ href, children, onClick, ...rest }: LinkProps) {
  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLAnchorElement>) => {
      onClick?.(e);
      if (e.defaultPrevented) return;
      e.preventDefault();
      navigate(href);
    },
    [href, onClick]
  );
  const target = href.startsWith("/") ? `#${href}` : href;
  return (
    <a href={target} onClick={handleClick} {...rest}>
      {children}
    </a>
  );
}
