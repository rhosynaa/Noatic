/**
 * The pictures the media library ships with.
 *
 * The first six are the app's own original photographs — the same warm,
 * aesthetic shots the dashboard and subject cards have always used. They're
 * stored as base64 text (see `photo-assets.ts`) rather than binary files so
 * they always travel with a download.
 *
 * They're joined by ten hand-painted watercolor study plates (see
 * `artwork-assets.ts`) themed around the workspace: one for each subject in
 * the library (biology, chemistry, math, history, english), a rainy version
 * of the dashboard banner mood, a focus-timer piece, a music-room piece, a
 * night-owl window and a weekend picnic — same cream-sketchbook style as the
 * subject covers, never the same compositions.
 */

import {
  GALLERY_PHOTO,
  HERO_PHOTO,
  SUBJECT_BIOLOGY_PHOTO,
  SUBJECT_CHEMISTRY_PHOTO,
  SUBJECT_ENGLISH_PHOTO,
  SUBJECT_HISTORY_PHOTO,
} from "@/lib/photo-assets";
import {
  ART_AMBER_ALCHEMY,
  ART_ANNOTATED_MARGINS,
  ART_EMBER_HOUR,
  ART_FIELD_DAY,
  ART_GOLDEN_SPIRAL,
  ART_LAMPLIGHT,
  ART_NIGHT_MOTH,
  ART_SEALED_LETTERS,
  ART_SIDE_A,
  ART_THIRD_FLOOR_STARS,
} from "@/lib/artwork-assets";

export type DemoMedia = { name: string; url: string; category: string };

/**
 * Two starter categories of photos, so the rotation picker has something to
 * choose between — plus the watercolor study plates spread over more
 * categories, so the category filter has enough chips to demonstrate its
 * two-line "show more / show less" wrap and the search has plenty of names
 * to find.
 */
export const DEMO_MEDIA: DemoMedia[] = [
  { name: "Warm welcome", url: HERO_PHOTO, category: "Study moods" },
  { name: "Daydream postcard", url: GALLERY_PHOTO, category: "Study moods" },
  { name: "Open notebook", url: SUBJECT_ENGLISH_PHOTO, category: "Study moods" },
  { name: "Desk & greenery", url: SUBJECT_BIOLOGY_PHOTO, category: "Calm places" },
  { name: "Quiet corner", url: SUBJECT_HISTORY_PHOTO, category: "Calm places" },
  { name: "Soft light", url: SUBJECT_CHEMISTRY_PHOTO, category: "Calm places" },
  /* watercolor study plates — one per workspace subject */
  { name: "Night moth study", url: ART_NIGHT_MOTH, category: "Subject sketches" },
  { name: "Amber alchemy", url: ART_AMBER_ALCHEMY, category: "Subject sketches" },
  { name: "Golden spiral", url: ART_GOLDEN_SPIRAL, category: "Margin notes" },
  { name: "Sealed letters", url: ART_SEALED_LETTERS, category: "Margin notes" },
  /* scenes from the rest of the workspace */
  { name: "Annotated margins", url: ART_ANNOTATED_MARGINS, category: "Desk stories" },
  { name: "Lamplight chapter", url: ART_LAMPLIGHT, category: "Desk stories" },
  { name: "Ember hour", url: ART_EMBER_HOUR, category: "Slow evenings" },
  { name: "Side A, side B", url: ART_SIDE_A, category: "Slow evenings" },
  { name: "Third-floor stars", url: ART_THIRD_FLOOR_STARS, category: "Outside pages" },
  { name: "Field day notes", url: ART_FIELD_DAY, category: "Outside pages" },
];
