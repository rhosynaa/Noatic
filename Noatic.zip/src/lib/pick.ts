/** Deterministic "random" pick that rotates every day (client- and server-safe). */
export function pickOfDay<T>(arr: T[]): T | null {
  if (arr.length === 0) return null;
  const now = new Date();
  const seed =
    now.getFullYear() * 1000 +
    Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000);
  // xorshift-style hash so consecutive days hop around the list
  let h = seed ^ 0x9e3779b9;
  h = Math.imul(h ^ (h >>> 16), 0x45d9f3b);
  h = Math.imul(h ^ (h >>> 16), 0x45d9f3b);
  h = (h ^ (h >>> 16)) >>> 0;
  return arr[h % arr.length];
}
