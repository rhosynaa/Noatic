"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useDashboard } from "@/lib/dashboard-context";
import { useSections } from "@/lib/sections-context";
import { useToast } from "@/lib/toast";
import type { MindMapLink, Workspace } from "@/lib/types";

/** A mind map row as the sidebar list and canvas consume it. */
export type MindMapInfo = {
  id: string;
  name: string;
  /** every note/subject this map is linked to — an unlimited list */
  links: MindMapLink[];
  nodeCount: number;
};

/** Fetch all mind maps (with node counts) — shared by every surface. */
export function useMindmapsList(enabled = true) {
  const [maps, setMaps] = useState<MindMapInfo[]>([]);
  const refresh = useCallback(async () => {
    try {
      setMaps(await api<MindMapInfo[]>("/api/mindmaps"));
    } catch {
      /* quiet — the caller keeps its last good list */
    }
  }, []);
  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    api<MindMapInfo[]>("/api/mindmaps")
      .then((rows) => {
        if (!cancelled) setMaps(rows);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [enabled]);
  return { maps, refresh };
}

/** Look up the first mind map linked to a given note or subject (or null). */
export function findLinkedMap(
  maps: MindMapInfo[],
  type: "note" | "subject",
  id: string
): MindMapInfo | null {
  return maps.find((m) => (m.links ?? []).some((l) => l.type === type && l.id === id)) ?? null;
}

/**
 * Jump to whatever a mind map is linked to — the note opens in its editor on
 * the dashboard, the subject opens its note library. Returns false when the
 * target is gone so callers can offer to clear the link.
 */
export function useOpenLinkTarget() {
  const { closeSection, closeMindmap, exitWorkspace, openWorkspace, openLibrary } =
    useSections();
  const { notes, subjects, setEditingNote } = useDashboard();
  const { push } = useToast();

  return useCallback(
    async (target: { type: "note" | "subject"; id: string }): Promise<boolean> => {
      if (target.type === "note") {
        const note = notes.find((n) => n.id === target.id);
        if (!note) {
          push("error", "That note doesn't exist anymore — unlink this map");
          return false;
        }
        // land on the widget dashboard, where the note editor lives
        closeMindmap();
        closeSection();
        exitWorkspace();
        setEditingNote(note.id);
        return true;
      }
      const subject = subjects.find((s) => s.id === target.id);
      if (!subject) {
        push("error", "That subject doesn't exist anymore — unlink this map");
        return false;
      }
      closeMindmap();
      closeSection();
      try {
        const wss = await api<Workspace[]>("/api/workspaces");
        const ws = wss.find((w) => w.id === subject.workspaceId) ?? wss[0];
        if (ws) openWorkspace({ id: ws.id, name: ws.name });
      } catch {
        /* no workspace reachable — the library still opens over the dashboard */
      }
      openLibrary({ id: subject.id, name: subject.name });
      push("info", `Opened ${subject.name} — the map stays linked in the sidebar`);
      return true;
    },
    [
      notes,
      subjects,
      closeMindmap,
      closeSection,
      exitWorkspace,
      openWorkspace,
      openLibrary,
      setEditingNote,
      push,
    ]
  );
}
