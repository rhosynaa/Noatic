"use client";

import { useEffect, useRef } from "react";
import { useDashboard } from "@/lib/dashboard-context";
import { useMusic } from "@/lib/music-context";
import { DEFAULT_ROTATE_SECONDS } from "@/lib/types";

/**
 * Drives the "shuffle a category" setting.
 *
 * Any image slot that has a `rotateCategory` gets a fresh random picture from
 * that category every `rotateSeconds`. The new picture is written to the slot
 * exactly like a manual change, so every place that already shows the slot
 * updates on its own — nothing else needed to know about rotation.
 */
export function useImageRotation() {
  const { images, media, setImage } = useDashboard();

  // keep the latest data in a ref so the timers never need re-creating
  const latest = useRef({ images, media, setImage });
  latest.current = { images, media, setImage };

  /* one timer per rotating slot, rebuilt only when the settings change */
  const signature = images
    .filter((i) => i.rotateCategory)
    .map((i) => `${i.key}:${i.rotateCategory}:${i.rotateSeconds ?? DEFAULT_ROTATE_SECONDS}`)
    .sort()
    .join("|");

  useEffect(() => {
    if (!signature) return;
    const timers: ReturnType<typeof setInterval>[] = [];

    for (const entry of signature.split("|")) {
      const [key, category, secsRaw] = entry.split(":");
      const secs = Number(secsRaw) || DEFAULT_ROTATE_SECONDS;

      const shuffle = () => {
        const { images: imgs, media: lib, setImage: put } = latest.current;
        const slot = imgs.find((i) => i.key === key);
        if (!slot?.rotateCategory) return;

        const pool = lib.filter(
          (m) => m.category.trim().toLowerCase() === category.trim().toLowerCase()
        );
        if (pool.length === 0) return;

        // never pick the picture that's already showing (unless it's the only one)
        const others = pool.length > 1 ? pool.filter((m) => m.url !== slot.url) : pool;
        const next = others[Math.floor(Math.random() * others.length)];
        // `silent` — a shuffle shouldn't pop a toast every interval
        if (next) void put(key, next.url, slot.label, true);
      };

      timers.push(setInterval(shuffle, secs * 1000));
    }

    return () => timers.forEach(clearInterval);
  }, [signature]);
}

/**
 * The same idea for everything else that has a cover: subject cards, note
 * images and music track art. Each rotation row names its target, so one
 * timer set drives them all.
 */
export function useCoverRotation() {
  const { coverRotations, media, updateSubject, updateNote } = useDashboard();
  const music = useMusic();

  const latest = useRef({ coverRotations, media, updateSubject, updateNote, music });
  latest.current = { coverRotations, media, updateSubject, updateNote, music };

  const signature = coverRotations
    .map((r) => `${r.target}~${r.refId}~${r.category}~${r.seconds}`)
    .sort()
    .join("|");

  useEffect(() => {
    if (!signature) return;
    const timers: ReturnType<typeof setInterval>[] = [];

    for (const entry of signature.split("|")) {
      const [target, refId, category, secsRaw] = entry.split("~");
      const secs = Number(secsRaw) || DEFAULT_ROTATE_SECONDS;

      const shuffle = () => {
        const l = latest.current;
        const pool = l.media.filter(
          (m) => m.category.trim().toLowerCase() === category.trim().toLowerCase()
        );
        if (pool.length === 0) return;

        // whatever is on the cover right now, so we can avoid repeating it
        const showing =
          target === "subject"
            ? undefined
            : target === "note"
              ? undefined
              : l.music.tracks.find((t) => t.id === refId)?.coverUrl;

        const others =
          pool.length > 1 && showing ? pool.filter((m) => m.url !== showing) : pool;
        const next = others[Math.floor(Math.random() * others.length)];
        if (!next) return;

        if (target === "subject") void l.updateSubject(refId, { coverUrl: next.url });
        else if (target === "note") void l.updateNote(refId, { imageUrl: next.url });
        else void l.music.updateTrackCover(refId, next.url, true);
      };

      timers.push(setInterval(shuffle, secs * 1000));
    }

    return () => timers.forEach(clearInterval);
  }, [signature]);
}

/** Mounted once by the shell so rotation runs app-wide. */
export default function ImageRotator() {
  useImageRotation();
  useCoverRotation();
  return null;
}
