export type Profile = {
  id: number;
  username: string;
  email: string;
  bio: string;
  pronouns: string;
  avatarUrl: string;
  googleConnected: boolean;
  googleEmail: string | null;
  autoSync: boolean;
  lastSyncAt: string | null;
};

export type Settings = {
  darkMode: boolean;
  accent: string;
  desktopMode: boolean;
  musicShuffle: boolean;
  widgetOrder: string[];
  hiddenWidgets: string[];
};

export type TaskPriority = "low" | "medium" | "high";

export type Task = {
  id: string;
  title: string;
  time: string;
  priority: TaskPriority;
  subject: string;
  dueDate: string | null;
  done: boolean;
  position: number;
};

export type Deadline = {
  id: string;
  title: string;
  subject: string;
  color: string;
  dueDate: string;
  done: boolean;
};

export type QuoteRow = {
  id: string;
  text: string;
  author: string;
  kind: "quote" | "motivation";
};

export type Track = {
  id: string;
  title: string;
  artist: string;
  coverUrl: string;
  sourceType: "audio" | "youtube" | "spotify";
  url: string;
  position: number;
};

export type Playlist = {
  id: string;
  name: string;
  coverUrl: string;
  position: number;
  trackIds: string[];
};

export type CoverOption = {
  id: string;
  label: string;
  url: string;
};

import { ASSET_MAP } from "@/lib/assets";

/** Built-in cover art used when a track has no artwork of its own. */
export const DEFAULT_COVER_LIST: CoverOption[] = [
  { id: "sunrise", label: "Sunrise", url: ASSET_MAP["/covers/sunrise.svg"] },
  { id: "dusk", label: "Dusk", url: ASSET_MAP["/covers/dusk.svg"] },
  { id: "rain", label: "Rain", url: ASSET_MAP["/covers/rain.svg"] },
  { id: "meadow", label: "Meadow", url: ASSET_MAP["/covers/meadow.svg"] },
  { id: "ember", label: "Ember", url: ASSET_MAP["/covers/ember.svg"] },
];

export const DEFAULT_COVERS = DEFAULT_COVER_LIST.map((c) => c.url);

/** Stable per-id pick so a track always gets the same fallback art. */
export function coverFor(id: string, coverUrl?: string): string {
  if (coverUrl && coverUrl.trim()) return coverUrl;
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return DEFAULT_COVERS[h % DEFAULT_COVERS.length];
}

export type Note = {
  id: string;
  title: string;
  content: string;
  color: string;
  subject: string;
  tags: string[];
  imageUrl: string;
  pinned: boolean;
  updatedAt: string;
};

/** "#Exam Prep" / " exam prep " → "Exam Prep" */
export function normalizeTag(raw: string): string {
  return raw.replace(/^#+/, "").trim().replace(/\s+/g, " ").slice(0, 24);
}

export type Template = {
  id: string;
  title: string;
  accent: string;
  content: string;
};

export type SiteImage = {
  key: string;
  label: string;
  url: string;
  /** when set, this slot cycles at random through the media of that category */
  rotateCategory?: string;
  /** how often the rotation picks a new picture, in seconds */
  rotateSeconds?: number;
};

/** One picture (or GIF) saved in the media library. */
export type MediaItem = {
  id: string;
  /** data URL or remote link */
  url: string;
  name: string;
  /** free-text folder, e.g. "Wallpapers" */
  category: string;
  createdAt: string;
};

/** The rotation speeds a slot can be set to — 30 seconds up to an hour. */
export const ROTATE_INTERVALS: { value: number; label: string }[] = [
  { value: 30, label: "Every 30 seconds" },
  { value: 60, label: "Every minute" },
  { value: 300, label: "Every 5 minutes" },
  { value: 900, label: "Every 15 minutes" },
  { value: 1800, label: "Every 30 minutes" },
  { value: 3600, label: "Every hour" },
];
export const ROTATE_MIN_SECONDS = 30;
export const ROTATE_MAX_SECONDS = 3600;
export const DEFAULT_ROTATE_SECONDS = 60;
/** Media library category used by the seeded demo pictures. */
export const DEMO_MEDIA_CATEGORY = "Study moods";

/**
 * A cover that shuffles itself. `target` says what the picture belongs to,
 * so subject cards, notes and tracks can rotate just like the site images.
 */
export type RotationTarget = "subject" | "note" | "track";

export type CoverRotation = {
  id: string;
  target: RotationTarget;
  /** the subject / note / track id */
  refId: string;
  category: string;
  seconds: number;
};

export type Subject = {
  id: string;
  name: string;
  color: string;
  /** which workspace this subject belongs to */
  workspaceId?: string;
  /** short code shown on the card, e.g. "BIO 101" */
  code?: string;
  /** semester / term shown on the card, e.g. "Fall 2022" */
  semester?: string;
  /** card cover image (data URL or link) */
  coverUrl?: string;
};

/** A workspace groups its own set of subjects (subject dashboard). */
export type Workspace = {
  id: string;
  name: string;
  position: number;
};

/** A self-graded score on a finished assignment, with my own commentary. */
export type SelfAssessment = {
  id: string;
  title: string;
  subject: string;
  score: number;
  maxScore: number;
  comment: string;
  assessedAt: string;
};

/** One row in the GPA calculator / tracker course table. */
export type GpaCourse = {
  id: string;
  name: string;
  grade: string;
  credits: number;
  /** bonus points: 0 regular · 0.5 honors · 1.0 AP/IB */
  weight: number;
  /** which semester slot (1–8) this course belongs to */
  semesterId?: string;
  /** free-text cell in the tracker's Notes column */
  notes?: string;
};

/** Grading-scale settings for the GPA tracker (custom points + weighted mode). */
export type GpaSettings = {
  /** point value for each letter grade (defaults to GRADE_POINTS) */
  scale: Record<string, number>;
  /** true = weighted GPA (adds AP/IB/Honors bonuses); false = unweighted */
  weighted: boolean;
  /** "Notes & Reflections" free text */
  notes: string;
};

export type GpaChecklistItem = { text: string; done: boolean };

/** One of the eight semester slots in the GPA tracker. */
export type GpaSemester = {
  id: string;
  name: string;
  academicYear: string;
  /** the goal itself — a brief sentence, not just a number */
  targetGpa: string;
  /** "I will achieve this by" date */
  achieveBy: string;
  checklist: GpaChecklistItem[];
  /** manually ticked in the Semester Progress table */
  achieved?: boolean;
};

/* word budgets for the tracker's free-text fields */
export const GPA_GOAL_MAX_WORDS = 50;
export const GPA_GOAL_WORDS_PER_LINE = 20;
export const GPA_NOTES_MAX_WORDS = 70;
export const GPA_NOTES_WORDS_PER_LINE = 25;
/* …and for the per-course notes column in the course table */
export const GPA_COURSE_NOTES_MAX_WORDS = 70;
export const GPA_COURSE_NOTES_WORDS_PER_LINE = 25;

/** Words in a chunk of text. */
export function countWords(text: string): number {
  return text.split(/\s+/).filter(Boolean).length;
}

/**
 * Caps `raw` at `maxWords` and re-flows it so each line holds at most
 * `perLine` words. A single trailing space is kept so typing feels normal.
 */
export function wrapByWords(raw: string, maxWords: number, perLine: number): string {
  const endsOpen = /\s$/.test(raw);
  const words = raw.split(/\s+/).filter(Boolean).slice(0, maxWords);
  const lines: string[] = [];
  for (let i = 0; i < words.length; i += perLine) lines.push(words.slice(i, i + perLine).join(" "));
  let out = lines.join("\n");
  if (endsOpen && words.length > 0 && words.length < maxWords) out += " ";
  return out;
}

/** Percentage bands for the GPA scale reference table. */
export const GPA_PERCENT: Record<string, string> = {
  "A+": "97 – 100%",
  A: "93 – 100%",
  "A-": "90 – 92%",
  "B+": "87 – 89%",
  B: "83 – 86%",
  "B-": "80 – 82%",
  "C+": "77 – 79%",
  C: "73 – 76%",
  "C-": "70 – 72%",
  "D+": "67 – 69%",
  D: "60 – 66%",
  F: "0 – 59%",
};

/** Default action-plan items for a semester heading. */
export const DEFAULT_GPA_CHECKLIST: string[] = [
  "Attending all classes",
  "Staying organized",
  "Completing assignments on time",
  "Studying consistently",
  "Asking for help when needed",
];

export const GRADE_POINTS: Record<string, number> = {
  "A+": 4.0,
  A: 4.0,
  "A-": 3.7,
  "B+": 3.3,
  B: 3.0,
  "B-": 2.7,
  "C+": 2.3,
  C: 2.0,
  "C-": 1.7,
  "D+": 1.3,
  D: 1.0,
  F: 0,
};

export const GPA_WEIGHTS: { label: string; value: number }[] = [
  { label: "Regular", value: 0 },
  { label: "Honors", value: 0.5 },
  { label: "AP / IB", value: 1 },
];

export type Flashcard = {
  id: string;
  subject: string;
  front: string;
  back: string;
};

export type ReviewRating = "easy" | "good" | "hard";

export type FlashcardReview = {
  id: string;
  cardId: string;
  rating: ReviewRating;
  subject: string;
  reviewedAt: string;
};

export const RATING_META: Record<
  ReviewRating,
  { label: string; color: string; hint: string }
> = {
  easy: { label: "Easy", color: "#6d9e7d", hint: "Knew it instantly" },
  good: { label: "Good", color: "#cf9c44", hint: "Got there with effort" },
  hard: { label: "Hard", color: "#d4705c", hint: "Struggled — review again" },
};

export type RatingCounts = { easy: number; good: number; hard: number; total: number };

export type ReviewBucket = {
  key: string;
  label: string;
} & RatingCounts;

export type ReviewStats = {
  daily: ReviewBucket[];
  weekly: ReviewBucket[];
  monthly: ReviewBucket[];
  totals: RatingCounts;
  /** cards whose most recent rating was "hard" */
  hardCardIds: string[];
  bySubject: ({ subject: string; color: string } & RatingCounts)[];
  recent: (FlashcardReview & { front: string | null })[];
};

export type MindNode = {
  id: string;
  /** which mind map this node belongs to */
  mapId: string;
  parentId: string | null;
  text: string;
  x: number;
  y: number;
};

/** One note or subject tied to a mind map — jumps there in one click. */
export type MindMapLink = {
  type: "note" | "subject";
  id: string;
};

/** A whole mind map canvas, listed in the sidebar's Mind map section. */
export type MindMap = {
  id: string;
  name: string;
  /** every note/subject this map jumps to — an unlimited list */
  links: MindMapLink[];
};

export type TimerKind = "focus" | "short" | "long" | "custom";

export type FocusSession = {
  id: string;
  minutes: number;
  kind: TimerKind;
  subject: string;
  label: string;
  noteId: string | null;
  completedAt: string;
};

export type TargetScope = "subject" | "note";

export type StudyTarget = {
  id: string;
  scope: TargetScope;
  ref: string;
  targetHours: number;
};

/** a target joined with the time actually logged against it */
export type TargetProgress = {
  id: string;
  scope: TargetScope;
  ref: string;
  /** display name — subject name or note title */
  name: string;
  color: string;
  targetHours: number;
  loggedMinutes: number;
  percent: number;
  remainingMinutes: number;
};

export type ProgressBucket = {
  key: string;
  label: string;
  minutes: number;
};

export type ProgressData = {
  daily: ProgressBucket[];
  weekly: ProgressBucket[];
  monthly: ProgressBucket[];
  targets: TargetProgress[];
  entries: (FocusSession & { noteTitle: string | null })[];
  totalLoggedMinutes: number;
};

export type TimerPreset = {
  id: string;
  label: string;
  minutes: number;
  kind: TimerKind;
  /** empty string = available to any subject */
  subject: string;
};

export type ChainStep = {
  kind: TimerKind;
  minutes: number;
  subject?: string;
  label?: string;
};

export type TimerChain = {
  id: string;
  name: string;
  steps: ChainStep[];
  subject: string;
  transitionSec: number;
};

export const TIMER_KIND_META: Record<TimerKind, { label: string; hint: string }> = {
  focus: { label: "Focus", hint: "Deep work block" },
  short: { label: "Short Break", hint: "Stretch & sip water" },
  long: { label: "Long Break", hint: "A proper reset" },
  custom: { label: "Custom", hint: "Your own session" },
};

export const DEFAULT_PRESETS: Record<"focus" | "short" | "long", number[]> = {
  focus: [15, 25, 45, 60],
  short: [5, 10],
  long: [15, 30],
};

export type TrashType = "task" | "note" | "deadline" | "flashcard";

export type TrashBin = {
  tasks: (Task & { deletedAt: string | null })[];
  notes: (Note & { deletedAt: string | null })[];
  deadlines: (Deadline & { deletedAt: string | null })[];
  flashcards: (Flashcard & { deletedAt: string | null })[];
};

export type AnalyticsData = {
  doneLast7: { date: string; label: string; count: number }[];
  focusLast7: { date: string; label: string; minutes: number }[];
  totals: {
    tasksTotal: number;
    tasksDone: number;
    notes: number;
    quotes: number;
    flashcards: number;
    subjects: number;
  };
  deadlinesBySubject: { subject: string; color: string; count: number }[];
  studyBySubject: { subject: string; color: string; totalMinutes: number; weekMinutes: number }[];
  todayFocusMinutes: number;
  streak: number;
};

export type DashboardData = {
  profile: Profile;
  settings: Settings;
  tasks: Task[];
  deadlines: Deadline[];
  quotes: QuoteRow[];
  notes: Note[];
  templates: Template[];
  images: SiteImage[];
  media: MediaItem[];
  coverRotations: CoverRotation[];
  subjects: Subject[];
};

export const WIDGET_META: Record<
  string,
  { title: string; span: string; description: string }
> = {
  plan: {
    title: "Today's Plan",
    span: "@3xl:col-span-7",
    description: "Tasks and checkboxes for the day",
  },
  deadlines: {
    title: "Deadlines",
    span: "@3xl:col-span-5",
    description: "Upcoming due dates, synced to the bell",
  },
  music: {
    title: "Music Room",
    span: "@3xl:col-span-5",
    description: "Lo-fi player with Spotify & YouTube links",
  },
  quote: {
    title: "Quote of the Day",
    span: "@3xl:col-span-7",
    description: "A fresh quote & motivation every day",
  },
  notes: {
    title: "Recent Notes",
    span: "@3xl:col-span-7",
    description: "Your latest thoughts, pinned and fresh",
  },
  focus: {
    title: "Focus Timer",
    span: "@3xl:col-span-5",
    description: "Pomodoro sessions with a calm ring",
  },
  gallery: {
    title: "Daydream",
    span: "@3xl:col-span-12",
    description: "A changeable image to breathe between tasks",
  },
};

export const DEFAULT_WIDGET_ORDER = [
  "plan",
  "deadlines",
  "music",
  "quote",
  "notes",
  "focus",
  "gallery",
];

export const ACCENTS: Record<
  string,
  { name: string; accent: string; soft: string; ink: string }
> = {
  bloom: { name: "Bloom", accent: "#d6457f", soft: "rgba(214,69,127,0.13)", ink: "#fff5f9" },
  rosewood: { name: "Rosewood", accent: "#b05c4a", soft: "rgba(176,92,74,0.14)", ink: "#fff6f1" },
  lavender: { name: "Lavender Dusk", accent: "#7c6bb0", soft: "rgba(124,107,176,0.16)", ink: "#f6f3ff" },
  fern: { name: "Fern", accent: "#52796f", soft: "rgba(82,121,111,0.15)", ink: "#f1f8f4" },
  honey: { name: "Honey", accent: "#bc8a3b", soft: "rgba(188,138,59,0.16)", ink: "#fffaf0" },
};

export const NOTE_COLORS: Record<string, { bg: string; label: string }> = {
  cream: { bg: "#fdf6e8", label: "Cream" },
  blush: { bg: "#fdeee9", label: "Blush" },
  lilac: { bg: "#f1edfb", label: "Lilac" },
  mint: { bg: "#ecf5ef", label: "Mint" },
  sky: { bg: "#eaf3fa", label: "Sky" },
};

export const DEADLINE_COLORS: Record<string, string> = {
  rose: "#d4705c",
  amber: "#cf9c44",
  violet: "#8b7bc4",
  green: "#6d9e7d",
  blue: "#6c93bf",
};
