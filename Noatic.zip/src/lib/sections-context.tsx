"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api } from "@/lib/api";
import type { Workspace } from "@/lib/types";

/** Slide-out drawer panels. The subject dashboard is NOT one of these. */
export type SectionKey =
  | "tasks"
  | "calendar"
  | "flashcards"
  | "workspaces"
  | "mindmap"
  | "analytics"
  | "timer"
  | "quotes"
  | "selfassessments"
  | "gpatracker"
  | "trash"
  | null;

/** The workspace whose subject dashboard owns the main content area. */
export type ActiveWorkspace = { id: string; name: string } | null;

/** The subject whose note library (book-cover grid) is open. */
export type ActiveLibrary = { id: string; name: string } | null;

/** The mind map whose canvas owns a drawer right now. */
export type ActiveMindmap = { id: string; name: string } | null;

type SectionsCtxType = {
  open: SectionKey;
  openSection: (key: Exclude<SectionKey, null>) => void;
  closeSection: () => void;

  /** non-null = the main content area is showing that workspace's subject dashboard */
  workspace: ActiveWorkspace;
  /** open a workspace full-screen in the main content area (closes the selector) */
  openWorkspace: (ws: NonNullable<ActiveWorkspace>) => void;
  /** leave the subject dashboard and go back to the widget dashboard */
  exitWorkspace: () => void;

  /** non-null = the subject view is drilled into one subject's note library */
  library: ActiveLibrary;
  /** open a subject's note library (book-cover grid) inside the subject view */
  openLibrary: (subject: NonNullable<ActiveLibrary>) => void;
  /** go back from the library to the subject card grid */
  closeLibrary: () => void;

  /** non-null = the mind map canvas drawer is showing that map */
  mindmap: ActiveMindmap;
  /** open one mind map's canvas (closes the map list drawer) */
  openMindmap: (map: NonNullable<ActiveMindmap>) => void;
  /** close the canvas and leave any map */
  closeMindmap: () => void;
};

const SectionsCtx = createContext<SectionsCtxType>({
  open: null,
  openSection: () => {},
  closeSection: () => {},
  workspace: null,
  openWorkspace: () => {},
  exitWorkspace: () => {},
  library: null,
  openLibrary: () => {},
  closeLibrary: () => {},
  mindmap: null,
  openMindmap: () => {},
  closeMindmap: () => {},
});

export function useSections() {
  return useContext(SectionsCtx);
}

export function SectionsProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState<SectionKey>(null);
  const [workspace, setWorkspace] = useState<ActiveWorkspace>(null);
  const [library, setLibrary] = useState<ActiveLibrary>(null);
  const [mindmap, setMindmap] = useState<ActiveMindmap>(null);
  const autoOpened = useRef(false);

  /* Land on the subject dashboard (with its workspace sidebar) on first mount,
     so the preview opens on the reference layout: cards left, stats rail right. */
  useEffect(() => {
    if (autoOpened.current) return;
    autoOpened.current = true;
    let cancelled = false;
    api<Workspace[]>("/api/workspaces")
      .then((ws) => {
        if (!cancelled && ws.length > 0) setWorkspace({ id: ws[0].id, name: ws[0].name });
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  /** opening any section drawer closes the mind map canvas, never the map list */
  const openSection = useCallback((key: Exclude<SectionKey, null>) => {
    setOpen(key);
    setMindmap(null);
  }, []);
  /** closing a drawer never disturbs the workspace shown in the main area */
  const closeSection = useCallback(() => setOpen(null), []);

  const openWorkspace = useCallback((ws: NonNullable<ActiveWorkspace>) => {
    setWorkspace(ws);
    setOpen(null);
    setLibrary(null); // switching workspace leaves any open library
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const exitWorkspace = useCallback(() => {
    setWorkspace(null);
    setLibrary(null);
  }, []);

  const openLibrary = useCallback((subject: NonNullable<ActiveLibrary>) => {
    setLibrary(subject);
    setOpen(null);
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const closeLibrary = useCallback(() => setLibrary(null), []);

  const openMindmap = useCallback((map: NonNullable<ActiveMindmap>) => {
    setMindmap(map);
    setOpen(null); // the list drawer hands over to the canvas
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const closeMindmap = useCallback(() => setMindmap(null), []);

  const value = useMemo(
    () => ({
      open,
      openSection,
      closeSection,
      workspace,
      openWorkspace,
      exitWorkspace,
      library,
      openLibrary,
      closeLibrary,
      mindmap,
      openMindmap,
      closeMindmap,
    }),
    [
      open,
      openSection,
      closeSection,
      workspace,
      openWorkspace,
      exitWorkspace,
      library,
      openLibrary,
      closeLibrary,
      mindmap,
      openMindmap,
      closeMindmap,
    ]
  );
  return <SectionsCtx.Provider value={value}>{children}</SectionsCtx.Provider>;
}
