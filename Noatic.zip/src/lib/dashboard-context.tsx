"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api } from "@/lib/api";
import { useToast } from "@/lib/toast";
import type {
  DashboardData,
  Deadline,
  Note,
  QuoteRow,
  SiteImage,
  MediaItem,
  CoverRotation,
  Subject,
  Task,
  Template,
} from "@/lib/types";

type DashboardCtxType = {
  tasks: Task[];
  toggleTask: (id: string) => void;
  addTask: (
    title: string,
    time: string,
    extra?: { priority?: Task["priority"]; subject?: string; dueDate?: string | null }
  ) => Promise<void>;
  deleteTask: (id: string) => void;

  deadlines: Deadline[];
  addDeadline: (data: { title: string; subject: string; color: string; dueDate: string }) => Promise<void>;
  toggleDeadline: (id: string) => void;
  deleteDeadline: (id: string) => void;

  quotes: QuoteRow[];
  addQuote: (data: { text: string; author: string; kind: "quote" | "motivation" }) => Promise<void>;
  updateQuote: (id: string, patch: Partial<QuoteRow>) => Promise<void>;
  deleteQuote: (id: string) => void;

  notes: Note[];
  addNote: (data: Partial<Note>) => Promise<Note | null>;
  updateNote: (id: string, patch: Partial<Note>) => Promise<void>;
  deleteNote: (id: string) => void;
  editingNoteId: string | null;
  setEditingNote: (id: string | null) => void;

  templates: Template[];
  addTemplate: (data: { title: string; accent: string; content: string }) => Promise<void>;
  deleteTemplate: (id: string) => void;

  images: SiteImage[];
  setImage: (key: string, url: string, label?: string, silent?: boolean) => Promise<boolean>;
  /** point a slot at a media category so it shuffles, or pass null to stop */
  setImageRotation: (
    key: string,
    category: string | null,
    seconds: number,
    label?: string
  ) => Promise<boolean>;

  /** covers that shuffle themselves — subject cards, notes, track art */
  coverRotations: CoverRotation[];
  setCoverRotation: (
    target: CoverRotation["target"],
    refId: string,
    category: string | null,
    seconds: number
  ) => Promise<void>;

  media: MediaItem[];
  addMedia: (data: { url: string; name: string; category: string }) => Promise<MediaItem | null>;
  updateMedia: (id: string, patch: Partial<MediaItem>) => Promise<void>;
  deleteMedia: (id: string) => void;

  subjects: Subject[];
  addSubject: (
    name: string,
    color: string,
    workspaceId?: string,
    code?: string,
    semester?: string
  ) => Promise<void>;
  updateSubject: (
    id: string,
    patch: Partial<Pick<Subject, "name" | "color" | "code" | "semester" | "coverUrl">>
  ) => Promise<boolean>;
  deleteSubject: (id: string) => void;

  reloadAll: () => Promise<void>;
};

const DashboardCtx = createContext<DashboardCtxType | null>(null);

export function useDashboard(): DashboardCtxType {
  const ctx = useContext(DashboardCtx);
  if (!ctx) throw new Error("useDashboard must be used inside DashboardShell");
  return ctx;
}

function sortNotes(list: Note[]): Note[] {
  return [...list].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });
}

export function DashboardProvider({
  children,
  initial,
}: {
  children: ReactNode;
  initial: DashboardData;
}) {
  const { push } = useToast();
  const [tasks, setTasks] = useState<Task[]>(initial.tasks);
  const [deadlines, setDeadlines] = useState<Deadline[]>(initial.deadlines);
  const [quotes, setQuotes] = useState<QuoteRow[]>(initial.quotes);
  const [notes, setNotes] = useState<Note[]>(sortNotes(initial.notes));
  const [templates, setTemplates] = useState<Template[]>(initial.templates);
  const [images, setImages] = useState<SiteImage[]>(initial.images);
  const [media, setMedia] = useState<MediaItem[]>(initial.media ?? []);
  const [coverRotations, setCoverRotations] = useState<CoverRotation[]>(
    initial.coverRotations ?? []
  );
  const [subjects, setSubjects] = useState<Subject[]>(initial.subjects);
  const [editingNoteId, setEditingNote] = useState<string | null>(null);
  // generation guard so out-of-order PATCH responses can't clobber UI state
  const gen = useRef(0);

  /* ---------- tasks (fix #1: instant toggle, zero reloads) ---------- */

  const toggleTask = useCallback(
    (id: string) => {
      const before = tasks;
      const target = tasks.find((t) => t.id === id);
      if (!target) return;
      const doneNow = !target.done;
      setTasks((ts) => ts.map((t) => (t.id === id ? { ...t, done: doneNow } : t)));
      if (doneNow) push("success", "One step closer — task done");
      api<Task>(`/api/tasks/${id}`, { method: "PATCH", body: { done: doneNow } }).catch(() => {
        setTasks(before);
        push("error", "Couldn't save that — check your connection");
      });
    },
    [tasks, push]
  );

  const addTask = useCallback(
    async (
      title: string,
      time: string,
      extra?: { priority?: Task["priority"]; subject?: string; dueDate?: string | null }
    ) => {
      const clean = title.trim();
      if (!clean) return;
      const myGen = ++gen.current;
      const tempId = `tmp-${myGen}`;
      const optimistic: Task = {
        id: tempId,
        title: clean,
        time: time ?? "",
        priority: extra?.priority ?? "medium",
        subject: extra?.subject ?? "",
        dueDate: extra?.dueDate ?? null,
        done: false,
        position: 0,
      };
      // functional update — never depends on a captured tasks array
      setTasks((ts) => [...ts, { ...optimistic, position: ts.length }]);
      try {
        const row = await api<Task>("/api/tasks", {
          method: "POST",
          body: {
            title: clean,
            time: optimistic.time,
            priority: optimistic.priority,
            subject: optimistic.subject,
            dueDate: optimistic.dueDate ?? "",
          },
        });
        setTasks((ts) => ts.map((t) => (t.id === tempId ? row : t)));
      } catch (e) {
        setTasks((ts) => ts.filter((t) => t.id !== tempId));
        push("error", e instanceof Error ? e.message : "Couldn't add that task");
      }
    },
    [push]
  );

  const deleteTask = useCallback(
    (id: string) => {
      const before = tasks;
      setTasks((ts) => ts.filter((t) => t.id !== id));
      api(`/api/tasks/${id}`, { method: "DELETE" }).catch(() => {
        setTasks(before);
        push("error", "Couldn't delete that task");
      });
    },
    [tasks, push]
  );

  /* ---------- deadlines ---------- */

  const addDeadline = useCallback(
    async (data: { title: string; subject: string; color: string; dueDate: string }) => {
      try {
        const row = await api<Deadline>("/api/deadlines", { method: "POST", body: data });
        setDeadlines((d) =>
          [...d, row].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
        );
        push("success", "Deadline added — the bell is watching it");
      } catch {
        push("error", "Couldn't add that deadline");
      }
    },
    [push]
  );

  const toggleDeadline = useCallback(
    (id: string) => {
      const before = deadlines;
      const target = deadlines.find((d) => d.id === id);
      if (!target) return;
      setDeadlines((ds) => ds.map((d) => (d.id === id ? { ...d, done: !d.done } : d)));
      api(`/api/deadlines/${id}`, { method: "PATCH", body: { done: !target.done } }).catch(() => {
        setDeadlines(before);
        push("error", "Couldn't update that deadline");
      });
    },
    [deadlines, push]
  );

  const deleteDeadline = useCallback(
    (id: string) => {
      const before = deadlines;
      setDeadlines((ds) => ds.filter((d) => d.id !== id));
      api(`/api/deadlines/${id}`, { method: "DELETE" }).catch(() => {
        setDeadlines(before);
        push("error", "Couldn't delete that deadline");
      });
    },
    [deadlines, push]
  );

  /* ---------- quotes ---------- */

  const addQuote = useCallback(
    async (data: { text: string; author: string; kind: "quote" | "motivation" }) => {
      try {
        const row = await api<QuoteRow>("/api/quotes", { method: "POST", body: data });
        setQuotes((q) => [...q, row]);
        push("success", data.kind === "quote" ? "Quote added" : "Motivation added");
      } catch {
        push("error", "Couldn't save that line");
      }
    },
    [push]
  );

  const updateQuote = useCallback(
    async (id: string, patch: Partial<QuoteRow>) => {
      const before = quotes;
      setQuotes((q) => q.map((x) => (x.id === id ? { ...x, ...patch } : x)));
      try {
        await api(`/api/quotes/${id}`, { method: "PATCH", body: patch });
      } catch {
        setQuotes(before);
        push("error", "Couldn't update that line");
      }
    },
    [quotes, push]
  );

  const deleteQuote = useCallback(
    (id: string) => {
      const before = quotes;
      setQuotes((q) => q.filter((x) => x.id !== id));
      api(`/api/quotes/${id}`, { method: "DELETE" }).catch(() => {
        setQuotes(before);
        push("error", "Couldn't delete that line");
      });
    },
    [quotes, push]
  );

  /* ---------- notes ---------- */

  const addNote = useCallback(
    async (data: Partial<Note>) => {
      try {
        const row = await api<Note>("/api/notes", { method: "POST", body: data });
        setNotes((n) => sortNotes([row, ...n]));
        return row;
      } catch {
        push("error", "Couldn't create that note");
        return null;
      }
    },
    [push]
  );

  const updateNote = useCallback(
    async (id: string, patch: Partial<Note>) => {
      const before = notes;
      setNotes((n) =>
        sortNotes(
          n.map((x) =>
            x.id === id ? { ...x, ...patch, updatedAt: new Date().toISOString() } : x
          )
        )
      );
      try {
        await api(`/api/notes/${id}`, { method: "PATCH", body: patch });
      } catch {
        setNotes(before);
        push("error", "Couldn't save that note");
      }
    },
    [notes, push]
  );

  const deleteNote = useCallback(
    (id: string) => {
      const before = notes;
      setNotes((n) => n.filter((x) => x.id !== id));
      api(`/api/notes/${id}`, { method: "DELETE" }).catch(() => {
        setNotes(before);
        push("error", "Couldn't delete that note");
      });
    },
    [notes, push]
  );

  /* ---------- templates ---------- */

  const addTemplate = useCallback(
    async (data: { title: string; accent: string; content: string }) => {
      try {
        const row = await api<Template>("/api/templates", { method: "POST", body: data });
        setTemplates((t) => [...t, row]);
        push("success", "Template saved — find it under New note → Template");
      } catch {
        push("error", "Couldn't save that template");
      }
    },
    [push]
  );

  const deleteTemplate = useCallback(
    (id: string) => {
      const before = templates;
      setTemplates((t) => t.filter((x) => x.id !== id));
      api(`/api/templates/${id}`, { method: "DELETE" }).catch(() => {
        setTemplates(before);
        push("error", "Couldn't delete that template");
      });
    },
    [templates, push]
  );

  /* ---------- images ---------- */

  const setImage = useCallback(
    async (key: string, url: string, label?: string, silent = false) => {
      const before = images;
      setImages((im) => {
        const exists = im.find((x) => x.key === key);
        return exists
          ? im.map((x) => (x.key === key ? { ...x, url } : x))
          : [...im, { key, label: label ?? key, url }];
      });
      try {
        await api("/api/images", { method: "PUT", body: { key, url, label } });
        // the auto-shuffle saves constantly, so it opts out of the toast
        if (!silent) push("success", "Image updated everywhere");
        return true;
      } catch (e) {
        setImages(before);
        push("error", e instanceof Error ? e.message : "Couldn't update that image");
        return false;
      }
    },
    [images, push]
  );

  /** turn a slot's random rotation on (a category) or off (null) */
  const setImageRotation = useCallback(
    async (key: string, category: string | null, seconds: number, label?: string) => {
      const before = images;
      const url = images.find((x) => x.key === key)?.url ?? "";
      setImages((im) =>
        im.map((x) =>
          x.key === key
            ? { ...x, rotateCategory: category ?? undefined, rotateSeconds: seconds }
            : x
        )
      );
      try {
        await api("/api/images", {
          method: "PUT",
          body: { key, url, label, rotateCategory: category ?? "", rotateSeconds: seconds },
        });
        push("success", category ? "Shuffle on — this picture will change itself" : "Shuffle off");
        return true;
      } catch (e) {
        setImages(before);
        push("error", e instanceof Error ? e.message : "Couldn't change that setting");
        return false;
      }
    },
    [images, push]
  );

  /** start or stop a shuffling cover for a subject / note / track */
  const setCoverRotation = useCallback(
    async (
      target: CoverRotation["target"],
      refId: string,
      category: string | null,
      seconds: number
    ) => {
      const before = coverRotations;
      setCoverRotations((rs) => {
        const rest = rs.filter((r) => !(r.target === target && r.refId === refId));
        return category
          ? [...rest, { id: `${target}:${refId}`, target, refId, category, seconds }]
          : rest;
      });
      try {
        await api("/api/cover-rotations", {
          method: "PUT",
          body: { target, refId, category: category ?? "", seconds },
        });
        push("success", category ? "Shuffle on for this cover" : "Shuffle off");
      } catch {
        setCoverRotations(before);
        push("error", "Couldn't change that setting");
      }
    },
    [coverRotations, push]
  );

  /* ---------- media library ---------- */

  const addMedia = useCallback(
    async (data: { url: string; name: string; category: string }) => {
      try {
        const row = await api<MediaItem>("/api/media", { method: "POST", body: data });
        setMedia((m) => [row, ...m]);
        push("success", "Added to your library");
        return row;
      } catch (e) {
        push("error", e instanceof Error ? e.message : "Couldn't save that picture");
        return null;
      }
    },
    [push]
  );

  const updateMedia = useCallback(
    async (id: string, patch: Partial<MediaItem>) => {
      const before = media;
      setMedia((m) => m.map((x) => (x.id === id ? { ...x, ...patch } : x)));
      try {
        await api(`/api/media/${id}`, { method: "PATCH", body: patch });
      } catch {
        setMedia(before);
        push("error", "Couldn't save that change");
      }
    },
    [media, push]
  );

  const deleteMedia = useCallback(
    (id: string) => {
      const before = media;
      setMedia((m) => m.filter((x) => x.id !== id));
      api(`/api/media/${id}`, { method: "DELETE" }).catch(() => {
        setMedia(before);
        push("error", "Couldn't remove that picture");
      });
    },
    [media, push]
  );

  /* ---------- subjects ---------- */

  const addSubject = useCallback(
    async (
      name: string,
      color: string,
      workspaceId?: string,
      code?: string,
      semester?: string
    ) => {
      try {
        const row = await api<Subject>("/api/subjects", {
          method: "POST",
          body: {
            name,
            color,
            workspaceId: workspaceId ?? "",
            code: code ?? "",
            semester: semester ?? "",
          },
        });
        setSubjects((s) => [...s, row]);
        push("success", `Subject "${row.name}" created`);
      } catch {
        push("error", "Couldn't add that subject");
      }
    },
    [push]
  );

  const updateSubject = useCallback(
    async (
      id: string,
      patch: Partial<Pick<Subject, "name" | "color" | "code" | "coverUrl">>
    ) => {
      const before = subjects;
      setSubjects((s) => s.map((x) => (x.id === id ? { ...x, ...patch } : x)));
      try {
        const row = await api<Subject>(`/api/subjects/${id}`, { method: "PATCH", body: patch });
        setSubjects((s) => s.map((x) => (x.id === id ? { ...x, ...row } : x)));
        return true;
      } catch {
        setSubjects(before);
        push("error", "Couldn't update that subject");
        return false;
      }
    },
    [subjects, push]
  );

  const deleteSubject = useCallback(
    (id: string) => {
      const before = subjects;
      setSubjects((s) => s.filter((x) => x.id !== id));
      api(`/api/subjects/${id}`, { method: "DELETE" }).catch(() => {
        setSubjects(before);
        push("error", "Couldn't delete that subject");
      });
    },
    [subjects, push]
  );

  /* ---------- restore-after-trash refresh ---------- */

  const reloadAll = useCallback(async () => {
    const safe = async <T,>(fn: () => Promise<T>) => {
      try {
        return await fn();
      } catch {
        return null;
      }
    };
    const [t, d, q, n, tp, im, sub, md] = await Promise.all([
      safe(() => api<Task[]>("/api/tasks")),
      safe(() => api<Deadline[]>("/api/deadlines")),
      safe(() => api<QuoteRow[]>("/api/quotes")),
      safe(() => api<Note[]>("/api/notes")),
      safe(() => api<Template[]>("/api/templates")),
      safe(() => api<SiteImage[]>("/api/images")),
      safe(() => api<Subject[]>("/api/subjects")),
      safe(() => api<MediaItem[]>("/api/media")),
    ]);
    if (t) setTasks(t);
    if (d) setDeadlines(d);
    if (q) setQuotes(q);
    if (n) setNotes(sortNotes(n));
    if (tp) setTemplates(tp);
    if (im) setImages(im);
    if (sub) setSubjects(sub);
    if (md) setMedia(md);
  }, []);

  const value = useMemo<DashboardCtxType>(
    () => ({
      tasks,
      toggleTask,
      addTask,
      deleteTask,
      deadlines,
      addDeadline,
      toggleDeadline,
      deleteDeadline,
      quotes,
      addQuote,
      updateQuote,
      deleteQuote,
      notes,
      addNote,
      updateNote,
      deleteNote,
      editingNoteId,
      setEditingNote,
      templates,
      addTemplate,
      deleteTemplate,
      images,
      setImage,
      setImageRotation,
      coverRotations,
      setCoverRotation,
      media,
      addMedia,
      updateMedia,
      deleteMedia,
      subjects,
      addSubject,
      updateSubject,
      deleteSubject,
      reloadAll,
    }),
    [
      tasks,
      toggleTask,
      addTask,
      deleteTask,
      deadlines,
      addDeadline,
      toggleDeadline,
      deleteDeadline,
      quotes,
      addQuote,
      updateQuote,
      deleteQuote,
      notes,
      addNote,
      updateNote,
      deleteNote,
      editingNoteId,
      templates,
      addTemplate,
      deleteTemplate,
      images,
      setImage,
      setImageRotation,
      coverRotations,
      setCoverRotation,
      media,
      addMedia,
      updateMedia,
      deleteMedia,
      subjects,
      addSubject,
      updateSubject,
      deleteSubject,
      reloadAll,
    ]
  );

  return <DashboardCtx.Provider value={value}>{children}</DashboardCtx.Provider>;
}
