"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, Info, XCircle } from "lucide-react";

type ToastType = "success" | "error" | "info";
type Toast = { id: number; type: ToastType; message: string };

const ToastCtx = createContext<{ push: (type: ToastType, message: string) => void }>({
  push: () => {},
});

export function useToast() {
  return useContext(ToastCtx);
}

let nextId = 1;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const push = useCallback((type: ToastType, message: string) => {
    const id = nextId++;
    setToasts((t) => [...t.slice(-3), { id, type, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3400);
  }, []);

  const value = useMemo(() => ({ push }), [push]);

  return (
    <ToastCtx.Provider value={value}>
      {children}
      {typeof document !== "undefined" &&
        createPortal(
          <div className="pointer-events-none fixed bottom-5 left-1/2 z-[120] flex w-full max-w-sm -translate-x-1/2 flex-col items-center gap-2 px-4">
            {toasts.map((t) => (
              <div
                key={t.id}
                className="animate-toast pointer-events-auto flex w-auto max-w-full items-center gap-2.5 rounded-full border px-4 py-2.5 text-[13px] font-medium shadow-[var(--card-shadow-hover)]"
                style={{
                  background: "var(--surface)",
                  borderColor: "var(--line)",
                  color: "var(--ink)",
                }}
              >
                {t.type === "success" && (
                  <CheckCircle2 size={16} style={{ color: "var(--accent)" }} />
                )}
                {t.type === "error" && <XCircle size={16} className="text-red-500" />}
                {t.type === "info" && <Info size={16} style={{ color: "var(--accent)" }} />}
                <span className="truncate">{t.message}</span>
              </div>
            ))}
          </div>,
          document.body
        )}
    </ToastCtx.Provider>
  );
}
